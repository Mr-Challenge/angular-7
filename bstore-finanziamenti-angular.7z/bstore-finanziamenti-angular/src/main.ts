import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
import { environmentLoader as environmentLoaderPromise } from './environments/environmentLoader';

environmentLoaderPromise.then(env => {

  if (env.production) {
    enableProdMode();
  }

  environment.bperTwainMock = env.bperTwainMock;
  environment.devUrlJSON = Object.assign(environment.devUrlJSON , env.devUrlJSON);

platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));
});
