import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BstoreAngularLibraryModule } from 'bstore-angular-library';
import { DettaglioImmobileComponent } from './components/dettaglio-immobile/dettaglio-immobile.component';
import { ImmobiliCommonComponent } from './components/immobili-common/immobili-common.component';
import { PolizzeProtezioneCommonComponent } from './components/polizze-protezione-common/polizze-protezione-common.component';
import { DettaglioImmobileButtonComponent } from './modules/immobili/components/dettaglio-immobile-button/dettaglio-immobile-button.component';
import { RichiediPeriziaButtonComponent } from './modules/immobili/components/richiedi-perizia-button/richiedi-perizia-button.component';
import { ForborneDetectionComponent } from './modules/product-configuration/components/forborne-detection/forborne-detection.component';

@NgModule({
  declarations: [
    ImmobiliCommonComponent,
    DettaglioImmobileComponent,
    RichiediPeriziaButtonComponent,
    DettaglioImmobileButtonComponent,
    PolizzeProtezioneCommonComponent,
    ForborneDetectionComponent],

  imports: [
    CommonModule,
    BstoreAngularLibraryModule,
    FormsModule,
    ReactiveFormsModule
  ],

  entryComponents: [
    ImmobiliCommonComponent,
    DettaglioImmobileComponent
  ],

  exports: [
    BstoreAngularLibraryModule,
    FormsModule,
    ImmobiliCommonComponent,
    DettaglioImmobileComponent,
    PolizzeProtezioneCommonComponent,
    ForborneDetectionComponent]
})
export class SharedModule { }
