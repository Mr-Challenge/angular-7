import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AntifrodeKOPopupComponent } from './antifrode-ko-popup.component';

describe('AntifrodeKOPopupComponent', () => {
  let component: AntifrodeKOPopupComponent;
  let fixture: ComponentFixture<AntifrodeKOPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AntifrodeKOPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AntifrodeKOPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
