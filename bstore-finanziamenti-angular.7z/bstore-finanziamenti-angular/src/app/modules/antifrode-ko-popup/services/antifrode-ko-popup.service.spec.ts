import { TestBed } from '@angular/core/testing';

import { AntifrodeKoPopupService } from './antifrode-ko-popup.service';

describe('AntifrodeKoPopupService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AntifrodeKoPopupService = TestBed.get(AntifrodeKoPopupService);
    expect(service).toBeTruthy();
  });
});
