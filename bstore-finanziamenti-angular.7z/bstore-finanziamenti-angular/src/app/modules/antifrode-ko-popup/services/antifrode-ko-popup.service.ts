import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {ComunicazioneNonAccoglimentoGenerica} from 'src/app/models/generateDoc.model';
import {EndpointsService} from "../../../services/endpoints.service";

@Injectable({
  providedIn: 'root'
})
export class AntifrodeKoPopupService {

  constructor(public httpClient:HttpClient, public endpointsService: EndpointsService) { }
  ComunicazioneNonAccoglimentoGenerica(comunicazioneNonAccoglimentoGenerica: ComunicazioneNonAccoglimentoGenerica) {
    return this.httpClient.post<any>(this.endpointsService.comunicazioneNonAccoglimentoGenerica, comunicazioneNonAccoglimentoGenerica);
  }
}
