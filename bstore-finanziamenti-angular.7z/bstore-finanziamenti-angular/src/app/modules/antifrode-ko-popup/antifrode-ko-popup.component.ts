import { Component, OnInit } from '@angular/core';
import { DialogModel, DialogRef, RedirectService } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { FinDocumentType } from 'src/app/constant/documentType';
import { ComunicazioneNonAccoglimentoGenerica } from 'src/app/models/generateDoc.model';
import { NotificationVm } from 'src/app/models/notificationVm.model';
import { CommonService } from 'src/app/services/common.service';
import { EndpointsService } from "../../services/endpoints.service";
import { BaseClientModel } from '../product-configuration/models/BaseClientModel';
import { SignatureStatusModel } from '../vendita/models/signature-status.model';
import { AntifrodeKoPopupService } from './services/antifrode-ko-popup.service';

@Component({
  selector: 'bst-fin-antifrode-ko-popup',
  templateUrl: './antifrode-ko-popup.component.html',
  styleUrls: ['./antifrode-ko-popup.component.scss']
})
export class AntifrodeKOPopupComponent implements OnInit {
  public idProposal: string;
  onDocumentoEvents: EventsModel[];
  onCloseEvents: EventsModel[];
  document: boolean;
  showPdf: boolean;
  signatureStatus: SignatureStatusModel;
  docGenerated: boolean;
  clientBaseArr: BaseClientModel[];
  onAction: boolean;
  disableFlag: boolean = true;
  notificaVm: NotificationVm;

  constructor(public config: DialogModel, private commonService: CommonService, public dialogRef: DialogRef, 
    public antifrodeKoPopupService: AntifrodeKoPopupService, private endpointsService: EndpointsService, 
    private redirectService: RedirectService) {
    this.signatureStatus = new SignatureStatusModel();
  }

  ngOnInit() {
    this.idProposal = this.config.data.idProposal;
    this.notificaVm = this.config.data.notificaVm;
    this.notificaVm.idPraticaBstore = this.idProposal;

    this.onDocumentoEvents = [
      { eventName: 'click', eventCallBack: this.onDocumento.bind(this) }
    ];

    this.onCloseEvents = [
      { eventName: 'click', eventCallBack: this.closeDialog.bind(this) }
    ];
  }

  onDocumento() {
    const comunicazioneNonAccoglimentoGenerica = new ComunicazioneNonAccoglimentoGenerica();
    // FIXME soon
    this.signatureStatus.docToGenerate.push(FinDocumentType.COMUNICAZIONE_NON_ACCOGLIMENTO_GENERICA);
    this.commonService.retrieveAllClient(this.idProposal).subscribe((respo) => {
      this.clientBaseArr = respo;
    }, () => {
      comunicazioneNonAccoglimentoGenerica.idProposta = Number.parseInt(this.idProposal);
      comunicazioneNonAccoglimentoGenerica.customers = this.clientBaseArr;
      comunicazioneNonAccoglimentoGenerica.docGenerated = this.docGenerated;
      this.antifrodeKoPopupService.ComunicazioneNonAccoglimentoGenerica(comunicazioneNonAccoglimentoGenerica).subscribe
        ((result) => {
          const urllist: Array<string> = [];
          for (const key in result) {
            urllist.push(result[key]);
          }
          urllist.forEach((url) => {
            window.open(url, '_blank');
          });
        });
      this.document = false;
    });

    this.onAction = true;
    this.disableFlag = false;
  }

  closeDialog() {
    this.dialogRef.close();
    this.commonService.updateProposalStepStatusAfterNotification(this.notificaVm).subscribe(response => {
      if (response) {
        this.redirectService.redirectWithSpinner(this.endpointsService.homePage);
      }
    });
  }

}
