import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CustomerData } from 'src/app/models/customerData';
import { InterviewResponse } from 'src/app/models/interview-response-vm';
import { MutuiProductwrapper } from 'src/app/modules/interview/models/MutuiProductwrapper';
import { environment } from 'src/environments/environment';
import { CodeDescription } from '../../../models/codeDescription';
import { EndpointsService } from "../../../services/endpoints.service";
import { CollectedSurveyQuestion } from '../models/collectedSurveyQuestion';
import { ListaPromozioniAttive } from '../models/listaPromozioniAttive';

@Injectable({
  providedIn: 'root'
})
export class InterviewService {

  parameters: HttpParams;

  constructor(private httpClient: HttpClient, private endpointsService: EndpointsService) { }
  public saveInterviewSurvey(collectedSurvey: CollectedSurveyQuestion[], surveyTypeId: string): Observable<any> {
    console.log('Saving interview survey: ', collectedSurvey);
    let surveyWrapper = new CodeDescription();
    surveyWrapper.codice = surveyTypeId;
    surveyWrapper.descrizione = JSON.stringify(collectedSurvey);
    console.log('Saving interview survey JSON: ', collectedSurvey);
    return this.httpClient.post(this.endpointsService.saveCollectedSurvey, surveyWrapper);
  }

  public loadCustomerData(ndg: string) {
    let parameters = new HttpParams().append('ndg', ndg);
    return this.httpClient.get<CustomerData>(this.endpointsService.loadCustomerData, { params: parameters });
  }

  mutuiSaveProposal(mutuoWrapper: MutuiProductwrapper): Observable<MutuiProductwrapper> {
    return this.httpClient.post<MutuiProductwrapper>(this.endpointsService.mutuiSaveProposal, mutuoWrapper);
  }

  public getSurveyjsonData(macroCategory: string): Observable<any> {
    let parameters = new HttpParams().append('macroCategory', macroCategory);
    return this.httpClient.get<CodeDescription>(this.endpointsService.loadNewSurvey, { params: parameters });
    //return this.httpClient.get<any>('assets/mock_data/survey-builder/PRESTITI_PERSONALI_FICS_QUESTION_LIST.json');
  }

  public getListOfIniziativeDiAcquisition(): Observable<ListaPromozioniAttive[]> {
    return this.httpClient.get<any>(this.endpointsService.getIniziativeDiAcquisition);
  }

  public containsBankEmployee(ndgList: string[]): Observable<boolean> {
    let httpParams = new HttpParams().append('ndgs', ndgList.join(', '));
    return this.httpClient.get<boolean>(this.endpointsService.containsBankEmpoyee, { params: httpParams });
  }

  public checkSegmentoDiRischio(ndg : string): Observable<boolean> {
    let httpParams = new HttpParams().append('ndg', ndg)
    return this.httpClient.get<boolean>(this.endpointsService.checkSegmentoDiRischio, { params: httpParams });
  }

  public checkStatoAmministrativo(ndg : string): Observable<boolean> {
    let httpParams = new HttpParams().append('ndg', ndg)
    return this.httpClient.get<boolean>(this.endpointsService.checkStatoAmministrativo, { params: httpParams });
  }

  public checkIfSardiniaCitizen(ndg: string[]): Observable<boolean> {
    let url = this.endpointsService.isSardiniaCitizen;
    let httpParams = new HttpParams().append('ndgs', ndg.join(', '));
    return this.httpClient.get<boolean>(url, { params: httpParams });
  }

  public gotoCongiuration(mutuoWrapper: MutuiProductwrapper): Observable<MutuiProductwrapper> {
    return this.httpClient.post<any>(this.endpointsService.goToConfiguration, mutuoWrapper);
  }

  public getInterviewAnswersByProposalId(proposalId: string): Observable<any> {
    const params = new HttpParams();
    const parameters = params.append('proposalId', proposalId);
    return this.httpClient.get<InterviewResponse>
      (`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/getInterviewAnswersByProposalId`, { params: parameters });
  }

  public loadNdgListAsync(proposalId: string): Observable<MutuiProductwrapper> {
    let wrapper: MutuiProductwrapper = new MutuiProductwrapper();

    let parameters = new HttpParams().append('proposalId', proposalId);
    return this.httpClient.get<MutuiProductwrapper>(this.endpointsService.loadMutuiProducWrapperAsync, { params: parameters });
  }

  public loadNdgIntProp(proposalId: string): Observable<string> {
    let parameters = new HttpParams().append('proposalId', proposalId);
    return this.httpClient.get<string>(this.endpointsService.getNdgIntestatarioProp, { params: parameters });
  }

  public needsToFetchImmobiliOfNdg(idProposal: string): Observable<boolean> {
    const parameters = new HttpParams().append('idProposal', idProposal);
    return this.httpClient.get<boolean>(this.endpointsService.needsToFetchImmobiliOfNdg, { params: parameters });
  }

  toDecimal(number: string) {
    if ((parseFloat(number).toString()).indexOf('NaN')) {
      return parseFloat(number.toString().replace(new RegExp('[.]', 'g'), '').replace(',', '.'));
    }
    return 0;
  }

  public checkProposal(ndg, jointHeading): Observable<any[]> {
    const params = new HttpParams();
    const parameters = params.append('ndg', ndg).append('jointHeading', jointHeading);
    return this.httpClient.get<any[]>(this.endpointsService.checkOngoingProposals, { params: parameters });
  }

  public deleteProposal(idProposal): Observable<boolean> {
    const params = new HttpParams();
    const parameters = params.append('idProposal', idProposal);
    return this.httpClient.get<boolean>(this.endpointsService.deleteProposalOnStatusAnnullata, { params: parameters });
  }

}
