import {FinalitaPrevalente} from './finalitaPrevalente';

export class AdditionalData {
   finalitaPrevalente?: FinalitaPrevalente[];
}