export class MutuiProductwrapper {
    id: Number;
    mainNdg: string;
    macroCategory: string;
    holdersList: string[];
    joint: string;
}
