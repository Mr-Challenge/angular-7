export interface ListaPromozioniAttive {
    codicePromo: string,
	descrizBreve: string,
	descrizEstesa: string,
	decorrenza: string,
	fine: string,
	dirTerr: string,	
}