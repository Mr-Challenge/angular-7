import { SurveyQuestion } from './surveyQuestion';

export class SurveyAnswer {
    id?: string;
    label?: string;
    onChange?: string;
    additionalData?: any;
    placeholder?: string;
    nextQuestions?: SurveyQuestion[];
}
