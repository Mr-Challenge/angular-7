import { CodiceDescrizione } from 'src/app/models/CodiceDescrizione.model';
export class CollectedSurveyQuestion {
    questionId?: string;
    question?: string;
    answerId?: string;
    answer?: string;
    additionalData?: CodiceDescrizione[];
}