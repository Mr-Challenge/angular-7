export class FinalitaPrevalente {
    code?: string;
    value?: string;
}
