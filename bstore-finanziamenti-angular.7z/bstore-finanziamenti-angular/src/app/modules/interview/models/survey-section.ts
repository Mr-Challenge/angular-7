import {SurveyQuestion} from './surveyQuestion';

export class SurveySection {
    sectionId?: string;
    title?: string;
    description?: string;
    questions?: SurveyQuestion[];
    additionalData?: any;
}
