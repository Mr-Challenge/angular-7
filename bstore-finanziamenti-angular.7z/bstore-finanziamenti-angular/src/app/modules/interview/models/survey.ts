import {SurveySection} from './survey-section';

export class Survey {
    type?: string;
    version?: number;
    title?: string;
    description?: string;
    sections?: SurveySection[];
}
