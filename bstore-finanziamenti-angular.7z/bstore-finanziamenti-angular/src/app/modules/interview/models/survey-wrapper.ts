import {Survey} from './survey';

export class SurveyWrapper {
    survey?: Survey;
}
