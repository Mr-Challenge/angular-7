import { SurveyAnswer } from './surveyAnswer'

export class SurveyQuestion {
    id?: string;
    number?: string;
    text?: string;
    description?: string;
    type?: string;
    required?: string;
    pattern?: string;
    preselectChoiceByUrl?: string;
    getChoicesFromService?: string;
    onChange?: string;
    validIf?: string;
    defaultValues?: string;
    choices?: SurveyAnswer[];
    onSubmit?: string;
}
