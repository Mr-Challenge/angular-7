import { HttpClient } from '@angular/common/http';
import { ChangeDetectorRef, Component, ComponentFactoryResolver, HostListener, OnInit, QueryList, ViewChild, ViewChildren, ViewContainerRef } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogService, FinanziamentiCrossJumpService, BreadcrumbModel, RedirectService } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { MortgageClientRoles } from 'src/app/constant/mortgageClientRoles';
import { ClientNDGModel } from 'src/app/models/clientNDG.model';
import { InterviewResult } from 'src/app/models/interview-response-vm';
import { InterviewQuestionRadioButtonComponent } from 'src/app/modules/interview/components/interview-question/interview-question-radio-button/interview-question-radio-button.component';
import { InterviewQuestionTextboxComponent } from 'src/app/modules/interview/components/interview-question/interview-question-textbox/interview-question-textbox.component';
import { MutuiProductwrapper } from 'src/app/modules/interview/models/MutuiProductwrapper';
import { Survey } from 'src/app/modules/interview/models/survey';
import { SurveyQuestion } from 'src/app/modules/interview/models/surveyQuestion';
import { InterviewService } from 'src/app/modules/interview/services/interview.service';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { CodeDescription } from 'src/app/modules/product-configuration/models/CodeDescription';
import { CommonService } from 'src/app/services/common.service';
import { environment } from 'src/environments/environment';
import { InterviewQuestionComponent } from '../../components/interview-question/interview-question.component';
import { CollectedSurveyQuestion } from '../../models/collectedSurveyQuestion';
import { InterviewMutuiDipendentiPopupComponent } from '../../components/interview-mutui-dipendenti-popup/interview-mutui-dipendenti-popup.component';
import { AnnulloPropostaPopupComponent } from '../../components/annullo-proposta-popup/annullo-proposta-popup.component';

@Component({
  selector: 'app-interview',
  templateUrl: './interview.component.html',
  styleUrls: ['./interview.component.scss']
})
export class InterviewComponent implements OnInit {

  constructor(public interviewService: InterviewService, private commonService: CommonService,
    public route: ActivatedRoute, public httpClient: HttpClient, public dialog: DialogService,
    public resolver: ComponentFactoryResolver, private cdRef: ChangeDetectorRef,
    public finanziamentiCrossJumpService: FinanziamentiCrossJumpService, private router: Router, private redirectService: RedirectService) {
    if (route.snapshot.params.proposalId != null) {
      // asynchronous case
      this.idProposal = route.snapshot.params.proposalId;
      this.commonService.getClientByRole(this.idProposal, MortgageClientRoles.INTESTATARI).subscribe(praposalHolder => {
        this.praposalHolder = praposalHolder;
      }, null, () => {
        const holdersList = this.praposalHolder.filter(this.isNotJoinHolder);
        this.clientData.ndgs = [];
        holdersList.forEach(data => {
          this.clientData.ndgs.push(data.ndg);
        });
        this.isLoading = false;
        const findMainNdg = holder => holder.cointestazione === true;
        this.clientData.mainNdg = (this.praposalHolder && this.praposalHolder.length > 1) ?
          this.praposalHolder.find(findMainNdg).ndg : this.praposalHolder[0].ndg;

        this.headerFlag = true;
      });
    } else {
      // sync case
      const jsonWrapper: string = route.snapshot.queryParams['mutuoWrapper'];
      this.mutuoWrapper = JSON.parse(jsonWrapper);
      console.log('Mutuo Wrapper', this.mutuoWrapper);
      if (this.mutuoWrapper && this.mutuoWrapper.macroCategory &&
        this.mutuoWrapper.macroCategory === 'MUTUI_CHIROGRAFARI_DIPENDENTI') {
        this.dialog.open(InterviewMutuiDipendentiPopupComponent, {
          title: 'ATTENZIONE',
          data: {
            message: 'il dipendente anche nelle sue cointestazioni ha un plafond massimo di 75000 euro ' +
              'come somma dei mutui chirografari dipendenti in essere'
          },
          size: 'large'
        });
      }
      this.clientData.mainNdg = this.mutuoWrapper.mainNdg;
      this.clientData.ndgs = this.mutuoWrapper.holdersList.filter(function (value, index, arr) {
        return index !== 0;
      });
      this.headerFlag = true;

      // construnctor vecchio header
      this.setbreadcrumbs();

    }

    console.log(this.clientData);



  }

  @ViewChild('interviewForm') public interviewForm: NgForm;
  @ViewChildren(InterviewQuestionComponent) children: QueryList<InterviewQuestionComponent>;
  @ViewChildren('questionscontainer', { read: ViewContainerRef }) private entry: QueryList<ViewContainerRef>;

  mutuoWrapper: MutuiProductwrapper = new MutuiProductwrapper();
  survey: Survey;
  surveyQuestions: SurveyQuestion[];
  surveyQuestionCopy: SurveyQuestion[];
  firstQuestion: SurveyQuestion;
  nextBranch: SurveyQuestion[];
  isDataAvailable: boolean = false;
  surveyTypeId: string;
  maxQuestions: number;
  isLastQuestion = false;
  progressValue: number;
  interviewQuestionComps: InterviewQuestionComponent[] = [];
  arrayOfThreeAnswers: String[] = new Array();
  submitInterviewEvent: EventsModel[];
  submitNewInterviewEvent: EventsModel[];
  componentRefMap: Map<string, any> = new Map;
  idProposal: string;
  oldInterview: InterviewResult[]; // for ansync case
  firstAnswer: string; // for ansync case
  tornaButtonEvent: EventsModel[];
  newProposalCreation: boolean;
  annullaModificheEvent: EventsModel[];
  modifAnswer: string;
  finaliPrevalente: string;
  abitextboxChange: string;
  clientData: ClientNDGModel = new ClientNDGModel();
  domainName = environment.devUrlJSON['npv.service.callback.url'];
  isLoading: boolean;
  headerFlag: boolean;
  viewNextQuestion: boolean;
  ndg: string;
  jointHeading: any;


  public breadcrumbs: BreadcrumbModel[];

  url: String;

  public progFixed: boolean = false;
  praposalHolder: BaseClientModel[];

  prevScrollpos = window.pageYOffset;

  ngOnInit() {
    const joint = this.mutuoWrapper.joint;
    this.ndg = (joint == null) ? this.mutuoWrapper.mainNdg : joint;
    this.jointHeading = (joint == null) ? false : true;
    this.interviewService.checkProposal(this.ndg, this.jointHeading).subscribe(proposalList => {
      if (proposalList.length > 0) {
        const ref = this.dialog.open(AnnulloPropostaPopupComponent, {
          data: { proposalList: proposalList },
          title: 'Proposte in corso',
          size: 'large',
          noCloseButton: false
        });

        ref.afterClosed.subscribe(result => {
          if (result !== 'interview') {
            this.redirectService.redirectWithSpinner(environment.devUrlJSON['npv.service.callback.url']
              + '/cartFlow.flow?modifyProposal=false&ndg=' + this.mutuoWrapper.mainNdg);

          }
        });
      }
      this.initializeEvents();
      // asynchronous case
      if (this.idProposal) {
        this.loadAsynchronous();
      } else {
        this.getSurvey(this.mutuoWrapper.macroCategory, false);
      }

    });



  }

  setbreadcrumbs() {
    if (this.mutuoWrapper != null && this.mutuoWrapper.mainNdg != null && this.mutuoWrapper.holdersList != null) {
      this.interviewService.gotoCongiuration(this.mutuoWrapper).subscribe(data => {
        const mainNdg = this.mutuoWrapper.mainNdg;
        const macroCategory = this.mutuoWrapper.macroCategory;
        let prop: string;
        if (this.idProposal) {
          prop = '&isPropCreated=true&idProposalDa=' + this.idProposal;
          this.url = environment.devUrlJSON['npv.service.callback.url'] + '/cartFlow.flow?modifyProposal=false&ndg=' + mainNdg + '&gotoCongif=true&factoryProductCode=' + macroCategory + '&istituto=05387&isAdditionalCard=false' + prop;
        } else {
          this.url = environment.devUrlJSON['npv.service.callback.url'] + '/cartFlow.flow?modifyProposal=false&ndg=' + mainNdg + '&gotoCongif=true&factoryProductCode=' + macroCategory + '&istituto=05387&isAdditionalCard=false';
        }

        this.breadcrumbs = [{
          label: 'Intestatari',
          url: `${this.url}`,
          enabled: true,
          externalLink: true
        }];

      });
      console.log(this.mutuoWrapper.macroCategory);
    }
  }

  ngAfterViewChecked() {
    this.cdRef.detectChanges();
    if (this.idProposal && this.isDataAvailable && this.firstAnswer == null) {
      this.firstAnswer = this.getAnswerForQuestionId(this.firstQuestion.id);
    } else {
      this.firstAnswer = null;
    }
    this.cdRef.detectChanges();
  }
  @HostListener('window:scroll', ['$event'])
  checkScroll() {
    const currentScrollPos = window.pageYOffset;
    if (this.prevScrollpos >= currentScrollPos) {
      this.progFixed = false;
    } else {
      this.progFixed = true;
    }
  }

  isNotJoinHolder(element, index, array) {
    return (element.cointestazione === false);
  }

  createComponent(surveyQuestion: SurveyQuestion, nextBranch: SurveyQuestion[]) {
    console.log('Creating component with question: ', surveyQuestion);
    console.log('Next branch will be: ', nextBranch);
    let componentType = null;
    if (surveyQuestion.type === 'radio') {
      componentType = InterviewQuestionRadioButtonComponent;

    }
    else if (surveyQuestion.type === 'textbox') {
      componentType = InterviewQuestionTextboxComponent;
    }

    const factory = this.resolver.resolveComponentFactory(componentType);
    const componentRef: any = this.entry.first.createComponent(factory);
    this.initializeQuestionComponent(componentRef, surveyQuestion, nextBranch);
    componentRef.instance.ndgList = this.mutuoWrapper.holdersList;
    componentRef.instance.ndg = this.ndg;
    this.interviewQuestionComps.push(componentRef.instance);
    this.componentRefMap.set(surveyQuestion.id, componentRef);
  }

  initializeQuestionComponent(componentRef: any, surveyQuestion: SurveyQuestion, nextBranch: SurveyQuestion[]) {
    componentRef.instance.surveyQuestion = surveyQuestion;
    this.surveyQuestionCopy = this.surveyQuestions;
    componentRef.instance.surveyQuestionCopy = this.surveyQuestions;
    componentRef.instance.proposalId = this.idProposal;
    componentRef.instance.isLastQuestion = this.isLastQuestion;
    componentRef.instance.nextBranch = nextBranch;
    componentRef.instance.newProposalCreation = this.newProposalCreation;
    componentRef.instance.showNextQuestion.subscribe(data => this.callShowNextQuestion(data, false));
    componentRef.instance.skipCurrentAndShowNextQuestion.subscribe(data => this.skipLastAndShowNextQuestion(componentRef, data, false));
    componentRef.instance.hideCurrentAndShowNextQuestion.subscribe(data => this.hideLastAndShowNextQuestion(componentRef, data, false));
    componentRef.instance.changedQuestion.subscribe(questionComponent => this.callChangedQuestion(questionComponent.surveyQuestion, questionComponent.nextBranch, false));
    componentRef.instance.newProposalCreationChange.subscribe(data => this.newProposalCreation = data);
    if (componentRef.instance.modifAns) {
      componentRef.instance.modifAns.subscribe(data => this.modifAns(data));
    }
    if (componentRef.instance.finPrevalente) {
      componentRef.instance.finPrevalente.subscribe(data => this.finalitaPrevalente(data));
    }
    if (componentRef.instance.abitextboxChange) {
      componentRef.instance.abitextboxChange.subscribe(data => this.abiText(data));
    }
    componentRef.instance.arrayOfThreeAnswers = this.arrayOfThreeAnswers;

    if (this.idProposal) {// async
      const answer = this.getAnswerForQuestionId(surveyQuestion.id);
      componentRef.instance.answerAsync = answer;
      const additionalList = this.getAdditionalDataForQuestionId(surveyQuestion.id);
      if (additionalList) {
        additionalList.forEach((additional) => {
          if (additional.codice === 'finalitaPrevalente') {
            componentRef.instance.finPrevalenteAns = additional.descrizione;
          }
          if (additional.codice ===
            'abiText') {
            componentRef.instance.abitextboxChangeAns = additional.descrizione;
          }
        });
      }
    }
  }

  destroyComponent(componentRef: any) {
    componentRef.destroy();
  }

  initializeEvents() {
    this.submitInterviewEvent = [
      { eventName: 'click', eventCallBack: this.mutuiSaveProposal.bind(this) }
    ];

    this.submitNewInterviewEvent = [
      { eventName: 'click', eventCallBack: this.deleteProposal.bind(this) }
    ];

    this.tornaButtonEvent = [
      { eventName: 'click', eventCallBack: this.goToSimulation.bind(this) }
    ];

    this.annullaModificheEvent = [
      { eventName: 'click', eventCallBack: this.revertChanges.bind(this) }
    ];
  }

  modifAns(data) {
    console.log(data);
    this.modifAnswer = data.target.id;
  }

  finalitaPrevalente(data) {
    this.finaliPrevalente = data;
  }

  abiText(data) {
    this.abitextboxChange = data;
  }

  loadCustomerData() {
    this.interviewService.loadCustomerData(this.mutuoWrapper.mainNdg).subscribe(
      res => console.log(res)
    );
  }

  getSurvey(category: string, async: boolean) {
    this.interviewService.getSurveyjsonData(category).subscribe(data => {
      this.surveyTypeId = data.codice;
      this.survey = JSON.parse(data.descrizione).survey;
      this.maxQuestions = this.survey.sections[0].additionalData.numMaxQuestions;
      this.surveyQuestions = this.survey.sections[0].questions;
      console.log('Fetched new interview Survey: ', this.surveyQuestions);
      this.progressBarValue(1, false);
      this.initializeFirstQuestion(async);
      this.isDataAvailable = true;
    });
  }

  initializeFirstQuestion(async: boolean) {
    this.firstQuestion = this.surveyQuestions[0];
    this.nextBranch = this.getNextBranch(this.surveyQuestions);
    console.log('First question initialized : ', this.firstQuestion);
    console.log('Branch that follows first question will be: ', this.nextBranch);
  }

  mutuiSaveProposal() {
    const collectedSurvey: CollectedSurveyQuestion[] = this.assembleCollectedSurvey();
    this.interviewService.saveInterviewSurvey(collectedSurvey, this.surveyTypeId).subscribe(getSaveDataId => {
      if (getSaveDataId != null) {
        this.mutuoWrapper.id = getSaveDataId;
        this.interviewService.mutuiSaveProposal(this.mutuoWrapper).subscribe(data => {
          console.log('Saved proposal with id: ', data);
          this.router.navigateByUrl('/simulazione/' + data);
        });
      }
    });
  }

  deleteProposal() {
    this.interviewService.deleteProposal(this.idProposal).subscribe(data => {
      console.log('Void proposal with id: ', this.idProposal);
      this.mutuiSaveProposal();
    });
  }

  assembleCollectedSurvey(): CollectedSurveyQuestion[] {
    const survey: CollectedSurveyQuestion[] = [];
    this.interviewQuestionComps.forEach((child, index) => {
      if (child.selectedAnswer != null) {
        const questionCollected: CollectedSurveyQuestion = new CollectedSurveyQuestion();
        questionCollected.questionId = child.surveyQuestion.id;
        questionCollected.question = child.surveyQuestion.text;
        questionCollected.answer = child.selectedAnswer;
        if (child.surveyQuestion.id === 'D2' && child instanceof InterviewQuestionRadioButtonComponent) {
          questionCollected.additionalData = [];
          const radioButton: InterviewQuestionRadioButtonComponent = <InterviewQuestionRadioButtonComponent>child;
          const finalitaPrevalente: string = radioButton.finalitaPrevalente;
          if (finalitaPrevalente) {
            const fin: CodeDescription = new CodeDescription();
            fin.codice = 'finalitaPrevalente';
            fin.descrizione = finalitaPrevalente;
            questionCollected.additionalData.push(fin);
          }
          const abitext: string = radioButton.abiText;
          if (abitext) {
            const abi: CodeDescription = new CodeDescription();
            abi.codice = 'abiText';
            abi.descrizione = abitext;
            questionCollected.additionalData.push(abi);
          }
        }
        survey.push(questionCollected);
      }
    });
    return survey;
  }

  progressBarValue(unitNumber: number, isLastQuestion: boolean) {
    const unit: number = 100 / this.maxQuestions;
    this.progressValue = isLastQuestion ? 100 : Math.round(unitNumber * unit);
  }

  callShowNextQuestion(currentBranch: SurveyQuestion[], isFirstQuestion: boolean) {
    console.log('ShowNextQuestion event: currentBranch', currentBranch);
    console.log('isFirstQuestion=', isFirstQuestion);
    if (isFirstQuestion) {
      this.interviewQuestionComps.splice(0);
      this.interviewQuestionComps.push(this.children.first);
    }
    if (currentBranch.length !== 0) {
      const nextNode = currentBranch[0];
      this.checkIfLast(currentBranch);
      console.log('isLastQuestion=', this.isLastQuestion);
      const nextBranch = this.getNextBranch(currentBranch);
      this.createComponent(nextNode, nextBranch);
      // removing all non-digits charachters
      const questionNumber: number = nextNode.number ? +nextNode.number : +nextNode.id.replace(/\D/g, '');
      this.progressBarValue(questionNumber, this.isLastQuestion);
    }
  }

  skipLastAndShowNextQuestion(componentRef: any, currentBranch: SurveyQuestion[], isFirstQuestion: boolean) {
    // destroy instance and DOM node
    this.destroyComponent(componentRef);
    // remove element from list
    this.interviewQuestionComps.pop();
    // show next question
    this.callShowNextQuestion(currentBranch, isFirstQuestion);
  }

  hideLastAndShowNextQuestion(componentRef: any, currentBranch: SurveyQuestion[], isFirstQuestion: boolean) {
    // destroy instance and DOM node
    setTimeout(() => { this.destroyComponent(componentRef); }, 50);
    if (!this.idProposal || this.viewNextQuestion) { // handling sync and async case
      this.callShowNextQuestion(currentBranch, isFirstQuestion);
    }
  }

  getNextBranch(currentBranch: SurveyQuestion[]): SurveyQuestion[] {
    const temp: SurveyQuestion[] = JSON.parse(JSON.stringify(currentBranch));
    temp.splice(0, 1);
    return temp;
  }

  checkIfLast(branch: SurveyQuestion[]) {
    // if no siblings look for children
    if (branch[1] == null) {
      let isLeaf = true;
      if (branch[0] !== null) {
        branch[0].choices.forEach((choice) => {
          if (choice.nextQuestions != null && choice.nextQuestions.length > 0) {
            isLeaf = false;
          }
        });
      }
      this.isLastQuestion = isLeaf;
    } else {// I'm sure it's not the last one
      this.isLastQuestion = false;
    }
  }

  rerouteMethod(breadcrumb, proposal) {
    this.finanziamentiCrossJumpService.doCrossJummp(environment.devUrlJSON['npv.service.callback.url'], breadcrumb, proposal);  // second parameter can be proposal id.
  }

  callChangedQuestion(question: SurveyQuestion, nextBranch: SurveyQuestion[], isFirstQuestion: boolean) {
    let toBeDeleted: InterviewQuestionComponent[];
    // remove from interviewQuestionComps

    this.interviewQuestionComps.forEach((child, index) => {
      if (child.surveyQuestion.id == question.id) {
        const count = this.interviewQuestionComps.length - (index + 1);
        toBeDeleted = this.interviewQuestionComps.splice(index + 1, count);
      }
    });
    // destroy instances of following questions and remove from DOM
    toBeDeleted.forEach(item => {
      if (this.componentRefMap.get(item.surveyQuestion.id)) {
        const compRef = this.componentRefMap.get(item.surveyQuestion.id);
        this.destroyComponent(compRef);
        this.componentRefMap.delete(item.surveyQuestion.id);
      }
    });
    // show next question
    this.viewNextQuestion = true;
    this.callShowNextQuestion(nextBranch, isFirstQuestion);

  }

  loadAsynchronous() {
    // load mutuo wrapper
    this.interviewService.loadNdgIntProp(this.idProposal).subscribe(ndg => {
      console.log('NdgIntProp: ', ndg);
      this.mutuoWrapper.mainNdg = ndg;
      this.commonService.fetchMutuoDetails(this.idProposal).subscribe(mutuoDetails => {
        console.log('mutuoDetails: ', mutuoDetails);
        this.mutuoWrapper.macroCategory = mutuoDetails.macroCategory;
        this.mutuoWrapper.id = mutuoDetails.idIntervista; // not used
        this.mutuoWrapper.holdersList = [];
        this.commonService.getClientByRole(this.idProposal, MortgageClientRoles.INTESTATARI).subscribe(holders => {
          console.log('holders: ', holders);
          holders.forEach(holder => {
            if (holder.cointestazione) {
              this.mutuoWrapper.joint = holder.ndg;
            } else {
              this.mutuoWrapper.holdersList.push(holder.ndg);
            }

          });
          this.setbreadcrumbs();
          // load existing interview
          this.interviewService.getInterviewAnswersByProposalId(this.idProposal).subscribe(interviewData => {
            this.oldInterview = JSON.parse(interviewData.interview);
            console.log('oldInterview: ', this.oldInterview);
            // load template survey
            this.getSurvey(this.mutuoWrapper.macroCategory, true);
          });
        });
      });
    });
  }

  getAnswerForQuestionId(questionId: string): string {
    let answer = null;
    this.oldInterview.forEach(question => {
      if (question.questionId == questionId) {
        answer = question.answer;
      }
    });
    return answer;
  }

  getAdditionalDataForQuestionId(questionId: string): CodeDescription[] {
    let additionalData: CodeDescription[];
    this.oldInterview.forEach(question => {
      if (question.questionId === questionId && question.questionId === 'D2') {
        additionalData = question.additionalData;
      }
    });
    return additionalData;
  }

  goToSimulation() {
    this.router.navigateByUrl('/simulazione/' + this.idProposal);
  }

  revertChanges() {
    location.reload();
  }
}
