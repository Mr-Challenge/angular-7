import { HttpClient } from '@angular/common/http';
import { Component, EventEmitter, Output, ViewChild } from '@angular/core';
import { ControlContainer, NgForm, NgModelGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DialogService, RedirectService } from 'bstore-angular-library';
import { SelectOptionModel } from 'bstore-angular-library/lib/models/select-option-model';
import { InterviewService } from '../../../services/interview.service';
import { InterviewQuestionComponent } from '../interview-question.component';
import { EndpointsService } from 'src/app/services/endpoints.service';

@Component({
  selector: 'bst-fin-interview-question-radio-button',
  templateUrl: './interview-question-radio-button.component.html',
  styleUrls: ['./interview-question-radio-button.component.scss'],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
  providers: [
    { provide: InterviewQuestionComponent, useExisting: InterviewQuestionRadioButtonComponent }
  ]
})
export class InterviewQuestionRadioButtonComponent extends InterviewQuestionComponent {

  @ViewChild('questionForm') public radioTemplateRef: NgModelGroup;

  checkedAns: string;
  showAbi: boolean = false;
  showFinalita: boolean = false;
  finalitaPrevalenteData: SelectOptionModel[] = [];
  abiText: string;
  finalitaPrevalente: string;
  tempFinalita: string;
  tempAbiText: string;
  isFinPrRequired: boolean;
  isAbiRequired: boolean;
  @Output() modifAns: EventEmitter<any> = new EventEmitter();
  @Output() finPrevalente: EventEmitter<any> = new EventEmitter();
  @Output() abitextboxChange: EventEmitter<any> = new EventEmitter();

  constructor(public interviewService: InterviewService, public route: ActivatedRoute, public httpClient: HttpClient, public dialog: DialogService, public redirectService: RedirectService, public endpointsService: EndpointsService) {
    super(interviewService, route, httpClient, dialog, redirectService, endpointsService);
  }

  ngOnInit() {
    super.ngOnInit();
    console.log(event);
  }

  public change(input, event): void {
    console.log(event);
    if (event.target.checked) {
      this.selectedAnswer = input.textContent;
      this.modifAns.emit(event);
      if (this.modify) {
        this.changeRadAnd = event.target.id;
        if (this.showFinalita) {
          this.finalitaPrevalente = "";
        }
        if (this.showAbi) {
          this.abiText = "";
        }
      }
    }
    this.showFinalita = false;
    this.showAbi = false;
    let esigenzaTemp = this.finalitaPrevalente;
    let abiTemp = this.abiText;
    this.additionaAnswerChanged = this.finalitaPrevalente != esigenzaTemp || this.abiText != abiTemp;
    super.modelChange(event);
  }

  showFinalitaPrevalente(input, event) {
    this.surveyQuestion.choices.forEach((options) => {
      if (options.label == input.textContent) {
        this.showFinalita = true;
        this.showAbi = (options.onChange === "showFinalitaPrevalenteAndAbi");
        let optionList = options.additionalData.finalitaPrevalente;
        this.finalitaPrevalente = "";
        this.abiText = "";
        this.finalitaPrevalenteData = [];
        this.finalitaPrevalenteData.push({ 'description': "", 'value': "" });
        optionList.forEach(e => {
          this.finalitaPrevalenteData.push({ 'description': e.value.toUpperCase(), 'value': e.value.toUpperCase() });
        });
        this.isFinPrRequired = false;
        this.isAbiRequired = false;

        // this.change(input, event);
        if (event.target.checked) {
          this.selectedAnswer = input.textContent;
        }
        super.modelChange(event);
        setTimeout(function () {
          this.isAbiRequired = true;
          this.isFinPrRequired = true;
        }, 1000);
      }
    });
  }

  showFinalitaPrevalenteAndAbi(input, event) {
    this.showFinalitaPrevalente(input, event);
  }

  setAbi(event) {
    this.abiText = event.target.value;
    this.abitextboxChange.emit(event.target.value);
    this.callToValidateConferma();
  }

  setfinalitaPrevalente(event) {
    this.finalitaPrevalente = event.target.value;
    this.finPrevalente.emit(event.target.value);
    this.callToValidateConferma();
  }

  callToValidateConferma() {

    if (this.radioTemplateRef.control.controls.hasOwnProperty('abitextbox')) {
      this.radioTemplateRef.control.controls['abitextbox'].markAsTouched();
      this.radioTemplateRef.control.controls['abitextbox'].markAsDirty();
      this.radioTemplateRef.control.controls['abitextbox'].updateValueAndValidity();
    }

    this.radioTemplateRef.control.controls['finalitaPrevalente'].markAsTouched();
    this.radioTemplateRef.control.controls['finalitaPrevalente'].markAsDirty();
    this.radioTemplateRef.control.controls['finalitaPrevalente'].updateValueAndValidity();

    if ((!this.checkConferma) || (this.abiText !== this.tempAbiText) || (this.finalitaPrevalente !== this.tempFinalita)) {
      this.confermaDisabled = false;
    } else {
      this.confermaDisabled = true;
    }
 
    if (this.checkedAns === 'Surroga' && this.abiText !== '' && this.finalitaPrevalente !== '') {
      this.confermaDisabled = false;
    } else if (this.checkedAns === 'Sostituzione' && this.finalitaPrevalente !== '') {
      this.confermaDisabled = false;
    } else if (this.checkedAns.toUpperCase() === ('Acquisto beni di consumo').toUpperCase() && this.finalitaPrevalente) {
      this.confermaDisabled = false;
    } else {
      this.confermaDisabled = true;
    }

    if (this.modify && ((this.checkedAns === 'Surroga' && this.tempFinalita === this.finalitaPrevalente && this.tempAbiText === this.abiText)
      || (this.checkedAns === 'Sostituzione' && this.finalitaPrevalente === this.tempFinalita) 
      || (this.checkedAns.toUpperCase() === ('Acquisto beni di consumo').toUpperCase() && this.finalitaPrevalente===this.tempFinalita))){
      this.confermaDisabled=true;
    }
  }

  public annulla(): void {
    this.checkedAns = this.temp;
    if (this.checkedAns === 'Surroga') {
      this.showFinalita = true;
      if (this.showFinalita) {
        this.finalitaPrevalente = this.tempFinalita;
      }
    }
    if (this.checkedAns === 'Surroga') {
      this.showAbi = true;
      if (this.showAbi) {
        this.abiText = this.tempAbiText;
      }
    }
    super.annulla();
  }

  public modifica(): void {
    if (this.showFinalita) {
      this.tempFinalita = this.finalitaPrevalente;
    }else{
      this.finalitaPrevalente="";
    }
    if (this.checkedAns === 'Surroga') {
      if (this.showAbi) {
        this.tempAbiText = this.abiText;
      } else {
        this.abiText = "";
      }
    }
    super.modifica();
  }

  protected setDefaultChoise(defaultChoise: string): void {
    this.checkedAns = this.selectedAnswer = defaultChoise;
  }

  protected clearAnswer() {
    this.checkedAns = null;
  }

  //async case
  prepopulate() {
    this.checkedAns = this.answerAsync;
    if (this.abitextboxChangeAns) {
      this.showAbi = true;
      this.abiText = this.abitextboxChangeAns;
    }
    if (this.finPrevalenteAns) {
      this.showFinalita = true;
      this.finalitaPrevalente = this.finPrevalenteAns;
      this.surveyQuestion.choices.forEach((options) => {
        if (options.label == this.answerAsync && options.additionalData) {
          let optionList = options.additionalData.finalitaPrevalente;
          this.finalitaPrevalenteData = [];
          this.finalitaPrevalenteData.push({ 'description': "", 'value': "" });
          optionList.forEach(e => {
            this.finalitaPrevalenteData.push({ 'description': e.value.toUpperCase(), 'value': e.value.toUpperCase() });
          });
          super.modelChange(event);
        }
      });
    }
    super.prepopulate();
  }
}
