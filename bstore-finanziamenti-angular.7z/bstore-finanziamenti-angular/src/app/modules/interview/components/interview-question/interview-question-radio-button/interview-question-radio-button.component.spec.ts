import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InterviewQuestionRadioButtonComponent } from './interview-question-radio-button.component';

describe('InterviewQuestionRadioButtonComponent', () => {
  let component: InterviewQuestionRadioButtonComponent;
  let fixture: ComponentFixture<InterviewQuestionRadioButtonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InterviewQuestionRadioButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InterviewQuestionRadioButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
