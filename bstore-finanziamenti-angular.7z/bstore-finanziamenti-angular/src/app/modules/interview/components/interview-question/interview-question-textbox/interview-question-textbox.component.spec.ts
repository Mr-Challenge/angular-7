import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InterviewQuestionTextboxComponent } from './interview-question-textbox.component';

describe('InterviewQuestionTextboxComponent', () => {
  let component: InterviewQuestionTextboxComponent;
  let fixture: ComponentFixture<InterviewQuestionTextboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InterviewQuestionTextboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InterviewQuestionTextboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
