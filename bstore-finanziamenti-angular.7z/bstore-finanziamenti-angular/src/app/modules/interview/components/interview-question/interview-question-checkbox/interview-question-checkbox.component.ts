import { HttpClient } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import { ControlContainer, NgForm, NgModelGroup, NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DialogService, RedirectService } from 'bstore-angular-library';
import { InterviewService } from '../../../services/interview.service';
import { InterviewQuestionComponent } from '../interview-question.component';
import { EndpointsService } from 'src/app/services/endpoints.service';


@Component({
  selector: 'bst-fin-interview-question-checkbox',
  templateUrl: './interview-question-checkbox.component.html',
  styleUrls: ['./interview-question-checkbox.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: InterviewQuestionComponent, multi: true },
    { provide: NG_VALIDATORS, useExisting: InterviewQuestionComponent, multi: true }
  ],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class InterviewQuestionCheckboxComponent extends InterviewQuestionComponent {

  @ViewChild('questionForm') public checkboxTemplateRef: NgModelGroup;

  private checkedAns: any[] = []

  constructor(public interviewService: InterviewService, public route: ActivatedRoute, public httpClient: HttpClient,
    public dialog: DialogService, public redirectService: RedirectService, public endpointsService: EndpointsService) {
    super(interviewService, route, httpClient, dialog, redirectService, endpointsService);
  }

  public change(input, event): void {
    super.modelChange(event);
    if (event.target.checked) {
      this.checkedAns.push(event.target.value);
    } else {
      this.checkedAns.splice(this.checkedAns.indexOf(event.target.value), 1);
    }
  }

  public change1(input, event): void {
    super.modelChange(event);
    this.confermaDisabled = false;
    console.log("my answer " + this.checkedAns)
    if (!event.target.checked && event.target.value) {
      const index = this.checkedAns.findIndex(res => res == event.target.value)
      this.checkedAns.splice(index, 1);
    }
    if (event.target.checked) {
      this.checkedAns.push(event.target.value);
    }
  }

  protected setDefaultChoise(defaultChoise: string): void {
    this.checkedAns.push(defaultChoise);
  }


}
