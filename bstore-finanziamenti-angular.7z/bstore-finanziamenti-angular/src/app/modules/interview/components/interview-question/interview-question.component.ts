import { HttpClient } from '@angular/common/http';
import { AfterViewChecked, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ControlContainer, ControlValueAccessor, NgForm, NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DialogService, RedirectService } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { SurveyQuestion } from 'src/app/modules/interview/models/surveyQuestion';
import { InterviewService } from 'src/app/modules/interview/services/interview.service';
import { EndpointsService } from 'src/app/services/endpoints.service';
import { ModificaIntervistaPopupComponent } from '../../components/modifica-intervista-popup/modifica-intervista-popup.component';
import { SurveyAnswer } from '../../models/surveyAnswer';
import { InterviewMessagePopupComponent } from '../interview-popup/interviewmessage-popup.component';
import { SurveyComponent } from '../survey/survey.component';
@Component({
  selector: 'bst-fin-interview-question',
  templateUrl: './interview-question.component.html',
  styleUrls: ['./interview-question.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: InterviewQuestionComponent, multi: true },
    { provide: NG_VALIDATORS, useExisting: InterviewQuestionComponent, multi: true }
  ],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class InterviewQuestionComponent extends SurveyComponent implements OnInit, AfterViewChecked, ControlValueAccessor {

  // input parameters
  @Input('holdersList') private ndgList: string[];
  @Input() surveyQuestion: SurveyQuestion;
  @Input() surveyQuestionCopy: SurveyQuestion[];
  @Input() isLastQuestion = false;
  @Input() proposalId: string;
  @Input() nextBranch: SurveyQuestion[];
  @Input() answerAsync: string;
  @Input() newProposalCreation: string;
  @Input() finPrevalenteAns: string;
  @Input() abitextboxChangeAns: string;
  @Input() arrayOfThreeAnswers: String[];
  @Input('mainNdg') private ndg: string;

  // output parameters
  @Output() showNextQuestion: EventEmitter<any> = new EventEmitter<any>();
  @Output() skipCurrentAndShowNextQuestion: EventEmitter<any> = new EventEmitter<any>();
  @Output() hideCurrentAndShowNextQuestion: EventEmitter<any> = new EventEmitter<any>();
  @Output() changedQuestion: EventEmitter<any> = new EventEmitter<any>();
  @Output() newProposalCreationChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  onChange: (value: any) => void;
  onTouched: () => void;

  // global variables
  submitted: boolean;
  temp: string;
  confermaDisabled = false;
  confermaTextDisabled = true;
  modify: boolean;
  selectedAnswer: string;
  demoEvents: EventsModel[];
  demoEventsOnButton: EventsModel[];
  demoEventsOnAnnulla: EventsModel[];
  demoEventsOnButtonConferma: EventsModel[];
  additionaAnswerChanged: boolean;
  answerOnChangeEvent: EventsModel[];

  changeRadAnd: string;
  checkConferma = true;
  cdref: ChangeDetectorRef;
  prestitiPersonali: boolean;

  constructor(public interviewService: InterviewService, public route: ActivatedRoute,
    public httpClient: HttpClient, public dialog: DialogService, public redirectService: RedirectService,
    public endpointsService: EndpointsService) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
    // works for questions that are not the first one
    if (!this.submitted && this.answerAsync != null && !this.newProposalCreation) {
      this.prepopulate();
    }
  }

  ngAfterViewChecked() {
    // works for first question
    if (!this.submitted && this.answerAsync != null && !this.newProposalCreation) {
      this.prepopulate();
    }
  }

  prepopulate() {
    this.selectedAnswer = this.answerAsync;
    this.submitted = true;
    if (this.surveyQuestion.onSubmit === 'checkForFicsQuestions') {
      this.checkForFicsQuestions();
    } else {
      this.loadNextBranch();
      this.showNextQuestion.emit(this.nextBranch);
    }
  }

  // public abstract change(input, event): void;
  public change(input, event): void {
    // TODO try to make this method abstract withour breaking ng build --prod
  }

  public keyup(input, event): void {
    // TODO try to make this method abstract withour breaking ng build --prod
  }

  protected initializeEvents(): void {

    this.demoEvents = [];
    if (this.surveyQuestion.onChange) {
      this.demoEvents.push({ eventName: 'change', eventCallBack: this[this.surveyQuestion.onChange].bind(this) });
    } else {
      this.demoEvents.push({ eventName: 'change', eventCallBack: this.change.bind(this) });
    }

    this.demoEventsOnButton = [];
    // if the question has a specific submit function you control in that function if you want to Save submitted answer or abort the process
    if (this.surveyQuestion.onSubmit) {
      this.demoEventsOnButton.push({ eventName: 'click', eventCallBack: this[this.surveyQuestion.onSubmit].bind(this) },
        { eventName: 'click', eventCallBack: this.scroll.bind(this) });
    } else {
      this.demoEventsOnButton.push({ eventName: 'click', eventCallBack: this.saveAnswer.bind(this) },
        { eventName: 'click', eventCallBack: this.scroll.bind(this) });
    }

    this.demoEventsOnAnnulla = [
      { eventName: 'click', eventCallBack: this.annulla.bind(this) }
    ];

    this.demoEventsOnButtonConferma = [];
    // if the question has a specific submit function you control in that function if you want to Save submitted answer or abort the process
    if (this.surveyQuestion.onSubmit) {
      this.demoEventsOnButtonConferma.push({ eventName: 'click', eventCallBack: this[this.surveyQuestion.onSubmit].bind(this) });
    } else {
      this.demoEventsOnButtonConferma.push({ eventName: 'click', eventCallBack: this.saveModifiedAnswer.bind(this) });
      this.demoEventsOnButtonConferma.push({ eventName: 'click', eventCallBack: this.removeOldNodes.bind(this) });
    }

    this.answerOnChangeEvent = [
      { eventName: 'click', eventCallBack: this.answerOnChange.bind(this) }
    ];
  }

  // It will be inkoveked by JSON survery, please DO NOT DELETE
  private checkIfBperEmployee(): void {
    if (!this.newProposalCreation && !this.proposalId) {
      this.interviewService.containsBankEmployee(this.ndgList).subscribe(res => {
        if (res != true || this.surveyQuestion.onChange != 'showBperEmployeePopup') {
          this.managePreselectedChoiseByUrl([res]);
        }
      });
    }
  }

  private checkSegmentoDiRischio(): void {
    if (!this.newProposalCreation && !this.proposalId) {
      this.interviewService.checkSegmentoDiRischio(this.ndg).subscribe(res => {
        this.managePreselectedChoiseByUrl([res]);
      });
    }
  }

  private checkStatoAmministrativo(): void {
    if (!this.newProposalCreation && !this.proposalId) {
      this.interviewService.checkStatoAmministrativo(this.ndg).subscribe(res => {
        this.managePreselectedChoiseByUrl([res]);
      });
    }
  }

  private hideIfNotSardiniaCitizen(): void {
    this.interviewService.checkIfSardiniaCitizen(this.ndgList).subscribe(isSardiniaCitizen => {
      if (!isSardiniaCitizen) {
        this.selectedAnswer = 'No'; // question 8 not shown has the same meaning of 'No'
        this.skipAndShowNext();
      }
    });
  }

  // It will be inkoveked by JSON survery, please DO NOT DELETE
  private hideAndSavePreselectedValue(): void {
    this.managePreselectedChoiseByUrl([this.surveyQuestion.defaultValues]);
    this.hideAndShowNext();
  }

  // It will be inkoveked by JSON survery, please DO NOT DELETE
  private getChoicesFromIniziativeAcquisition(): void {
    this.interviewService.getListOfIniziativeDiAcquisition().subscribe(res => {
      console.log('Iniziative di Acquisition: ', res);
      const choiceList: Array<SurveyAnswer> = [];
      res.forEach(element => {
        const choice = new SurveyAnswer;
        choice.id = element.codicePromo;
        choice.label = element.descrizBreve;
        choiceList.push(choice);
      });
      this.surveyQuestion.choices = choiceList;
    });
  }

  public saveAnswer(input): void {
    if (this.modify) {
      this.saveModifiedAnswer();
    } else {
      this.submitted = true;
      if (this.prestitiPersonali) {
        this.loadModiPrestitiNextBranch();
      } else {
        this.loadNextBranch();
      }
      if (this.isLastQuestion) {
        this.showNextQuestion.emit(this.surveyQuestion);
      } else {
        this.showNextQuestion.emit(this.nextBranch);
      }

    }
  }

  loadNextBranch() {
    // returns sibling (input 'nextBranch') or nested branch depending on the answer
    if (this.nextBranch == null || this.nextBranch.length == 0) {
      this.surveyQuestion.choices.forEach(choice => {
        if (choice.label == this.selectedAnswer) {
          this.nextBranch = choice.nextQuestions;
        }
      });
    }
  }

  loadModiNextBranch() {
    this.surveyQuestion.choices.forEach(choice => {
      if (choice.id === this.changeRadAnd) {
        if (choice.nextQuestions) {
          this.nextBranch = choice.nextQuestions;
        }
      }
    });
  }

  loadModiPrestitiNextBranch() {
    if (this.surveyQuestionCopy) {
      if (this.prestitiPersonali) {
        const map = new Map();
        this.surveyQuestionCopy.forEach(question => {
          map.set(question.id, question);
        });
        const tempMap = map.get(this.surveyQuestion.id);
        tempMap.choices.forEach(choice => {
          if (choice.id === this.changeRadAnd || this.prestitiPersonali) {
            if (choice.nextQuestions) {
              this.nextBranch = choice.nextQuestions;
            }
          }
        });
      } else {
        let tempCopy: SurveyQuestion[];
        tempCopy = this.copyToTempVariable(this.surveyQuestionCopy, tempCopy);

        this.surveyQuestionCopy.forEach((question, index) => {
          if (question.id === this.surveyQuestion.id) {
            this.nextBranch = tempCopy.splice(index + 1, tempCopy.length);
          }
        });
      }
    }


  }

  private checkIfLowerThanD5() {
    this.saveAnswer(this);
  }

  public modifica(): void {
    this.confermaDisabled = true;
    this.modify = true;
    this.temp = this.selectedAnswer;
    if (this.surveyQuestion.type == 'textbox' && this.modify) {
      this.confermaTextDisabled = true;
      this.demoEvents.push({ eventName: 'keyup', eventCallBack: this.keyup.bind(this) });
    }
  }

  public annulla(): void {
    this.selectedAnswer = this.temp;
    this.modify = false;
  }

  public saveModifiedAnswerFunction(): void {
    this.modify = false;
    this.selectedAnswer ? this.submitted = true : this.submitted = false;
  }

  // TODO use this function to handle async process
  public removeOldNodes(): void {
  }

  public saveModifiedAnswer(): void {
    if (this.surveyQuestion.onSubmit === 'checkForFicsQuestions') {
      this.loadModiPrestitiNextBranch();
    } else {
      this.loadModiNextBranch();
    }
    if (this.proposalId != null && !this.newProposalCreation) {
      const ref = this.dialog.open(ModificaIntervistaPopupComponent, {
        data: this.proposalId,
        title: 'MODIFICA INTERVISTA',
        size: 'large'
      });
      ref.afterClosed.subscribe(result => {
        const msg: string = result;
        if (msg == 'conferma') {
          this.saveModifiedAnswerFunction();
          this.newProposalCreationChange.emit(true);
          this.changedQuestion.emit(this);
        } else {
          this.annulla();
        }
      });
    } else {
      this.saveModifiedAnswerFunction();
      this.loadNextBranch();
      this.changedQuestion.emit(this);
    }
  }

  public writeValue(value: any): void {
    // Writes a new value to the element
    // this.dataModel = value; can leave it blank
  }

  public registerOnTouched(onTouched: () => void): void {
    this.onTouched = onTouched;
  }

  public registerOnChange(onChange: any): void {
    // Sets the function to be called when the control receives a change event.
    this.onChange = onChange;
  }

  protected modelChange(event): void {
    if (this.onChange !== undefined && this.onChange != null) {
      this.onChange('');
    }
    // check if value is changed after clicking modifica button
    if (this.modify && this.selectedAnswer !== this.temp
      && (this.selectedAnswer !== 'Surroga'
        && this.selectedAnswer !== 'Sostituzione'
        && (this.selectedAnswer && this.selectedAnswer.toUpperCase()
          !== ('Acquisto beni di consumo').toUpperCase()))) {
      this.confermaTextDisabled = false;
      this.confermaDisabled = false;
      this.checkConferma = false;

    } else if (this.selectedAnswer === 'Surroga'
      || this.selectedAnswer === 'Sostituzione'
      || (this.selectedAnswer && this.selectedAnswer.toUpperCase() === ('Acquisto beni di consumo').toUpperCase())) {
      this.confermaDisabled = true;
    } else {
      this.confermaTextDisabled = true;
      if (this.modify && this.temp === this.selectedAnswer) {
        this.confermaDisabled = true;
      } else {
        this.confermaDisabled = false;
      }
      this.checkConferma = true;
    }
  }

  protected setDefaultChoise(defaultChoise: string): void {
    // TODO try to make this method abstract withour breaking ng build --prod
  }

  protected scroll() {
    window.scrollTo(0, 8000);
  }

  protected answerOnChange(input, event) {
    this.surveyQuestion.choices.forEach(choice => {
      if (choice.label === input.textContent) {
        this[choice.onChange](input, event);
      }
    });
  }

  protected showPopupNoFondoPrimaCasa(): void {
    const dialogRef = this.dialog.open(InterviewMessagePopupComponent, {
      title: 'ATTENZIONE',
      data: {
        message: 'Attualmente non vendibile da BStore. E\' necessario procedere con PEF Ordinaria.',
        showWrongMacroCategoryPopup: false
      },
      size: 'large'
    });
    dialogRef.afterClosed.subscribe(result => {
      this.clearAnswer();
    });
  }

  protected showWrongMacroCategoryPopup(): void {
    if (this.selectedAnswer === 'No') {
      const dialogRef = this.dialog.open(InterviewMessagePopupComponent, {
        title: 'ATTENZIONE',
        data: {
          message: 'Hai sbagliato macro-categoria di mutuo. Scegliere un prodotto diverso.',
          showWrongMacroCategoryPopup: true
        },
        size: 'large'
      });
      dialogRef.afterClosed.subscribe(result => {
        if (result === 'goBackToProductList') {
          const mainNdg = this.ndgList[0];
          this.redirectService.redirectWithSpinner(this.endpointsService.openCart
            + '?modifyProposal=false&ndg=' + mainNdg + '&gotoCongif=false&isAdditionalCard=false&preselectedCategory=M75');
        }
      });
    } else {
      this.saveAnswer(this);
    }
    if (this.nextBranch[0].onChange === 'showBperEmployeePopup') {
      this.interviewService.containsBankEmployee(this.ndgList).subscribe(isBperEmployee => {
        if (isBperEmployee) {
          const dialogRef = this.dialog.open(InterviewMessagePopupComponent, {
            title: 'ATTENZIONE',
            data: { message: 'Non è possibile selezionare questa opzione. Rivedere la coerenza con le domande precedenti' },
            size: 'large'
          });
        }
      });
    }
  }

  protected showCategoriaSelezioneErrorPopup(input, event): void {
    if (input.textContent === 'No') {
      const dialogRef = this.dialog.open(InterviewMessagePopupComponent, {
        title: 'ATTENZIONE',
        data: {
          message: 'Categoria selezionata errata. Tornare al catalogo prodotti.',
          showWrongMacroCategoryPopup: true
        },
        size: 'large'
      });
      dialogRef.afterClosed.subscribe(result => {
        if (result === 'goBackToProductList') {
          const mainNdg = this.ndgList[0];
          this.redirectService.redirectWithSpinner(this.endpointsService.openCart
            + '?modifyProposal=false&ndg=' + mainNdg + '&gotoCongif=false&isAdditionalCard=false&preselectedCategory=M75');
        } else {
          this.clearAnswer();
        }
      });
    } else {
      this.change(input, event);
    }
  }

  protected clearAnswer() { }

  protected showBperEmployeePopup(input, event): void {
    if (input.textContent == 'Si') {
      const dialogRef = this.dialog.open(InterviewMessagePopupComponent, {
        title: 'ATTENZIONE',
        data: {
          message: 'Non è possibile selezionare questa opzione. Rivedere la coerenza con le domande precedenti',
          showWrongMacroCategoryPopup: false
        },
        // message : ,
        size: 'large'
      });
      dialogRef.afterClosed.subscribe(result => {
        this.clearAnswer();
      });
    } else {
      this.change(input, event);
    }
  }

  // skip question 11.e and show the next one in case there's a joint OR in case the user is not a bper employee but D11==Si
  protected checkAndSkipIfJoint() {
    if (this.checkIfJoint()) {
      this.skipAndShowNext();
    } else {
      this.interviewService.containsBankEmployee(this.ndgList).subscribe(isBperEmployee => {
        if (isBperEmployee) {
          this.skipAndShowNext();
        }
      });
    }
  }

  protected checkIfJoint(): boolean {
    return this.ndgList.length > 1;
  }

  protected skipAndShowNext() {
    this.loadNextBranch();
    this.skipCurrentAndShowNextQuestion.emit(this.nextBranch);
  }

  protected hideAndShowNext() {
    this.loadNextBranch();
    this.hideCurrentAndShowNextQuestion.emit(this.nextBranch);
  }

  private checkForFicsQuestions() {
    if (this.selectedAnswer === 'No') {
      this.prestitiPersonali = false;
      this.saveAnswer(this);
    } else {
      this.prestitiPersonali = true;
      this.saveAnswer(this);
    }
  }

  lastQuestion() {
    this.isLastQuestion = true;
    this.saveAnswer(this);
  }

  saveTempRadioAnswerZero() {
    if (this.modify) {
      this.arrayOfThreeAnswers.splice(0, 1);
    }
    this.arrayOfThreeAnswers[0] = this.selectedAnswer;
    this.saveAnswer(this);
  }

  saveTempRadioAnswerOne() {
    if (this.modify) {
      this.arrayOfThreeAnswers.splice(1, 1);
    }
    this.arrayOfThreeAnswers[1] = this.selectedAnswer;

    this.saveAnswer(this);
  }

  callPopupOrProceed() {
    if (this.modify) {
      this.arrayOfThreeAnswers.splice(2, 1);
    }
    if (this.arrayOfThreeAnswers.length === 3) {
      this.arrayOfThreeAnswers.splice(2, 1);
    }
    this.arrayOfThreeAnswers[2] = this.selectedAnswer;

    let showPopup = true;
    this.arrayOfThreeAnswers.forEach(element => {
      console.log(element);
      if (element === 'Si') {
        showPopup = false;
      }
    });
    if (showPopup) {
      this.showPrestitiPersonaliPopup();
    } else {
      this.saveAnswer(this);
    }
  }

  private hideForPrestitiPersonali(): void {
    this.selectedAnswer = 'No';
    this.skipAndShowNext();
  }

  selectDefaultRadioAnswer(): void {
    this.selectedAnswer = 'Acquisto Beni di Consumo?';
  }

  saveDefaultRadioAnswer(): void {
    this.saveAnswer(this);
  }

  showPrestitiPersonaliPopup() {
    const errorMessage = 'Categoria prodotti errata. \u00C8 necessario selezionare la categoria "Prestiti Personali Bibanca"';
    const dialogRef = this.dialog.open(InterviewMessagePopupComponent, {
      title: 'ATTENZIONE',
      data: {
        message: errorMessage,
        showWrongMacroCategoryPopup: true
      },
      size: 'large'
    });
    dialogRef.afterClosed.subscribe(result => {
      if (result === 'goBackToProductList') {
        const mainNdg = this.ndgList[0];
        this.redirectService.redirectWithSpinner(this.endpointsService.openCart
          + '?modifyProposal=false&ndg=' + mainNdg + '&gotoCongif=false&isAdditionalCard=false&preselectedCategory=M75');
      }
    });
  }

  public copyToTempVariable(copyFrom: SurveyQuestion[], copyTo: SurveyQuestion[]) {
    copyTo = [];
    copyFrom.forEach((question, index) => {
      copyTo[index] = copyFrom[index];
    });
    return copyTo;
  }
}
