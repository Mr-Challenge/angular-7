import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InterviewQuestionCheckboxComponent } from './interview-question-checkbox.component';

describe('InterviewQuestionCheckboxComponent', () => {
  let component: InterviewQuestionCheckboxComponent;
  let fixture: ComponentFixture<InterviewQuestionCheckboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InterviewQuestionCheckboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InterviewQuestionCheckboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
