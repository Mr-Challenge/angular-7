import { HttpClient } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import { ControlContainer, NgForm, NgModelGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DialogService, RedirectService } from 'bstore-angular-library';
import { InterviewService } from '../../../services/interview.service';
import { InterviewQuestionComponent } from '../interview-question.component';
import { EndpointsService } from 'src/app/services/endpoints.service';

@Component({
  selector: 'bst-fin-interview-question-textbox',
  templateUrl: './interview-question-textbox.component.html',
  styleUrls: ['./interview-question-textbox.component.scss'],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
  providers: [
    { provide: InterviewQuestionComponent, useExisting: InterviewQuestionTextboxComponent }
  ]
})
export class InterviewQuestionTextboxComponent extends InterviewQuestionComponent {

  @ViewChild('questionForm') public textboxTemplateRef: NgModelGroup;

  checkIfValid: boolean;
  ifPrice: boolean;
  inputText: string;
  checkFamPatten: boolean = false;

  constructor(public interviewService: InterviewService, public route: ActivatedRoute, public httpClient: HttpClient, public dialog: DialogService, public redirectService: RedirectService, public endpointsService: EndpointsService) {
    super(interviewService, route, httpClient, dialog, redirectService, endpointsService);
    this.checkIfValid = true;
  }

  public ngOnInit(): void {
    super.ngOnInit();
    this.clearAnswer();
    this.checkIfPrice();
    //FIXME: the next line caused an issue: on focus of input you saw ',00', instead of on focus out
    // this.demoEvents.push({ eventName: 'focus', eventCallBack: this.change.bind(this)});
  }

  public keyup(input, event): void {
    if (this.modify && ((this.temp === this.inputText) || (this.interviewService.toDecimal(this.temp) === (this.interviewService.toDecimal(this.inputText))))){
      this.confermaTextDisabled=true;
    }else{
      this.confermaTextDisabled=false;
    }
    
    if (!this.ifPrice) {
      this.checkNonPriceInput();
    }
  }

  public change(input, event): void {

    //commented because it was impossible to add value 0,00
    //removing leading zeroes
    // while((this.inputText.charAt(0))=='0'){
    //   console.log(this.inputText);
    //   console.log(this.inputText.slice(1));
    //   this.inputText = this.inputText.slice(1)
    // }

    if (this.ifPrice) {
      //this.inputText = parseFloat(this.inputText).toLocaleString('es-ES')
      console.log(this.textboxTemplateRef.valid);

      if (this.textboxTemplateRef.valid) {
        this.numberWithCommas(this.inputText);
        this.appendAtTheEnd(this.inputText);
      }

      console.log(this.inputText);
    } else {
      this.checkNonPriceInput();
    }
    this.selectedAnswer = this.inputText;
    super.modelChange(event);
  }

  public appendAtTheEnd(inputText): void {
    if (inputText !== null) {
      let textLength = inputText.length - 3;
      var regex = new RegExp('^[0-9.]*$')
      var regexZero = new RegExp('^0+$')
      var reg = new RegExp('^\\d{1,3}(.\\d{3})*$')

      if (!(this.inputText.indexOf(",") < 0) && ((this.inputText.length - this.inputText.indexOf(",")) > 3)) {
        this.inputText = inputText;
      }
      else if (this.inputText.charAt(inputText.length - 2) == ","
        && regex.test(this.inputText.charAt(this.inputText.length - 1))
        && regex.test(this.inputText.toString().slice(0, inputText.length - 2))) {
        this.inputText = inputText.concat("0")
      }
      else if (Number(inputText) || reg.test(this.inputText)) {
        this.inputText = inputText.concat(",00")
      }
      else if (regexZero.test(this.inputText)) {
        this.inputText = "0,00";
      }
      else {
        this.inputText = inputText;
      }
      let num = Number(inputText.replace(new RegExp('[.]', 'g'), '').replace(new RegExp('[,]', 'g'), '.')).toFixed(2);
      let inum = num.replace(new RegExp('[\.]', 'g'), ',');
      this.numberWithCommas(inum);
    }
  }

  public annulla(): void {
    this.inputText = this.temp;
    super.annulla()
  }

  protected setDefaultChoise(defaultChoise: string): void {
    this.inputText = defaultChoise;
  }

  numberWithCommas(inputObt) {
    inputObt = inputObt.toString().replace(/\./g, '');
    this.inputText = inputObt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');

  }

  checkNonPriceInput() {
    var reg = new RegExp('^$|^[+ 0-9]{1,20}$');
    if (reg.test(this.inputText)) {
      this.checkFamPatten = true;
    }
    else {
      this.checkFamPatten = false;
    }
  }

  protected clearAnswer() {
    this.inputText = "";
  }

  checkIfPrice() {
    if (this.surveyQuestion.choices[0].additionalData && this.surveyQuestion.choices[0].additionalData.price) {

      this.ifPrice = true;
    } else {
      this.ifPrice = false;
    }
  }

  //async case
  prepopulate() {
    this.inputText = this.answerAsync;
    super.prepopulate();
  }

  public modifica(): void {
    this.inputText = this.selectedAnswer;
    super.modifica();
  }

}
