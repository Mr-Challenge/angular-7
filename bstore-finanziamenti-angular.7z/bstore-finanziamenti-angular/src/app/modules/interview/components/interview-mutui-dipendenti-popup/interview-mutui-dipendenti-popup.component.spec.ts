import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InterviewMutuiDipendentiPopupComponent } from './interview-mutui-dipendenti-popup.component';

describe('InterviewMutuiDipendentiPopupComponent', () => {
  let component: InterviewMutuiDipendentiPopupComponent;
  let fixture: ComponentFixture<InterviewMutuiDipendentiPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InterviewMutuiDipendentiPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InterviewMutuiDipendentiPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
