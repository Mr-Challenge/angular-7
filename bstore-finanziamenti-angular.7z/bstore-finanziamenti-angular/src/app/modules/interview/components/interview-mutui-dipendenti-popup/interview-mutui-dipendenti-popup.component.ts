import { Component, OnInit } from '@angular/core';
import { DialogRef, DialogModel } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';

@Component({
  selector: 'bst-fin-interview-mutui-dipendenti-popup',
  templateUrl: './interview-mutui-dipendenti-popup.component.html',
  styleUrls: ['./interview-mutui-dipendenti-popup.component.scss']
})
export class InterviewMutuiDipendentiPopupComponent implements OnInit {

  closeEvents: EventsModel[];
  constructor(public dialogRef: DialogRef, public config: DialogModel) { }

  ngOnInit() {
    this.closeEvents = [
      { eventName: 'click', eventCallBack: this.closeDialog.bind(this) }
    ];
  }

  closeDialog() {
    this.dialogRef.close('close');
  }

}
