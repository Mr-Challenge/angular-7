import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnnulloPropostaPopupComponent } from './annullo-proposta-popup.component';

describe('AnnulloPropostaPopupComponent', () => {
  let component: AnnulloPropostaPopupComponent;
  let fixture: ComponentFixture<AnnulloPropostaPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnnulloPropostaPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnnulloPropostaPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
