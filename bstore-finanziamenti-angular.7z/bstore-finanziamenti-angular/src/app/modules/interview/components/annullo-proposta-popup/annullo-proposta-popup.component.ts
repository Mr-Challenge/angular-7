import { Component, EventEmitter, OnInit } from '@angular/core';
import { DialogModel, DialogRef } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { PaginationService } from 'src/app/modules/notifications/services/pagination.service';
import { InterviewService } from '../../services/interview.service';
@Component({
  selector: 'bst-fin-annullo-proposta-popup',
  templateUrl: './annullo-proposta-popup.component.html',
  styleUrls: ['./annullo-proposta-popup.component.scss']
})
export class AnnulloPropostaPopupComponent implements OnInit {

  mutuoWrapper: any;
  ndg: any;
  jointHeading: boolean;
  proposalList: any[];
  pagerEmitter: EventEmitter<any> = new EventEmitter<any>();
  pagedItemsEmitter: EventEmitter<any> = new EventEmitter<any>();
  pager: any = {};
  pagedItems: any[];
  result: boolean = true || false;
  closeEvents: EventsModel[];
  interviewDisable = true;

  constructor(private interviewService: InterviewService, private paginationService: PaginationService,
    public dialogRef: DialogRef, private config: DialogModel) {
    const proposalList = this.config.data.proposalList;
    this.proposalList = [];
    // tslint:disable-next-line:forin
    for (const obj in proposalList) {
      this.proposalList.push({ 'idProposal': proposalList[obj], 'disabled': false });
    }
  }

  ngOnInit() {
    this.setPage(1);
    this.intialiseevent();
  }

  intialiseevent() {
    this.closeEvents = [
      { eventName: 'click', eventCallBack: this.closeDialog.bind(this) }
    ];
  }

  setPage(page: number) {
    // get pager object from service
    this.pager = this.paginationService.getPager(this.proposalList.length, page, 3);

    // get current page of items
    this.pagedItems = this.proposalList.slice(this.pager.startIndex, this.pager.endIndex + 1);
    this.pagerEmitter.emit(this.pager);
    this.pagedItemsEmitter.emit(this.pagedItems);
  }

  deleteProposalOnAnnullo(idProposal: string, index: number) {
    this.interviewService.deleteProposal(idProposal).subscribe(data => {
      this.result = data;
      if (this.result) {
        this.pagedItems[index].disabled = true;
      }
      this.checkForInterviewEnable(this.proposalList);
    });
  }

  checkForInterviewEnable(proposalList: any[]) {
    let foundPropToDelete = false;
    proposalList.forEach(data => {
      if (!data.disabled) {
        foundPropToDelete = true;
        return;
      }
    });
    if (!foundPropToDelete) {
      this.interviewDisable = false;
    }
  }

  closeDialog() {
    this.dialogRef.close('interview');
  }
}
