import { Component, OnInit } from '@angular/core';
import { DialogRef } from 'bstore-angular-library';
import { DialogModel } from 'bstore-angular-library';

@Component({
  selector: 'bst-fin-modifica-intervista-popup',
  templateUrl: './modifica-intervista-popup.component.html',
  styleUrls: ['./modifica-intervista-popup.component.scss']
})
export class ModificaIntervistaPopupComponent implements OnInit {

  constructor(public dialog: DialogRef, public config: DialogModel) { }

  ngOnInit() {
  }

  onAnnulla() {
    this.dialog.close('annulla');
  }

  onConferma(){
    this.dialog.close('conferma');
  }

}
