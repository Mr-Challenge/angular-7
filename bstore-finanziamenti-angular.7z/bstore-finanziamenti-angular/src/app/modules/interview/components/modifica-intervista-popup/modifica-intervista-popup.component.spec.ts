import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModificaIntervistaPopupComponent } from './modifica-intervista-popup.component';

describe('ModificaIntervistaPopupComponent', () => {
  let component: ModificaIntervistaPopupComponent;
  let fixture: ComponentFixture<ModificaIntervistaPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModificaIntervistaPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModificaIntervistaPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
