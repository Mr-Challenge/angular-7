import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InterviewMessagePopupComponent } from './interviewmessage-popup.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

describe('MessagePopupComponent', () => {
  let component: InterviewMessagePopupComponent;
  let fixture: ComponentFixture<InterviewMessagePopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [InterviewMessagePopupComponent],
      providers: [
        NgbActiveModal
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InterviewMessagePopupComponent);
    component = fixture.componentInstance;
    component.message = 'test';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
