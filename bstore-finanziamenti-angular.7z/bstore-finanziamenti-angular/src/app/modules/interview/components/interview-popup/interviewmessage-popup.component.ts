import { Component, OnInit, Input } from '@angular/core';
import { DialogRef, DialogModel } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';

@Component({
  selector: 'app-message-popup',
  templateUrl: './interviewmessage-popup.component.html',
  styleUrls: ['./interviewmessage-popup.component.scss']
})
export class InterviewMessagePopupComponent implements OnInit {

  @Input()
  message: any;

  closeEvents: EventsModel[];
  goBackEvent = [
    { eventName: 'click', eventCallBack: this.goBackToProductList.bind(this) }
  ];
  constructor(public dialogRef: DialogRef, public config: DialogModel) { }

  ngOnInit() {
    this.initializeEvents();
  }

  protected initializeEvents(): void {
    this.closeEvents = [
      { eventName: 'click', eventCallBack: this.closeDialog.bind(this) }
    ];
  }

  goBackToProductList() {
    this.dialogRef.close('goBackToProductList');
  }

  closeDialog() {
    this.dialogRef.close('close');
  }

}
