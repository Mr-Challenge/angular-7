import { OnInit, Input } from '@angular/core';
import { SurveyQuestion } from '../../models/surveyQuestion';

export abstract class SurveyComponent implements OnInit {

  @Input()
  public surveyQuestion: SurveyQuestion;

  constructor() { }

  public ngOnInit(): void {
    this.initializeEvents();
    this.checkAndloadChoicesFromService();
    this.loadPreselectedChoise();
  };

  protected invokeMethod(methodName: string): void {
    if (methodName) {
      console.log("INVOKING method: " + methodName);
      this[methodName]();
      console.log("INVOKED  method: " + methodName);
    }
  }

  protected managePreselectedChoiseByUrl<T extends string | boolean>(results: Array<T>): void {

    if (results == undefined || results.length == 0) {
      throw new Error("results is undefined or empty");
    }

    const choises = this.surveyQuestion.choices;
    if (choises == undefined || choises.length == 0) {
      throw new Error("choises is undefined or empty");
    }

    for (let result of results) {
      for (let answer of choises) {
        const additionalData = answer.additionalData;
        if (additionalData != undefined) {
          const preselectChoiceByUrlAdditionalData = additionalData.preselectChoiceByUrl;
          if (String(preselectChoiceByUrlAdditionalData) === String(result)) {
            this.setDefaultChoise(answer.label);
          }
        }
        else {
          throw new Error("additionalData field does not exist in JSON survey");
        }
      }
    }
  }

  protected abstract setDefaultChoise(defaultChoise: string): void;
  protected abstract initializeEvents(): void;

  private checkAndloadChoicesFromService(): void {
    this.invokeMethod(this.surveyQuestion.getChoicesFromService);
  }

  private loadPreselectedChoise(): void {
    this.invokeMethod(this.surveyQuestion.preselectChoiceByUrl);
  }

}
