import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmMessagePopupComponent } from './confirm-message-popup.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

describe('MessagePopupComponent', () => {
  let component: ConfirmMessagePopupComponent;
  let fixture: ComponentFixture<ConfirmMessagePopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ConfirmMessagePopupComponent],
      providers: [
        NgbActiveModal
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmMessagePopupComponent);
    component = fixture.componentInstance;
    component.message = 'test';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
