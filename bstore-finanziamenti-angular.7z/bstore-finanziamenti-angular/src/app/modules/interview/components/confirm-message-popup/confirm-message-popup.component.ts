import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {  DialogRef,  DialogModel } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';

@Component({
  selector: 'app-message-popup',
  templateUrl: './confirm-message-popup.component.html',
  styleUrls: ['./confirm-message-popup.component.scss']
})
export class ConfirmMessagePopupComponent implements OnInit {

  @Input()
  message: any;

  @Output() confirmClicked = new EventEmitter<any>();

  resetFiledToModify : boolean = false;
  siEvents: EventsModel[];
  noEvents: EventsModel[];

  constructor(public dialogRef: DialogRef, public config: DialogModel) { }

  ngOnInit() {
    this.initializeEvents();
  }

  protected initializeEvents(): void {
    this.siEvents = [
      { eventName: 'click', eventCallBack: this.callReset.bind(this) }
    ];
    this.noEvents = [
      { eventName: 'click', eventCallBack: this.closeDialog.bind(this) }
    ];
  }

  callReset() { 
    this.resetFiledToModify = true;
    this.confirmClicked.emit(this.resetFiledToModify);
    this.dialogRef.close(this.resetFiledToModify);
  }

  closeDialog() {
    this.dialogRef.close(this.resetFiledToModify);
  }

}
