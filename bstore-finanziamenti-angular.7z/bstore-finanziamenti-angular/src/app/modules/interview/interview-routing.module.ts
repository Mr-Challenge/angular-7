import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InterviewComponent } from './pages/interview/interview.component';

const routes: Routes = [
  { path: '', component: InterviewComponent },
  { path: ':proposalId', component: InterviewComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InterviewRoutingModule { }
