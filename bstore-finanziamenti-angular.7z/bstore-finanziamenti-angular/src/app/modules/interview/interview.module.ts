import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BstoreCommonModule } from '../bstore-common/bstore-common.module';
import { InterviewQuestionCheckboxComponent } from './components/interview-question/interview-question-checkbox/interview-question-checkbox.component';
import { InterviewQuestionRadioButtonComponent } from './components/interview-question/interview-question-radio-button/interview-question-radio-button.component';
import { InterviewQuestionTextboxComponent } from './components/interview-question/interview-question-textbox/interview-question-textbox.component';
import { InterviewQuestionComponent } from './components/interview-question/interview-question.component';
import { InterviewRoutingModule } from './interview-routing.module';
import { InterviewComponent } from './pages/interview/interview.component';


@NgModule({
  declarations: [
    InterviewComponent,
    InterviewQuestionCheckboxComponent,
    InterviewQuestionRadioButtonComponent,
    InterviewQuestionTextboxComponent,
    InterviewQuestionComponent
  ],
  imports: [
    BstoreCommonModule,
    InterviewRoutingModule,
    FormsModule
  ], entryComponents: [
    InterviewQuestionRadioButtonComponent,
    InterviewQuestionTextboxComponent
  ]
})
export class InterviewModule { }
