import { TestBed } from '@angular/core/testing';

import { PefService } from './pef.service';

describe('PefService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PefService = TestBed.get(PefService);
    expect(service).toBeTruthy();
  });
});
