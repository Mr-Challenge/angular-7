import { TestBed } from '@angular/core/testing';

import { VenditaCommonService } from './vendita-common.service';

describe('VenditaCommonService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: VenditaCommonService = TestBed.get(VenditaCommonService);
    expect(service).toBeTruthy();
  });
});
