import { TestBed } from '@angular/core/testing';

import { VenditaPageService } from './vendita-page.service';

describe('VenditaPageService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: VenditaPageService = TestBed.get(VenditaPageService);
    expect(service).toBeTruthy();
  });
});
