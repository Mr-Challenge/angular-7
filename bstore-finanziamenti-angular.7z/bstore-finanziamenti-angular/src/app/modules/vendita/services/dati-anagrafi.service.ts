import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { EndpointsService } from "../../../services/endpoints.service";

@Injectable({
  providedIn: 'root'
})
export class DatiAnagrafiService {

  iconFlagStato: boolean;
  fidiGaranzieAccordion: boolean;
  private setAsyncNdgList = new BehaviorSubject('');

  constructor(private httpClient: HttpClient, private endpointsService: EndpointsService) {
    this.iconFlagStato = true;
    this.fidiGaranzieAccordion = true;
  }

  getSchedaPrivatiData(baseClientListVm: any[]) {
    return this.httpClient.post<any[]>(this.endpointsService.schedaPrivatiData, baseClientListVm);
  }

  deleteClientBYType(ndg, proposalId, role) {
    const params = new HttpParams();
    const parameters = params.append('idProposal', proposalId).append('ndg', ndg).append('clientRole', role);
    return this.httpClient.get<any>(this.endpointsService.deleteClientByRole, { params: parameters });
  }

  setNdgList(ndgList: string) {
    this.setAsyncNdgList.next(ndgList);
  }

  getNdgList(): Observable<any> {
    return this.setAsyncNdgList.asObservable();
  }

}
