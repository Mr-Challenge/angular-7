import { TestBed } from '@angular/core/testing';

import { DatiAnagrafiService } from './dati-anagrafi.service';

describe('DatiAnagrafiService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DatiAnagrafiService = TestBed.get(DatiAnagrafiService);
    expect(service).toBeTruthy();
  });
});
