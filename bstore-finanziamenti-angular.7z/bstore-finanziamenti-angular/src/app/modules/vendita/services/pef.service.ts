import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { VenditaPef } from 'src/app/models/vendita-pef';
import { environment } from 'src/environments/environment';
import { EndpointsService } from '../../../services/endpoints.service';
import { ContoCorrenteDetailsModel } from '../models/conto-corrente-details.model';
import { GuaranteesInputModel } from '../models/guarantees.input';
import { InterviewResponse } from '../models/interview-response-vm';
import { RequestVenditaVm } from '../models/request-vendita-vm.model';
import { SimulationDataModel } from '../models/simulation-data.model';
import { TipoResponseModel } from '../models/tipo.response.model';
import { VenditaFetchDocumentVm } from '../models/vendita-fetch-document-vm.model';
import { VenditaPageVm } from '../models/vendita-page-vm.model';
import { UpdateDocsModel } from '../models/updateDocsModel';
import { OtpFieldsVm } from '../models/otpFieldsVm.model';
import { VerificaAcquisizioneDocumentiModel } from 'bstore-angular-library';

@Injectable({
  providedIn: 'root'
})
export class PefService {

  constructor(private httpClient: HttpClient, private endpointsService: EndpointsService) { }

  getFormaTecnicaList(proposalId) {
    const params = new HttpParams();
    const parameters = params.append('proposalId', proposalId);
    return this.httpClient.get<VenditaPef>
      (`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/formaTecnicaList`, { params: parameters });
  }

  getAccountDetails(ndg: string) {
    const params = new HttpParams();
    const parameters = params.append('ndg', ndg);
    return this.httpClient.get<ContoCorrenteDetailsModel[]>
      (`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/getAccountDetails`, { params: parameters });
  }

  verifyOTPFields(ndg, naturaGiuridica) {
    const params = new HttpParams();
    const parameters = params.append('ndg', ndg).append('naturaGiuridica', naturaGiuridica);
    return this.httpClient.get<OtpFieldsVm>
      (`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/verifyOTPFields`, { params: parameters });
  }
  getSimulationData(proposalId: number) {
    const params = new HttpParams();
    const parameters = params.append('proposalId', proposalId.toString());
    return this.httpClient.get<SimulationDataModel>
      (`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/getSimulationDataFromService`, { params: parameters });
  }

  getGuarantees(guaranteesInputModel: GuaranteesInputModel) {
    return this.httpClient.post<any>
      (`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/getGuarantees`, guaranteesInputModel);
  }

  getRisultatoCreazioneNuovaPratica(idProposta: number, idPrenotazione: string) {
    const params = new HttpParams();
    const parameters = params.append('idProposta', idProposta.toString()).append('idPrenotazione', idPrenotazione);
    return this.httpClient.get<string>(this.endpointsService.getRisultatoCreazioneNuovaPratica, { params: parameters });
  }

  saveVenditaData(requestVenditaVm: RequestVenditaVm): Observable<any> {
    return this.httpClient.post<boolean>
      (`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/saveVendita`, requestVenditaVm);
  }

  saveConsensoSicData(consisoRequestData): Observable<any> {
    return this.httpClient.post<boolean>
      (`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/consenso/saveCollectedConsenso`, consisoRequestData);
  }

  getDocumentiDetails(data): Observable<VerificaAcquisizioneDocumentiModel> {
    return this.httpClient.post<VerificaAcquisizioneDocumentiModel>(`${environment.devUrlJSON['npv.service.callback.url']}/api/verificaAcquisizioneDocumenti`, data);
  }

  getMutuiDocumentiDetails(data): Observable<VerificaAcquisizioneDocumentiModel> {
    return this.httpClient.post<VerificaAcquisizioneDocumentiModel>(`${environment.devUrlJSON['npv.service.callback.url']}/api/verificaAcquisizioneMutuiDocumenti`, data);
  }

  getTipoDescrizioneData(techniciaCode: string) {
    const params = new HttpParams();
    const parameters = params.append('techniciaCode', techniciaCode);
    return this.httpClient.get<TipoResponseModel>
      (`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/recuperaGaranzieAmmessePerFido`, { params: parameters });
  }

  /* retrieveVendita Data */
  getVenditaPageData(proposalId: number): Observable<any> {
    const params = new HttpParams();
    const parameters = params.append('proposalId', proposalId.toString());
    return this.httpClient.get<VenditaPageVm>(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/getVenditaData`,
      { params: parameters });
  }

  getGenerateDocVm(venditaFetchDocumentVm: VenditaFetchDocumentVm): Observable<any> {
    return this.httpClient.post(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/getGenerateDocVm`, venditaFetchDocumentVm);
  }

  saveAcquiredDocStatus(ndg: string, proposalId): Observable<boolean> {
    const params = new HttpParams();
    const parameters = params.append('acquisitionKey', ndg).append('idProposal', proposalId);
    return this.httpClient.get<boolean>
      (`${environment.devUrlJSON['npv.service.callback.url']}/api/saveAcquiredDocStatus`, { params: parameters });
  }

  findAcquiredDocStatus(proposalId): Observable<String[]> {
    const params = new HttpParams();
    const parameters = params.append('idProposal', proposalId);
    return this.httpClient.get<String[]>
      (`${environment.devUrlJSON['npv.service.callback.url']}/api/findAcquiredDocStatus`, { params: parameters });
  }

  updateAcquiredDocs(updateDocsModel: UpdateDocsModel): Observable<boolean> {
    return this.httpClient.post<boolean>
      (`${environment.devUrlJSON['npv.service.callback.url']}/api/updateAcquiredDocs`, updateDocsModel);
  }

  getAllContiTecniciType(proposalId: number) {
    const params = new HttpParams();
    const parameters = params.append('proposalId', proposalId.toString());
    return this.httpClient.get<boolean>
      (`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/showAllContiTecniciType`, { params: parameters });
  }

  public getNotaPratica(idPef: string, categoriaNota: string) {
    const params = new HttpParams();
    const parameters = params.append('idPef', idPef).append('categoriaNota', categoriaNota);
    return this.httpClient.get(this.endpointsService.getNotaPratica, { params: parameters, responseType: 'text' });
  }
}
