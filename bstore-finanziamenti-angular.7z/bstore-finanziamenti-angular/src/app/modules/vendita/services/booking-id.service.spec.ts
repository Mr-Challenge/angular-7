import { TestBed } from '@angular/core/testing';

import { BookingIdService } from './booking-id.service';

describe('BookingIdService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BookingIdService = TestBed.get(BookingIdService);
    expect(service).toBeTruthy();
  });
});
