import { Injectable } from '@angular/core';
import { GuaranteesModel } from '../models/guarantees.model';
import { Subject, Observable, BehaviorSubject, ReplaySubject } from 'rxjs';
import { AltreBancheModel } from '../models/altre-banche.model';
import { PrefinanziamentoModel } from '../models/prefinanziamento.model';
import { SimulationDataModel } from '../models/simulation-data.model';
import { HttpParams, HttpClient } from '@angular/common/http';
import { MutuiProductwrapper } from '../../interview/models/MutuiProductwrapper';
import { EndpointsService } from 'src/app/services/endpoints.service';
import { D2AnswerVm } from '../models/d2AnswerVM.model';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class VenditaCommonService {
  allGranzie = new BehaviorSubject<GuaranteesModel>(null);
  altraBranche = new Subject<any>();
  venditaPageData = new Subject<any>();
  currentGranzie: GuaranteesModel;
  granzieList: Array<GuaranteesModel>;
  allAltreBanche: Array<AltreBancheModel>;
  prefinanziamentoModel = new PrefinanziamentoModel;
  documentData: any;
  formaTecnica: any;
  selecteFormaTecnica = new Subject<any>();
  venditaData = [];
  simulationData: SimulationDataModel;
  acquiredDocument = new Subject<any>();
  privateCardData: any;
  d2Answer: string;
  d2AnswerForDocumenti: D2AnswerVm;
  constructor(private httpClient: HttpClient, private endpointsService: EndpointsService)  { }

  setGranzie(data) {
    data.selectedGuarantee = true;
    this.allGranzie.next(data);
  }

  getGranzie() {
    return this.allGranzie;
  }

  setGranzieList(data) {
    this.granzieList = data;
  }

  getGranzieList() {
    return this.granzieList;
  }

  selectedGranzie() {
    return this.currentGranzie;
  }
  setCurrentGranzie(data) {
    this.currentGranzie = data;
  }
  setFirmaTechnicia(firmaCode) {
    this.formaTecnica = firmaCode;
  }
  getFirmaTechnicia() {
    return this.formaTecnica;
  }

  setAltreBanche(data) {
    this.altraBranche.next(data);
  }

  getAltreBanche() {
    return this.allAltreBanche;
  }


  setVenditaPageData(key, data) {
    this.venditaData['key'] = key;
    this.venditaData['value'] = data;
    this.venditaPageData.next(this.venditaData);
  }

  setPreFinzi(prefinanziamento) {
    this.prefinanziamentoModel = prefinanziamento;
  }
  getPreFinzi() {
    return this.prefinanziamentoModel;
  }
  setSimulationData(simulationData: SimulationDataModel) {
    this.simulationData = simulationData;
  }

  getSimulationData(): SimulationDataModel {
    return this.simulationData;
  }

  setDocumentiData(data) {
    this.documentData = data;
  }

  getDocumentiData() {
    return this.documentData;
  }

  setAcquiredDocument(ndg) {
    this.acquiredDocument.next(ndg);
  }

  setPrivateCardData(data) {
    this.privateCardData = data;
  }

  getPrivateCardData() {
    return this.privateCardData;
  }

  setD2AnswerLocal(data) {
    this.d2AnswerForDocumenti = data;
  }

  getD2AnswerLocal() {
    return of(this.d2AnswerForDocumenti);
  }
  
  setSelectedFirmaTechnicia(data) {
    this.selecteFormaTecnica.next(data);
  }

  getSelectedFirmaTechnicia() {
    return this.selecteFormaTecnica;
  }
  public getD2Answer(idProposal: string): Observable<any> {
    const params = new HttpParams();
    const parameters = params.append('idProposal', idProposal);
    return this.httpClient.get<D2AnswerVm>(this.endpointsService.getCheckD2Answer, { params: parameters });
  }

  public getDefaultGuarantees(): Observable<any> {
    return this.httpClient.get<GuaranteesModel>(this.endpointsService.getDefaultGuarantees);
  }

}
