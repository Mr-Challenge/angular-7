import { TestBed } from '@angular/core/testing';

import { SchedaPrivatiIntegrationService } from './scheda-privati-integration.service';

describe('SchedaPrivatiIntegrationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SchedaPrivatiIntegrationService = TestBed.get(SchedaPrivatiIntegrationService);
    expect(service).toBeTruthy();
  });
});
