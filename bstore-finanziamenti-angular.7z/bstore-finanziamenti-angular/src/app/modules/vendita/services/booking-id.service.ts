import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EndpointsService } from '../../../services/endpoints.service';

@Injectable({
  providedIn: 'root'
})
export class BookingIdService {

  constructor(private httpClient: HttpClient, private endpointsService: EndpointsService) { }

  getBookingId(proposalId: number, ndg: string) {
    const params = new HttpParams();
    const parameters = params.append('proposalId', proposalId.toString()).append('ndg', ndg);
    return this.httpClient.get<string>(this.endpointsService.generateBookingId, { params: parameters });
  }

}
