import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EndpointsService } from '../../../services/endpoints.service';

import { FetchAnomalies } from 'src/app/models/fetchAnomalies.model';
import { ForborneAnomaliesAndForceData } from 'src/app/models/forborneAnomaliesForceData.model';
import { LoanPurposeModel } from '../../product-configuration/models/LoanPurposeModel';

@Injectable({
  providedIn: 'root'
})
export class ForborneService {

  constructor(private httpClient: HttpClient, private endpointsService: EndpointsService) { }

  public getAnomaliaListAndDataToForce(fetchAnomalie: FetchAnomalies): Observable<ForborneAnomaliesAndForceData> {
    //return this.httpClient.get<ForborneAnomaliesAndForceData>('assets/mock_data/product-configuration/forborne.json');
    return this.httpClient.post<ForborneAnomaliesAndForceData>(this.endpointsService.fetchAnomaliaListAndDataToForce, fetchAnomalie);
  }


  public selectFinancingPurposeForCategory(mutuoCategory: string): Observable<LoanPurposeModel[]> {
    const url = this.endpointsService.selectFinancingPurposeForCategory;
    let parameters = new HttpParams().append('macroCategory', mutuoCategory);
    return this.httpClient.get<LoanPurposeModel[]>(url, { params: parameters });

  }

}
