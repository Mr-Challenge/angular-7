import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EndpointsService } from '../../../services/endpoints.service';
import { SignatureStatusModel } from '../models/signature-status.model';


@Injectable({
  providedIn: 'root'
})
export class VenditaPageService {

  constructor(private httpClient: HttpClient, private endpointsService: EndpointsService) { }

  censisciDaInformativa(proposalId): Observable<boolean> {
    const params = new HttpParams();
    const parameters = params.append('proposalId', proposalId);
    return this.httpClient.post<boolean>(this.endpointsService.censisciDaInformativaPersonalizzata, parameters);
  }
}
