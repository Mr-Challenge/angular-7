import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SicContentComponent } from './sic-content.component';

describe('SicContentComponent', () => {
  let component: SicContentComponent;
  let fixture: ComponentFixture<SicContentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SicContentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SicContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
