import { Component, OnInit, Input, ViewChild, AfterViewInit, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { SicContent } from 'src/app/models/sic-content';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import {
  NgModelGroup, NG_VALUE_ACCESSOR,
  NG_VALIDATORS, ControlContainer, NgForm
} from '@angular/forms';
import { InputConsensoVm } from '../../models/input-consenso-vm.model';

@Component({
  selector: 'bst-fin-sic-content',
  templateUrl: './sic-content.component.html',
  styleUrls: ['./sic-content.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: SicContentComponent, multi: true },
    { provide: NG_VALIDATORS, useExisting: SicContentComponent, multi: true }
  ],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class SicContentComponent implements OnInit, AfterViewInit {

  @Input() sicContent: any;
  @Input() consensoType: string;
  @Input() consensoSicList: Array<InputConsensoVm>;

  @Output() consensoClicked = new EventEmitter<any>();
  answer: boolean[] = [];
  consensoSiNo: boolean;
  consensoList: Array<InputConsensoVm> = [];
  changedSic: InputConsensoVm;
  name: string;
  selectedObj: any;
  @ViewChild('contentForm') public contentForm: NgModelGroup;

  constructor(private changeDetectorRef: ChangeDetectorRef) {
  }

  ngOnInit() {
    this.sicContent.forEach(sic => {
      if (this.consensoSicList) {
        this.consensoSicList.forEach(element => {

          let ndgExist = false;

          this.consensoList.forEach(ele => {
            if (ele.ndg == sic.ndg) {
              ndgExist = true;
            }
          });

          if (!ndgExist) {

            if (element.ndg === sic.ndg) {

              this.consensoList.push(
                {
                  name: sic.name + ' ' + sic.surname, consensoRoccolto: element.consensoRoccolto,
                  consensoType: this.consensoType, ndg: sic.ndg, birthDate: sic.birthDate
                });
              this.changeCallBack(null);

            } else if (this.consensoSicList.find(x => x.ndg === sic.ndg) === undefined) {

              this.consensoList.push(
                {
                  name: sic.name + ' ' + sic.surname, consensoRoccolto: null,
                  consensoType: this.consensoType, ndg: sic.ndg, birthDate: sic.birthDate
                });
            }
          }
        });
      } else {
        this.consensoList.push(
          { name: sic.name + ' ' + sic.surname, consensoRoccolto: null, consensoType: this.consensoType, ndg: sic.ndg });
      }
    });
  }

  changeCallBack(changedSic) {
    this.changedSic = changedSic;
    if (changedSic) {
      this.consensoClicked.emit({ consensoList: this.consensoList, rollBack: this.resetValue.bind(this) });
    }
  }

  ngAfterViewInit() {
    this.changeDetectorRef.detectChanges();
  }

  clearComponent() {
    delete this.contentForm;
  }

  resetValue() {
    this.consensoList.forEach(element => {
      if (element['ndg'] === this.changedSic['ndg']) {
        element['consensoRoccolto'] = !element['consensoRoccolto'];
      }
    });
  }
}
