import { Component, OnInit } from '@angular/core';
import { DialogRef, DialogModel } from 'bstore-angular-library';
import { VenditaPageService } from '../../services/vendita-page.service';
import { FinDocumentType } from 'src/app/constant/documentType';
import { SignatureStatusModel } from '../../models/signature-status.model';
import { TipoProcesso } from 'src/app/constant/tipoProcesso';
import { combineLatest } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'bst-fin-page-behaviour-pop-up',
  templateUrl: './page-behaviour-pop-up.component.html',
  styleUrls: ['./page-behaviour-pop-up.component.scss']
})
export class PageBehaviourPopUpComponent implements OnInit {

  siButtonClickEvents = [
    { eventName: 'click', eventCallBack: this.onPressSi.bind(this) }
  ];
  noButtonClickEvents = [
    { eventName: 'click', eventCallBack: this.onCloseMain.bind(this) }
  ];
  constructor(public dialog: DialogRef, public config: DialogModel, public venditaPageService: VenditaPageService,
    private commonService: CommonService) { }

  ngOnInit() {

  }

  onCloseMain() {
    this.dialog.close(false);
  }

  onPressSi() {
    const signatureStatus = <SignatureStatusModel>{
      processId: this.config.data.proposalId,
      processType: TipoProcesso.VENDITA,
      docToGenerate: [FinDocumentType.RICHIESTA_PRESTITO]
    };
    combineLatest(
      this.commonService.deletePefId(this.config.data.proposalId),
      this.commonService.deleteDocuments(signatureStatus))
      .subscribe(([pefSuccess, docsSuccess]) => {
        // if (pefSuccess && docsSuccess) {
        if (pefSuccess) {
          this.dialog.close(true);
        }
      });
  }

}
