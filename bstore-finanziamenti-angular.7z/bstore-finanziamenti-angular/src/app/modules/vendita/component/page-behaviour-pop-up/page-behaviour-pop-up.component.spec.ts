import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageBehaviourPopUpComponent } from './page-behaviour-pop-up.component';

describe('PageBehaviourPopUpComponent', () => {
  let component: PageBehaviourPopUpComponent;
  let fixture: ComponentFixture<PageBehaviourPopUpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageBehaviourPopUpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageBehaviourPopUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
