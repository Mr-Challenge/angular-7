import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatiAnagrafiComponent } from './dati-anagrafi.component';

describe('DatiAnagrafiComponent', () => {
  let component: DatiAnagrafiComponent;
  let fixture: ComponentFixture<DatiAnagrafiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatiAnagrafiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatiAnagrafiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
