import { AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CustomerData } from 'src/app/models/customerData';
import { DatiAnagrafiService } from 'src/app/modules/vendita/services/dati-anagrafi.service';

@Component({
  selector: 'bst-fin-dati-anagrafi',
  templateUrl: './dati-anagrafi.component.html',
  styleUrls: ['./dati-anagrafi.component.scss']
})
export class DatiAnagrafiComponent implements OnInit, AfterViewInit {
  result: CustomerData;
  mutuoWrapper: any;
  @Input() componentEnable: boolean;
  @Input() proposalId: any;
  @Input() chirografarioFlag: boolean;
  @Input() GARClientRole: any;
  @Input() INTClientRole: any;
  @Input() TERClientRole: any;
  @Output() isDatiAnagrafiStatus = new EventEmitter();

  constructor(public datiAnagrafiService: DatiAnagrafiService, private route: ActivatedRoute
    , private cdr: ChangeDetectorRef) {
    this.mutuoWrapper = route.snapshot.queryParams['mutuoWrapper'];
  }
  ngOnInit() {
    this.isDatiAnagrafiStatus.emit(this.datiAnagrafiService.iconFlagStato);
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

}
