import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BaseFidiGaranzieSectionComponent } from './base-fidi-garanzie-section.component';

describe('BaseFidiGaranzieSectionComponent', () => {
  let component: BaseFidiGaranzieSectionComponent;
  let fixture: ComponentFixture<BaseFidiGaranzieSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BaseFidiGaranzieSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BaseFidiGaranzieSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
