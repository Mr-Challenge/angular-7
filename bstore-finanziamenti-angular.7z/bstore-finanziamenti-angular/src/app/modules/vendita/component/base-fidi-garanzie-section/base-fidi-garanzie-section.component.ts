import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { DialogService } from 'bstore-angular-library';
import { PageBehaviourPopUpComponent } from '../page-behaviour-pop-up/page-behaviour-pop-up.component';

@Component({
  selector: 'bst-fin-base-fidi-garanzie-section',
  template: 'NO UI TO BE FOUND HERE!'
})
export class BaseFidiGaranzieSectionComponent implements OnInit {

  @Input() proposalId: number;
  @Input() componentEnable: boolean;

  @Output() enableFidiGaranzieSections: EventEmitter<void> = new EventEmitter<void>();
  @Output() sectionValid: EventEmitter<boolean> = new EventEmitter();

  constructor(protected dialog: DialogService) { }

  ngOnInit() {
  }

  checkForPopUp() { // : Promise<>
    const self = this;
    return new Promise(function (resolve, reject) {
      if (!self.componentEnable) {
        const ref = self.dialog.open(PageBehaviourPopUpComponent, {
          data: { proposalId: self.proposalId },
          noCloseButton: true
        });
        ref.afterClosed.subscribe((result: boolean) => {
          if (result) {
            self.enableFidiGaranzieSections.emit();
            resolve();
          } else {
            reject();
          }
        });
      } else {
        resolve();
      }
    });
  }

}
