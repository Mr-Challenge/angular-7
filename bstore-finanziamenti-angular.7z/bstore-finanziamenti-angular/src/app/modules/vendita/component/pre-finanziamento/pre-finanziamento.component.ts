import { Component, Input, OnChanges, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DialogService, NpvErrorServiceService } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { InterviewResult } from 'src/app/models/interview-response-vm';
import { ContoCorrenteDetailsModel } from '../../models/conto-corrente-details.model';
import { InterviewResponse } from '../../models/interview-response-vm';
import { PrefinanziamentoModel } from '../../models/prefinanziamento.model';
import { SimulationDataModel } from '../../models/simulation-data.model';
import { PefService } from '../../services/pef.service';
import { VenditaCommonService } from '../../services/vendita-common.service';
import { BaseFidiGaranzieSectionComponent } from '../base-fidi-garanzie-section/base-fidi-garanzie-section.component';
import { SelectOptionModel } from 'bstore-angular-library/lib/models/select-option-model';

@Component({
  selector: 'bst-fin-pre-finanziamento',
  templateUrl: './pre-finanziamento.component.html',
  styleUrls: ['./pre-finanziamento.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PreFinanziamentoComponent extends BaseFidiGaranzieSectionComponent implements OnInit, OnChanges {

  @ViewChild('prefinForm') form: NgForm;

  @Input() prefinanziamentoModel: PrefinanziamentoModel;
  @Input() mainNdg: string;
  @Input() simulationData: SimulationDataModel;

  prefinanziamentoLabel: string;
  prefinanaziamentoSelection: boolean;
  validSection: boolean;
  importoLabel: string;
  durataLabel: string;
  accountLabel: string;
  durataValue: string;
  tipoConto: string;
  accountNumber: string;
  accountBranch: string;
  contoCorrenteDetails: ContoCorrenteDetailsModel[] = [];
  contoCorrenteOptions: SelectOptionModel[] = [];
  contoCorrenteMap: Map<string, ContoCorrenteDetailsModel> = new Map();
  importoEvent: EventsModel[] = [];
  durataEvent: EventsModel[] = [];
  accountEvent: EventsModel[] = [];
  importoValue: string;
  importoThreshold: string;
  durataThreshold: string;
  mcdPerimeter: boolean;
  amountThresholdError: boolean;
  durataThresholdError: boolean;
  durataMcdPerimeterError: boolean;
  durataNonMcdError: boolean;
  errorMessage: string;
  showAllContiTecniciTypeFlag:boolean;
  prefinFormData: PrefinanziamentoModel;
  importoErrorMessage: string;
  durataErrorMessage: string;
  showErrMsg: boolean;
  optionId: string;

  constructor(protected dialog: DialogService, private pefService: PefService,
    public npvErrorServiceService: NpvErrorServiceService,
    private venditaCommonService: VenditaCommonService) {
    super(dialog);
  }

  ngOnInit() {

    this.importoEvent = [
      { eventName: 'keyup', eventCallBack: this.validateFields.bind(this) }
    ];

    this.durataEvent = [
      { eventName: 'keyup', eventCallBack: this.validateFields.bind(this) }
    ];

    this.accountEvent = [{ eventName: 'change', eventCallBack: this.changeAccount.bind(this) }];

    this.prefinanziamentoLabel = 'Il richiedente vuole usufruire di un fido di pre-finanziamento?';
    this.importoLabel = 'Importo pre-finanziamento';
    this.durataLabel = 'Durata pre-finanziamento';
    this.accountLabel = 'Conto corrente';
    this.errorMessage = 'Non è stato recuperato alcun conto tecnico di prefinanziamento. Per richiedere un fido di pre-finanziamento ' +
      'è necessario aprire un conto dedicato in una nuova proposta';

    this.pefService.getAccountDetails(this.mainNdg).subscribe(data => {
      this.contoCorrenteDetails = data;
    }, null,
      () => {
        let interviewResponse: InterviewResponse;
        this.pefService.getAllContiTecniciType(this.proposalId).subscribe(response => {
          this.showAllContiTecniciTypeFlag = response;
        }, null,
          () => {
            if (this.contoCorrenteDetails) {
              this.contoCorrenteOptions = this.createOptionValues(this.contoCorrenteDetails);

              if (this.prefinanziamentoModel) {
                for (let i = 0; i < this.contoCorrenteMap.size; i++) {
                  const account: ContoCorrenteDetailsModel = this.contoCorrenteMap.get(i + '');
                  if (this.prefinanziamentoModel.accountNumber === account.number && 
                    this.prefinanziamentoModel.accountBranch === account.filiale) {
                    this.optionId = i + '';
                    break;
                  }
                }
              }

            }
          });
      });

    if (this.simulationData) {
      this.importoThreshold = this.simulationData.amount;
      this.durataThreshold = this.simulationData.durata;
      if (this.simulationData.perimeter === 'M') {
        this.mcdPerimeter = true;
      }
    }

    // async process start
    if (this.prefinanziamentoModel) {
      this.prefillForAsyncCase();
    }
    // async process ends
  }


  private prefillForAsyncCase() {
    this.prefinanaziamentoSelection = this.prefinanziamentoModel.prefinanziamentoFlag;
    this.tipoConto = this.prefinanziamentoModel.tipoConto;
    this.importoValue = this.prefinanziamentoModel.importoValue;
    this.durataValue = this.prefinanziamentoModel.durataValue;
    this.accountNumber = this.prefinanziamentoModel.accountNumber;
    this.accountBranch = this.prefinanziamentoModel.accountBranch;
    this.validSection = true;
    this.sectionValid.emit(this.validSection);
    this.prefinFormData = {
      prefinanziamentoFlag: this.prefinanaziamentoSelection,
      tipoConto: this.tipoConto, durataValue: this.durataValue, importoValue: this.importoValue,
      accountNumber: this.accountNumber, accountBranch: this.accountBranch
    };
    this.venditaCommonService.setVenditaPageData('prefinFormData', this.prefinFormData);

    
  }

  validateDropDownOptions(): boolean {
    return this.showAllContiTecniciTypeFlag;
  }

  binaryEvents(event) {

    this.checkForPopUp().then(() => {
      if (this.prefinanaziamentoSelection === false) {
        this.validSection = true;
        this.prefinFormData = {
          prefinanziamentoFlag: this.prefinanaziamentoSelection,
          tipoConto: null, durataValue: null, importoValue: null, accountNumber: null, accountBranch: null
        };
        this.venditaCommonService.setVenditaPageData('prefinFormData', this.prefinFormData);
      } else {
        if (this.contoCorrenteOptions.length === 0) {
          this.openErrorPopup();
          this.validSection = true;
          this.prefinFormData = {
            prefinanziamentoFlag: this.prefinanaziamentoSelection,
            tipoConto: null, durataValue: null, importoValue: null, accountNumber: null, accountBranch: null
          };
          this.venditaCommonService.setVenditaPageData('prefinFormData', this.prefinFormData);
        } else {
          this.validateFields();
        }
      }
      this.sectionValid.emit(this.validSection);
    }, () => {
      this.prefinanaziamentoSelection = !this.prefinanaziamentoSelection;
    });

  }

  ngOnChanges(changes) {
    if (this.prefinanaziamentoSelection === false) {
      this.sectionValid.emit(this.validSection);
    } else {
      this.validateFields();
    }
  }

  validateFields() {
    let check = true;
    if (this.importoValue === undefined || this.importoValue === null || this.importoValue === '') {
      this.validSection = false;
      check = false;
    }
    if (this.durataValue === undefined || this.durataValue === null || this.durataValue === '') {
      this.validSection = false;
      check = false;
    }
    if (Number(this.importoValue) > Number(this.importoThreshold)) {
      check = false;
      this.amountThresholdError = true;
      this.importoErrorMessage = 'L\'importo ' + 'del pre-finanziamento non può essere maggiore dell\'importo ' +
        'di simulazione';
    } else {
      this.amountThresholdError = false;
      this.importoErrorMessage = ' ';
    }
    if (Number(this.durataValue) > Number(this.durataThreshold)) {
      check = false;
      this.durataThresholdError = true;
      this.durataErrorMessage = 'La durata del pre-finanziamento non può ' + 'essere maggiore della durata della simulazione';
    } else {
      this.durataThresholdError = false;
    }

    if (Number(this.durataValue) > 12 && this.mcdPerimeter === true) {
      check = false;
      this.durataMcdPerimeterError = true;
      this.durataErrorMessage = 'La durata di un pre-finanziamento in perimetro MCD deve essere minore o uguale a 12 mesi';
    } else {
      this.durataMcdPerimeterError = false;
    }

    if (Number(this.durataValue) > 18 && this.mcdPerimeter === false) {
      check = false;
      this.durataNonMcdError = true;
      this.durataErrorMessage = 'La durata di un pre-finanziamento non in perimetro MCD deve essere minore o uguale a 18 mesi';
    } else {
      this.durataNonMcdError = false;
    }
    if (this.durataThresholdError || this.durataMcdPerimeterError || this.durataNonMcdError) {
      this.showErrMsg = true;
    } else {
      this.showErrMsg = false;
      this.durataErrorMessage = ' ';
    }
    if (this.tipoConto === undefined || this.tipoConto === null) {
      check = false;
      this.validSection = false;
    }
    if (check === true) {
      this.validSection = true;
    } else {
      this.validSection = false;
    }
    this.prefinFormData = {
      prefinanziamentoFlag: this.prefinanaziamentoSelection,
      tipoConto: this.tipoConto, durataValue: this.durataValue, importoValue: this.importoValue,
      accountNumber: this.accountNumber, accountBranch: this.accountBranch
    };
    console.log(this.prefinFormData);
    this.venditaCommonService.setVenditaPageData('prefinFormData', this.prefinFormData);
    this.sectionValid.emit(this.validSection);
  }

  openErrorPopup() {
    this.prefinanaziamentoSelection = false;
    const Error = {
      'message': this.errorMessage,
      'details': [{ 'code': null, 'message': '', 'service': '', 'forzabile': true }]
    };
    this.npvErrorServiceService.openErrorPopup(Error);
  }

  changeAccount(model, event: any) {
    this.checkForPopUp().then(() => {
      if (event) {
        const account: ContoCorrenteDetailsModel = this.contoCorrenteMap.get(this.optionId);
        this.tipoConto = account.formaTecnica;
        this.accountNumber = account.number;
        this.accountBranch = account.filiale;
      }
    });
  }


  clearComponent() {
    delete this.prefinanaziamentoSelection;
    this.form.reset();
  }

  createOptionValues(contoCorrenteDetails: ContoCorrenteDetailsModel[]): SelectOptionModel[] {
    const enableAll = this.validateDropDownOptions();
    const temp: SelectOptionModel[] = [];
    let i = 0;

    contoCorrenteDetails.forEach(e => {
      if (e.formaTecnica !== '32005' || enableAll) {
        this.contoCorrenteMap.set(i + '', e);
        temp.push({ 'description': e.number, 'value': i + '' });
        i++;
      }
    });
      return temp;
  }

}
