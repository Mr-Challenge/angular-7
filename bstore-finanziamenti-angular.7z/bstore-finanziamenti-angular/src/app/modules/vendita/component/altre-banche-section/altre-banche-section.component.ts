import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DialogService } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { AltreBancheModel } from '../../models/altre-banche.model';
import { VenditaCommonService } from '../../services/vendita-common.service';
import { BaseFidiGaranzieSectionComponent } from '../base-fidi-garanzie-section/base-fidi-garanzie-section.component';

@Component({
  selector: 'bst-fin-altre-banche-section',
  templateUrl: './altre-banche-section.component.html',
  styleUrls: ['./altre-banche-section.component.scss']
})
export class AltreBancheSectionComponent extends BaseFidiGaranzieSectionComponent implements OnInit {

  @Input() listaRapportiAltreBanche: Array<AltreBancheModel>;
  @Input() altreBancheFlag: any;

  altreBancheValid: boolean;
  check: boolean;
  allAltreBanche: AltreBancheModel[] = [];
  altreBancheEvents: EventsModel[] = [];
  newBankEvents: EventsModel[] = [];

  constructor(private venditaCommonService: VenditaCommonService,
    private router: Router, protected dialog: DialogService) {
    super(dialog);
    this.venditaCommonService.altraBranche.subscribe(altreBanche => {
      this.allAltreBanche.push(altreBanche);
      this.venditaCommonService.setVenditaPageData('altreBanche', this.allAltreBanche);
      console.log(this.allAltreBanche);
      this.validateSection();
    });
    this.altreBancheEvents = [
      { eventName: 'click', eventCallBack: this.clickOnQuestion.bind(this) },
      { eventName: 'change', eventCallBack: this.clickOnQuestion.bind(this) }
    ];

    this.newBankEvents = [
      { eventName: 'click', eventCallBack: this.newBankPage.bind(this) }
    ];
  }



  private newBankPage() {
    this.checkForPopUp().then(() => {
      this.router.navigate(['vendita/newbankpage'], { preserveQueryParams: true });
    });
  }

  clickOnQuestion() {
    this.checkForPopUp().then(() => {
      this.validateSection();
    }, () => {
      this.check = !this.check;
    });
  }


  ngOnInit() {
    if (this.listaRapportiAltreBanche) {
      this.allAltreBanche = this.listaRapportiAltreBanche;
      if (this.allAltreBanche.length > 0) {
        this.check = true;
      } else {
        this.check = false;
      }
    } else {
      if (this.allAltreBanche.length > 0) {
        this.check = true;
      }
    }

    this.validateSection();

  }

  private validateSection() {
    this.altreBancheValid = this.validCheck() && this.validBankList();
    this.sectionValid.emit(this.altreBancheValid);
  }

  private validBankList(): boolean {
    return this.check ? this.allAltreBanche.length > 0 : true;
  }

  private validCheck(): boolean {
    return this.check !== undefined && this.check !== null;
  }

  clearComponent() {
    this.check = undefined;
    this.allAltreBanche = [];
  }
}
