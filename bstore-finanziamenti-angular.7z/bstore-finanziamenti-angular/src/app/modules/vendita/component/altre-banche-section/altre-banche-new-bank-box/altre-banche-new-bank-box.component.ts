import { Component, OnInit, ViewChild } from '@angular/core';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { Location } from '@angular/common';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { VenditaCommonService } from '../../../services/vendita-common.service';
import { Router } from '@angular/router';
import { CommonPopupComponent } from 'bstore-angular-library';
@Component({
  selector: 'bst-fin-altre-banche-new-bank-box',
  templateUrl: './altre-banche-new-bank-box.component.html',
  styleUrls: ['./altre-banche-new-bank-box.component.scss']
})

export class AltreBancheNewBankBoxComponent implements OnInit {
  altraBancaInputBox: EventsModel[] = [];
  euroPattern = '^([0-9]+[,]?[0-9]+|[0-9]{1,3}([.][0-9]{3})*([,][0-9]+)?)$';
  saveButtonClickEvent = [
    { eventName: 'click', eventCallBack: this.submitaltreBancheForm.bind(this) }
  ];

  cancelButtonClickEvents = [
    { eventName: 'click', eventCallBack: this.backClicked.bind(this) }
  ];

  valid = false;
  altreBancheForm = new FormGroup({
    denominazioneBanca: new FormControl('', Validators.required),
    importoAutoliquidante: new FormControl('',
      Validators.pattern(this.euroPattern)),
    importoScadenzaBT: new FormControl('', Validators.pattern(this.euroPattern)),
    importoScadenzaMT: new FormControl('', Validators.pattern(this.euroPattern)),
    importoRevoca: new FormControl('', Validators.pattern(this.euroPattern)),
    importoSofferenza: new FormControl('', Validators.pattern(this.euroPattern)),
    importoProcedureConcorsuali: new FormControl('', Validators.pattern(this.euroPattern)),
    importoFirmaCommerciale: new FormControl('', Validators.pattern(this.euroPattern)),
    importoFirmaFinanziaria: new FormControl('', Validators.pattern(this.euroPattern)),
    totaleBanca: new FormControl('', Validators.pattern(this.euroPattern))
  });

  totaleBanca: any;
  totaleBancaThousandPresion: any;

  @ViewChild(CommonPopupComponent) commonPopupComponent: CommonPopupComponent;

  constructor(private location: Location,
    private venditaCommonService: VenditaCommonService,
    private router: Router) { }

  ngOnInit() {
    this.altraBancaInputBox = [
      { eventName: 'keyup', eventCallBack: this.updateTotaleBanca.bind(this) }
    ];

    
  }

  submitaltreBancheForm() {
    Object.keys(this.altreBancheForm.controls).forEach(key => {
      if (key !== 'denominazioneBanca') {
        if (this.altreBancheForm.get(key).value === '') {
          this.altreBancheForm.get(key).setValue(this.toDecimal('0'));
        } else {
          this.altreBancheForm.get(key).setValue(this.toDecimal(this.altreBancheForm.controls[key].value));
        }
      }
    });
    this.venditaCommonService.setAltreBanche(this.altreBancheForm.value);
    this.indietro();
  }

  updateTotaleBanca(input, event) {
    let result;
    this.totaleBanca =
      this.toDecimal(this.altreBancheForm.controls.importoAutoliquidante.value) +
      this.toDecimal(this.altreBancheForm.controls.importoScadenzaBT.value) +
      this.toDecimal(this.altreBancheForm.controls.importoScadenzaMT.value) +
      this.toDecimal(this.altreBancheForm.controls.importoRevoca.value) +
      this.toDecimal(this.altreBancheForm.controls.importoSofferenza.value) +
      this.toDecimal(this.altreBancheForm.controls.importoProcedureConcorsuali.value) +
      this.toDecimal(this.altreBancheForm.controls.importoFirmaCommerciale.value) +
      this.toDecimal(this.altreBancheForm.controls.importoFirmaFinanziaria.value);

    this.totaleBancaThousandPresion =
      this.thousandPresion(this.totaleBanca);

    if (this.totaleBancaThousandPresion > 0) {
      this.valid = true;
    } else {
      this.valid = false;
    }
    result = ((new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR', useGrouping: true
    })
      .format(this.totaleBanca.toString())));
    if (result.indexOf('NaN') === -1) {
      this.altreBancheForm.controls.totaleBanca.setValue(result.substring(0, result.length - 2));
    }
  }

  backClicked() {
    this.location.back();
  }

  indietro() {
    this.router.navigate(['/vendita'], { preserveQueryParams: true });
  }

  toEuro(controllName) {
    const number = this.altreBancheForm.controls[controllName].value;
    let result;
    if (number.indexOf('.') > -1 || number.indexOf(',') > -1) {
      result =
        (new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR', useGrouping: true })
          .format(number.replace(new RegExp('[.]', 'g'), '').replace(',', '.')));
      if (result.indexOf('NaN') === -1) {
        this.altreBancheForm.controls[controllName].patchValue(result.substring(0, result.length - 2));
      }
    } else {
      result = (new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR', useGrouping: true })
        .format(number));
      if (result.indexOf('NaN') === -1) {
        this.altreBancheForm.controls[controllName].patchValue(result.substring(0, result.length - 2));
      } else {
        this.altreBancheForm.controls[controllName].patchValue(number);
      }
    }
  }

  toDecimal(number) {
    if ((parseFloat(number).toString()).indexOf('NaN')) {
      return (parseFloat(number.replace(new RegExp('[.]', 'g'), '').replace(',', '.')));
    }
    return 0;
  }

  thousandPresion(number) {
    return Math.round(number / 1000);
  }
}
