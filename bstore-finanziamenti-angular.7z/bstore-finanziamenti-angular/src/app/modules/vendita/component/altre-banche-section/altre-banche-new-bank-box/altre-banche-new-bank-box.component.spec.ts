import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AltreBancheNewBankBoxComponent } from './altre-banche-new-bank-box.component';

describe('AltreBancheNewBankBoxComponent', () => {
  let component: AltreBancheNewBankBoxComponent;
  let fixture: ComponentFixture<AltreBancheNewBankBoxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AltreBancheNewBankBoxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AltreBancheNewBankBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
