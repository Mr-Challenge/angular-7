import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AltreBancheSectionComponent } from './altre-banche-section.component';

describe('AltreBancheSectionComponent', () => {
  let component: AltreBancheSectionComponent;
  let fixture: ComponentFixture<AltreBancheSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AltreBancheSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AltreBancheSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
