import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, HostListener, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RedirectService } from 'bstore-angular-library';
import { CustomerData } from 'src/app/models/customerData';
import { DatiAnagrafiService } from 'src/app/modules/vendita/services/dati-anagrafi.service';
import { VenditaPageService } from 'src/app/modules/vendita/services/vendita-page.service';
import { EndpointsService } from 'src/app/services/endpoints.service';
import { VenditaCommonService } from '../../services/vendita-common.service';

@Component({
  selector: 'bst-fin-cust-details',
  templateUrl: './cust-details.component.html',
  styleUrls: ['./cust-details.component.scss'],
  animations: [
    trigger('scrollAnimation', [
      state('show', style({
        opacity: 1,
        display: 'block',
        transform: 'translate3d(0, 0, 0)'
      })),
      state('hide', style({
        opacity: 0,
        display: 'none',
        transform: 'translate3d(0, -100%, 0)'
      })),
      transition('show => hide', animate('200ms ease-out')),
      transition('hide => show', animate('200ms ease-in'))
    ])
  ]
})
export class CustDetailsComponent implements OnInit {

  @Input() INTClientRole: any[];
  result: CustomerData;
  resultArr: CustomerData[];
  mutuoWrapper: any;
  coint: any;
  ndgArr: any[];
  iconFlagOK: boolean;
  denomStr: String;
  statoStr: String;
  nameObj: any;
  ndgObj: string;
  idProposta: any;
  state = 'show';
  prevScrollpos = window.pageYOffset;
  idProposal: string;

  allHoldersConfigured = true;

  constructor(private datiAnagrafiService: DatiAnagrafiService, private route: ActivatedRoute, public venditaPageService: VenditaPageService,
    private venditaCommonService: VenditaCommonService, private endpointsService: EndpointsService, private redirectService: RedirectService) {
    this.mutuoWrapper = route.snapshot.queryParams['mutuoWrapper'];
    this.resultArr = [];
    this.iconFlagOK = true;
    this.ndgArr = [];
    this.statoStr = '';
    this.denomStr = '';
    this.nameObj = {};
    this.nameObj.name = '';
    this.nameObj.ndg = '';
    this.ndgObj = '';

    this.route.queryParams.subscribe(params => {
      this.idProposal = params['idProposal'];
    });
  }

  ngOnInit() {
    this.getClientRole(this.INTClientRole);
    console.log(this.INTClientRole);
  }

  getClientRole(getClientRoleResponse) {
    for (const x in getClientRoleResponse) {
      // const client = getClientRoleResponse[x];


      if (getClientRoleResponse[x].cointestazione) {
        getClientRoleResponse[x].buttonEvents = [
          { eventName: 'click', eventCallBack: this.redirectToCensimentoCointestazione.bind(this, getClientRoleResponse[x].ndg) }
        ];
        this.coint = getClientRoleResponse[x];
        this.checkIconFlag([this.coint]);
      } else {
        getClientRoleResponse[x].buttonEvents = [
          { eventName: 'click', eventCallBack: this.redirectToCensimentoConfiguraPersona.bind(this, getClientRoleResponse[x].ndg) }
        ];
        if (getClientRoleResponse[x].constructor === Array) {
          for (const y in getClientRoleResponse[x]) {
            if (getClientRoleResponse[x][y]) {
              this.resultArr.push(getClientRoleResponse[x][y]);
            }
          }
        } else {
          this.resultArr.push(getClientRoleResponse[x]);
        }
        this.checkIconFlag(this.resultArr);
      }
    }
    this.resultArr.forEach(data => {
      if (this.ndgObj === '') {
        this.ndgObj = data.ndg ? data.ndg : '';
      } else {
        this.ndgObj += '_' + (data.ndg ? data.ndg : '');
      }
      if (!data.complete) {
        this.allHoldersConfigured = false;
      }
    });
    this.datiAnagrafiService.setNdgList(this.ndgObj);
  }

  checkIconFlag(data) {


    for (const x in data) {

      if (data[x]) {
        if (!data[x].complete) {
          this.datiAnagrafiService.iconFlagStato = false;
          this.datiAnagrafiService.fidiGaranzieAccordion = false;
          this.statoStr = 'Anagrafica mancante';
          break;
        }
        if (data[x].complete && data[x].cointestazione) {
          this.statoStr = 'Anagrafica completa';
          break;
        }
        this.statoStr = this.statoStr ? 'Anagrafica mancante' : 'Anagrafica completa';
      }
    }
  }


  // currently proposal id has been hardcoded once we receive actual idPoposal from previous
  // pages will replace this hardcoded value

  private redirectToCensimentoConfiguraPersona(ndg: string) {
    // alert('config persona NDG= '+ndg);
    // redirect to url
    const x = {
      'ndg': ndg,
      'idProposta': this.idProposal,
      'showSearchBox': false,
      'showBss': false,
      'newClient': false,
      'callbackurl': this.endpointsService.returnFromAnagrafeChanges + '?idProposal=' + this.idProposal
    };

    // Workaround to bybass apache urls restrictions (must not contains encoded \ or / into the path part, but allowed as fragment)
    const callbackurl = x.callbackurl;
    x.callbackurl = null;

    // tslint:disable-next-line: max-line-length
    this.redirectService.redirectWithSpinner(this.endpointsService.censimentoPrivati + '/' + encodeURIComponent(JSON.stringify(x)) + '#' + callbackurl);
  }

  private redirectToCensimentoCointestazione(ndg: string) {
    const process = 'VENDITA';
    const x = {
      'ndg': ndg,
      'finanziamenti': process,
      'idProposta': this.idProposal,
      'ndgArr': this.ndgObj,
      'callbackurl': this.endpointsService.returnToFinanziamentAndSaveJointAccount + '?prop=' + this.idProposal
    };
    // Workaround to bybass apache urls restrictions (must not contains encoded \ or / into the path part, but allowed as fragment)
    const callbackurl = x.callbackurl;
    x.callbackurl = null;
    // tslint:disable-next-line:max-line-length
    this.redirectService.redirectWithSpinner(this.endpointsService.censimentoCointestazione + '/' + encodeURIComponent(JSON.stringify(x)) + '#' + callbackurl);
  }

  @HostListener('window:scroll', ['$event'])
  checkScroll() {
    const currentScrollPos = window.pageYOffset;
    if (this.prevScrollpos >= currentScrollPos) {
      this.state = 'show';
    } else {
      this.state = 'hide';
    }
  }
}
