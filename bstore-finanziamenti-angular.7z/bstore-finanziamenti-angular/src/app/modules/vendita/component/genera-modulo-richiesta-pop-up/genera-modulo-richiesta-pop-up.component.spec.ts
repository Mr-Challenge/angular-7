import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GeneraModuloRichiestaPopUpComponent } from './genera-modulo-richiesta-pop-up.component';

describe('GeneraModuloRichiestaPopUpComponent', () => {
  let component: GeneraModuloRichiestaPopUpComponent;
  let fixture: ComponentFixture<GeneraModuloRichiestaPopUpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GeneraModuloRichiestaPopUpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GeneraModuloRichiestaPopUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
