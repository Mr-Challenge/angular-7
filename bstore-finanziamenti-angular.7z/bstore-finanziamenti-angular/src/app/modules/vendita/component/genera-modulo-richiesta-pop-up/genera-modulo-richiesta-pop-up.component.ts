import { Component, OnInit } from '@angular/core';
import { DialogModel, DialogRef } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';

@Component({
  selector: 'bst-fin-genera-modulo-richiesta-pop-up',
  templateUrl: './genera-modulo-richiesta-pop-up.component.html',
  styleUrls: ['./genera-modulo-richiesta-pop-up.component.scss']
})
export class GeneraModuloRichiestaPopUpComponent implements OnInit {
  email: any;
  mobilePhone: any;
  isVerifyOTPFields: boolean;
  okEvents: EventsModel[] = [];
  backEvents: EventsModel[] = [];
  constructor(
    public config: DialogModel,
    public dialog: DialogRef) { }

  ngOnInit() {
    // this.user = this.config.data.user;
    this.isVerifyOTPFields = this.config.data.otpFieldsComplete;
    if(this.config.data.email && this.config.data.mobilePhone) { 
      this.email =  this.config.data.email;
      this.mobilePhone =  this.config.data.mobilePhone;
    }

    this.okEvents = [
      { eventName: 'click', eventCallBack: this.submit.bind(this) },
    ];
    this.backEvents = [
      { eventName: 'click', eventCallBack: this.close.bind(this) },
    ];
  }

  submit() {
    this.dialog.close(true);
  }

  close() {
    this.dialog.close(false);
  }
}
