import { AfterContentInit, Component, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SchedaPrivatiIntegrationService } from 'src/app/modules/vendita/services/scheda-privati-integration.service';
import { CommonPopupComponent } from 'bstore-angular-library';
import { VenditaCommonService } from '../../services/vendita-common.service';

declare var startApplication: () => void;
declare var killApplication: () => void;

@Component({
  selector: 'bst-fin-private-card',
  templateUrl: './private-card.component.html'
})
export class PrivateCardComponent implements AfterContentInit, OnDestroy {

  private idProposal: any;

  @ViewChild(CommonPopupComponent) commonPopupComponent: CommonPopupComponent;

  constructor(private service: SchedaPrivatiIntegrationService, private route: ActivatedRoute, private venditaCommonService: VenditaCommonService) {
    this.route.queryParams.subscribe(params => {
      this.idProposal = params['idProposal'];
    });
  }

  ngAfterContentInit() {
    window['bstoreAppPath'] = '/SchedaPrivati';
    this.service.loadApp().subscribe(justLoaded => {
      if (!justLoaded) {
        startApplication();
        this.commonPopupComponent.createObserver();
      }
    });
  }

  ngOnDestroy() {
    killApplication();
  }

  indietro() {
    window['schedaPrivatiData'].callbackFunction();
  }
}

