import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormaTecnicaSectionComponent } from './forma-tecnica-section.component';

describe('FormaTecnicaSectionComponent', () => {
  let component: FormaTecnicaSectionComponent;
  let fixture: ComponentFixture<FormaTecnicaSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormaTecnicaSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormaTecnicaSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
