import { AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { DialogService } from 'bstore-angular-library';
import { takeWhile } from 'rxjs/operators';
import { PefService } from '../../services/pef.service';
import { VenditaCommonService } from '../../services/vendita-common.service';
import { BaseFidiGaranzieSectionComponent } from '../base-fidi-garanzie-section/base-fidi-garanzie-section.component';
import { PopupMutuoPrimaCasaComponent } from 'src/app/components/popup-mutuo-prima-casa/popup-mutuo-prima-casa.component';

@Component({
  selector: 'bst-fin-forma-tecnica-section',
  templateUrl: './forma-tecnica-section.component.html',
  styleUrls: ['./forma-tecnica-section.component.scss']
})
export class FormaTecnicaSectionComponent extends BaseFidiGaranzieSectionComponent implements OnInit, OnDestroy, AfterViewInit {

  @Input() preSelectValue;

  tabAlignment = false;
  formaTecnicaList: any;
  private isAlive = true;
  selectEvents = [
    { eventName: 'change', eventCallBack: this.emitValidation.bind(this) }
  ];
  formaTecnica: any;
  formaTecnicaSelected: string;
  @Output() completoValidation: EventEmitter<any> = new EventEmitter<any>();
  @Output() formaTecnicaResponse: EventEmitter<any> = new EventEmitter<any>();

  constructor(protected dialog: DialogService, private venditaCommonService: VenditaCommonService,
    private pefService: PefService, private cdr: ChangeDetectorRef) {
    super(dialog);
  }


  ngOnInit() {
    this.getFormaTecnicaList();
  }

  getFormaTecnicaList() {
    this.pefService.getFormaTecnicaList(this.proposalId)
      .pipe(takeWhile(() => this.isAlive))
      .subscribe(formaTecnicaList => {
        this.formaTecnicaList = formaTecnicaList;
        if (this.preSelectValue) {
          this.formaTecnica = this.preSelectValue;
          this.emitValidation(null, null, true);
        }
      });
    // this.events = [{ eventName: 'change', eventCallBack: this.emitValidation.bind(this) }];
  }

  ngOnDestroy() {
    this.isAlive = false;
  }

  private emitValidation(target: any, event: any, programaticCall: boolean) {
    const successFunction = () => {

      this.completoValidation.emit(this.formaTecnica);
      this.venditaCommonService.setFirmaTechnicia(this.formaTecnica);
      this.venditaCommonService.setSelectedFirmaTechnicia(this.formaTecnica);
      this.formaTecnicaSelected = this.formaTecnicaList.filter(Obj => Obj.value.indexOf(this.formaTecnica) > -1);
      this.formaTecnicaResponse.emit(this.formaTecnicaSelected[0]);
      const valid = this.formaTecnica ? true : false;
      this.sectionValid.emit(valid);
    };
    if (programaticCall) {
      successFunction.apply(this);
    } else {
      this.checkForPopUp().then(() => {
        successFunction.apply(this);
      }, () => {
        this.formaTecnica = this.venditaCommonService.getFirmaTechnicia();
        this.emitValidation(null, null, true);
      });
    }
    if (this.formaTecnica === '340174') {
      this.dialog.open(PopupMutuoPrimaCasaComponent, {});
    }
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

  clearComponent() {
    delete this.formaTecnica;
  }
}
