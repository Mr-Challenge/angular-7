import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { DatiAnagrafiService } from '../../services/dati-anagrafi.service';
// import { SimulationsService } from '../../services/simulations.service';


@Component({
  selector: 'bst-fin-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss']
})
export class TabsComponent implements OnInit {

  @Output() emitPass: EventEmitter<[number, string]> = new EventEmitter<[number, string]>();
  @Output() emitDeleteStatus: EventEmitter<[number, string]> = new EventEmitter<[number, string]>();
  @Output() role: EventEmitter<string> = new EventEmitter<string>(); // ADDED For Task 640
  @Input() chirografarioFlag: boolean;
  @Input() GARClientRole: any[];
  @Input() TERClientRole: any[];
  @Input() INTClientRole: any[];
  @Input() saveButtonClicked;
  @Input() proposalId;
  showIntestatariTab: boolean = true;
  showGarantiTab: boolean = false;
  showTerzoDatoreIpotecaTab: boolean = false;


  venditaButton: String;
  constructor(private datiAnagrafiService: DatiAnagrafiService, private cdr: ChangeDetectorRef) { }

  ngOnInit() {

  }


  /*function created for emitting the evidenza status flag to the parent simulation-detail component */
  changeEvidezaStatus([selectedSet, tassoOption]) {
    this.emitPass.emit([selectedSet, tassoOption]);
  }

  /*added for emitting the delete status flag to the parent simulation-detail component */
  deleteSimulation([selectedSet, tassoOption]) {
    this.emitDeleteStatus.emit([selectedSet, tassoOption]);
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

  /**
   * START - ADDED for Task 640
   */
  callDatiAnagrafi() {
    this.role.next();
  }
  /* END */
}
