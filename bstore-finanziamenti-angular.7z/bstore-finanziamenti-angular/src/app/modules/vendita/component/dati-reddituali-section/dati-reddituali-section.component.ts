import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, EventEmitter, Input, NgZone, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { combineLatest } from 'rxjs';
import { DatiAnagrafiService } from '../../services/dati-anagrafi.service';
import { VenditaCommonService } from '../../services/vendita-common.service';

@Component({
  selector: 'bst-fin-dati-reddituali-section',
  templateUrl: './dati-reddituali-section.component.html',
  styleUrls: ['./dati-reddituali-section.component.scss']
})
export class DatiRedditualiSectionComponent implements OnInit {
  @Input() GARClientRole: any;
  @Input() INTClientRole: any;
  @Input() TERClientRole: any;
  @Input() sectionDisabled: boolean;
  @Output() isDatiRedditualiCompleted = new EventEmitter<any>();
  @Input() chirografarioFlag: boolean;
  checkIncompleteCnt = 0;
  showIntestatariTab = true;
  showGarantiTab = false;
  showTerzoDatoreIpotecaTab = false;
  isValid = true;
  userData: any;
  isValidIncomeData: boolean;
  baseClientListVm: any;
  serviceFail: boolean;
  expand:false | true = false;
  constructor(

    private router: Router,
    public datiAnagrafiService: DatiAnagrafiService,
    private cdr: ChangeDetectorRef,
    private venditaCommonService: VenditaCommonService
  ) { }

  ngOnInit() {
    this.isValidIncomeData = false;
    this.INTClientRole = this.INTClientRole ? this.INTClientRole.filter(this.isNotJoinHolder) : [];
    this.GARClientRole = this.GARClientRole ? this.GARClientRole.filter(this.isNotJoinHolder) : [];
    this.TERClientRole = this.TERClientRole ? this.TERClientRole.filter(this.isNotJoinHolder) : [];
    this.baseClientListVm = {
      'intclientRoleList': this.INTClientRole,
      'garclientRoleList': this.GARClientRole,
      'terclientRoleList': this.TERClientRole
    };

    this.setSchedaPrivatiData(this.baseClientListVm);

    window['bstoreApplicationLocation'] = window.location.href;
    console.log(window['bstoreApplicationLocation']);
  }


  isNotJoinHolder(element, index, array) {
    return (element.cointestazione === false);
  }

  setSchedaPrivatiData(vm) {
    const self = this;
    combineLatest(
      self.datiAnagrafiService.getSchedaPrivatiData(vm),
    ).subscribe(([ClientRoles]) => {
      if (ClientRoles) {
        this.venditaCommonService.setPrivateCardData(ClientRoles);
        self.INTClientRole = ClientRoles['intclientRoleList'] ? ClientRoles['intclientRoleList'] : [];
        self.GARClientRole = ClientRoles['garclientRoleList'] ? ClientRoles['garclientRoleList'] : [];
        self.TERClientRole = ClientRoles['terclientRoleList'] ? ClientRoles['terclientRoleList'] : [];
        self.serviceFail = false;
        self.checkIncompleteCnt = 0;

        let backFromScheda = sessionStorage.getItem('callbackFlag');
        if (backFromScheda === 'true') {

          if(self.INTClientRole && self.INTClientRole.length > 1 || self.GARClientRole && self.GARClientRole.length > 1 || self.TERClientRole && self.TERClientRole.length > 1){
            this.expand = true;
            sessionStorage.clear();
          }
        }

        
        
        if (self.INTClientRole && self.INTClientRole.length > 0) {
          self.INTClientRole.forEach(function (nominee) {
            self.checkIncompleteCnt = nominee.schedaModificaFlag ? self.checkIncompleteCnt + 1 : self.checkIncompleteCnt;
          });
        }
        if (self.GARClientRole && self.GARClientRole.length > 0) {
          self.GARClientRole.forEach(function (guarantor) {
            self.checkIncompleteCnt = guarantor.schedaModificaFlag ? self.checkIncompleteCnt + 1 : self.checkIncompleteCnt;
          });
        }
        if (self.TERClientRole && self.TERClientRole.length > 0) {
          self.TERClientRole.forEach(function (mortgagegiver) {
            self.checkIncompleteCnt = mortgagegiver.schedaModificaFlag ? self.checkIncompleteCnt + 1 : self.checkIncompleteCnt;
          });
        }
        if (self.checkIncompleteCnt === 0) {
          self.isValidIncomeData = true;
          this.isDatiRedditualiCompleted.emit(self.isValidIncomeData);
        } else {
          self.isValidIncomeData = false;
          this.isDatiRedditualiCompleted.emit(self.isValidIncomeData);
        }
      } else {
        self.serviceFail = true;
        this.isDatiRedditualiCompleted.emit(false);
      }
    }, () => {
      self.serviceFail = true;
      this.isDatiRedditualiCompleted.emit(false);
    }, null);
  }


  showPrivateCard(ndg, ndgGovern, abi) {
    ndg = ndg.padStart(9, '0');
    ndgGovern = ndgGovern.padStart('11', '0');
    window['schedaPrivatiData'] = {
      ndg: ndg,
      ndgGoverno: ndgGovern,
      abi: abi,
      callbackFunction: (info) => {
        let callbackFlag = true;
        sessionStorage.setItem('callbackFlag', callbackFlag.toString());
        console.log('before zone Call');
        console.log('before Call');
        window.location.href = window['bstoreApplicationLocation'];
        console.log('after zone Call');
      }
    };
    this.router.navigate(['vendita/SchedaPrivati'], { preserveQueryParams: true });

  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

}
