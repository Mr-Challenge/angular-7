import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatiRedditualiSectionComponent } from './dati-reddituali-section.component';

describe('DatiRedditualiSectionComponent', () => {
  let component: DatiRedditualiSectionComponent;
  let fixture: ComponentFixture<DatiRedditualiSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatiRedditualiSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatiRedditualiSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
