import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { SelectOptionModel } from 'bstore-angular-library/lib/models/select-option-model';
import { MortgageClientRoles } from 'src/app/constant/mortgageClientRoles';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { InterviewService } from 'src/app/modules/simulations/services/interview.service';
import { CommonService } from 'src/app/services/common.service';
import { InterviewResult } from '../../../models/interview-response-vm';
import { SimulationDataModel } from '../../../models/simulation-data.model';
import { PefService } from '../../../services/pef.service';
import { VenditaCommonService } from '../../../services/vendita-common.service';
import { CommonPopupComponent } from 'bstore-angular-library';
import { GuaranteesModel } from '../../../models/guarantees.model';
import { GaranteGaranzia } from '../../../models/garante-garanzia.model';

@Component({
  selector: 'bst-fin-add-visualizza-garanzia',
  templateUrl: './add-visualizza-garanzia.component.html',
  styleUrls: ['./add-visualizza-garanzia.component.scss']
})
export class AddVisualizzaGaranziaComponent implements OnInit {

  @ViewChild(CommonPopupComponent) commonPopupComponent: CommonPopupComponent;

  interviewResult: InterviewResult[];
  proposalId: string;
  tipoEvents: EventsModel[] = [];
  parentTipoList: any;
  tipoList: SelectOptionModel[] = [];
  descriptions: any[] = [];
  selectedDesc: string;
  selectedTipo: string;
  importo: string;
  d2Answer: string;
  simulationData: SimulationDataModel;
  percentualeGaranzia: number;
  tipologiaImporto: any;
  importoGaranzieDisabled: boolean;
  percentualeGaranzieDisabled: boolean;
  ndgGaranteObbligatorio: boolean;
  descrizione: SelectOptionModel[] = [];
  baseClients: SelectOptionModel[] = [];
  INTClientRoleList: BaseClientModel[];
  GARClientRoleList: BaseClientModel[];
  TERClientRoleList: BaseClientModel[];
  garanteDisabledFlag = true;
  importoMutuo: string;
  garanteRequired = false;
  attoRequired = true;
  importoRequired: boolean;
  percentualeRequired: boolean;
  showGaranteMultiselect = false;
  dropdownList = [];
  dropdownSettings = {};

  saveButtonClickEvents = [
    { eventName: 'click', eventCallBack: this.saveNewGaranzie.bind(this) }
  ];
  garanziaForm = new FormGroup({
    tipo: new FormControl('', Validators.required),
    descrizioneCodice: new FormControl('', Validators.required),
    importoMutuo: new FormControl('', Validators.required),
    importo: new FormControl('', Validators.compose([Validators.pattern('^([1-9][0-9]*[\.]?[0-9]*|[0][\.][1-9][0-9]?)$')])),
    atto: new FormControl(''),
    fuoriAtto: new FormControl(''),
    garantiList: new FormControl(''),
    descrizioneEstesa: new FormControl('')
  });


  constructor(private venditaCommonService: VenditaCommonService, private elementRef: ElementRef,
    private router: Router, private commonService: CommonService,
    private route: ActivatedRoute,
    private pefService: PefService,
    public interviewService: InterviewService) {
    this.getTipoDescrizioneList();
    this.tipoEvents = [{ eventName: 'change', eventCallBack: this.gettipoDescription.bind(this) }];
  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.proposalId = params['idProposal'];
    });
    this.simulationData = this.venditaCommonService.getSimulationData();
    this.importoMutuo = this.simulationData.amount;
    this.addFormControl();
    this.garanziaForm.controls.importoMutuo.setValue(this.importoMutuo);
    this.d2Answer = this.venditaCommonService.d2Answer;

    this.commonService.getClientByRole(this.proposalId, MortgageClientRoles.INTESTATARI).subscribe((INTClientRole) => {
      this.INTClientRoleList = INTClientRole;
    });

    this.commonService.getClientByRole(this.proposalId, MortgageClientRoles.GARANTI).subscribe((GARClientRole) => {
      this.GARClientRoleList = GARClientRole;
    });

    this.commonService.getClientByRole(this.proposalId, MortgageClientRoles.TERZI_DATORI_IPOTECA).subscribe((TERClientRole) => {
      this.TERClientRoleList = TERClientRole;
    }, error => { }, () => {
      this.commonPopupComponent.createObserver();
    });

    this.dropdownSettings = {
      singleSelection: false,
      idField: 'ndgGarante',
      textField: 'intestazioneGarante',
      itemsShowLimit: 3,
      allowSearchFilter: false,
      enableCheckAll: false
    };
  }

  createClientDrop(clientRole: BaseClientModel[]) {
    if (clientRole) {
      clientRole.forEach(client => {
        this.baseClients.push({ 'description': client.name + ' ' + client.surname, 'value': client.ndg });
      });
    }
  }

  saveNewGaranzie() {
    var ipoProductArr = ['MUTUI_IPOTECARI_CASA', 'ALTRI_MUTUI_IPOTECARI'];
    if (this.simulationData && ipoProductArr.indexOf(this.simulationData.macroCategory) == -1) {
      this.garanziaForm.controls['fuoriAtto'].setValue('Fuori atto');
    }
    const graranzia: GuaranteesModel = this.garanziaForm.value;
    if (this.tipologiaImporto === 'O' || this.tipologiaImporto === 'L') {
      if (graranzia.importo !== null && graranzia.importo != "") {
        delete graranzia.percentualeIpoteca;
      } else {
        delete graranzia.importo;
      }
    }

    if (!this.showGaranteMultiselect && !this.garanteDisabledFlag) {
      const client = this.baseClients.find(data => this.garanziaForm.value.garantiList === data.value);
      if (client) {
        const garante: GaranteGaranzia = { ndgGarante: client.value, intestazioneGarante: client.description };
        graranzia.garantiList = [];
        graranzia.garantiList.push(garante);
      }
    }

    if (graranzia.garantiList && graranzia.garantiList.length > 0) {
      graranzia.garantiList.forEach((garante, index) => {
        if (index === 0) {
          graranzia.intestazione = garante.intestazioneGarante;
        } else {
          graranzia.intestazione += ', ' + garante.intestazioneGarante;
        }
      });
    }

    graranzia.flagEstendibile = false;

    this.venditaCommonService.setGranzie(graranzia);
    this.indietro();
  }

  indietro() {
    this.router.navigate(['/vendita'], { preserveQueryParams: true });
  }

  // Get Tipo and Descrizione List
  getTipoDescrizioneList() {
    const techniciaCode = this.venditaCommonService.getFirmaTechnicia();
    this.pefService.getTipoDescrizioneData(techniciaCode).
      subscribe(response => {
        this.parentTipoList = response;
        this.tipoList = Object.keys(this.parentTipoList.tippoDescriptionMap).reduce((temp, e) => {
          if (e != null) {
            temp.push({ 'description': e, 'value': e });
          }
          return temp;
        }, []);

      }, error => {
        console.log('Error occured in retrieving tipo & descrizione service call');
      }, () => {
        this.setTipoDescription();
      });
  }

  gettipoDescription(input, event) {

    this.garanziaForm.get('descrizioneCodice').setValue('');

    const selectedOption = event.target.value;
    const selectedTipo = this.tipoList.find(tipo => tipo.value === this.garanziaForm.get('tipo').value);

    if (selectedTipo.description === 'FIDEIUSSORIA') {
      this.garanziaForm.get('atto').enable();

      this.garanziaForm.get('fuoriAtto').enable();

    } else {
      this.garanziaForm.get('atto').setValue('');
      this.garanziaForm.get('atto').disable();

      this.garanziaForm.get('fuoriAtto').setValue('');
      this.garanziaForm.get('fuoriAtto').disable();
    }

    if (selectedOption) {
      this.baseClients = [];
      if (this.parentTipoList.tippoDescriptionMap != null) {
        this.descriptions = [];
        this.parentTipoList.tippoDescriptionMap[selectedOption].forEach(data => {
          this.descriptions.push({
            description: data.description,
            value: data.codice,
            tipologiaImporto: data.tipologiaImporto,
            ndgGaranteObbligatorio: data.ndgGaranteObbligatorio,
            percentualeGaranzia: data.percentualeGaranzia,
            pegnoObbligatorio: data.pegnoObbligatorio,
            ndgPegnoObbligatorio: data.ndgPegnoObbligatorio
          });
        });
      } else {
        this.selectedDesc = '';
        this.garanteDisabledFlag = true;
      }
    }

    if (this.garanziaForm.controls.percentualeIpoteca) {
      this.garanziaForm.controls.percentualeIpoteca.setValue('');
    }
    this.garanziaForm.controls.importo.setValue(0);

    this.validation(this.descriptions[0].value);
  }

  addFormControl() {
    if (this.simulationData.macroCategory === 'MUTUI_IPOTECARI_CASA' || this.simulationData.macroCategory === 'ALTRI_MUTUI_IPOTECARI') {
      this.garanziaForm.addControl('percentualeIpoteca', new FormControl('',
        Validators.compose([Validators.pattern('^([/s]|100|[1-9][0-9]?[\.]?[0-9]*|[0][\.][1-9][0-9]?)$')])));
    }
  }

  setImportoGaranzie() {
    if (this.selectedDesc != '51') {

      this.requireImportoOrPercentage();
      this.garanziaForm.controls.importo.setValue(0);

      if (this.garanziaForm.value.percentualeIpoteca && this.garanziaForm.controls.percentualeIpoteca && this.garanziaForm.value.percentualeIpoteca !== '' && this.garanziaForm.controls.percentualeIpoteca.value !== '') {
        const valore = ((+this.garanziaForm.controls.percentualeIpoteca.value * +this.importoMutuo) / 100).toString();
        this.importo = ((+this.garanziaForm.value.percentualeIpoteca * +this.importoMutuo) / 100).toString();
        this.garanziaForm.controls.importo.setValue(valore);
        this.garanziaForm.controls.importo.setErrors(null);
      }
    }
  }

  setTipoDescription() {
    this.tipoList.forEach(data => {
      switch (data.value) {
        case '01': {
          data.description = 'FIDEIUSSORIA';
          break;
        }
        case '02': {
          data.description = 'IPOTECARIA';
          break;
        }
        case '03': {
          data.description = 'REALE';
          break;
        }
        case '04': {
          data.description = 'PATRONAGE';
          break;
        }
        case '05': {
          data.description = 'CAMBIARIA';
          break;
        }
        case '06': {
          data.description = 'CON MANDATO';
          break;
        }
        case '07': {
          data.description = 'CON CESSIONE';
          break;
        }
        case '08': {
          data.description = 'CON POLIZZA';
          break;
        }

      }
    });
  }

  validation(event: any) {
    let selectedOption;
    if (event.target) {
      selectedOption = event.target.value;
    } else {
      selectedOption = event;
    }

    if (selectedOption) {
      if (this.descriptions != null) {
        const actualDesc = this.descriptions.find(selectedDescription => selectedDescription.value == selectedOption);
        this.garanziaForm.controls['descrizioneEstesa'].setValue(actualDesc.description);
        this.tipologiaImporto = actualDesc.tipologiaImporto;
        this.checkPercentageAndImporto(actualDesc);
        if (actualDesc.ndgPegnoObbligatorio) {
          this.garanziaForm.controls.garantiList.setValidators([Validators.required]);
        } else {
          this.garanziaForm.controls.garantiList.setValidators(null);
        }
        this.garanziaForm.controls.garantiList.updateValueAndValidity();
        this.garanteRequired = actualDesc.ndgPegnoObbligatorio;
        this.refreshGarantiList(actualDesc.ndgGaranteObbligatorio);
      }
    }
    if (selectedOption) {

      if (this.descriptions != null) {
        const result = this.descriptions.find(selectedDescription => selectedDescription.value == selectedOption);

        if (result.percentualeGaranzia > 0 && this.garanziaForm.controls.percentualeIpoteca) {
          this.garanziaForm.controls.percentualeIpoteca.setValue(result.percentualeGaranzia);
        } else if (this.garanziaForm.controls.percentualeIpoteca) {
          this.garanziaForm.controls.percentualeIpoteca.setValue('');
        }

        if (event.target) {
          this.setImportoGaranzie();
        }

      }
    }
  }

  checkPercentageAndImporto(actualDesc) {

    if (this.selectedTipo == '02') { //forzatura per garanzie ipotecarie
      this.importoGaranzieDisabled = true;
      this.importoRequired = true;

      this.percentualeGaranzieDisabled = false;
      this.percentualeRequired = true;

      if (this.garanziaForm.controls.percentualeIpoteca) {
        this.garanziaForm.controls.percentualeIpoteca.updateValueAndValidity();
      }
      this.showGaranteMultiselect = false;
      return;

    } else if (this.selectedDesc == '51') {  // 51 vale alla descrizione: fideiussione solidale limitata
      this.importoGaranzieDisabled = true;
      this.percentualeGaranzieDisabled = false;
      this.garanziaForm.controls.importo.setValue(this.importoMutuo);
      this.importo = this.importoMutuo;
      this.garanziaForm.controls.importo.setValidators(null);
      if (this.garanziaForm.controls.percentualeIpoteca) {
        this.garanziaForm.controls.percentualeIpoteca.setValidators(null);
      }
      this.garanziaForm.controls.importo.updateValueAndValidity();
      this.showGaranteMultiselect = true
      return;
    } else {
      this.garanziaForm.controls.importo.setValidators(Validators.compose([Validators.required, Validators.pattern('^([1-9][0-9]*[\.]?[0-9]*|[0][\.][1-9][0-9]?)$')]));
      if (this.garanziaForm.controls.percentualeIpoteca) {
        this.garanziaForm.controls.percentualeIpoteca.setValidators(Validators.compose([Validators.required, Validators.pattern('^([/s]|100|[1-9][0-9]?[\.]?[0-9]*|[0][\.][1-9][0-9]?)$')]));
      }
      this.showGaranteMultiselect = false;
      this.garanziaForm.updateValueAndValidity();
    }

    switch (actualDesc.tipologiaImporto) {
      case 'I':
      case 'L': {
        this.importoGaranzieDisabled = false;
        this.importoRequired = true;

        this.percentualeGaranzieDisabled = true;
        this.percentualeRequired = false;
        if (this.garanziaForm.controls.percentualeIpoteca) {
          this.garanziaForm.controls.percentualeIpoteca.setValidators(null);
          this.garanziaForm.controls.percentualeIpoteca.setErrors(null);
        }
        break;
      }
      case 'P': {
        this.importoGaranzieDisabled = true;
        this.importoRequired = false;

        this.percentualeGaranzieDisabled = false;
        this.percentualeRequired = true;
        break;
      }
      case 'O': {
        this.importoGaranzieDisabled = false;
        this.importoRequired = true;

        this.percentualeGaranzieDisabled = false;
        this.percentualeRequired = true;
        break;
      }
      default: {
        break;
      }
    }
  }

  requireImportoOrPercentage() {
    const actualDesc = this.descriptions.find(selectedDescription => selectedDescription.value == this.selectedDesc);

    if (actualDesc.tipologiaImporto == 'O') {

      if (this.garanziaForm.controls.importo.value != '' && this.garanziaForm.controls.importo.value != 0) {
        this.garanziaForm.controls.importo.setValidators(Validators.compose([Validators.required, Validators.pattern('^([1-9][0-9]*[\.]?[0-9]*|[0][\.][1-9][0-9]?)$')]));
        if (this.garanziaForm.controls.percentualeIpoteca) {
          this.garanziaForm.controls.percentualeIpoteca.setValidators(null);
        }
        this.importoRequired = true;
        this.percentualeRequired = false;
      } else if (this.garanziaForm.controls.percentualeIpoteca && this.garanziaForm.controls.percentualeIpoteca.value != '' && this.garanziaForm.controls.percentualeIpoteca.value != 0) {
        this.garanziaForm.controls.importo.setValidators(null);
        this.garanziaForm.controls.percentualeIpoteca.setValidators(Validators.compose([Validators.required, Validators.pattern('^([/s]|100|[1-9][0-9]?[\.]?[0-9]*|[0][\.][1-9][0-9]?)$')]));
        this.importoRequired = false;
        this.percentualeRequired = true;
      } else {
        this.garanziaForm.controls.importo.setValidators(Validators.compose([Validators.required, Validators.pattern('^([1-9][0-9]*[\.]?[0-9]*|[0][\.][1-9][0-9]?)$')]));
        if (this.garanziaForm.controls.percentualeIpoteca) {
          this.garanziaForm.controls.percentualeIpoteca.setValidators(Validators.compose([Validators.required, Validators.pattern('^([/s]|100|[1-9][0-9]?[\.]?[0-9]*|[0][\.][1-9][0-9]?)$')]));
        }
        this.importoRequired = true;
        this.percentualeRequired = true;
      }
      this.garanziaForm.updateValueAndValidity();
    }
  }

  refreshGarantiList(needInt: boolean) {
    this.baseClients = [];
    this.dropdownList = [];
    this.garanziaForm.controls.garantiList.setValue(null);
    // not proud of this, my last day in Cap and too much work do to.
    this.garanteDisabledFlag = false;
    if (this.GARClientRoleList != null) {
      this.GARClientRoleList.forEach(data => {
        if (!this.showGaranteMultiselect) {
          this.baseClients.push({ 'description': data.name + ' ' + data.surname, 'value': data.ndg });
        } else {
          this.dropdownList.push({ ndgGarante: data.ndg, intestazioneGarante: data.name + ' ' + data.surname });
        }
      });
    }
    if (this.TERClientRoleList != null) {
      this.TERClientRoleList.forEach(data => {
        if (!this.showGaranteMultiselect) {
          this.baseClients.push({ 'description': data.name + ' ' + data.surname, 'value': data.ndg });
        } else {
          this.dropdownList.push({ ndgGarante: data.ndg, intestazioneGarante: data.name + ' ' + data.surname });
        }
      });
    }
    if (needInt && this.INTClientRoleList != null) {
      this.INTClientRoleList.forEach(data => {
        if (!data.cointestazione) {
          if (!this.showGaranteMultiselect) {
            this.baseClients.push({ 'description': data.name + ' ' + data.surname, 'value': data.ndg });
          } else {
            this.dropdownList.push({ ndgGarante: data.ndg, intestazioneGarante: data.name + ' ' + data.surname });
          }
        }
      });
    }
    this.garanteDisabledFlag = this.baseClients.length === 0;
  }
}
