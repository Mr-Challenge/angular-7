import { AfterViewInit, ChangeDetectorRef, Component, Input, OnChanges, OnInit, ViewEncapsulation, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { DialogService } from 'bstore-angular-library';
import { GaranzieAmmessePerFidoModel } from '../../models/garanzieAmmessePerFido.model';
import { GuaranteesInputModel } from '../../models/guarantees.input';
import { GuaranteesModel } from '../../models/guarantees.model';
import { SimulationDataModel } from '../../models/simulation-data.model';
import { PefService } from '../../services/pef.service';
import { VenditaCommonService } from '../../services/vendita-common.service';
import { BaseFidiGaranzieSectionComponent } from '../base-fidi-garanzie-section/base-fidi-garanzie-section.component';
import { Subscription } from 'rxjs';

@Component({
  selector: 'bst-fin-garanzie',
  templateUrl: './garanzie.component.html',
  styleUrls: ['./garanzie.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class GaranzieComponent extends BaseFidiGaranzieSectionComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {

  @Input() simulationData: SimulationDataModel;
  @Input() formaTecnica: any;
  @Input() GARClientRole: any[];
  @Input() INTClientRole: any[];
  @Input() TERClientRole: any[];
  @Input() formaFlag: string;
  @Input() praticaId: string;
  @Input() chirografarioFlag: boolean;

  guarantees: GuaranteesModel[] = [];
  allGranzie: GuaranteesModel[] = [];
  selecteFormaTecnica: any;
  selectedGaranzies: any;
  getFormaTecnica: any;
  garanzieAmmesseList: GaranzieAmmessePerFidoModel[] = [];
  addGuaranteeEvents = [
    { eventName: 'click', eventCallBack: this.addNewGaranzie.bind(this) }
  ];
  validGuarantees: boolean;
  isGuaranteeError: boolean;
  subscribtion: Subscription;

  constructor(protected dialog: DialogService, private pefService: PefService,
    private router: Router, private venditaCommonService: VenditaCommonService,
    private cdr: ChangeDetectorRef) {
    super(dialog);
    this.guarantees = [];

    this.subscribtion = this.venditaCommonService.allGranzie.subscribe(guarantee => {
      if (guarantee != null) {
        this.guarantees.push(guarantee);
        this.updateVenditaData();
      }
    });
  }

  ngOnInit() {

    const guaranteesFromSubject = [...this.guarantees];

    this.guarantees = this.venditaCommonService.getGranzieList();
    guaranteesFromSubject.forEach(gnzFromSubject => {
      this.guarantees.push(gnzFromSubject);
    });

    this.guarantees = this.guarantees ? this.guarantees : [];
    this.formaTecnica = this.venditaCommonService.getFirmaTechnicia();
    console.log(this.formaTecnica);
    if (this.guarantees && this.guarantees.length !== 0) {
      this.validGuarantees = true;
      this.sectionValid.emit(true);
    } else {
      if (this.chirografarioFlag) {
        this.validGuarantees = true;
        this.sectionValid.emit(true);
      } else {
        this.validGuarantees = false;
      }
      this.getGuarantees();
    }
  }

  deleteGaranzie(index: number) {
    this.checkForPopUp().then(() => {
      this.guarantees.splice(index, 1);
      if (this.guarantees) {
        this.venditaCommonService.setGranzieList(this.guarantees);
      }
      this.updateVenditaData();
      this.isValidGuarantees();
    });
  }

  getGuarantees() {
    const guaranteesInputModel = new GuaranteesInputModel();
    if (this.formaTecnica) {
      guaranteesInputModel.techniciaCode = this.formaTecnica.value;
    } else {
      return;
    }
    const ndgList = [...this.GARClientRole, ...this.INTClientRole, ...this.TERClientRole].map(Clientrole => Clientrole.ndg);
    guaranteesInputModel.numeraPratica = this.praticaId;
    guaranteesInputModel.ndgList = ndgList;
    guaranteesInputModel.idProdotto = this.simulationData['idProdotto'];
    guaranteesInputModel.proposalId = this.proposalId;
    this.pefService.getGuarantees(guaranteesInputModel).subscribe(data => {
      if (data.guaranteesList && data.guaranteesList.length > 0) {
        this.guarantees = data.guaranteesList;
      } else {
        if (!this.guarantees) {
          this.guarantees = [];
        } else {
          // if I have already on page a list of guarantee but no object back from controller
          // -> check if there is a default guarantee and remove it
          const defaultGuaranteeIndex: number[] = [];
          this.guarantees.forEach((element, index) => {
            if (element.defaultGuarantees) {
              defaultGuaranteeIndex.push(index);
            }
          });
          if (defaultGuaranteeIndex.length > 0) {
            defaultGuaranteeIndex.forEach(element => {
              this.deleteGaranzie(element);
            });
          }
        }
      }
      if (data.garanzieAmmesseList) {
        this.garanzieAmmesseList = data.garanzieAmmesseList;
      }
    }, err => {
      this.isGuaranteeError = true;
    }, () => {
      this.updateVenditaData();
    });
  }

  addNewGaranzie() {
    this.checkForPopUp().then(() => {
      this.router.navigate(['vendita/add-visualizza-garanzia'], { preserveQueryParams: true });
    });
  }

  openGuaranteeDetail(guarantee: GuaranteesModel) {
    if (guarantee.tipo) {
      this.venditaCommonService.setCurrentGranzie(guarantee);
      this.router.navigate(['vendita/visualizza-garanzia'], { preserveQueryParams: true });
    }
  }

  setFlag(event: any, data: GuaranteesModel, i: number) {
    this.checkForPopUp().then(() => {
      const newGaranzies: GuaranteesModel[] = [];
      this.guarantees.forEach(element => {
        if (element.selectedGuarantee) {
          newGaranzies.push(element);
        }
      });
      this.updateVenditaDataNewGaranzies(newGaranzies);
    }, () => {
      data.selectedGuarantee = !data.selectedGuarantee;
    });
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

  clearComponent() {
    this.sectionValid.emit(false);
    delete this.guarantees;
  }

  updateVenditaData() {
    const selectedGaranzies = [];
    this.guarantees.forEach(element => {
      if (element.selectedGuarantee) {
        selectedGaranzies.push(element);
      }
    });
    if (selectedGaranzies.length > 0) {
      this.isValidGuarantees();
      this.venditaCommonService.setVenditaPageData('selectedGuarantees', selectedGaranzies);
    }
  }

  updateVenditaDataNewGaranzies(newGaranzies) {
    if (this.guarantees.length > 0) {
      this.isValidGuarantees();
      this.venditaCommonService.setVenditaPageData('selectedGuarantees', newGaranzies);
    }
  }

  ngOnChanges() {
    if (this.formaFlag && this.formaTecnica && this.componentEnable) {
      this.getGuarantees();
    }
  }

  ngOnDestroy() {
    this.subscribtion.unsubscribe();
  }

  isValidGuarantees() {
    if (this.chirografarioFlag) {
      this.validGuarantees = true;
      this.sectionValid.emit(this.validGuarantees);
    } else {
      this.validGuarantees = this.guarantees.some(element => element.selectedGuarantee && !element.defaultGuarantees);
      this.sectionValid.emit(this.validGuarantees);
    }
  }

}

