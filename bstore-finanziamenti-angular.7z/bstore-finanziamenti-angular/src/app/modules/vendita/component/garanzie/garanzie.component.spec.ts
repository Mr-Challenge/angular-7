import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GaranzieComponent } from './garanzie.component';

describe('GaranzieComponent', () => {
  let component: GaranzieComponent;
  let fixture: ComponentFixture<GaranzieComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GaranzieComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GaranzieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
