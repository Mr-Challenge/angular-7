import { Component, OnInit, ViewChild } from '@angular/core';
import { SelectOptionModel } from 'bstore-angular-library/lib/models/select-option-model';
import { Router } from '@angular/router';
import { GuaranteesModel } from '../../../models/guarantees.model';
import { VenditaCommonService } from '../../../services/vendita-common.service';
import { CommonPopupComponent } from 'bstore-angular-library';

@Component({
  selector: 'bst-fin-visualizza-garanzia',
  templateUrl: './visualizza-garanzia.component.html',
  styleUrls: ['./visualizza-garanzia.component.scss']
})
export class VisualizzaGaranziaComponent implements OnInit {

  @ViewChild(CommonPopupComponent) commonPopupComponent: CommonPopupComponent;

  selectedGranzie: GuaranteesModel;
  public descriptions: SelectOptionModel[];
  public tipoList: SelectOptionModel[];
  constructor(private router: Router, private venditaCommonService: VenditaCommonService) { }

  ngOnInit() {
    this.selectedGranzie = this.venditaCommonService.selectedGranzie();
    if (this.selectedGranzie) {
      this.descriptions = [
        {
          value: this.selectedGranzie.descrizioneEstesa,
          description: this.selectedGranzie.descrizioneEstesa
        }
      ];
      this.tipoList = [
        {
          value: this.selectedGranzie.tipo,
          description: this.selectedGranzie.tipo
        }
      ];
    }
    
  }

  indietro() {
    this.router.navigate(['/vendita'], { preserveQueryParams: true });
  }
}
