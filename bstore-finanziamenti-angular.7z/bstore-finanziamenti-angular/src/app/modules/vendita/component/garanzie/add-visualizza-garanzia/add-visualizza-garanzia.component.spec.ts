import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddVisualizzaGaranziaComponent } from './add-visualizza-garanzia.component';

describe('AddVisualizzaGaranziaComponent', () => {
  let component: AddVisualizzaGaranziaComponent;
  let fixture: ComponentFixture<AddVisualizzaGaranziaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddVisualizzaGaranziaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddVisualizzaGaranziaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
