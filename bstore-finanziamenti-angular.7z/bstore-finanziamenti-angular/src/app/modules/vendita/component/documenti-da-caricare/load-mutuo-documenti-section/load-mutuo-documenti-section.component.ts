import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BpertwainUtilsService, CommonPopupComponent, NpvErrorServiceService } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { LoadDocValidation } from 'bstore-angular-library/lib/models/load-doc-validation';
import { environment } from 'src/environments/environment';
import { PefService } from '../../../services/pef.service';
import { VenditaCommonService } from '../../../services/vendita-common.service';
import { BaseDocumentiSectionComponent } from '../base-documenti-section/base-documenti-section.component';
import { D2AnswerVm } from '../../../models/d2AnswerVM.model';
import { LogDetailsModel } from 'bstore-angular-library/lib/models/log-details-model';

@Component({
  selector: 'bst-fin-load-mutuo-documenti-section',
  templateUrl: './load-mutuo-documenti-section.component.html',
  styleUrls: ['./load-mutuo-documenti-section.component.scss']
})
export class LoadMutuoDocumentiSectionComponent extends BaseDocumentiSectionComponent implements OnInit {
  prevAcquiredDocuments: any[] = [];
  documentForm: FormGroup;
  documentiData: any;
  professionType: string;
  documentDetectChange: boolean;
  isDaCariCareValid: boolean;
  currentcodiceDocumento: any;
  isDevelopmentEnv: boolean;
  idProposal: number;
  submitEvents: EventsModel[] = [];
  loadDocValidations: LoadDocValidation[] = [];
  proposalId: string;
  answerVM: D2AnswerVm;
  @ViewChild(CommonPopupComponent) commonPopupComponent: CommonPopupComponent;
  logDetailsModel: LogDetailsModel = {};
  domainName = environment.devUrlJSON['npv.service.callback.url'];

  constructor(
    protected npvErrorServiceService: NpvErrorServiceService,
    protected venditaCommonService: VenditaCommonService,
    protected pefService: PefService,
    protected bpertwainUtils: BpertwainUtilsService,
    protected router: Router,
    private route: ActivatedRoute
  ) {
    super(npvErrorServiceService, pefService, venditaCommonService, bpertwainUtils, router);
    this.route.queryParams.subscribe(params => {
      this.idProposal = params['idProposal'];
    });
  }

  ngOnInit() {
    this.submitEvents = [
      { eventName: 'click', eventCallBack: this.startArchive.bind(this) }
    ];

    this.isDevelopmentEnv = environment.bperTwainMock;
    this.documentiData = this.venditaCommonService.getDocumentiData();
    this.identifier = 'MUTUO_DOCS';

    if (this.idProposal) {
      this.logDetailsModel.numeroPropostaVenditaOPV = this.idProposal.toString();
    } else {
      this.logDetailsModel.section = 'Mutui';
    }

    this.venditaCommonService.getD2AnswerLocal().subscribe(interviewData => {
      this.answerVM = interviewData;
    }, error => { }, () => {
      this.pefService.getMutuiDocumentiDetails(
        {
          ndg: this.documentiData.ndg,
          pefId: this.documentiData.praticaId,
          surrogheAttive: this.answerVM.surroga,
          acquistoAttivo: this.answerVM.acquisto,
          sostituzioneAttiva: this.answerVM.sostituzione
        }).subscribe(mutuidocumentiData => {
          this.sezioneDocumenti = mutuidocumentiData;
          this.documentForm = this.createFromGroup(this.sezioneDocumenti.sezioneDocumenti);
        }, error => { }, () => {
          this.commonPopupComponent.createObserver();
        });
    });
  }
}
