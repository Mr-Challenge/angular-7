import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentiDiMutuoComponent } from './documenti-di-mutuo.component';

describe('DocumentiDiMutuoComponent', () => {
  let component: DocumentiDiMutuoComponent;
  let fixture: ComponentFixture<DocumentiDiMutuoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentiDiMutuoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentiDiMutuoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
