import { Component, OnInit, ChangeDetectorRef, Input } from '@angular/core';
import { DocumentiSogettiDetails } from 'src/app/models/documentiSogettiDetails';
import { Router } from '@angular/router';
import { VenditaCommonService } from '../../../services/vendita-common.service';
import { DialogService } from 'bstore-angular-library';
import { DocumentiPopUpComponent } from '../documenti-pop-up/documenti-pop-up.component';

@Component({
  selector: 'bst-fin-documenti-sogetti',
  templateUrl: './documenti-sogetti.component.html',
  styleUrls: ['./documenti-sogetti.component.scss']
})
export class DocumentiSogettiComponent implements OnInit {
  @Input() documentiSogettiDetails: DocumentiSogettiDetails[];
  @Input() praticaId: any;
  @Input() tabName: string;
  @Input() tab: string;
  showPopup = [];
  constructor(
    private router: Router,
    private cdr: ChangeDetectorRef,
    private venditaCommonService: VenditaCommonService,
    public dialog: DialogService) {

  }

  ngOnInit() {
  }

  displaySection(data) {
    data['praticaId'] = this.praticaId;
    let entita = '';
    if (this.tabName === 'Intestatari') {
      entita = 'INTESTATARIO';
    }
    if (this.tabName === 'Garanti') {
      entita = 'GARANTE';
    }
    if (this.tabName === 'Terzo datore ipoteca') {
      entita = 'TERZO_DATORE';
    }
    data['entita'] = entita;
    const privateCardData = this.venditaCommonService.getPrivateCardData();
    const findHolder = holder => holder.ndg === data.ndg;
    const holder = privateCardData[this.tab].find(findHolder);
    this.venditaCommonService.setDocumentiData(data);
    if (holder != undefined && holder.requiredProfession) {
      this.dialog.open(DocumentiPopUpComponent, {
        size: 'small',
        noCloseButton: true,
        data: ''
      });
    } else {
      this.router.navigate(['vendita/load-documenti-section'], { preserveQueryParams: true });
    }
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

}
