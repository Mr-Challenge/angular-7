import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BaseDocumentiSectionComponent } from './base-documenti-section.component';

describe('BaseDocumentiSectionComponent', () => {
  let component: BaseDocumentiSectionComponent;
  let fixture: ComponentFixture<BaseDocumentiSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BaseDocumentiSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BaseDocumentiSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
