import { Component, OnInit } from '@angular/core';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { VenditaCommonService } from '../../../services/vendita-common.service';
import { Router } from '@angular/router';
import { DialogRef } from 'bstore-angular-library';

@Component({
  selector: 'bst-fin-documenti-pop-up',
  templateUrl: './documenti-pop-up.component.html',
  styleUrls: ['./documenti-pop-up.component.scss']
})
export class DocumentiPopUpComponent implements OnInit {
  okEvents: EventsModel[] = [];
  constructor(
    private venditaCommonService: VenditaCommonService,
    private router: Router,
    public dialog: DialogRef
  ) { }

  ngOnInit() {
    this.okEvents = [
      {eventName: 'click', eventCallBack: this.closeOkDocument.bind(this)},
    ];
  }

  closeOkDocument() {
    this.dialog.close('Closed');
    this.router.navigate(['vendita/load-documenti-section'], { preserveQueryParams: true });
  }

}
