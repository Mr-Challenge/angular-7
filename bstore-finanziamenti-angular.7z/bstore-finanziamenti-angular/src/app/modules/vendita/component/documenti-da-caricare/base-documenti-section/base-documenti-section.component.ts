import { Component, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BpertwainUtilsService, NpvErrorServiceService, VerificaAcquisizioneDocumentiModel } from 'bstore-angular-library';
import { ErrorMessageModel } from 'bstore-angular-library/lib/models/error-message-model';
import { LoadDocValidation } from 'bstore-angular-library/lib/models/load-doc-validation';
import { environment } from 'src/environments/environment';
import { UpdateDocsModel } from '../../../models/updateDocsModel';
import { PefService } from '../../../services/pef.service';
import { VenditaCommonService } from '../../../services/vendita-common.service';

@Component({
  selector: 'bst-fin-base-documenti-section',
  template: 'NO UI TO BE FOUND HERE!'
})
export class BaseDocumentiSectionComponent implements OnInit {

  prevAcquiredDocuments: any[] = [];
  documentForm: FormGroup;
  loadDocValidations: LoadDocValidation[] = [];
  idProposal: number;
  documentiData: any;
  documentDetectChange: boolean;
  isDaCariCareValid: boolean = null;
  sezioneDocumenti: VerificaAcquisizioneDocumentiModel;
  sezioneDocumentiToStore: any;
  identifier: string;
  missingDocumentDescription: string;
  successFunctionArchive: Function;
  errorFunctionArchive: Function;
  sezioneDocumentiKey = 'sezioneDocumenti';

  constructor(protected npvErrorServiceService: NpvErrorServiceService, protected pefService: PefService,
    protected venditaCommonService: VenditaCommonService, protected bpertwainUtils: BpertwainUtilsService, protected router: Router) {
    const self = this;
    this.successFunctionArchive = (archivedDocumentResult) => {
      const updateAcquiredDocModel = new UpdateDocsModel;
      if (archivedDocumentResult && archivedDocumentResult[0]) {
        updateAcquiredDocModel.filenetId = archivedDocumentResult[0].documentId;
        updateAcquiredDocModel.idProposta = self.idProposal.toString();
        self.pefService.updateAcquiredDocs(updateAcquiredDocModel).subscribe(response => {
          if (response) {
            console.log('Sucessfully updated Acquired Documents Status');
          } else {
            console.log('Error while updating Acquired Documents Status');
          }
        });
      }
    };
    this.errorFunctionArchive = (errorData) => {
      console.log('from archive error callback', errorData);
    };
  }

  ngOnInit() {
  }

  createFromGroup(documents) {
    const documentForm: any = {};
    let currentcodiceDocumento = '';
    let firstSelectElem: string;
    documents.forEach(question => {
      const formGroupControls = Object.keys(question.documentiDaAcquisire).reduce((group, key) => {
        if (key !== 'FACOLTATIVO') {
          question.documentiDaAcquisire[key].forEach((mandatoryDocuments, index) => {
            if (mandatoryDocuments.numeroDocumentiRichiesti !== null) {
              for (let i = 0; i < mandatoryDocuments.numeroDocumentiRichiesti; i++) {
                const valid = i < mandatoryDocuments.documentiAcquisiti.length;
                this.createValidator(question.categoriaDiDocumento, key, mandatoryDocuments.codiceDocumento, i + 1, valid, mandatoryDocuments.descrizioneDocumento);
              }
              if (!firstSelectElem) {
                firstSelectElem = mandatoryDocuments.codiceDocumento;
              }
              if (mandatoryDocuments.documentiAcquisiti.length > 0) {
                currentcodiceDocumento = mandatoryDocuments.codiceDocumento;
                mandatoryDocuments.documentiAcquisiti.forEach((elem) => {
                  elem['modalitaAcquisizione'] = key;
                  elem['categoriaDiDocumento'] = question.categoriaDiDocumento;
                  elem['codiceDocumento'] = mandatoryDocuments.codiceDocumento;
                  this.prevAcquiredDocuments.push(elem);
                });
              }
            } else {
              const errorModel = <ErrorMessageModel>{
                message: 'Numero documenti richiesti non presente'
              };
              this.npvErrorServiceService.openErrorPopup(errorModel);
            }
          });
          group[key] = new FormControl(currentcodiceDocumento ? currentcodiceDocumento : firstSelectElem, Validators.required);
          firstSelectElem = '';
          return group;
        } else {
          question.documentiDaAcquisire[key].forEach((mandatoryDocuments, index) => {
            if (mandatoryDocuments.documentiAcquisiti.length > 0) {
              if (mandatoryDocuments.documentiAcquisiti.length > 0) {
                mandatoryDocuments.documentiAcquisiti.forEach((elem) => {
                  elem['modalitaAcquisizione'] = key;
                  elem['categoriaDiDocumento'] = question.categoriaDiDocumento;
                  elem['codiceDocumento'] = mandatoryDocuments.codiceDocumento;
                  this.prevAcquiredDocuments.push(elem);
                  currentcodiceDocumento = mandatoryDocuments.codiceDocumento;
                });
              }
            }

            group[mandatoryDocuments.codiceDocumento] = new FormControl();
          });

          return group;
        }
      }, {});
      formGroupControls['isChecked'] = new FormControl('');
      documentForm[question.categoriaDiDocumento] = new FormGroup(formGroupControls);
    });
    this.checkDaCariCareIsValid();
    return new FormGroup(documentForm);
  }

  startArchive() {
    const self = this;
    const fileNetIds = [];
    this.prevAcquiredDocuments.map(doc => {
      fileNetIds.push(doc.idFilenet);
    });

    const updateMetadata = () => new Promise((resolve, reject) => {
      if (fileNetIds != null && fileNetIds.length > 0) {
        fileNetIds.forEach((fileId) => {
          const updateAcquiredDocModel = new UpdateDocsModel;
          updateAcquiredDocModel.filenetId = fileId;
          updateAcquiredDocModel.idProposta = self.idProposal.toString();
          self.pefService.updateAcquiredDocs(updateAcquiredDocModel).subscribe(response => {
            if (response) {
              console.log('Sucessfully updated Acquired Documents Status');
            } else {
              console.log('Error while updating Acquired Documents Status');
            }
            resolve();
          });
        });
      } else {
        resolve();
      }
    });
    updateMetadata().then(() => {
      this.pefService.saveAcquiredDocStatus(this.identifier, this.idProposal).subscribe(response => {
        if (response != null && response === true) {
          console.log('Acquired Documents status saved sucessfully with this identifier: ' + this.identifier);
          this.venditaCommonService.setAcquiredDocument(this.identifier);
        }
      }, error => {
        console.log('Error in saving acquired documents status: ' + error);
      });
    });
    this.indietro();
  }

  checkValidation(event) {
    this.documentDetectChange = true;
    this.updateValidatore(event.categoria, event.modalita, event.codiciDocumento[0], event.index, event.valid);
    this.checkDaCariCareIsValid();
  }

  checkDaCariCareIsValid() {
    const searchDoc = this.loadDocValidations.find(function (item: LoadDocValidation) {
      return item.valid === false;
    });
    if (searchDoc) {
      this.isDaCariCareValid = false;
    } else {
      this.isDaCariCareValid = true;
    }
  }


  indietro() {
    this.bpertwainUtils.resetDocumentState();
    this.bpertwainUtils.clearDocumentsState();
    this.router.navigate(['/vendita'], { preserveQueryParams: true });
  }

  createValidator(categoria: string, modalita: string, codiceDoc: string, index: number, valid: boolean, descrizione: string) {
    let loadDocValidation: LoadDocValidation = {
      categoria: categoria,
      modalita: modalita,
      codiciDocumento: [codiceDoc],
      valid: valid,
      index: index,
      descrizione: descrizione,
      validString: valid ? String(valid) : ''
    };
    if (modalita === 'OBBLIGATORIO_ALMENO_UNO_FRA' || modalita === 'OBBLIGATORIO_ALMENO_UNO_FRA_2') {
      // controllo se già presente l'oggetto in this.loadDocValidations
      const searchDoc = this.loadDocValidations.find(function (item: LoadDocValidation) {
        return item.categoria === categoria && item.modalita === modalita;
      });
      if (searchDoc) {
        searchDoc.codiciDocumento.push(codiceDoc);
        loadDocValidation = {
          ...searchDoc
        };
        if (valid) {
          loadDocValidation.valid = valid;
        }
        this.loadDocValidations.pop();
      }
    }
    this.loadDocValidations.push(loadDocValidation);
  }

  updateValidatore(categoria: string, modalita: string, codiceDoc: string, index: number, valid: boolean) {
    const searchDoc = this.loadDocValidations.find(function (item: LoadDocValidation) {
      if (modalita !== 'OBBLIGATORIO_ALMENO_UNO_FRA') {
        return item.categoria === categoria && item.modalita === modalita
          && item.codiciDocumento.some(x => x === codiceDoc) && index === item.index;
      } else {
        const res1 = item.categoria === categoria && item.modalita === 'OBBLIGATORIO_ALMENO_UNO_FRA'
          && item.codiciDocumento.some(x => x === codiceDoc) && index === item.index;
        const res2 = item.categoria === categoria && item.modalita === 'OBBLIGATORIO_ALMENO_UNO_FRA_2'
          && item.codiciDocumento.some(x => x === codiceDoc) && index === item.index;
        return res1 || res2;
      }
    });

    if (searchDoc) {
      //rimuovo da prevAcquiredDocuments, perchè non vanno aggiornati i documenti acquisiti nuovamente
      const remove = this.prevAcquiredDocuments.find(function (item) {
        if (modalita !== 'OBBLIGATORIO_ALMENO_UNO_FRA') {
          return item.categoriaDiDocumento === categoria && item.modalitaAcquisizione === modalita;
        } else {
          const res1 = item.categoriaDiDocumento === categoria && item.modalitaAcquisizione === 'OBBLIGATORIO_ALMENO_UNO_FRA';
          const res2 = item.categoriaDiDocumento === categoria && item.modalitaAcquisizione === 'OBBLIGATORIO_ALMENO_UNO_FRA_2';
          return res1 || res2;
        }
      });

      if (remove) {
        this.prevAcquiredDocuments.splice(remove, 1);
      }
      searchDoc.valid = valid;
      searchDoc.validString = valid ? String(valid) : '';
    }
  }

}
