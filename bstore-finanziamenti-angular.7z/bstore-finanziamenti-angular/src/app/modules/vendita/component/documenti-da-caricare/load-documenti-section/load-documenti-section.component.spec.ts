import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoadDocumentiSectionComponent } from './load-documenti-section.component';

describe('LoadDocumentiSectionComponent', () => {
  let component: LoadDocumentiSectionComponent;
  let fixture: ComponentFixture<LoadDocumentiSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoadDocumentiSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoadDocumentiSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
