import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentiPopUpComponent } from './documenti-pop-up.component';

describe('DocumentiPopUpComponent', () => {
  let component: DocumentiPopUpComponent;
  let fixture: ComponentFixture<DocumentiPopUpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentiPopUpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentiPopUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
