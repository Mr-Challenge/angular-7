import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentiDaCaricareComponent } from './documenti-da-caricare.component';

describe('DocumentiDaCaricareComponent', () => {
  let component: DocumentiDaCaricareComponent;
  let fixture: ComponentFixture<DocumentiDaCaricareComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentiDaCaricareComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentiDaCaricareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
