import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { BpertwainUtilsService, CommonPopupComponent, NpvErrorServiceService } from 'bstore-angular-library';
import { environment } from 'src/environments/environment';
import { PefService } from '../../../services/pef.service';
import { VenditaCommonService } from '../../../services/vendita-common.service';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { BaseDocumentiSectionComponent } from '../base-documenti-section/base-documenti-section.component';
import { EndpointsService } from 'src/app/services/endpoints.service';
import { InterviewResponse } from '../../../models/interview-response-vm';
import { D2AnswerVm } from '../../../models/d2AnswerVM.model';
import { LogDetailsModel } from 'bstore-angular-library/lib/models/log-details-model';

@Component({
  selector: 'bst-fin-load-documenti-section',
  templateUrl: './load-documenti-section.component.html',
  styleUrls: ['./load-documenti-section.component.scss']
})

export class LoadDocumentiSectionComponent extends BaseDocumentiSectionComponent implements OnInit {

  professionType: string;
  isDevelopmentEnv: boolean;
  submitEvents: EventsModel[] = [];
  @ViewChild(CommonPopupComponent) commonPopupComponent: CommonPopupComponent;
  entita: string;
  proposalId : string;
  answerVM : D2AnswerVm;
  logDetailsModel: LogDetailsModel = {};
  domainName = environment.devUrlJSON['npv.service.callback.url'];

  constructor(
    protected npvErrorServiceService: NpvErrorServiceService,
    protected venditaCommonService: VenditaCommonService,
    protected pefService: PefService,
    protected bpertwainUtils: BpertwainUtilsService,
    protected router: Router,
    private route: ActivatedRoute,
    private endpointsService: EndpointsService
  ) {
    super(npvErrorServiceService, pefService, venditaCommonService, bpertwainUtils, router);
    this.route.queryParams.subscribe(params => {
      this.idProposal = params['idProposal'];
    });

  }

  ngOnInit() {
    this.submitEvents = [
      { eventName: 'click', eventCallBack: this.startArchive.bind(this) }
    ];

    this.isDevelopmentEnv = environment.bperTwainMock;
    this.documentiData = this.venditaCommonService.getDocumentiData();
    this.identifier = this.documentiData.ndg;

    if (this.idProposal) {
      this.logDetailsModel.numeroPropostaVenditaOPV = this.idProposal.toString();
    } else {
      this.logDetailsModel.section = 'Mutui';
    }

    this.venditaCommonService.getD2AnswerLocal().subscribe(interviewData => {
      this.answerVM = interviewData;
       }, error => { }, () => {
        this.pefService.getDocumentiDetails(
          {
            ndg: this.documentiData.ndg,
            prodotto: ['MUTUO'],
            pefId: this.documentiData.praticaId,
            surrogheAttive: this.answerVM.surroga,
            acquistoAttivo: this.answerVM.acquisto,
            sostituzioneAttiva: this.answerVM.sostituzione,
            entita: this.documentiData.entita
          }).subscribe(documentiData => {
            this.sezioneDocumenti = documentiData;
    
            this.professionType = this.sezioneDocumenti.tipoLavoro;
            this.documentForm = this.createFromGroup(this.sezioneDocumenti.sezioneDocumenti);
    
            const documentFormKey = 'documentForm';
            const sezioneDocumentiKey = 'sezioneDocumenti';
    
          }, error => { }, () => {
            this.commonPopupComponent.createObserver();
            this.checkDaCariCareIsValid();
          });

       });

   
  }
}

