import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoadMutuoDocumentiSectionComponent } from './load-mutuo-documenti-section.component';

describe('LoadMutuoDocumentiSectionComponent', () => {
  let component: LoadMutuoDocumentiSectionComponent;
  let fixture: ComponentFixture<LoadMutuoDocumentiSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoadMutuoDocumentiSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoadMutuoDocumentiSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
