import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentiSogettiComponent } from './documenti-sogetti.component';

describe('DocumentiSogettiComponent', () => {
  let component: DocumentiSogettiComponent;
  let fixture: ComponentFixture<DocumentiSogettiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentiSogettiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentiSogettiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
