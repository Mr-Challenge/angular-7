import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { VenditaCommonService } from '../../../services/vendita-common.service';
import { PefService } from '../../../services/pef.service';

@Component({
  selector: 'bst-fin-documenti-di-mutuo',
  templateUrl: './documenti-di-mutuo.component.html',
  styleUrls: ['./documenti-di-mutuo.component.scss']
})
export class DocumentiDiMutuoComponent implements OnInit {
  @Input() user: any;
  mutuiDocumenti: any;
  documentiData: any;
  isValidSection: boolean;
  idProposal: number;
  @Output() mutuoDocsStatus = new EventEmitter<boolean>();

  private DOC_VALUE = 'MUTUO_DOCS';
  completed = false;

  constructor(
    private router: Router,
    private pefService: PefService,
    private route: ActivatedRoute,
    private venditaCommonService: VenditaCommonService) {
      this.route.queryParams.subscribe(params => {
        this.idProposal = params['idProposal'];
      });

     }

  ngOnInit() {
    this.venditaCommonService.acquiredDocument.subscribe(data => {
      if (this.DOC_VALUE === data) {
        this.completed = true;
        this.mutuoDocsStatus.emit(true);
      }
    });
    this.findAcquiredDocStatus();
  }

  displaySection() {
    this.venditaCommonService.setDocumentiData(this.user);
    this.router.navigate(['vendita/load-mutuo-documenti-section'], { preserveQueryParams: true });
  }

  findAcquiredDocStatus() {
     this.pefService.findAcquiredDocStatus(this.idProposal).subscribe(acquiredDocStatus => {
      console.log(acquiredDocStatus);
      if (acquiredDocStatus != null) {
      this.completed = acquiredDocStatus.includes(this.DOC_VALUE);
      this.mutuoDocsStatus.emit(this.completed);
      }
    });
  }
}
