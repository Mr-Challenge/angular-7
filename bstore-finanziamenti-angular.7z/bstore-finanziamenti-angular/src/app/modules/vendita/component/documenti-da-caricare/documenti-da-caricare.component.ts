import { Component, OnInit, Input, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { VenditaCommonService } from '../../services/vendita-common.service';
import { ActivatedRoute } from '@angular/router';
import { PefService } from '../../services/pef.service';
import { MortgageClientRoles } from 'src/app/constant/mortgageClientRoles';

@Component({
  selector: 'bst-fin-documenti-da-caricare',
  templateUrl: './documenti-da-caricare.component.html',
  styleUrls: ['./documenti-da-caricare.component.scss']
})
export class DocumentiDaCaricareComponent implements OnInit {
  GARClientRole: any;
  INTClientRole: any;
  TERClientRole: any;
  documentAcquiredUser: any;
  isValidSection: boolean;
  idProposal: number;
  acquiredDocument: boolean;
  @Input() documentsData: any;
  @Input() praticaId: any;
  @Input() chirografarioFlag: boolean;
  @Output() isDaCariCareStatus = new EventEmitter();

  constructor(private cdr: ChangeDetectorRef, private venditaCommonService: VenditaCommonService,
    private route: ActivatedRoute,
    private pefService: PefService) {
    this.venditaCommonService.acquiredDocument.subscribe(data => {
      this.documentsData.forEach(user => {
        if (user.ndg === data) {
          user.acquiredDocument = true;
          this.getRolesAndValidation();
        }
      });
    });
    this.route.queryParams.subscribe(params => {
      this.idProposal = params['idProposal'];
    });
  }

  ngOnInit() {
    this.getRolesAndValidation();
  }

  getRolesAndValidation() {
    this.GARClientRole = this.documentsData.filter(user => user.role === MortgageClientRoles.GARANTI);
    this.INTClientRole = this.documentsData.filter(user => user.role === MortgageClientRoles.INTESTATARI);
    this.TERClientRole = this.documentsData.filter(user => user.role === MortgageClientRoles.TERZI_DATORI_IPOTECA);
    this.pefService.findAcquiredDocStatus(this.idProposal).subscribe(acquiredDocStatus => {
      console.log(acquiredDocStatus);
      if (acquiredDocStatus != null) {
        this.isValidSection = this.documentsData.every(user => {
          this.acquiredDocument = acquiredDocStatus.includes(user.ndg);
          if (this.acquiredDocument === true) {
            user.acquiredDocument = true;
          }
          return this.acquiredDocument;
        });
        this.isDaCariCareStatus.emit(this.isValidSection);
      }
    });
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }
}
