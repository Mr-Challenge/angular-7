import { AfterViewChecked, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogService, RedirectService } from 'bstore-angular-library';
import { combineLatest } from 'rxjs';
import { FinDocumentType } from 'src/app/constant/documentType';
import { MortgageClientRoles } from 'src/app/constant/mortgageClientRoles';
import { MortgageStepWizard } from 'src/app/constant/mortgageStepWizard';
import { TipoProcesso } from 'src/app/constant/tipoProcesso';
import { GenerateDoc } from 'src/app/models/generateDoc.model';
import { ModificaPropostaPopupComponent } from 'src/app/modules/modifica-proposta/components/modifica-proposta-popup/modifica-proposta-popup.component';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { EndpointsService } from 'src/app/services/endpoints.service';
import { environment } from 'src/environments/environment';
import { CommonService } from '../../../../services/common.service';
import { AltreBancheModel } from '../../models/altre-banche.model';
import { GuaranteesModel } from '../../models/guarantees.model';
import { InputConsensoVm } from '../../models/input-consenso-vm.model';
import { InputFormaTecnica } from '../../models/input-forma-tecnica.model';
import { InputSetSituazioneAltreBancheVm } from '../../models/input-set-situazione-altre-banche-vm.model';
import { PrefinanziamentoModel } from '../../models/prefinanziamento.model';
import { RequestVenditaVm } from '../../models/request-vendita-vm.model';
import { SignatureStatusModel } from '../../models/signature-status.model';
import { SimulationDataModel } from '../../models/simulation-data.model';
import { VenditaFetchDocumentVm } from '../../models/vendita-fetch-document-vm.model';
import { VenditaPageVm } from '../../models/vendita-page-vm.model';
import { BookingIdService } from '../../services/booking-id.service';
import { PefService } from '../../services/pef.service';
import { VenditaCommonService } from '../../services/vendita-common.service';
import { VenditaPageService } from '../../services/vendita-page.service';
import { GeneraModuloRichiestaPopUpComponent } from '../genera-modulo-richiesta-pop-up/genera-modulo-richiesta-pop-up.component';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'bst-fin-vendita',
  templateUrl: './vendita.component.html',
  styleUrls: ['./vendita.component.scss']
})
export class VenditaComponent implements OnInit, AfterViewChecked {

  @ViewChild('fidiGaranziePanel') fidiGranziaPanelComponent: any; // ExpansionPanelComponent;
  @ViewChild('parentForm') parentform: NgForm;

  idProposal: number;
  holders: BaseClientModel[];
  bookingId: string;
  baseClientListVm: any;
  mainNdg: string;
  chirografarioFlag: boolean;
  INTClientRole: any[] = [];
  GARClientRole: any[] = [];
  TERClientRole: any[] = [];
  venditaData: any[] = [];
  saveVenditaVM: RequestVenditaVm;
  simulationData: SimulationDataModel;
  requestForSaveVendita: RequestVenditaVm;
  venditaFetchDocumentVm: VenditaFetchDocumentVm;
  praticaId: any;
  ischirografarioFlagSet: boolean;
  documentsData: any;
  domainName = environment.devUrlJSON['npv.service.callback.url'];
  garanzieFlag: boolean;
  preFinFlag: boolean;
  formaFlag: any;
  formaTecnicaFlag: boolean;
  consensoFlag: boolean;
  altreBancheFlag: boolean;
  fidiGaranzieCompleted: boolean;
  fidiGaranzieSaved: boolean;
  richiestaFinanziamentoSigned: boolean;
  consisoSic: any;
  clientBaseList: BaseClientModel[];
  formaTecnica: any;
  altreBancheData: any;
  prefinData: any;
  numberOfElement = 0;
  generateDoc: GenerateDoc;
  venditaPageData: VenditaPageVm;
  asyncVenditaService: boolean;
  prefinanziamentoModel: PrefinanziamentoModel;
  consensoSicList: Array<InputConsensoVm>;
  listaRapportiAltreBanche: Array<AltreBancheModel>;
  isDatiRedditualiCompleted: boolean;
  garanzieExpansion: false | true = false;
  date: Date;
  flagCentraleRischi: boolean;
  mainUser: BaseClientModel;
  guaranteeList: Array<GuaranteesModel>;
  dataChiamataCentraleRischi: Date;
  numeroRapporto: string;

  firmaEvents = [
    { eventName: 'click', eventCallBack: this.onFirmaButtonClick.bind(this) }
  ];

  immobiliEvents = [
    { eventName: 'click', eventCallBack: this.goToImmobiliPage.bind(this) }
  ];

  saveButtonClickEvents = [
    { eventName: 'click', eventCallBack: this.onSaveButtonClick.bind(this) }
  ];

  isDatiAnagrafiCompleted: false | true = false;
  isMutuoDocsCompleted: false | true = false;
  isDaCariCareCompleted: false | true = false;

  constructor(private venditaCommonService: VenditaCommonService, private bookingIdService: BookingIdService, private route: ActivatedRoute,
    private dialogservice: DialogService, private redirectService: RedirectService,
    private pefService: PefService, private cdr: ChangeDetectorRef, private venditaPageService: VenditaPageService,
    private commonService: CommonService, private router: Router, private endpointsService: EndpointsService) {

    this.fidiGaranzieSaved = false;
    this.fidiGaranzieCompleted = false;
    this.richiestaFinanziamentoSigned = false;

    this.route.queryParams.subscribe(params => {
      this.idProposal = params['idProposal'];
      const flagCentraleRischi = params['flagCentraleRischi'] === 'true';
      this.checkSignatureStatus(flagCentraleRischi);
      this.getClientRoles();
      this.getVenditaPageData();
      this.getD2Answer();
    });

    this.venditaCommonService.venditaPageData.subscribe(data => {
      this.venditaData = data;
      if (this.venditaData['key'] === 'altreBanche') {
        this.altreBancheData = this.venditaData['value'];
      }
      if (this.venditaData['key'] === 'prefinFormData') {
        this.prefinData = this.venditaData['value'];
      }
      if (this.venditaData['key'] === 'selectedGuarantees') {
        this.guaranteeList = this.venditaData['value'];
      }
    });

  }

  ngOnInit() {
    this.date = new Date();
  }

  fetchMutuoDetails() {
    this.commonService.fetchMutuoDetails(this.idProposal.toString()).subscribe(result => {
      this.praticaId = result.idPef;
      this.numeroRapporto = result.numeroRapporto;
    });
  }

  getVenditaPageData() {
    this.pefService.getVenditaPageData(this.idProposal).subscribe(response => {
      this.asyncVenditaService = true;
      if (response != null) {
        this.venditaPageData = response;
        this.fidiGaranzieSaved = true;
        this.formaTecnica = this.venditaPageData.codiceFormaTecnica;
        this.prefinanziamentoModel = this.venditaPageData.inputPrefinanziamentoVm;
        this.consensoSicList = this.venditaPageData.inputConsensoVm;
        this.altreBancheFlag = this.venditaPageData.altreBancheFlag;
        this.listaRapportiAltreBanche = this.venditaPageData.listaRapportiAltreBanche;
        this.guaranteeList = this.venditaPageData.guaranteeList;
        this.saveFormaTecnica(this.venditaPageData.codiceFormaTecnica);
        if (this.guaranteeList) {
          this.venditaCommonService.setGranzieList(this.guaranteeList);
        }
        this.dataChiamataCentraleRischi = this.venditaPageData.dataChiamataCentraleRischi;
      }
    }, null, () => {
      this.fetchMutuoDetails();
    });
  }

  getClientRoles() {
    combineLatest(
      this.commonService.getClientByRoleNoCache(this.idProposal.toString(), MortgageClientRoles.INTESTATARI),
      this.commonService.getClientByRoleNoCache(this.idProposal.toString(), MortgageClientRoles.GARANTI),
      this.commonService.getClientByRoleNoCache(this.idProposal.toString(), MortgageClientRoles.TERZI_DATORI_IPOTECA),
      this.commonService.isMutuoIpotecario(this.idProposal.toString()),
      this.pefService.getSimulationData(this.idProposal),
      this.commonService.retrieveAllClient(this.idProposal.toString()))
      .subscribe(([INTClientRole, GARClientRole, TERClientRole, ipotecarioFlag, simulationData, clientList]) => {
        this.INTClientRole = INTClientRole ? INTClientRole : [];
        this.GARClientRole = GARClientRole ? GARClientRole : [];
        this.TERClientRole = TERClientRole ? TERClientRole : [];
        this.ischirografarioFlagSet = true;
        this.simulationData = simulationData;
        this.chirografarioFlag = !ipotecarioFlag;
        this.documentsData = clientList.filter((holder: { cointestazione: any; }) => !holder.cointestazione);
        this.clientBaseList = clientList;
        this.mainUser = this.commonService.getMainUser(this.INTClientRole);
        this.mainNdg = this.mainUser.ndg;

        // If product is chirografario removal of prefin section and setting prefinData as false
        if (this.chirografarioFlag) {
          this.isMutuoDocsCompleted = true;
          this.preFinFlag = true;
          this.prefinData = {
            'prefinanziamentoFlag': false
          };
        }
      });
  }

  onSaveButtonClick() {
    const naturaGiuridica = (!this.mainUser.cointestazione) ? 'PERSONA_FISICA' : 'COINTESTAZIONE';
    this.pefService.verifyOTPFields(this.mainUser.ndg, naturaGiuridica).subscribe(data => {
      if (data.mobilePhone && data.email) {
        const ref = this.dialogservice.open(GeneraModuloRichiestaPopUpComponent, {
          noCloseButton: true,
          data: data
        });
        ref.afterClosed.subscribe(result => {
          if (result) {
            this.openContrattiModule();
          }
        });
      } else {
        this.openContrattiModule();
      }
    });
  }

  openContrattiModule() {
    if (this.fidiGaranzieSaved) {
      this.onFirmaButtonClick();
    } else {
      this.submitData();
    }
  }

  submitData() {
    if (this.altreBancheData) {
      this.numberOfElement = this.altreBancheData.length;
    }

    this.requestForSaveVendita = {
      'inputSetSituazioneAltreBancheVm': {
        listaRapportiAltreBanche: this.altreBancheData,
        numeroElementiTotale: this.numberOfElement,
        numeroPratica: this.praticaId
      },
      'inputConsensoVm': this.consensoSicList,
      'garanzieInRichiestaList': this.guaranteeList,
      'inputFormaTechnicaVm': {
        formaTecnicaDesc: this.formaTecnica.description,
        formaTecnicaValue: this.formaTecnica.value
      },
      'inputPrefinanziamentoVm': this.prefinData,
      'proposalId': this.idProposal.toString(),
      'ndg': this.mainNdg,
      'allClientList': this.clientBaseList,
      'pefId': this.praticaId
    };
    const requestVendita: RequestVenditaVm = {} as any;

    const inputSetSituazioneAltreBanche: InputSetSituazioneAltreBancheVm = {} as any;
    inputSetSituazioneAltreBanche.listaRapportiAltreBanche = this.altreBancheData;
    inputSetSituazioneAltreBanche.numeroElementiTotale = this.numberOfElement;
    inputSetSituazioneAltreBanche.numeroPratica = this.praticaId;

    requestVendita.inputSetSituazioneAltreBancheVm = inputSetSituazioneAltreBanche;

    requestVendita.inputConsensoVm = this.consensoSicList;
    requestVendita.garanzieInRichiestaList = this.guaranteeList;

    const inputFormaTechnica: InputFormaTecnica = {} as any;
    inputFormaTechnica.formaTecnicaDesc = this.formaTecnica.description;
    inputFormaTechnica.formaTecnicaValue = this.formaTecnica.value;

    requestVendita.inputFormaTechnicaVm = inputFormaTechnica;
    requestVendita.inputPrefinanziamentoVm = this.prefinData;
    requestVendita.proposalId = this.idProposal.toString();
    requestVendita.ndg = this.mainNdg;
    requestVendita.allClientList = this.clientBaseList;
    requestVendita.pefId = this.praticaId;

    this.pefService.saveVenditaData(requestVendita).subscribe(bankaResponse => {
      this.fidiGaranzieSaved = true;
      this.generateDoc = bankaResponse;
    }, null, () => {
      this.onFirmaButtonClick();
    });
  }

  generateBookingId(opening: boolean) {
    if (opening) {
      if (!this.bookingId && !this.praticaId) {
        this.mainUser = this.commonService.getMainUser(this.INTClientRole);
        this.mainNdg = this.mainUser.ndg;
        this.bookingIdService.getBookingId(this.idProposal, this.mainNdg).subscribe(userData => {
          this.bookingId = userData;
          this.getPraticaId(this.bookingId);
        }, err => {
          // chiudiamo accordion fidi e garanzie
          this.fidiGranziaPanelComponent.toggle();
        });
      }
      if (!this.numeroRapporto) {
        this.venditaPageService.censisciDaInformativa(this.idProposal).subscribe(data => {
          console.log(data);
        }, err => {
          // chiudiamo accordion fidi e garanzie
          this.fidiGranziaPanelComponent.toggle();
        });
      }
    }
    this.venditaCommonService.setSimulationData(this.simulationData);
  }

  getPraticaId(bookingId: string) {
    this.pefService.getRisultatoCreazioneNuovaPratica(this.idProposal, bookingId).subscribe(data => {
      if (!data) {
        this.getPraticaId(bookingId);
      } else {
        this.praticaId = data;
        this.garanzieExpansion = true;
      }
    }, err => {
      this.bookingId = null;
      // chiudiamo accordion fidi e garanzie
      this.fidiGranziaPanelComponent.toggle();
    });
  }

  garanzieFlagSet(garanzieFlag: boolean) {
    this.garanzieFlag = garanzieFlag;
    this.calculateFidiGaranzieCompletion();
  }

  preFinFlagSet(preFinFlag: boolean) {
    this.preFinFlag = preFinFlag;
    this.calculateFidiGaranzieCompletion();
  }

  consensoFlagSet(valid: boolean) {
    this.consensoFlag = valid;
    this.calculateFidiGaranzieCompletion();
  }

  formaFlagSet(data: any) {
    this.formaFlag = data;
  }

  formaTecnicaFlagSet(formaTecnicaFlag: boolean) {
    this.formaTecnicaFlag = formaTecnicaFlag;
    this.calculateFidiGaranzieCompletion();
  }

  altreBancheFlagSet(valid: boolean) {
    this.altreBancheFlag = valid;
    this.calculateFidiGaranzieCompletion();
  }

  saveConsensoSic(consensoList: InputConsensoVm[]) {
    this.consensoSicList = consensoList;
  }

  saveFormaTecnica(formaTecnica: string) {
    this.formaTecnica = formaTecnica;
  }

  // il buttone Raccogli firme non esiste piu,  quindi il metodo onFirmaButtonClick viene chiamato automaticamente dal metodo submitData
  onFirmaButtonClick() {
    const succesFunction = function () {
      this.commonService.saveContrattiInputInSession(this.generateDoc).subscribe((result: any) => {
        const signatureStatus = new SignatureStatusModel();
        signatureStatus.processId = this.idProposal;
        signatureStatus.processType = TipoProcesso.VENDITA;
        signatureStatus.docToGenerate = [FinDocumentType.RICHIESTA_PRESTITO];
        this.redirectService.redirectWithSpinner(this.endpointsService.openContratti
          + '/' + encodeURIComponent(JSON.stringify(signatureStatus)));
      });

    };
    if (!this.generateDoc) {
      this.venditaFetchDocumentVm = {
        'inputPrefinanziamentoVm': this.prefinanziamentoModel,
        'garanzieInRichiestaList': this.guaranteeList,
        'inputFormaTechnicaVm': {
          formaTecnicaDesc: this.formaTecnica.description,
          formaTecnicaValue: this.formaTecnica.value
        },
        'proposalId': this.idProposal.toString(),
        'ndg': this.mainNdg,
        'allClientList': this.clientBaseList,
        'pefId': this.praticaId,
        'inputConsensoVm': this.consensoSicList
      };

      this.pefService.getGenerateDocVm(this.venditaFetchDocumentVm).subscribe(result => {
        this.generateDoc = result;
        succesFunction.apply(this);
      });
    } else {
      if (!this.generateDoc.documentList[0].signers || this.generateDoc.documentList[0].signers.length === 0) {
        const pfClients = this.clientBaseList.filter(client => !client.cointestazione);
        this.generateDoc.documentList[0].signers = pfClients;
      }
      if (!this.generateDoc.paramsGenerateEndpoint.clientList || this.generateDoc.paramsGenerateEndpoint.clientList.length === 0) {
        this.generateDoc.paramsGenerateEndpoint.clientList = this.clientBaseList;
      }
      succesFunction.apply(this);
    }
  }

  resetVenditaPage() {
    this.fidiGaranzieSaved = false;
    this.fidiGranziaPanelComponent.toggle();
    this.bookingId = null;
    this.praticaId = null;
    this.dataChiamataCentraleRischi = null;
    this.richiestaFinanziamentoSigned = false;
    this.fidiGranziaPanelComponent.toggle();
  }

  goToImmobiliPage() {
    this.commonService.updateProposalStep(this.idProposal.toString(), MortgageStepWizard.TWO).subscribe(result => {
      if (result) {
        this.router.navigate(['/immobili', this.idProposal]);
      }
    });
  }

  private checkSignatureStatus(flagCentraleRischi: boolean) {
    const data = <SignatureStatusModel>{
      processId: this.idProposal,
      processType: TipoProcesso.VENDITA,
      docToGenerate: [FinDocumentType.RICHIESTA_PRESTITO]
    };
    this.commonService.checkSignatureStatus(data).subscribe(signed => {
      if (signed) {
        this.richiestaFinanziamentoSigned = true;
        if (flagCentraleRischi) {
          this.flagCentraleRischi = true;
        }
      }
    });
  }

  private getD2Answer() {
    this.venditaCommonService.getD2Answer(this.idProposal.toString()).subscribe(data => {
      this.venditaCommonService.setD2AnswerLocal(data);
    });
  }

  onDatiRedditualiCompletion(isCompleted: boolean) {
    this.isDatiRedditualiCompleted = isCompleted;
  }

  modificaPopup() {
    const dialogRef = this.dialogservice.open(ModificaPropostaPopupComponent, {
      data: { idProposal: this.idProposal },
      noCloseButton: true,
      size: 'large'
    }
    );
  }

  checkDatiAnagrafiStatus(isComplted: boolean) {
    this.isDatiAnagrafiCompleted = isComplted;
  }

  checkDaCariCareStatus(isCompleted: boolean) {
    this.isDaCariCareCompleted = isCompleted;
  }

  checkMutuoDocs(isCompleted: boolean) {
    this.isMutuoDocsCompleted = isCompleted;
  }

  ngAfterViewChecked() {
    this.cdr.detectChanges();
  }

  private calculateFidiGaranzieCompletion() {
    this.fidiGaranzieCompleted = this.allIdsValid() && this.allSectionValid();
  }

  private allIdsValid() {
    return this.praticaId;
  }

  private allSectionValid(): boolean {
    return this.formaTecnicaFlag && this.preFinFlag && this.garanzieFlag && this.consensoFlag && this.altreBancheFlag;
  }

}
