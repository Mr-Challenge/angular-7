import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, HostListener, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DialogService, RedirectService } from 'bstore-angular-library';
import { MortgageClientRoles } from 'src/app/constant/mortgageClientRoles';
import { CustomerData } from 'src/app/models/customerData';
import { DatiAnagrafiService } from 'src/app/modules/vendita/services/dati-anagrafi.service';
import { EndpointsService } from 'src/app/services/endpoints.service';
import { BaseFidiGaranzieSectionComponent } from '../base-fidi-garanzie-section/base-fidi-garanzie-section.component';

@Component({
  selector: 'bst-fin-garanti',
  templateUrl: './garanti.component.html',
  styleUrls: ['./garanti.component.scss'],
  animations: [
    trigger('scrollAnimation', [
      state('show', style({
        opacity: 1,
        display: 'block',
        transform: 'translate3d(0, 0, 0)'
      })),
      state('hide', style({
        opacity: 0,
        display: 'none',
        transform: 'translate3d(0, -100%, 0)'
      })),
      transition('show => hide', animate('200ms ease-out')),
      transition('hide => show', animate('200ms ease-in'))
    ])
  ]
})
export class GarantiComponent extends BaseFidiGaranzieSectionComponent implements OnInit {

  @Input() GARClientRole: any[];
  result: CustomerData;
  resultArr: CustomerData[];
  state = 'show';
  prevScrollpos = window.pageYOffset;
  iconFlagOK: boolean;
  dispFlag: boolean;
  idProposal: string;
  ndgList: string;

  constructor(protected dialog: DialogService, private datiAnagrafiService: DatiAnagrafiService,
    private route: ActivatedRoute, private endpointsService: EndpointsService, private redirectService: RedirectService) {
    super(dialog);
    this.resultArr = [];
    this.iconFlagOK = true;
    this.ndgList = '';
    this.route.queryParams.subscribe(params => {
      this.idProposal = params['idProposal'];
    });
  }

  ngOnInit() {
    this.datiAnagrafiService.getNdgList().subscribe(response => {
      this.ndgList = response;
    });
    this.getClientRole(this.GARClientRole);
    console.log(this.GARClientRole);


  }
  getClientRole(GARClientRole) {
    GARClientRole.forEach(x => {
      this.resultArr.push(x);
      this.checkIconFlag(this.resultArr);
    });

    if (this.resultArr) {
      this.resultArr.forEach(data => {
        if (this.ndgList === '') {
          this.ndgList = data.ndg ? data.ndg : '';
        } else {
          this.ndgList += '_' + (data.ndg ? data.ndg : '');
        }
      });
    }
    this.datiAnagrafiService.setNdgList(this.ndgList);

  }

  checkIconFlag(data) {
    const dataArr = data[0];
    if (dataArr) {
      this.dispFlag = true;
      if (!dataArr.complete) {
        this.datiAnagrafiService.iconFlagStato = false;
      }
    } else {
      this.dispFlag = false;
    }
  }

  deleteGaranti(ndg, idProposal) {
    this.checkForPopUp().then(() => {
      this.datiAnagrafiService.deleteClientBYType(ndg, idProposal, MortgageClientRoles.GARANTI)
        .subscribe(() => this.redirectService.reloadWithSpinner());
    });
  }

  // Start for task 1328
  showSearchBox() {
    // insert and redirect to url
    this.checkForPopUp().then(() => {
      const x = {
        'idProposta': this.idProposal,
        'showSearchBox': true,
        'newClient': true,
        'ndgList': this.ndgList,
        'duplicateMortgageMessage': 'L\'intestatario del mutuo non puo\' assumere il ruolo di garante',
        'callbackurl': this.endpointsService.saveNewClientByRole + '?idProposal=' + this.idProposal + '&role=GAR'
      };
      // console.log(JSON.stringify(x));
      // const y = JSON.stringify(x);
      // const parsed = JSON.parse(y);
      // console.log(parsed.showSearchBox + ' ' + typeof parsed.showSearchBox);

      // Workaround to bybass apache urls restrictions (must not contains encoded \ or / into the path part, but allowed as fragment)
      const callbackurl = x.callbackurl;
      x.callbackurl = null;

      // tslint:disable-next-line: max-line-length
      this.redirectService.redirectWithSpinner(this.endpointsService.censimentoPrivati + '/' + encodeURIComponent(JSON.stringify(x)) + '#' + callbackurl);
    });
  }

  redirectToCensimentoConfiguraPersona(ndg) {
    // redirect to url
    // alert('config persona NDG= '+ndg);
    const x = {
      'ndg': ndg,
      'idProposta': this.idProposal,
      'showSearchBox': false,
      'newClient': false,
      'callbackurl': this.endpointsService.returnFromAnagrafeChanges + '?idProposal=' + this.idProposal

    };

    // Workaround to bybass apache urls restrictions (must not contains encoded \ or / into the path part, but allowed as fragment)
    const callbackurl = x.callbackurl;
    x.callbackurl = null;

    // tslint:disable-next-line: max-line-length
    this.redirectService.redirectWithSpinner(this.endpointsService.censimentoPrivati + '/' + encodeURIComponent(JSON.stringify(x)) + '#' + callbackurl);
  }

  // end for task 1328
  @HostListener('window:scroll', ['$event'])
  checkScroll() {
    const currentScrollPos = window.pageYOffset;
    if (this.prevScrollpos >= currentScrollPos) {
      this.state = 'show';
    } else {
      this.state = 'hide';
    }
  }


}
