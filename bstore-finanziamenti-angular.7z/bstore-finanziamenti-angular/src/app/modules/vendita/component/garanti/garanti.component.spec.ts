import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GarantiComponent } from './garanti.component';

describe('GarantiComponent', () => {
  let component: GarantiComponent;
  let fixture: ComponentFixture<GarantiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GarantiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GarantiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
