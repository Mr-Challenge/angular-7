import { Component, OnInit, ViewChild, ChangeDetectorRef, Input, AfterViewInit, Output, EventEmitter } from '@angular/core';
import { SicContentDetails } from 'src/app/models/SicContentDetails';
import { NgForm } from '@angular/forms';
import { PageBehaviourPopUpComponent } from '../page-behaviour-pop-up/page-behaviour-pop-up.component';
import { DialogService } from 'bstore-angular-library';
import { SicContentComponent } from '../sic-content/sic-content.component';
import { InputConsensoVm } from '../../models/input-consenso-vm.model';
import { AngularWaitBarrier } from 'blocking-proxy/built/lib/angular_wait_barrier';
import { BaseFidiGaranzieSectionComponent } from '../base-fidi-garanzie-section/base-fidi-garanzie-section.component';

@Component({
  selector: 'bst-fin-consenso-sic',
  templateUrl: './consenso-sic.component.html',
  styleUrls: ['./consenso-sic.component.scss']
})
export class ConsensoSicComponent extends BaseFidiGaranzieSectionComponent implements OnInit, AfterViewInit {

  @Input() GARClientRole: any;
  @Input() INTClientRole: any;
  @Input() TERClientRole: any;
  @Input() consensoSicList: Array<InputConsensoVm>;
  @Input() chirografarioFlag: boolean;

  @Output() consensoResponse = new EventEmitter<any>();

  @ViewChild('sicContentForm') public sicContentForm: NgForm;
  @ViewChild(SicContentComponent) public sicContentChild: SicContentComponent;
  consisoSicGAR: any = [];
  consisoSicTER: any = [];
  consisoSicINT: any = [];
  sicContentDetails: SicContentDetails[];
  consensoIsValid: boolean;
  consensoCount = 0;
  constructor(
    private cdr: ChangeDetectorRef,
    protected dialog: DialogService) {
    super(dialog);
  }

  ngOnInit() {

    this.TERClientRole = this.TERClientRole ? this.TERClientRole : [];
    this.GARClientRole = this.GARClientRole ? this.GARClientRole : [];
    this.INTClientRole = this.INTClientRole ? this.INTClientRole.filter(this.isNotJoinHolder) : [];
    this.consensoCount = this.TERClientRole.length + this.GARClientRole.length + this.INTClientRole.length;

    if(this.consensoSicList){
      this.consensoSicList.forEach((consenso, index) => {

        let ter: boolean;
        this.TERClientRole.forEach(terClient => {
          if (terClient.ndg == consenso.ndg) {
            ter = true;
            return;
          }
        });

        let gar: boolean;
        this.GARClientRole.forEach(garClient => {
          if (garClient.ndg == consenso.ndg) {
            gar = true;
            return;
          }
        });


        let int: boolean;
        this.INTClientRole.forEach(intClient => {
          if (intClient.ndg == consenso.ndg) {
            int = true;
            return;
          }
        });

        if (ter) {
          this.consisoSicTER.push(consenso);
        } else if (gar) {
          this.consisoSicGAR.push(consenso);
        } else if (int) {
          this.consisoSicINT.push(consenso);
        } else {
          this.consensoSicList.splice(index, 1);
        }

      });
    }

    this.consensoIsValid = this.validateSection(this.consensoSicList ? this.consensoSicList : []);
    this.sectionValid.emit(this.consensoIsValid);
  }


  isNotJoinHolder(element, index, array) {
    return (element.cointestazione === false);
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

  consensoClicked(role: string, consenso: { consensoList: any; rollBack: () => void; }) {
    this.checkForPopUp().then(() => {
      if (role === 'consisoSicGAR') {
        this.consisoSicGAR = consenso.consensoList;
      } else if (role === 'consisoSicINT') {
        this.consisoSicINT = consenso.consensoList;
      } else {
        this.consisoSicTER = consenso.consensoList;
      }
      const consisoSic = [...this.consisoSicGAR, ...this.consisoSicINT, ...this.consisoSicTER];

      if (this.validateSection(consisoSic)) {
        this.consensoIsValid = true;
        this.consensoResponse.emit(consisoSic);
        this.sectionValid.emit(true);
      } else {
        this.consensoIsValid = false;
        this.sectionValid.emit(false);
      }
    }, () => {
      consenso.rollBack();
    });

  }


  private validateSection(consisoSic: any[]): boolean {
    let count = 0;
    consisoSic.forEach(element => {
      if (element.consensoRoccolto !== null) {
        count++;
      }
    });
    return count === this.consensoCount;
  }
  //   if(this.saveButtonClicked === true) {
  //   this.sicContentChild.resetValue();
  // }
}
