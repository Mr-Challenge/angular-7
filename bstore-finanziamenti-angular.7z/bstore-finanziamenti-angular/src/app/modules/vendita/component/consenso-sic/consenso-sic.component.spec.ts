import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsensoSicComponent } from './consenso-sic.component';

describe('ConsensoSicComponent', () => {
  let component: ConsensoSicComponent;
  let fixture: ComponentFixture<ConsensoSicComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsensoSicComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsensoSicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
