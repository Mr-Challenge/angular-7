import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TerzoDatoreComponent } from './terzo-datore.component';

describe('TerzoDatoreComponent', () => {
  let component: TerzoDatoreComponent;
  let fixture: ComponentFixture<TerzoDatoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TerzoDatoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TerzoDatoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
