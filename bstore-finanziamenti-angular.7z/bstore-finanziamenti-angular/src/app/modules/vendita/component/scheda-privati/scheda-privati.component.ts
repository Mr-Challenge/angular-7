import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'bst-fin-scheda-privati',
  templateUrl: './scheda-privati.component.html',
  styleUrls: ['./scheda-privati.component.scss']
})
export class SchedaPrivatiComponent implements OnInit {
  proposalId: any;
  domainName = environment.devUrlJSON['npv.service.callback.url'];
  constructor(private route: ActivatedRoute) {
    this.route.queryParams.subscribe(params => {
      this.proposalId = params['idProposal'];
    });
  }
  ngOnInit() {
  }

}
