import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';

@Component({
  selector: 'bst-fin-vendita-page',
  templateUrl: './vendita-page.component.html',
  styleUrls: ['./vendita-page.component.scss']
})
export class VenditaPageComponent implements OnInit {

  showIncomplete = true;

  constructor(public route: ActivatedRoute, private router: Router) {
    if (this.route.snapshot.paramMap.get('idProposal')) {
      const navigationExtras: NavigationExtras = {
        queryParams: { 'idProposal': this.route.snapshot.paramMap.get('idProposal') }
      };
      this.router.navigate(['vendita'], navigationExtras);
    }
  }

  ngOnInit() {
  }

}
