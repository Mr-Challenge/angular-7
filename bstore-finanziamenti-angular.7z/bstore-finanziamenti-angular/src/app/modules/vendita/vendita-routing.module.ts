import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { VenditaPageComponent } from './pages/vendita-page/vendita-page.component';
import { AltreBancheNewBankBoxComponent } from './component/altre-banche-section/altre-banche-new-bank-box/altre-banche-new-bank-box.component';
import { VisualizzaGaranziaComponent } from './component/garanzie/visualizza-garanzia/visualizza-garanzia.component';
import { VenditaComponent } from './component/vendita/vendita.component';
import { SchedaPrivatiComponent } from './component/scheda-privati/scheda-privati.component';
import { AddVisualizzaGaranziaComponent } from './component/garanzie/add-visualizza-garanzia/add-visualizza-garanzia.component';
import { LoadDocumentiSectionComponent } from './component/documenti-da-caricare/load-documenti-section/load-documenti-section.component';
import { LoadMutuoDocumentiSectionComponent } from './component/documenti-da-caricare/load-mutuo-documenti-section/load-mutuo-documenti-section.component';

// const routes: Routes = [
//   { path: '', component: VenditaComponent },
//   { path: ':proposalId', component: VenditaComponent },
//   { path: 'newbankpage', component: AltreBancheNewBankBoxComponent },
//   { path: 'visualizza-garanzia', component: VisualizzaGaranziaComponent },
//   { path: 'load-documenti-section', component: LoadDocumentiSectionComponent },
//   { path: 'SchedaPrivati', component: SchedaPrivatiComponent },
//   { path: 'SchedaPrivati/:subpath1', component: SchedaPrivatiComponent },
//   { path: 'SchedaPrivati/:subpath1/:subpath2', component: SchedaPrivatiComponent }
// ];

const routes: Routes = [
  {
    path: '',
    component: VenditaPageComponent,
    children: [
      {
        path: 'visualizza-garanzia',
        component: VisualizzaGaranziaComponent
      },
      {
        path: 'add-visualizza-garanzia',
        component: AddVisualizzaGaranziaComponent
      },
      {
        path: 'newbankpage',
        component: AltreBancheNewBankBoxComponent
      },
      {
        path: 'load-documenti-section',
        component: LoadDocumentiSectionComponent
      },
      {
        path: 'load-mutuo-documenti-section',
        component: LoadMutuoDocumentiSectionComponent
      },
      {
        path: 'SchedaPrivati',
        component: SchedaPrivatiComponent
      },
      {
        path: 'SchedaPrivati/:subpath1',
        component: SchedaPrivatiComponent
      },
      {
        path: 'SchedaPrivati/:subpath1/:subpath2',
        component: SchedaPrivatiComponent
      }
    ]
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VenditaRoutingModule { }
