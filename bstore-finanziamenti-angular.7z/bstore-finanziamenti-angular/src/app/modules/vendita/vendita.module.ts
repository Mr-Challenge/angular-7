import { NgModule, APP_ID } from '@angular/core';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { VenditaRoutingModule } from './vendita-routing.module';
import { AltreBancheSectionComponent } from './component/altre-banche-section/altre-banche-section.component';
import { FormaTecnicaSectionComponent } from './component/forma-tecnica-section/forma-tecnica-section.component';
import { BstoreCommonModule } from '../bstore-common/bstore-common.module';
import { VenditaPageComponent } from './pages/vendita-page/vendita-page.component';
import { PreFinanziamentoComponent } from './component/pre-finanziamento/pre-finanziamento.component';
import { AltreBancheNewBankBoxComponent } from './component/altre-banche-section/altre-banche-new-bank-box/altre-banche-new-bank-box.component';
import { DatiRedditualiSectionComponent } from './component/dati-reddituali-section/dati-reddituali-section.component';
import { GaranzieComponent } from './component/garanzie/garanzie.component';
import { FormsModule } from '@angular/forms';
import { VisualizzaGaranziaComponent } from './component/garanzie/visualizza-garanzia/visualizza-garanzia.component';
import { VenditaComponent } from './component/vendita/vendita.component';
import { ConsensoSicComponent } from './component/consenso-sic/consenso-sic.component';
import { SicContentComponent } from './component/sic-content/sic-content.component';
import { DocumentiDaCaricareComponent } from './component/documenti-da-caricare/documenti-da-caricare.component';
// import { ExtracomunitariComponent } from './component/extracomunitari/extracomunitari.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { SchedaPrivatiIntegrationService } from './services/scheda-privati-integration.service';
import { PrivateCardComponent } from './component/private-card/private-card.component';
import { SchedaPrivatiComponent } from './component/scheda-privati/scheda-privati.component';
import { DatiAnagrafiComponent } from './component/dati-anagrafi/dati-anagrafi.component';
import { TabsComponent } from './component/tabs/tabs.component';
import { CustDetailsComponent } from './component/cust-details/cust-details.component';
import { GarantiComponent } from './component/garanti/garanti.component';
import { TerzoDatoreComponent } from './component/terzo-datore/terzo-datore.component';
import { AddVisualizzaGaranziaComponent } from './component/garanzie/add-visualizza-garanzia/add-visualizza-garanzia.component';
import { LoadDocumentiSectionComponent } from './component/documenti-da-caricare/load-documenti-section/load-documenti-section.component';
import { DocumentiSogettiComponent } from './component/documenti-da-caricare/documenti-sogetti/documenti-sogetti.component';
import { PageBehaviourPopUpComponent } from './component/page-behaviour-pop-up/page-behaviour-pop-up.component';
import { DocumentiDiMutuoComponent } from './component/documenti-da-caricare/documenti-di-mutuo/documenti-di-mutuo.component';
import { LoadMutuoDocumentiSectionComponent } from './component/documenti-da-caricare/load-mutuo-documenti-section/load-mutuo-documenti-section.component';
import { BaseFidiGaranzieSectionComponent } from './component/base-fidi-garanzie-section/base-fidi-garanzie-section.component';
import { BaseDocumentiSectionComponent } from './component/documenti-da-caricare/base-documenti-section/base-documenti-section.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';


@NgModule({
  declarations: [AltreBancheSectionComponent,
    FormaTecnicaSectionComponent,
    VenditaPageComponent,
    PreFinanziamentoComponent,
    AltreBancheNewBankBoxComponent,
    GaranzieComponent,
    DatiRedditualiSectionComponent,
    VisualizzaGaranziaComponent,
    VenditaComponent,
    ConsensoSicComponent,
    SicContentComponent,
    DocumentiSogettiComponent,
    DocumentiDaCaricareComponent,
    PrivateCardComponent,
    SchedaPrivatiComponent,
    LoadDocumentiSectionComponent,
    DatiAnagrafiComponent,
    TabsComponent,
    CustDetailsComponent,
    GarantiComponent,
    TerzoDatoreComponent,
    AddVisualizzaGaranziaComponent,
    DocumentiDiMutuoComponent,
    LoadMutuoDocumentiSectionComponent,
    BaseFidiGaranzieSectionComponent,
    BaseDocumentiSectionComponent
  ],
  imports: [
    BstoreCommonModule,
    VenditaRoutingModule,
    CommonModule,
    FormsModule,
    NgMultiSelectDropDownModule.forRoot()
  ],
  providers: [
    SchedaPrivatiIntegrationService,
    {

      provide: APP_BASE_HREF,
      useFactory: () => window[`bstoreAppPath`] || null
    }
  ],
  entryComponents: [
    PrivateCardComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VenditaModule { }
