export interface ContoCorrenteDetailsModel {
    formaTecnica: string;
    number: string;
    filiale: string;
}
