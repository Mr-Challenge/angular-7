import { GuaranteesModel } from './guarantees.model';

export interface InputGaranzieListVm {
    listaGaranzie: Array<GuaranteesModel>;
}
