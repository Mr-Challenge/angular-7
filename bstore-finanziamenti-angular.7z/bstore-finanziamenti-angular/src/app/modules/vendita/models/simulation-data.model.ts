export interface SimulationDataModel {
    amount: string;
    durata: string;
    perimeter: string;
    idProdotto: number;
    macroCategory: string;
    idIntervista: number;
    unsecuredLoan: boolean;
}
