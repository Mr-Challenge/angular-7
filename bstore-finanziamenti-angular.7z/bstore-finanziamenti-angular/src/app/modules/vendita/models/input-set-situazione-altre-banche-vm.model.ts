import { AltreBancheModel } from './altre-banche.model';

export interface InputSetSituazioneAltreBancheVm {
    numeroPratica: string;
    numeroElementiTotale: number;
    listaRapportiAltreBanche: Array<AltreBancheModel>;
}
