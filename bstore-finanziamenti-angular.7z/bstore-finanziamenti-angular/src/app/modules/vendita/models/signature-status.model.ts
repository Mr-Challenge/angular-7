import { ContrattiDocument } from "src/app/models/contrattiDocument";


export class SignatureStatusModel {
    processId: number;
    processType: string;
    docToGenerate: Array<string> = [];
    documents: ContrattiDocument[];
}
