export class UpdateDocsModel {
    filenetId: string;
    idProposta: string;
}