export interface GaranteGaranzia {
  intestazioneGarante: string;
  ndgGarante: string;
}
