export interface InputFormaTecnica {
  formaTecnicaDesc: string;
  formaTecnicaValue: string;
}
