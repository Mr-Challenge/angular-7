export interface InterviewResult {
    questionId: string;
    question: string;
    answerId: string;
    answer: string;
}
export interface InterviewResponse {
    interview: string;
    type: string;
}
