export interface AltreBancheModel {
  denominazioneBanca: string;
  importoAutoliquidante: string;
  importoScadenzaBT: string;
  importoScadenzaMT: string;
  importoRevoca: string;
  importoSofferenza: string;
  importoProcedureConcorsuali: string;
  importoFirmaCommerciale: string;
  importoFirmaFinanziaria: string;
  totaleBanca: string;
}
