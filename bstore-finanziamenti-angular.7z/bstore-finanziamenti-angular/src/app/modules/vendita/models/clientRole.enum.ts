export enum ClientRole {
    // ORDINE IMPORANTE per compareTo()
    // 0
    INTESTATARIO_PRINCIPALE = ('Intestatario principale'),
    // 1
    INT = ('Intestatario'),
    // 2
    DEL = ('Delegato'),
    // 3
    GAR = ('Garante'),
    // 4
    PAP = ('Patria potestà'),
    // 5
    TUT = ('Tutore'),
    // 6
    USU = ('Usufruttuario'),

    // RUOLI CLIENT AGGIUNTI PER LA #9904
    TU = ('TU'),
    PT = ('PT'),
    AS = ('AS'),
    CU = ('CU'),

    // RUOLI PER GESTIONE PROPOSTE CORPORATE
    TIT = ('Titolare'),
    TER = ('Terzo datore ipoteca')
}

