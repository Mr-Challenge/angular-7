import { GaranteGaranzia } from './garante-garanzia.model';

export interface GuaranteesModel {

  numeroGaranzia?: string;
  numeroRapporto?: string;
  importo?: string;
  descrizioneEstesa?: string;
  tipo?: string;
  durata?: string;
  duration?: string;
  percentualeIpoteca?: string;
  importoMutuo?: string;
  atto?: string;
  selectedGuarantee?: boolean;
  descrizioneCodice?: string;
  garanteNdg?: string;
  garantiList?: GaranteGaranzia[];
  intestazione?: string;
  flagEstendibile: boolean;
  garanteObbligatorio?: boolean;
  disabled: boolean;
  garanzieNo: number;
  ndgIntestazione: string;
  inAttoFlag: string;
  uniqueId: number; // creato ed utilizzato per identificare le singole garanzie nelle le logiche di generare il contratto fideiussione
  defaultGuarantees: boolean;
}
