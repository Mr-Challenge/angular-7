export interface InputConsensoVm {
  consensoRoccolto: boolean;
  name: string;
  ndg: string;
  consensoType: string;
  birthDate?: string;
}
