import { GuaranteesModel } from './guarantees.model';
import { BaseClientModel } from '../../product-configuration/models/BaseClientModel';

export interface GaranzieGaranti {
  garanzia: GuaranteesModel;
  garanti: BaseClientModel[]
}
