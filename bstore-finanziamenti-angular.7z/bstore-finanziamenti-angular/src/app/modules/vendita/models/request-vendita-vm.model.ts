import { InputSetSituazioneAltreBancheVm } from './input-set-situazione-altre-banche-vm.model';
import { InputConsensoVm } from './input-consenso-vm.model';
import { InputGaranzieListVm } from './input-garanzie-list-vm.model';
import { InputFormaTecnica } from './input-forma-tecnica.model';
import { InputSimulazione } from '../../../models/input-simulazione.model';
import { GuaranteesModel } from './guarantees.model';
export interface RequestVenditaVm {
    inputSetSituazioneAltreBancheVm: InputSetSituazioneAltreBancheVm;
    inputConsensoVm: Array<InputConsensoVm>;
    garanzieInRichiestaList: Array<GuaranteesModel>;
    inputFormaTechnicaVm: InputFormaTecnica;
    inputPrefinanziamentoVm: any;
    proposalId: string;
    ndg: string;
    allClientList: any;
    pefId: string;
}
