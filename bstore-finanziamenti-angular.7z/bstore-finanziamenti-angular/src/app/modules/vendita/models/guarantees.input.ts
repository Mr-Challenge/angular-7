export class GuaranteesInputModel {

    ndgList?: string[];
    numeraPratica: string;
    idProdotto: number;
    techniciaCode: string;
    proposalId: number;
}
