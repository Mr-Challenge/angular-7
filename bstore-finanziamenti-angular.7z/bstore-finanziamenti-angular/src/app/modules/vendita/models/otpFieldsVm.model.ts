export class OtpFieldsVm {
    email: string;
    mobilePhone: string;
    otpFieldsComplete: boolean;
}