import { AltreBancheModel } from './altre-banche.model';
import { GuaranteesModel } from './guarantees.model';
import { InputConsensoVm } from './input-consenso-vm.model';
import { InputFormaTecnica } from './input-forma-tecnica.model';
import { PrefinanziamentoModel } from './prefinanziamento.model';
export interface VenditaPageVm {
  listaRapportiAltreBanche: Array<AltreBancheModel>;
  inputConsensoVm: Array<InputConsensoVm>;
  inputFormaTechnicaVm: InputFormaTecnica;
  inputPrefinanziamentoVm: PrefinanziamentoModel;
  proposalId: string;
  ndg: string;
  pefId: string;
  codiceFormaTecnica: string;
  altreBancheFlag: boolean;
  guaranteeList: Array<GuaranteesModel>;
  dataChiamataCentraleRischi: Date;
}
