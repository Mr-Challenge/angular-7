export class QueryWrapper {
    query: string;
    pageLimit: string;
    searchType: string;
    idPorposta: string;
    birthDate: string;
    NDG: number;
}