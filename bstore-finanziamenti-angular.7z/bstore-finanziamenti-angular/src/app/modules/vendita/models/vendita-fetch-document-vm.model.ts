import { BaseClientModel } from '../../product-configuration/models/BaseClientModel';
import { GuaranteesModel } from './guarantees.model';
import { InputConsensoVm } from './input-consenso-vm.model';
import { InputFormaTecnica } from './input-forma-tecnica.model';
import { PrefinanziamentoModel } from './prefinanziamento.model';
export interface VenditaFetchDocumentVm {
    inputFormaTechnicaVm: InputFormaTecnica;
    inputPrefinanziamentoVm: PrefinanziamentoModel;
    proposalId: string;
    ndg: string;
    pefId: string;
    garanzieInRichiestaList: Array<GuaranteesModel>;
    allClientList: Array<BaseClientModel>;
    inputConsensoVm: Array<InputConsensoVm>;
}
