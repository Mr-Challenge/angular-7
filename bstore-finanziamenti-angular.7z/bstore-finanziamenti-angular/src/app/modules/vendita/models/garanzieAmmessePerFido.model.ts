export class GaranzieAmmessePerFidoModel{
    codice?:string;
    garanteObbligatorio?:boolean;
}