export interface TipoResponseModel {
    tippoDescriptionMap: any;
    
}
