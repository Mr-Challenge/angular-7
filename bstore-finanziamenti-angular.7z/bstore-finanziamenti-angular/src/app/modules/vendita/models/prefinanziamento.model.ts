export class PrefinanziamentoModel {
    prefinanziamentoFlag?: boolean;
    importoValue?: string;
    durataValue?: string;
    tipoConto?: string;
    accountNumber?: string;
    accountBranch?: string;
}
