export class D2AnswerVm {
    surroga: boolean;
    acquisto: boolean;
    sostituzione: boolean;
}