export class InternalDataBanksModel {
    officialRating: string;
    performanceRating: string;
    previousChecksFiled: string;
    practiceInProgress: string;
}
