export class BaseClientModel {
	ndg: string;
	name: string;
	surname: string;
	complete: boolean;
	role: string;
	cointestazione: boolean;
	controllato: boolean;
	birthDate: string;
	abi: string;
	email: string;
	phone: string;
	jointNdgs: string[];
	status: string;
	emailOtp: string;
	phoneOtp: string;
}
