import { CodeDescription } from 'src/app/modules/product-configuration/models/CodeDescription';
export class CreditLineModel {
    numeroRapporto: string;
    type: string;
    holder: CodeDescription;
    remainingDebt: string;
    numeroFido: string;
    suffissoFido: string;
    codiceFormaTecnica: string;
    identificativoUnivoco: string;
}