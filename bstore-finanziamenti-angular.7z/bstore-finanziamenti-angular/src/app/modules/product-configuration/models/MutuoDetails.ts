export interface MutuoDetails {
    preSalesAmount: string;
    appraisalAmount: string;
    showFirstHome: boolean;
    showLiquidity: boolean;
    residentialProperties: string;
    showNonResidentialProperties: boolean;
    valoreImmobile: string;
    usoAbitativo: string;
    collectedSurveyJSON: string;
    codiciImmobiliAssociati: number[];
    codiceSimulazioneDesk: number;
    esigenza: string;
    finalitaSpecifica: string;
    maxAmount: number;
}
