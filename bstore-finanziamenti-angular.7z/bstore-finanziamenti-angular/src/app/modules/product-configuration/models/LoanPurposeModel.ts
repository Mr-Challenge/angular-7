import { SelectOptionModel } from 'bstore-angular-library/lib/models/select-option-model';

export class LoanPurposeModel implements SelectOptionModel{

     remodulation : boolean;
     description: string;
     value?: string;
     descrizioneEscape:String;

}

