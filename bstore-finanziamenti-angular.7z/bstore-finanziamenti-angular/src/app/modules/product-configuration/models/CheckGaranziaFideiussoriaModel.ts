import { GaranziaFideiussoriaInAttoFuoriAttoModel } from './GaranziaFideiussoriaInAttoFuoriAttoModel';

export class CheckGaranziaFideiussoriaModel {
    hasGaranziaFideiussoria: boolean;
    listaGaranzieFideiussorie: GaranziaFideiussoriaInAttoFuoriAttoModel[];
    listaGaranzieNonFideiussorie: GaranziaFideiussoriaInAttoFuoriAttoModel[];
}