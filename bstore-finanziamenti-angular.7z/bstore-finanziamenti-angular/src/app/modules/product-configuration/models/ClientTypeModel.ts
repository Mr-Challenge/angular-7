import { BaseClientModel } from './BaseClientModel';
import { ClientRole } from 'src/app/models/clientRole.enum';

export class ClientTypeModel {
    proposalId: String;
    clientRoleStr: Map<ClientRole, BaseClientModel[]>;
}
