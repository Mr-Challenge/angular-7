import { GaranteGaranzia } from '../../vendita/models/garante-garanzia.model';

export class GaranziaFideiussoriaInAttoFuoriAttoModel {
  fideiussoriaInAtto: boolean;
  descrizioneEstesa: string;
  garantiList: GaranteGaranzia[]

}
