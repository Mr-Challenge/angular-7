export class ProponenteModel{
    pefProposalId:number;
	proposalId:number;
    proponenteId:string;
    ruoloProponente:string;
    codRuolo:string;
}