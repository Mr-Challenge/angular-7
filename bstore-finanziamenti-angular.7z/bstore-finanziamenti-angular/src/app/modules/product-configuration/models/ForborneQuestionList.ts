export class ForborneQuestionList {
    praticaId: number;
    difficoltàFinanziaria: Boolean;
    concessionConcession: Boolean;
    lineaForborne: Boolean;
    finalitàFinanziamento: String;
    notaForborne: String;
    loanEvent: String;
    dateEvent: String;
    ndgList: String[];
    suffisoFido: boolean;
    pefProposalId: number;
    documentId: String;
    fileNetId: String;
    rimodulazione: boolean;
    istruttoriaAvviata: boolean;
}