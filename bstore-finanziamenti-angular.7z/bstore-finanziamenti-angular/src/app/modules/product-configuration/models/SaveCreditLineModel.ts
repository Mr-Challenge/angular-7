import { CreditLineModel } from './CreditLineModel';

export class SaveCreditLineModel {
    idProdotto: number;
    listCreditLine: CreditLineModel[];
}