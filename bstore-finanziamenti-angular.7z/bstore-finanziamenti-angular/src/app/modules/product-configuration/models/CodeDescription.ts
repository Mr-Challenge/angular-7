export class CodeDescription{
    codice: string;
    descrizione: string;
}