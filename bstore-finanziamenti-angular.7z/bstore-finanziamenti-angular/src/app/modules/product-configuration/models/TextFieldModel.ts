export class TextFieldModel {
    name: string;
    value: string;
}