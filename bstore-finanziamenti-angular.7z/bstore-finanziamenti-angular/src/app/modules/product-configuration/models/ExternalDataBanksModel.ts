export class ExternalDataBanksModel {
    bankruptcyProceedings: string;
    nonPerformingLoans: string;
    sufferingStatusReports: string;
}
