export interface Proponent{
   ndg : string; 
   name : string; 
   branchManager:boolean;
   serialNumber : string; 
   selected:boolean;
   ruoloDescrizione:string;
   codRuolo:string;
}