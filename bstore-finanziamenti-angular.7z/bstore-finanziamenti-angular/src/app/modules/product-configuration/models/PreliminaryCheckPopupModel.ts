import { CreditPoliciesModel } from './CreditPoliciesModel';
import { ExternalDataBanksModel } from './ExternalDataBanksModel';
import { InternalDataBanksModel } from './InternalDataBanksModel';

export class PreliminaryCheckPopupModel {
    serviceModel: string;
    internalDataBanks: InternalDataBanksModel;
    externalDataBanks: ExternalDataBanksModel;
    creditPoliciesVm: CreditPoliciesModel;
}
