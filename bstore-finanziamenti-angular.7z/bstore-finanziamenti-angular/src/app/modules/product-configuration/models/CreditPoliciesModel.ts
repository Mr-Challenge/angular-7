export class CreditPoliciesModel {
    address: string;
    macroSegmentRisk: string;
    activityATECO: string;
    activity_ATECO_status: string;
    riskRange: string;
    riskRange_status: string;
    geographicalArea: string;
    sowTerget: string;
    maxMediumTermFee: string;
    sowCR: string;
    maxMediumTermFeeTotalSystem: string;
}
