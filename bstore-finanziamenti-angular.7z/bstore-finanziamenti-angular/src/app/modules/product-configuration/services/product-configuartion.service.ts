import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
import { CodeDescription } from 'src/app/models/codeDescription';
import { ForborneProponenteVm } from 'src/app/models/forborneProponenteVm.model';
import { EndpointsService } from '../../../services/endpoints.service';
import { CreditLineModel } from '../models/CreditLineModel';
import { ForborneQuestionList } from '../models/ForborneQuestionList';
import { LoanPurposeModel } from '../models/LoanPurposeModel';
import { MutuiDetailsModel } from '../models/MutuiDetailsModel';
import { MutuoDetails } from '../models/MutuoDetails';
import { PreliminaryCheckPopupModel } from '../models/PreliminaryCheckPopupModel';
import { Proponent } from '../models/Proponent';
import { ProponenteModel } from '../models/ProponenteModel';
import { SaveCreditLineModel } from '../models/SaveCreditLineModel';
import { GuaranteesInputModel } from '../../vendita/models/guarantees.input';
import { environment } from 'src/environments/environment';
import { NotificationVm } from 'src/app/models/notificationVm.model';
import { CheckGaranziaFideiussoriaModel } from '../models/CheckGaranziaFideiussoriaModel';
import { TextFieldModel } from '../models/TextFieldModel';


@Injectable({
  providedIn: 'root'
})
export class ProductConfiguartionService {

  constructor(private httpClient: HttpClient, private endpointsService: EndpointsService) { }

  private idPesf = new Subject<any>();
  private idProdottoCrLn = new Subject<any>();
  private dettagliMutuo = new Subject<MutuoDetails>();
  private fidiDaSost = new Subject<CreditLineModel[]>();
  private dettMutuoInPage = new Subject<TextFieldModel[]>();
  private notaRequired: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  public getCreditLineVm(idPef: string, idProposal: string): Observable<CreditLineModel[]> {
    const params = new HttpParams();
    const parameters = params.append('idPef', idPef).append('idProposal', idProposal);
    const url = this.endpointsService.listOfCreditLines;
    return this.httpClient.get<CreditLineModel[]>(url, { params: parameters });
  }



  public selectCodiceDescrizione() {
    return this.httpClient.get<CodeDescription[]>(this.endpointsService.selectCodiceDescrizione);
  }

  saveForborne(forborneList: ForborneQuestionList): Observable<ForborneQuestionList> {
    return this.httpClient.post<ForborneQuestionList>(this.endpointsService.saveForborneQuestion, forborneList);
  }

  public loadDettagliMutuo(proposalId: any, pefProposalId: any): Observable<MutuoDetails> {
    const params = new HttpParams();
    const parameters = params.append('proposalId', proposalId).append('pefProposalId', pefProposalId);
    return this.httpClient.get<MutuoDetails>(this.endpointsService.loadMutuoDetagliData, { params: parameters });
  }

  public getPreliminaryCheckValues(ndg: string, PEFProposalId: string): Observable<PreliminaryCheckPopupModel> {
    const params = new HttpParams();
    const parameters = params.append('ndg', ndg).append('PEFProposalId', PEFProposalId);
    return this.httpClient.get<PreliminaryCheckPopupModel>(this.endpointsService.getPreliminaryCheckValues, { params: parameters });
  }

  public retrieveNumeroRapportoMutuo(proposalId: string): Observable<string> {
    const params = new HttpParams();
    const parameters = params.append('idProposal', proposalId);
    const url = this.endpointsService.retrieveNumeroRapportoMutuo;
    return this.httpClient.get<string>(url, { params: parameters });
  }

  public setDettagliMutuo(dettaglioMutuo: MutuoDetails) {
    this.dettagliMutuo.next(dettaglioMutuo);
  }

  public getDettagliMutuo(): Observable<any> {
    return this.dettagliMutuo.asObservable();
  }

  public setFidiDaSostituire(fidi: CreditLineModel[]) {
    this.fidiDaSost.next(fidi);
  }

  public getFidiDaSostituire(): Observable<CreditLineModel[]> {
    return this.fidiDaSost.asObservable();
  }

  public setDettMutuoInPage(dettagli: TextFieldModel[]) {
    this.dettMutuoInPage.next(dettagli);
  }

  public getDettMutuoInPage(): Observable<TextFieldModel[]> {
    return this.dettMutuoInPage.asObservable();
  }

  public setIdpef(idPef: string) {
    this.idPesf.next(idPef);
  }

  public getIdpef(): Observable<any> {
    return this.idPesf.asObservable();
  }

  public setIdProdotto(idProdotto: number) {
    this.idProdottoCrLn.next(idProdotto);
  }

  public getIdProdotto(): Observable<any> {
    return this.idProdottoCrLn.asObservable();
  }

  public loadProponent(proposalId: string, PEFproposalId: string): Observable<Proponent[]> {
    const params = new HttpParams();
    const parameters = params.append('PEFproposalId', PEFproposalId).append('ProposalId', proposalId);
    const url = this.endpointsService.loadProponent;
    return this.httpClient.get<Proponent[]>(url, { params: parameters });
  }

  public saveProponent(proponenteModel: ProponenteModel): Observable<any> {
    return this.httpClient.post<any>(this.endpointsService.saveProponent, proponenteModel);
  }

  public changeProposalStatus(idProposal: string, proposalStatus: string, notaPratica: string, secondaNotaPef: string, idPef: string) {
    const params = {
      idProposal: idProposal,
      proposalStatus: proposalStatus,
      testoNota: notaPratica,
      secondaNotaPef: secondaNotaPef,
      idPef: idPef
    };
    return this.httpClient.post<any>(this.endpointsService.changeProposalStatus, params);
  }

  public updateMutuiDettagli(mutuiData: MutuiDetailsModel) {
    return this.httpClient.post<any>(this.endpointsService.saveMutuiDettagli, mutuiData);
  }

  public saveCreditLineVm(saveCreditLines: SaveCreditLineModel) {
    return this.httpClient.post<SaveCreditLineModel>(this.endpointsService.saveCreditLines, saveCreditLines);
  }

  public fetchCreditLineListByIdProdotto(idProdotto: string): Observable<SaveCreditLineModel> {
    const params = new HttpParams();
    const parameters = params.append('idProdotto', idProdotto);
    const url = this.endpointsService.fetchCreditLineListByIdProdotto;
    return this.httpClient.get<SaveCreditLineModel>(url, { params: parameters });
  }

  deleteForborneQuestionAndProponenteSRNO(forborneProponenteVm: ForborneProponenteVm): Observable<ForborneProponenteVm> {
    return this.httpClient.post<ForborneProponenteVm>(this.endpointsService.deleteForborneQuestionAndProponenteSRNO, forborneProponenteVm);
  }

  getGuarantees(guaranteesInputModel: GuaranteesInputModel) {
    return this.httpClient.post<any>
      (`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/getGuarantees`, guaranteesInputModel);
  }

  public isFideiussioneInAtto(idProposal: string): Observable<CheckGaranziaFideiussoriaModel> {
    const params = new HttpParams();
    const parameters = params.append('idProposal', idProposal);
    const url = this.endpointsService.isFideiussioneInAtto;
    return this.httpClient.get<CheckGaranziaFideiussoriaModel>(url, { params: parameters });
  }


  saveNotaVerificaPreliminare(idProposal: string, nota: string): Observable<boolean> {
    const params = {
      idProposal: idProposal,
      testoNota: nota
    };
    return this.httpClient.post<any>(this.endpointsService.saveNotaVerificaPreliminare, params);
  }

  setNotaRequired(val) {
    this.notaRequired.next(val);
  }
  getNotaRequired(): Observable<boolean> {
    return this.notaRequired.asObservable();
  }
}
