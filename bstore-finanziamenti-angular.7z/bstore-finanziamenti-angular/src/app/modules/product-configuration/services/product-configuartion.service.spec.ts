import { TestBed } from '@angular/core/testing';

import { ProductConfiguartionService } from './product-configuartion.service';

describe('ProductConfiguartionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProductConfiguartionService = TestBed.get(ProductConfiguartionService);
    expect(service).toBeTruthy();
  });
});
