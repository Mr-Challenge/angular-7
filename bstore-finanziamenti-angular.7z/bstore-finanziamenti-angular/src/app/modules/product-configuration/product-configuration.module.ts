import { NgModule } from '@angular/core';
import { ProductConfigurationPageComponent } from './pages/product-configuration-page/product-configuration-page.component';
import { BstoreCommonModule } from '../bstore-common/bstore-common.module';
import { FormsModule } from '@angular/forms';
import { ProductConfigurationRoutingModule } from './product-configuration-routing.module';
import { SubstitutionCreditLinesComponent } from './components/substitution-credit-lines/substitution-credit-lines.component';
import { ProponentComponent } from './components/proponent/proponent.component';
import { PreliminaryCheckComponent } from './components/preliminary-check/preliminary-check.component';
import { MutuoDetailsComponent } from './components/mutuo-details/mutuo-details.component';
import { ItalianCurrencyPipeSharedModule } from '../simulations/italianCurrencyPipeShared.modules';
import { SharedModule } from 'src/app/shared.module';
import { SecondaNotaPefComponent } from './components/seconda-nota-pef/seconda-nota-pef.component';


@NgModule({
  declarations: [
    ProductConfigurationPageComponent,
    SubstitutionCreditLinesComponent,
    ProponentComponent,
    PreliminaryCheckComponent,
    MutuoDetailsComponent,
    SecondaNotaPefComponent
  ],
  imports: [
    BstoreCommonModule,
    FormsModule,
    ProductConfigurationRoutingModule,
    ItalianCurrencyPipeSharedModule,
    SharedModule
  ]
})
export class ProductConfigurationModule { }
