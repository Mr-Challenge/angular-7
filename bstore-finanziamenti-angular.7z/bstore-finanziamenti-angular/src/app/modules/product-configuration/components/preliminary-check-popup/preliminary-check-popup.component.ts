import { Component, ElementRef, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { DialogModel, DialogRef } from 'bstore-angular-library';
import { BaseClientModel } from '../../models/BaseClientModel';
import { PreliminaryCheckPopupModel } from '../../models/PreliminaryCheckPopupModel';
import { ProductConfiguartionService } from '../../services/product-configuartion.service';
import { Subscription } from 'rxjs';

declare var $: any;

@Component({
  selector: 'bst-fin-preliminary-check-popup',
  templateUrl: './preliminary-check-popup.component.html',
  styleUrls: ['./preliminary-check-popup.component.scss']
})
export class PreliminaryCheckPopupComponent implements OnInit, OnDestroy {

  @ViewChild('myInput') myInput: ElementRef;

  public preliminaryCheckValues: PreliminaryCheckPopupModel;
  baseClient: BaseClientModel;
  private baseClients: BaseClientModel[];
  textAreaData: string;
  private mainNdg: string;
  public subtitle: string;
  isAllSemaforeGreen: boolean;
  disableOkBtn = false;
  idProposal: string;
  notaSalvata: string;
  controllato = false;
  notaRequired: boolean;
  subscription: Subscription;
  constructor(private dialogRef: DialogRef, public config: DialogModel, private productConfigurationService: ProductConfiguartionService) { }

  ngOnInit() {
    this.preliminaryCheckValues = this.config.data.preliminaryCheckValues;
    this.baseClient = this.config.data.baseClient;
    this.baseClients = this.config.data.baseClients;
    this.subtitle = this.config.data.title;
    this.mainNdg = this.config.data.mainNdg;
    this.textAreaData = this.config.data.textAreaData;
    this.notaSalvata = this.config.data.textAreaData;
    this.idProposal = this.config.data.idProposal;

    this.setTextAreaRequired();

    this.productConfigurationService.getNotaRequired().subscribe(val => {
      this.notaRequired = val;
    });

    this.checkTextArea();
    this.adjustPopupCss();
  }

  checkVisualizzaPoliticheCreditizie() {
    let contrattoCointestato = false;
    this.baseClients.forEach(client => {
      if (client.cointestazione) {
        contrattoCointestato = true;
      }
    });

    if (contrattoCointestato && this.baseClient.cointestazione) {
      return true;
    } else if (contrattoCointestato && !this.baseClient.cointestazione) {
      return false;
    } else if (!contrattoCointestato && this.mainNdg === this.baseClient.ndg) {
      return true;
    }
    return false;
  }

  onClose() {
    if (this.isAllSemaforeGreen) {
      this.controllato = true;
    }
    this.dialogRef.close({ textAreaData: this.notaSalvata, controllato: this.controllato });
  }

  saveAndClose() {
    if (this.textAreaData != this.notaSalvata) {
      this.subscription = this.productConfigurationService.saveNotaVerificaPreliminare(this.idProposal, this.textAreaData).subscribe(result => {
        if (result) {
          this.dialogRef.close({ textAreaData: this.textAreaData, controllato: true });
        }
      });
    } else {
      this.dialogRef.close({ textAreaData: this.textAreaData, controllato: true });
    }
  }

  resize() {
    this.myInput.nativeElement.style.height = this.myInput.nativeElement.scrollHeight + 'px';
    this.myInput.nativeElement.style.overflow = 'hidden';
    this.checkTextArea();
  }

  checkTextArea() {
    if (this.isAllSemaforeGreen === false || this.notaRequired) {
      if (this.textAreaData && this.textAreaData.length >= 1) {
        this.disableOkBtn = false;
      } else {
        this.disableOkBtn = true;
      }
    } else {
      this.disableOkBtn = false;
    }
  }

  setTextAreaRequired() {
    const previousChecksFiled = this.verificaSemafori(this.preliminaryCheckValues.internalDataBanks.previousChecksFiled);
    const bankruptcyProceedings = this.verificaSemafori(this.preliminaryCheckValues.externalDataBanks.bankruptcyProceedings);
    const sufferingStatusReports = this.verificaSemafori(this.preliminaryCheckValues.externalDataBanks.sufferingStatusReports);
    const activity_ATECO_status = this.verificaSemafori(this.preliminaryCheckValues.creditPoliciesVm.activity_ATECO_status);
    const riskRange_status = this.verificaSemafori(this.preliminaryCheckValues.creditPoliciesVm.riskRange_status);

    if (previousChecksFiled && bankruptcyProceedings && sufferingStatusReports && activity_ATECO_status && riskRange_status) {
      this.isAllSemaforeGreen = true;
    } else {
      this.isAllSemaforeGreen = false;
      this.productConfigurationService.setNotaRequired(true);
    }
  }

  verificaSemafori(semaforo: string): boolean {
    if (!semaforo || semaforo === 'GREEN') {
      return true;
    }
    return false;
  }

  adjustPopupCss() {
    $('body').css('overflow-y', 'hidden');
    $('#popupVPContent').parent().parent().parent().css('max-width', '70%');
    $('#popupVPContent').parent().parent().parent().parent().css({ 'overflow-y': 'scroll' });
    $('#popupVPContent').parent().parent().children(":first").css('display', 'none');
    $('#popupVPContent').parent().parent().children(":first").css('display', 'none');
    $('#popupVPContent').parent().parent().find('.modal-header').css('padding', '30px 0');
  }

  ngOnDestroy(): void {
    $('body').css('overflow-y', 'scroll');
    this.subscription.unsubscribe();
  }

}
