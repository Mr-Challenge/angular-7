import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreliminaryCheckPopupComponent } from './preliminary-check-popup.component';

describe('PreliminaryCheckPopupComponent', () => {
  let component: PreliminaryCheckPopupComponent;
  let fixture: ComponentFixture<PreliminaryCheckPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreliminaryCheckPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreliminaryCheckPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
