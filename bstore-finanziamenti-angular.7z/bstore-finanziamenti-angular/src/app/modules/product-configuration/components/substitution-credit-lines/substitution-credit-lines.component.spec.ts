import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubstitutionCreditLinesComponent } from './substitution-credit-lines.component';

describe('SubstitutionCreditLinesComponent', () => {
  let component: SubstitutionCreditLinesComponent;
  let fixture: ComponentFixture<SubstitutionCreditLinesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubstitutionCreditLinesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubstitutionCreditLinesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
