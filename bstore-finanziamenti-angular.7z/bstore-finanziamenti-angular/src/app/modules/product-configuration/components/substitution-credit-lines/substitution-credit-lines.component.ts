import { Component, OnInit, ViewChild, Input, ChangeDetectorRef, Output, EventEmitter, AfterViewChecked } from '@angular/core';
import { NgModelGroup, NG_VALUE_ACCESSOR, NG_VALIDATORS, ControlValueAccessor, Validator, ControlContainer, NgForm } from '@angular/forms';
import { CreditLineModel } from '../../models/CreditLineModel';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { ProductConfiguartionService } from '../../services/product-configuartion.service';
import { DialogService, RedirectService } from 'bstore-angular-library';
import { SaveCreditLineModel } from '../../models/SaveCreditLineModel';
import { MutuiDetailsModel } from '../../models/MutuiDetailsModel';
import { GuranteesListPopupComponent } from '../gurantees-list-popup/gurantees-list-popup.component';
import { CommonService } from 'src/app/services/common.service';
import { GuaranteesInputModel } from 'src/app/modules/vendita/models/guarantees.input';
import { GuaranteesModel } from 'src/app/modules/vendita/models/guarantees.model';

@Component({
  selector: 'bst-fin-substitution-credit-lines',
  templateUrl: './substitution-credit-lines.component.html',
  styleUrls: ['./substitution-credit-lines.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: SubstitutionCreditLinesComponent, multi: true },
    { provide: NG_VALIDATORS, useExisting: SubstitutionCreditLinesComponent, multi: true }
  ],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],

})
export class SubstitutionCreditLinesComponent implements OnInit, ControlValueAccessor, Validator, AfterViewChecked {

  @ViewChild('creditLineForm') public textboxTemplateRef: NgModelGroup;

  @Input() public idProdotto: number;
  @Input() public idProposal: string;
  @Input() fetchedMutuiDetails: MutuiDetailsModel;

  @Output() substitutionStatus: EventEmitter<boolean> = new EventEmitter();

  creditLineListFetched: CreditLineModel[];
  creditLines: CreditLineModel[];
  creditLineFlag: boolean;
  getDetailsBoolean: boolean;
  flagEnabled = false;
  requiredAttribute = false;
  onChange: (value: any) => void;
  onTouched: () => void;
  demoEventsOnButton: EventsModel[];
  checkedSi: boolean;
  creditLinesOk = false;
  ndgList: any[] = [];
  guaranteesList: GuaranteesModel[] = [];
  mappaCheckbox: Map<string, boolean> = new Map();

  constructor(private productConfiguartionService: ProductConfiguartionService, public dialog: DialogService,
    private cdr: ChangeDetectorRef, private commonService: CommonService, private redirectService: RedirectService) { }

  ngOnInit() {
    this.initializeEvents();
    this.preselectRadioAsync();
    this.loadCreditLines();
  }

  loadCreditLines() {
    // fetch full list of existing credit lines from ESB service
    this.productConfiguartionService.getIdpef().subscribe(idPef => {
      this.productConfiguartionService.getCreditLineVm(idPef, this.idProposal).subscribe(
        data => {
          this.creditLines = data;

          if (this.creditLines !== undefined) {
            this.creditLines.forEach(element => {
              if (!this.mappaCheckbox.get(element.identificativoUnivoco)) {
                this.mappaCheckbox.set(element.identificativoUnivoco, false);
              }
            });
            this.productConfiguartionService.setFidiDaSostituire(this.selectedElementCheckBox());
          }
        }
      );
    });

    // fetching from DB the list of credit line already selected to be replaced (async case)
    this.productConfiguartionService.getIdProdotto().subscribe(idProdotto => {
      this.productConfiguartionService.fetchCreditLineListByIdProdotto(idProdotto).subscribe(
        res => {
          this.creditLineListFetched = res.listCreditLine;
          if (this.creditLineListFetched) {
            this.creditLineListFetched.forEach(element => {
              this.mappaCheckbox.set(element.identificativoUnivoco, true);
              let alreadyPresent = false;
              if (this.creditLines) {
                this.creditLines.forEach(lineaCredito => {
                  if (lineaCredito.identificativoUnivoco == element.identificativoUnivoco) {
                    alreadyPresent = true;
                  }
                });
                if (!alreadyPresent) {
                  this.creditLines.push(element);
                }
              } else {
                this.creditLines = this.creditLineListFetched;
              }
            });
            if (this.creditLineListFetched.length > 0) {
              this.creditLineFlag = true;
              this.getDetailsBoolean = true;
              this.flagEnabled = true;
              this.creditLinesOk = true;
              this.checkedSi = true;
              this.substitutionStatus.emit(this.flagEnabled);
            }
          }
        }
      );
    });


  }

  ngAfterViewChecked() {
    this.cdr.detectChanges();
  }

  initializeEvents() {
    this.demoEventsOnButton = [
      { eventName: 'click', eventCallBack: this.clickCallBackForConferma.bind(this) }
    ];
  }

  preselectRadioAsync() {
    if (this.fetchedMutuiDetails && this.fetchedMutuiDetails.sostituzioneLinea != null) {
      this.creditLineFlag = this.fetchedMutuiDetails.sostituzioneLinea === true; // preselect radio button SI/NO
      this.flagEnabled = false; // disable button conferma
      this.creditLinesOk = true; // show green flag on section
      this.substitutionStatus.emit(this.creditLinesOk); // update label COMPLETO/INCOMPLETO on section
    }
  }

  changeCallBackForRadioButton(value) {
    this.creditLinesOk = false;
    if (!value) {
      this.getDetailsBoolean = false;
      this.flagEnabled = true;
      this.requiredAttribute = false;
      this.checkedSi = false;
      this.productConfiguartionService.setFidiDaSostituire([]);
    } else {
      this.productConfiguartionService.setFidiDaSostituire(this.selectedElementCheckBox());
      this.checkedSi = true;
      this.getDetailsBoolean = true;
      if (this.selectedCheckBoxNumber() !== 0) {
        this.requiredAttribute = false;
        this.flagEnabled = true;
      } else {
        this.requiredAttribute = true;
        this.flagEnabled = false;
      }
    }
    this.substitutionStatus.emit(this.flagEnabled);
  }


  clickCheckBoxFunction(identificatoreCheckBox, rapporto) {

    if (this.mappaCheckbox.get(identificatoreCheckBox)) {
      this.mappaCheckbox.set(identificatoreCheckBox, false);
      if (this.selectedCheckBoxNumber() === 0) {
        // is the last one that i'm removing so change the flag to false
        this.requiredAttribute = true;
        this.flagEnabled = false;
        this.creditLinesOk = false;
      }
    } else {
      this.mappaCheckbox.set(identificatoreCheckBox, true);

      this.commonService.retrieveAllClient(this.idProposal).subscribe(data => {
        this.ndgList = data.map(Client => Client.ndg);
      }, null, () => {

        const guaranteesInputModel = new GuaranteesInputModel();
        guaranteesInputModel.idProdotto = this.idProdotto;
        guaranteesInputModel.ndgList = this.ndgList;
        guaranteesInputModel.numeraPratica = this.fetchedMutuiDetails.idPef.toString();
        this.productConfiguartionService.getGuarantees(guaranteesInputModel).subscribe(result => {
          this.guaranteesList = result.guaranteesList;
        }, null, () => {
          const dialogRef = this.dialog.open(GuranteesListPopupComponent, {
            data: { numeroRapporto: rapporto, guaranteesList: this.guaranteesList },
            title: 'GARANZIE',
            size: 'large',
            externalHeaderClass: {
              'bg-primary': true,
              'text-light': true
            }

          });
          dialogRef.afterClosed.subscribe(res => {

          });
        });

      });
      if (this.selectedCheckBoxNumber() !== 0) {
        // I have selected at least one element so flag to green!
        this.requiredAttribute = false;
        this.flagEnabled = true;
        this.creditLinesOk = true;
      }
    }

    this.productConfiguartionService.setFidiDaSostituire(this.selectedElementCheckBox());
    this.substitutionStatus.emit(this.flagEnabled);
  }

  selectedCheckBoxNumber() {
    let number = 0;
    if (this.mappaCheckbox) {
      this.mappaCheckbox.forEach((value: boolean, key: string) => {
        if (value) {
          number++;
        }
      });
    }
    return number;
  }

  selectedElementCheckBox() {

    const checkedCreditLines: CreditLineModel[] = [];

    this.mappaCheckbox.forEach((value: boolean, key: string) => {
      if (value) {
        if (this.creditLines) {
          this.creditLines.forEach(element => {
            if (element.identificativoUnivoco === key) {
              checkedCreditLines.push(element);
            }
          });
        }
      }
    });

    return checkedCreditLines;

  }


  writeValue(value: any) {
    console.log(value);
  }

  registerOnTouched(onTouched: () => void) {
    this.onTouched = onTouched;
  }

  registerOnChange(onChange: any) {
    this.onChange = onChange;
  }

  validate() {
    if (!this.textboxTemplateRef.valid) {
      return { 'required': 'please select both the values' };
    } else {
      return null;
    }
  }

  clickCallBackForConferma() {

    let creditLinesToSave: CreditLineModel[] = [];

    if (this.checkedSi) {
      creditLinesToSave = this.selectedElementCheckBox();
    }

    const saveCreditLines = new SaveCreditLineModel();
    saveCreditLines.idProdotto = this.idProdotto;
    saveCreditLines.listCreditLine = creditLinesToSave;
    this.productConfiguartionService.saveCreditLineVm(saveCreditLines).subscribe(
      () => {
        this.creditLinesOk = true;
        this.flagEnabled = false;
      }
    );
  }
}
