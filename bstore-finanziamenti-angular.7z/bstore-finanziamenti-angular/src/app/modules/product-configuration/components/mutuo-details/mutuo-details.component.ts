import { AfterViewChecked, AfterViewInit, Component, EventEmitter, Input, OnInit, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { ControlContainer, NgForm, NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';
import { DialogService } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { CommonMessagePopupComponent } from '../../../../components/common-message-popup/common-message-popup.component';
import { MutuiDetailsModel } from '../../models/MutuiDetailsModel';
import { MutuoDetails } from '../../models/MutuoDetails';
import { TextFieldModel } from '../../models/TextFieldModel';
import { ProductConfiguartionService } from '../../services/product-configuartion.service';

@Component({
  selector: 'bst-fin-mutuo-details',
  templateUrl: './mutuo-details.component.html',
  styleUrls: ['./mutuo-details.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: MutuoDetailsComponent, multi: true },
    { provide: NG_VALIDATORS, useExisting: MutuoDetailsComponent, multi: true }
  ],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
  encapsulation: ViewEncapsulation.None
})
export class MutuoDetailsComponent implements OnInit, AfterViewChecked, AfterViewInit {

  @ViewChild('mutuiRef') public mutuiForm: NgForm;

  @Input() fetchedMutuiDetails: MutuiDetailsModel;
  @Input() public idProposal: string;
  @Input() public idPef: number;
  @Input() public isMutuiChiro: boolean;

  @Output() showStatus: EventEmitter<boolean> = new EventEmitter();
  @Output() showAmount: EventEmitter<boolean> = new EventEmitter();

  amountRequested: number;
  mutuoDetails: MutuoDetails;
  isMutuoDettagliUpdated: boolean;
  skipValidation = true;
  dettagliListControls: Array<any> = [];
  showFirstHome: boolean;
  showLiquidity: boolean;
  showNonResidentialProperties: boolean;
  MutuiDetails: TextFieldModel[] = [];
  importoRichiesto: any = 0;
  mutuoDettagli = {
    importoPerPrimaCasa: '',
    importoPerSecondaCasa: '',
    liquidita: '',
    importoPerImmobiliNonResidenziali: ''
  };
  mutuoDettagliError: boolean;
  mutuoDettagliEvent: EventsModel[];
  importoRichiestoEvents: EventsModel[];

  ngAfterViewChecked() {
    /*
      Emits the validity of the Section
    */
    if (this.fetchedMutuiDetails && !this.isMutuiChiro) {
      if ((this.isMutuoDettagliUpdated || this.mutuiForm.invalid)) {
        this.showStatus.emit(((!this.isMutuoDettagliUpdated) && this.mutuiForm.valid));
      }
    }
  }

  ngAfterViewInit(): void {
    this.checkMutuoDettagli();
  }

  constructor(public productConfigurationService: ProductConfiguartionService, public dialog: DialogService) {
  }

  ngOnInit() {
    this.productConfigurationService.getDettagliMutuo().subscribe(data => {
      this.mutuoDetails = data; // fetch data to decide whic fields we have to show
      this.showFirstHome = this.mutuoDetails.showFirstHome;
      this.showLiquidity = this.mutuoDetails.showLiquidity;
      this.showNonResidentialProperties = this.mutuoDetails.showNonResidentialProperties;
      this.loadDettagliList(); // populate the list of fields using flags like 'showFirstHome'
      this.setEvent();
      this.initializeForm(); // handle async case with values from DB
      this.checkForErrorAsync();
      if (this.isMutuiChiro) {
        this.showAmount.emit(true);
        this.showStatus.emit(true);
      }
    });
    if (this.fetchedMutuiDetails && !this.isMutuiChiro) {
      this.mutuiForm.valueChanges.subscribe(() => this.emitMutuiDetail());
    }
  }

  setEvent() {
    /*
      Initialization of Events
    */
    this.mutuoDettagliEvent = [
      { eventName: 'keyup', eventCallBack: this.setisMutuoDettagliUpdated.bind(this) },
      // { eventName: 'focus', eventCallBack: this.removeMutuoDettagliError.bind(this) },
      { eventName: 'keyup', eventCallBack: this.checkMutuoDettagli.bind(this) }
    ];
  }

  initializeForm() {
    /*
        To Populate the form with tha values coming from db.
    */
    this.amountRequested = this.fetchedMutuiDetails.importoRichiesto;
    this.importoRichiesto = this.fetchedMutuiDetails.importoRichiesto && !this.isMutuiChiro ? this.fetchedMutuiDetails.importoRichiesto : 0;
    this.dettagliListControls.forEach((element, index) => {
      if (element.value === 'IMPORTO PER PRIMA CASA' && this.fetchedMutuiDetails.importoPerPrimaCasa
        && this.showFirstHome && !this.isMutuiChiro) {
        this.MutuiDetails.push({ name: 'IMPORTO PER PRIMA CASA', value: this.fetchedMutuiDetails.importoPerPrimaCasa });
      } else if (element.value === 'IMPORTO PER SECONDA CASA' && this.fetchedMutuiDetails.importoPerSecondaCasa && !this.showFirstHome) {
        this.MutuiDetails.push({ name: 'IMPORTO PER SECONDA CASA', value: this.fetchedMutuiDetails.importoPerSecondaCasa });
      } else if (element.value === 'LIQUIDITA' && this.fetchedMutuiDetails.liquidita && this.showLiquidity) {
        this.MutuiDetails.push({ name: 'LIQUIDITA', value: this.fetchedMutuiDetails.liquidita });
      } else if (element.value === 'IMPORTO PER IMMOBILI NON RESIDENZIALI'
        && this.fetchedMutuiDetails.importoPerImmobiliNonResidenziali && this.showNonResidentialProperties) {
        this.MutuiDetails.push({
          name: 'IMPORTO PER IMMOBILI NON RESIDENZIALI',
          value: this.fetchedMutuiDetails.importoPerImmobiliNonResidenziali
        });
      }
    });
    if (!this.isMutuiChiro) {
      this.MutuiDetails.push({ name: 'IMPORTO RICHIESTO', value: this.importoRichiesto + '' });
    }
    this.mutuoDettagli = {
      importoPerPrimaCasa: this.fetchedMutuiDetails.importoPerPrimaCasa && !this.isMutuiChiro ?
        this.fetchedMutuiDetails.importoPerPrimaCasa.replace(new RegExp('[.]', 'g'), ',') : '',
      importoPerSecondaCasa: this.fetchedMutuiDetails.importoPerSecondaCasa ?
        this.fetchedMutuiDetails.importoPerSecondaCasa.replace(new RegExp('[.]', 'g'), ',') : '',
      liquidita: this.fetchedMutuiDetails.liquidita ? this.fetchedMutuiDetails.liquidita.replace(new RegExp('[.]', 'g'), ',') : '',
      importoPerImmobiliNonResidenziali: this.fetchedMutuiDetails.importoPerImmobiliNonResidenziali ?
        this.fetchedMutuiDetails.importoPerImmobiliNonResidenziali.replace(new RegExp('[.]', 'g'), ',') : ''
    };
  }

  checkForErrorAsync() {
    /*
      Check the section is valid or not .checkMutuoDettagli() method cant be used beacuse the form
      is not created.And emit MutuiDetail to Parent Component.
    */
    let total = 0;
    if (this.showFirstHome) {
      total = total + Number(this.fetchedMutuiDetails.importoPerPrimaCasa);
    }
    if (!this.showFirstHome) {
      total = total + Number(this.fetchedMutuiDetails.importoPerSecondaCasa);
    }
    if (this.showLiquidity) {
      total = total + Number(this.fetchedMutuiDetails.liquidita);
    }
    if (this.showNonResidentialProperties) {
      total = total + Number(this.fetchedMutuiDetails.importoPerImmobiliNonResidenziali);
    }
    total > 0 ? this.mutuiForm.controls.mutuoDettagli.markAsTouched() : null;
    this.emitMutuiDetail();
    if (this.fetchedMutuiDetails.importoRichiesto !== null) {
      this.MutuiDetails.forEach(det => {
        if (det.name === 'IMPORTO RICHIESTO' && det.value !== this.fetchedMutuiDetails.importoRichiesto + '') {
          this.MutuiDetails.push({ name: 'IMPORTO RICHIESTO', value: this.fetchedMutuiDetails.importoRichiesto + '' });
          return;
        }
      });
    }
    this.showAmount.emit(true);
    if ((!this.isEmptyMutuoDettagli() && total === 0) || this.fetchedMutuiDetails.importoRichiesto === 0) {
      this.showStatus.emit(false);
      this.isMutuoDettagliUpdated = true;
    } else {
      this.showStatus.emit(!this.isEmptyMutuoDettagli() ? total === this.toDecimal(this.fetchedMutuiDetails.importoRichiesto.toString()) : true);
    }
    if (!this.isMutuoDettagliUpdated) {
      this.productConfigurationService.setDettMutuoInPage(this.MutuiDetails);
    }
  }

  setisMutuoDettagliUpdated() {
    this.isMutuoDettagliUpdated = true;
  }

  removeMutuoDettagliError() {
    this.mutuoDettagliError = false;
  }

  setMutuoDettagliError() {
    this.mutuoDettagliError = true;
  }

  loadDettagliList() {

    /*
      To create a Form fild which need to be shown;
    */
    const dettagliList = [
      {
        value: 'IMPORTO PER PRIMA CASA', booleanVal: this.showFirstHome !== undefined && this.showFirstHome,
        name: 'importoPerPrimaCasa'
      },
      {
        value: 'IMPORTO PER SECONDA CASA', booleanVal: this.showFirstHome !== undefined && !this.showFirstHome,
        name: 'importoPerSecondaCasa'
      },
      {
        value: 'LIQUIDITA', booleanVal: this.showLiquidity !== undefined && this.showLiquidity,
        name: 'liquidita'
      },
      {
        value: 'IMPORTO PER IMMOBILI NON RESIDENZIALI',
        booleanVal: this.showNonResidentialProperties !== undefined && this.showNonResidentialProperties,
        name: 'importoPerImmobiliNonResidenziali'
      }
    ];
    dettagliList.forEach(element => {
      if (element.booleanVal) {
        this.dettagliListControls.push(element);
      }
    });
  }

  validateImportoPeriziaString() {
    /*
      To Show ImportoRichiesto and if any error open PopUp
    */
    this.validateImportoPerizia(this.toDecimal(this.importoRichiesto));
  }

  validateImportoPerizia(amountRequested) {
    /*
      To Show ImportoRichiesto and if any error open PopUp
    */
    this.amountRequested = amountRequested;
    let maxAppraisalAmount = 0;
    // Modificato BE per passaggio amount come BigDecimal e non piu come String
    if (this.fetchedMutuiDetails.amount) {
      if (this.fetchedMutuiDetails.amount < amountRequested) {
        this.openErrorPopup('Non è possibile richiedere un finanziamento di '
          + 'importo superiore a quello inserito in fase di Simulazione. Avviare una nuova proposta di vendita.');
        this.importoRichiesto = '0';
        return;
      }
    }
    if (this.mutuoDetails && this.mutuoDetails.maxAmount != null && this.mutuoDetails.maxAmount !== undefined) {
      //if the this.mutuoDetails.maxAmount is zero, I proceed and show popup
      maxAppraisalAmount = this.mutuoDetails.maxAmount;
      if (maxAppraisalAmount < amountRequested) {
        this.openErrorPopup('Impossibile procedere per mancanza di fondiarietà. L’importo richiesto' +
          ' deve essere minore o uguale all’80% del valore risultante dalla perizia');
        this.importoRichiesto = '0';
        return;
      }
    }
  }

  openErrorPopup(msg) {
    /*
      To Show ImportoRichiesto error Popup
    */
    const ref = this.dialog.open(CommonMessagePopupComponent, {
      data: { message: msg, title: 'ATTENZIONE' }
    });
    ref.afterClosed.subscribe(result => {
    });
  }

  checkMutuoDettagli() {
    /*
      To Check of the importoRichiesto is eqaul to sum of
      importoPerPrimaCasa ,importoPerSecondaCasa, liquidita ,importoPerImmobiliNonResidenziali
      we skip this method on initization because
    */
    if (this.mutuiForm.controls &&
      !this.skipValidation &&
      this.mutuiForm.value.mutuoDetails.importoRichiesto != 0 && this.mutuiForm.controls.mutuoDettagli.touched) {
      let total = 0;
      Object.keys(this.mutuiForm.value.mutuoDettagli)
        .forEach(key => {
          total = total + this.toDecimal(this.mutuiForm.value.mutuoDettagli[key]);
        }
        );
      this.mutuoDettagliError = (total != this.toDecimal(this.mutuiForm.value.mutuoDetails.importoRichiesto));
    }
    this.skipValidation = false;
  }

  toDecimal(number: string) {
    /*
      Converts a currency format form (dot thousand seperated) to floating point no;
      e.g : 9.000,00 to 9000.00
    */
    if ((parseFloat(number).toString()).indexOf('NaN')) {
      return parseFloat(number.toString().replace(new RegExp('[.]', 'g'), '').replace(',', '.'));
    }
    return 0;
  }

  updateMutuiDettagli() {
    /*
      Send data to backend. Only send the data which is visible on screen and rest is set to null.
    */
    if (this.isMutuoDettagliUpdated
      && this.mutuiForm.valid && (this.isEmptyMutuoDettagli() || this.mutuiForm.controls.mutuoDettagli.touched)) {
      if (!(!this.isMutuoDettagliUpdated && this.mutuiForm.valid)) {
        this.showStatus.emit((!this.isMutuoDettagliUpdated && this.mutuiForm.valid));
      }
      const mutuiData = new MutuiDetailsModel();

      mutuiData.praticaId = Number(this.idProposal);
      mutuiData.importoRichiesto = this.toDecimal(this.importoRichiesto);
      mutuiData.importoPerPrimaCasa = this.showFirstHome ? this.toDecimal(this.mutuoDettagli['importoPerPrimaCasa']).toString() : null;
      mutuiData.importoPerSecondaCasa = !this.showFirstHome ? this.toDecimal(this.mutuoDettagli['importoPerSecondaCasa']).toString() : null;
      mutuiData.liquidita = this.showLiquidity ? this.toDecimal(this.mutuoDettagli['liquidita']).toString() : null;
      mutuiData.importoPerImmobiliNonResidenziali = this.showNonResidentialProperties ?
        this.toDecimal(this.mutuoDettagli['importoPerImmobiliNonResidenziali']).toString() : null;

      if (mutuiData != null) {
        this.productConfigurationService.updateMutuiDettagli(mutuiData).subscribe(data => {
          this.isMutuoDettagliUpdated = false;
          this.showStatus.emit(true);
          this.emitMutuiDetail();
        });
      }
    }
  }

  emitMutuiDetail() {
    /*
      send Updated MutuiDetails value to parent component.
      this is done in 2 case.
      1. On Async call when the only if the value from coming form db are valid as per the condition
      2. When user change the data and click on confirma on success call back.
      Rest all the values will be set to null.
    */
    if (!(this.isMutuoDettagliUpdated || this.mutuiForm.invalid) && this.mutuiForm.value.mutuoDettagli) {
      this.MutuiDetails = [];
      if (this.mutuiForm.value.mutuoDettagli['importoPerPrimaCasa'] && this.showFirstHome) {
        this.MutuiDetails.push({ name: 'IMPORTO PER PRIMA CASA', value: this.mutuiForm.value.mutuoDettagli['importoPerPrimaCasa'] });
      }
      if (this.mutuiForm.value.mutuoDettagli['importoPerSecondaCasa'] && !this.showFirstHome) {
        this.MutuiDetails.push({ name: 'IMPORTO PER SECONDA CASA', value: this.mutuiForm.value.mutuoDettagli['importoPerSecondaCasa'] });
      }
      if (this.mutuiForm.value.mutuoDettagli['liquidita'] && this.showLiquidity) {
        this.MutuiDetails.push({ name: 'LIQUIDITA', value: this.mutuiForm.value.mutuoDettagli['liquidita'] });
      }
      if (this.mutuiForm.value.mutuoDettagli['importoPerImmobiliNonResidenziali'] && this.showNonResidentialProperties) {
        this.MutuiDetails.push({
          name: 'IMPORTO PER IMMOBILI NON RESIDENZIALI',
          value: this.mutuiForm.value.mutuoDettagli['importoPerImmobiliNonResidenziali']
        });
      }
      if (this.mutuiForm.value.mutuoDetails.importoRichiesto) {
        this.MutuiDetails.push({ name: 'IMPORTO RICHIESTO', value: this.mutuiForm.value.mutuoDetails.importoRichiesto + '' });
      }
      this.productConfigurationService.setDettMutuoInPage(this.MutuiDetails);
    } else if (this.isMutuiChiro) {
      this.productConfigurationService.setDettMutuoInPage([]);
    }

  }

  isEmptyMutuoDettagli(): boolean {
    return (this.showFirstHome == undefined || this.showFirstHome == null) && !this.showLiquidity && !this.showNonResidentialProperties;
  }
}


