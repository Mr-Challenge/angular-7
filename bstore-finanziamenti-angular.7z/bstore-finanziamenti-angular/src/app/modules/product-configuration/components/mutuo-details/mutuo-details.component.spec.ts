import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MutuoDetailsComponent } from './mutuo-details.component';

describe('MutuoDetailsComponent', () => {
  let component: MutuoDetailsComponent;
  let fixture: ComponentFixture<MutuoDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MutuoDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MutuoDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
