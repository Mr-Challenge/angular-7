import { Component, OnInit } from '@angular/core';
import { DialogRef, DialogModel } from 'bstore-angular-library';
import { config } from 'rxjs';

@Component({
  selector: 'bst-fin-credit-line-popup',
  templateUrl: './credit-line-popup.component.html',
  styleUrls: ['./credit-line-popup.component.scss']
})
export class CreditLinePopupComponent implements OnInit {
  numeroRapporto: any;
  inputText: string;
  text: string;

  constructor(public dialogRef: DialogRef, public config: DialogModel) {
    this.numeroRapporto = config.data[0].numeroRapporto;
    this.inputText = "The loan replaces the credit line n°" + config.data[0].numeroRapporto;
  }

  ngOnInit() {
  }
  onClose() {
    this.dialogRef.close('closed');
  }
}
