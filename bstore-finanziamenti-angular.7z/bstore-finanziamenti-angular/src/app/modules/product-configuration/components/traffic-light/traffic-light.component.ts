import { Component, Input } from '@angular/core';
import { PreliminaryCheckPopupModel } from '../../models/PreliminaryCheckPopupModel';

@Component({
  selector: 'bst-fin-traffic-light',
  templateUrl: './traffic-light.component.html',
  styleUrls: ['./traffic-light.component.scss']
})
export class TrafficLightComponent {

  @Input() preliminaryCheckValues: PreliminaryCheckPopupModel;

  constructor() { }

}
