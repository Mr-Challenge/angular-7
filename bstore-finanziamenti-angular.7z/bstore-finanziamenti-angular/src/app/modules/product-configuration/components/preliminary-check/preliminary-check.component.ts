import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { DialogService } from 'bstore-angular-library';
import { combineLatest } from 'rxjs';
import { MortgageClientRoles } from 'src/app/constant/mortgageClientRoles';
import { CommonService } from 'src/app/services/common.service';
import { BaseClientModel } from '../../models/BaseClientModel';
import { PreliminaryCheckPopupModel } from '../../models/PreliminaryCheckPopupModel';
import { ProductConfiguartionService } from '../../services/product-configuartion.service';
import { PreliminaryCheckPopupComponent } from '../preliminary-check-popup/preliminary-check-popup.component';

@Component({
  selector: 'bst-fin-preliminary-check',
  templateUrl: './preliminary-check.component.html',
  styleUrls: ['./preliminary-check.component.scss']
})
export class PreliminaryCheckComponent implements OnInit {

  @Input() private idProposal: any;
  @Input() private idPef: number;
  @Input() private textAreaData: string;

  @Output() isAllVisualized: EventEmitter<any> = new EventEmitter<any>();
  @Output() NotaPraticaEventEmitter: EventEmitter<any> = new EventEmitter<any>();

  baseClients: BaseClientModel[];
  baseClientsGAR: BaseClientModel[];
  baseClientsTER: BaseClientModel[];
  private preliminaryCheckValues: PreliminaryCheckPopupModel;
  private isVisualizedINT: boolean;
  private isVisualizedGAR: boolean;
  private isVisualizedTER: boolean;
  public isBaseClientFlagSet = false;
  isChirografario: boolean;

  constructor(private dialog: DialogService, private commonService: CommonService,
    private productConfigurationService: ProductConfiguartionService) {
  }

  ngOnInit() {
    this.commonService.isMutuoIpotecario(this.idProposal).subscribe(result => {
      this.isChirografario = !result;
    });
    this.getClientRoles();
  }

  getClientRoles() {
    combineLatest(
      this.commonService.getClientByRole(this.idProposal, MortgageClientRoles.INTESTATARI),
      this.commonService.getClientByRole(this.idProposal, MortgageClientRoles.GARANTI),
      this.commonService.getClientByRole(this.idProposal, MortgageClientRoles.TERZI_DATORI_IPOTECA))
      .subscribe(([INTClientRole, GARClientRole, TERClientRole]) => {
        this.baseClients = INTClientRole;
        this.baseClientsGAR = GARClientRole;
        this.baseClientsTER = TERClientRole;

        this.isVisualizedINT = this.checkVisualization(this.baseClients);
        this.isVisualizedGAR = this.checkVisualization(this.baseClientsGAR);
        this.isVisualizedTER = this.checkVisualization(this.baseClientsTER);

        this.isBaseClientFlagSet = true;
      });
  }

  OnClick(baseClient: BaseClientModel) {
    this.productConfigurationService.getPreliminaryCheckValues(baseClient.ndg, this.idPef.toString()).subscribe(data => {
      this.preliminaryCheckValues = data;
      const mainNdg = this.findMainNdg();
      const subtitle = this.getIdActivetab();
      const dialogRef = this.dialog.open(PreliminaryCheckPopupComponent, {
        data: {
          preliminaryCheckValues: this.preliminaryCheckValues,
          baseClient: baseClient,
          textAreaData: this.textAreaData,
          mainNdg: mainNdg,
          title: subtitle,
          baseClients: this.baseClients,
          idProposal: this.idProposal
        },
        title: 'VERIFICA PRELIMINARE',
        externalHeaderClass: { 'bg-primary': true, 'text-light': true }
      });
      dialogRef.afterClosed.subscribe(res => {
        this.textAreaData = res.textAreaData;

        baseClient.controllato = res.controllato;
        this.isVisualizedINT = this.checkVisualization(this.baseClients);
        this.isVisualizedGAR = this.checkVisualization(this.baseClientsGAR);
        if (this.isChirografario) {
          this.isAllVisualized.emit(this.isVisualizedINT && this.isVisualizedGAR);
        } else {
          this.isVisualizedTER = this.checkVisualization(this.baseClientsTER);
          this.isAllVisualized.emit(this.isVisualizedINT && this.isVisualizedGAR && this.isVisualizedTER);
        }

        this.NotaPraticaEventEmitter.emit(this.textAreaData);
      });
    });
  }

  private getIdActivetab(): string {
    const active = document.querySelector('.nav-link.active');
    const id = active.getAttribute('id');

    if (id === 'intestatari_tab') {
      return 'INTESTATARIO';

    } else if (id === 'garanti_tab') {
      return 'GARANTE';

    } else if (id === 'terzo_tab') {
      return 'TERZO DATORE IPOTECA';
    }
  }

  private findMainNdg(): string {
    let mainNdg: string = null;
    if (this.baseClients) {
      mainNdg = this.baseClients[0].ndg;
    }
    return mainNdg;
  }

  private checkVisualization(clientList: BaseClientModel[]): boolean {
    if (clientList) {
      for (const client of clientList) {
        if (!client.controllato) {
          return false;
        }
      }
    }
    return true;
  }
}
