import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { ProductConfiguartionService } from '../../services/product-configuartion.service';
import { Proponent } from '../../models/Proponent';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { NgModelGroup, ControlContainer, NgForm } from '@angular/forms';
import { ProponenteModel } from '../../models/ProponenteModel';
import { MutuiDetailsModel } from '../../models/MutuiDetailsModel';


@Component({
  selector: 'bst-fin-proponent',
  templateUrl: './proponent.component.html',
  styleUrls: ['./proponent.component.scss'],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class ProponentComponent implements OnInit {

  @ViewChild('questionForm') public radioTemplateRef: NgModelGroup;
  @Input() proponentList: Proponent[];
  @Output() serialNumber: EventEmitter<any> = new EventEmitter<any>();
  @Output() isFlagForCreditLines: EventEmitter<boolean> = new EventEmitter<any>();
  @Input() idProposal: string;
  @Input() fetchedMutuiDetails: MutuiDetailsModel;
  checkedAns: string;
  demoEvents: EventsModel[];
  demoEventsOnButtonConferma: EventsModel[];
  proponenteId: string;
  proponenteConfirmed: boolean;

  constructor(public productConfiguartionService: ProductConfiguartionService) {
  }

  ngOnInit() {
    this.isSelected();

    this.demoEvents = [
      { eventName: 'change', eventCallBack: this.changeCheckedAns.bind(this) }
    ];

    this.demoEventsOnButtonConferma = [
      { eventName: 'click', eventCallBack: this.clickConfirma.bind(this) }
    ];

  }

  proponentConfirma(serialNumber) {
    // added for #894 ,new proponente model added to send idProposal
    // and serianNumber known as proponenteId to save it in db as part of #1490
    const proponent = new ProponenteModel();
    proponent.proposalId = +this.idProposal;
    proponent.proponenteId = serialNumber;
    proponent.pefProposalId = this.fetchedMutuiDetails.idPef;
    this.proponentList.forEach(data => {
      if (data.serialNumber === serialNumber) {
        proponent.ruoloProponente = data.ruoloDescrizione;
        proponent.codRuolo = data.codRuolo;
      }
    });
    this.productConfiguartionService.saveProponent(proponent).
      subscribe(data => {
        console.log('Proponente id saved successfuly ' + data);
        if (data) {
          this.proponenteConfirmed = true;
          this.isFlagForCreditLines.emit(true);
        }
      },
        error => {
          console.log('Error occured in retrieveAllClient service call');
        });
  }

  isSelected() {
    console.log(this.proponentList);
    //iterating the list to check if any proponente has attribute selected == true - it means it was choosen on purpose by user
    let data = this.proponentList.some(proponente => proponente.selected === true);

    if (data) {
      this.proponentList.forEach(proponent => {
        if (proponent.selected === true) {
          this.checkedAns = proponent.name;
          this.proponenteConfirmed = true;//show green flag and disable button conferma
          this.isFlagForCreditLines.emit(true);
        }

      });
    } else { //if proponente was not selected on purpose (async) then preselect the default one
      this.proponentList.forEach(proponent => {
        if (proponent.branchManager === true) {
          this.checkedAns = proponent.name;
          proponent.selected = true;
        }
      });
    }

  }

  changeCheckedAns(input, event) {
    console.log(this.proponentList);
    this.proponenteConfirmed = false;
    this.isFlagForCreditLines.emit(false);
    if (event.target.checked) {
      this.proponentList.forEach(proponent => {
        if (proponent.name === this.checkedAns) {
          proponent.selected = true;
        } else {
          proponent.selected = false;
        }
      });
    }
  }

  clickConfirma() {
    for (const proponent of this.proponentList) {
      if (proponent.selected === true) {
        this.proponenteId = proponent.serialNumber;
        this.serialNumber.emit(proponent.serialNumber);
        break;
      }
    }
    this.proponentConfirma(this.proponenteId);
  }
}
