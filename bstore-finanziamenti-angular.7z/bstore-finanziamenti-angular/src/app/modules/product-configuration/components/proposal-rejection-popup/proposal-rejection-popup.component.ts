import { Component, OnInit } from '@angular/core';
import { DialogModel, DialogRef } from 'bstore-angular-library';
import { StatoMutuoType } from 'src/app/constant/statoMutuo';
import { CommonService } from 'src/app/services/common.service';
import { ProductConfiguartionService } from '../../services/product-configuartion.service';

@Component({
  selector: 'bst-fin-proposal-rejection-popup',
  templateUrl: './proposal-rejection-popup.component.html',
  styleUrls: ['./proposal-rejection-popup.component.scss']
})
export class ProposalRejectionPopupComponent implements OnInit {
  EventoData: String[];
  ProposalId: string;
  updatedResult: boolean;
  constructor(public dialogRef: DialogRef, private commonService: CommonService, public config: DialogModel, public productConfigurationService: ProductConfiguartionService) { }

  ngOnInit() {
    this.EventoData = this.config.data.EventoData;
    this.ProposalId = this.config.data.ProposalId;
  }

  onClose() {
    this.dialogRef.close();
  }

  modificaProposta() {
    this.commonService.updateMortgageStatus(this.ProposalId, StatoMutuoType.CONFIGURAZIONE_PRODOTTO).subscribe(res => {
      this.updatedResult = res;
      this.dialogRef.close();
    }, (error: any) => {
      this.onClose();
    });
    this.onClose();
  }
}
