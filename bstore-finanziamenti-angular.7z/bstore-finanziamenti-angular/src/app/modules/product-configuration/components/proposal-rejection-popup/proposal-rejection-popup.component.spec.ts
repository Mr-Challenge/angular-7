import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProposalRejectionPopupComponent } from './proposal-rejection-popup.component';

describe('ProposalRejectionPopupComponent', () => {
  let component: ProposalRejectionPopupComponent;
  let fixture: ComponentFixture<ProposalRejectionPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProposalRejectionPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProposalRejectionPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
