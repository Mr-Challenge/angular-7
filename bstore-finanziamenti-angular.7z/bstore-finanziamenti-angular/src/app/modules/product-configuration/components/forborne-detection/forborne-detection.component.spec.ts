import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ForborneDetectionComponent } from './forborne-detection.component';

describe('ForborneDetectionComponent', () => {
  let component: ForborneDetectionComponent;
  let fixture: ComponentFixture<ForborneDetectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForborneDetectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForborneDetectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
