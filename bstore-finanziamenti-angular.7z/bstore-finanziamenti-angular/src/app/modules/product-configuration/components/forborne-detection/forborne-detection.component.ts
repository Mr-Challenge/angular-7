import { AfterContentChecked, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ControlContainer, NgForm, NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';
import { DialogService } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { SelectOptionModel } from 'bstore-angular-library/lib/models/select-option-model';
import { CommonMessagePopupComponent } from 'src/app/components/common-message-popup/common-message-popup.component';
import { ClientRole } from 'src/app/models/clientRole.enum';
import { CodiceDescrizione } from 'src/app/models/CodiceDescrizione.model';
import { FetchAnomalies } from 'src/app/models/fetchAnomalies.model';
import { FinancingFinality } from 'src/app/models/FinancingFinality.model';
import { ForborneAnomaliesAndForceData } from 'src/app/models/forborneAnomaliesForceData.model';
import { ForborneService } from 'src/app/modules/vendita/services/forborne.service';
import { CommonService } from 'src/app/services/common.service';
import { ForborneQuestionList } from '../../models/ForborneQuestionList';
import { LoanPurposeModel } from '../../models/LoanPurposeModel';
import { MutuiDetailsModel } from '../../models/MutuiDetailsModel';
import { ProductConfiguartionService } from '../../services/product-configuartion.service';

@Component({
  selector: 'bst-fin-forborne-detection',
  templateUrl: './forborne-detection.component.html',
  styleUrls: ['./forborne-detection.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: ForborneDetectionComponent, multi: true },
    { provide: NG_VALIDATORS, useExisting: ForborneDetectionComponent, multi: true }
  ],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class ForborneDetectionComponent implements OnInit, AfterContentChecked {

  @ViewChild('forborneDetectionForm') forborneDetection: NgForm;
  @Input() public idProposal: any;
  @Input() idPef: number;
  @Input() fetchedMutuiDetails: MutuiDetailsModel;
  @Input() visible: boolean;

  @Output() isForborneSection: EventEmitter<boolean> = new EventEmitter();
  @Output() isLineaForborneSelected: EventEmitter<boolean> = new EventEmitter();
  @Output() notaInvalid: EventEmitter<boolean> = new EventEmitter();

  financialDifficultyToolTipText = 'Il debitore è in difficoltà finanziaria o ci andrebbe senza la seguente concessione?';
  concessionToolTipText = 'Almeno uno degli interventi effettuati sulla linea lavorata si configura come concessione agevolativa?';
  forborneLineToolTipsText = 'La linea di credito è forborne?';
  msgLineaForborne = 'La proposta di misure di forbearance non è supportata tramite BStore. Procedere tramite PEF.';
  loanEvent: EventsModel[];
  confirmForborneEvents: EventsModel[];
  remodulationForm: boolean;
  difficoltaFinanziariaEvent: EventsModel[];
  finanziamentoList: FinancingFinality[] = [];
  onLoad = true;
  loanEventList: SelectOptionModel[] = [];
  difficoltaFinanziariaChangeEvent: EventsModel[];
  notaForboneEvent: EventsModel[];
  concessionEvent: EventsModel[];
  ndgList: string[] = [];
  ndgListForborneCall: string[] = [];
  disabilitaDifficoltaFinanziariaRadio = false;
  visibleLineaForbone: boolean;
  visibleConcessione: boolean;
  forbornePef: boolean;
  anomaliaList: ForborneAnomaliesAndForceData;
  visibleNota: boolean;
  notaForborneInvalid: boolean;
  isConfermaValid: boolean;
  constructor(private productConfiguartionService: ProductConfiguartionService,
    public dialog: DialogService,
    private commonService: CommonService,
    private forborneService: ForborneService,
  ) { }

  ngOnInit() {
    this.forbornePef = true;
    if (this.fetchedMutuiDetails) {
      if (this.fetchedMutuiDetails.lineaforbone === null) {
        this.visibleLineaForbone = false;
      } else {
        this.visibleLineaForbone = true;
      }
      if (this.fetchedMutuiDetails.concess === null) {
        this.visibleConcessione = false;
        this.forbornePef = true;
      } else {
        //aggiungere logica in base alle altre domande
        if (this.fetchedMutuiDetails.diff == false) {
          this.visibleConcessione = false;
        } else {
          this.visibleConcessione = true;
        }
      }
      this.lineaForboneUpdate();
    }

    setTimeout(() => {
      this.saveAndEmitFlags(this.forborneDetection.valid);
    }, 5000);

    this.initializeEvents();

    this.loadFinancingPurposeOptions();

    this.loadEventOptions();

    this.commonService.retrieveAllClient(this.idProposal).subscribe(result => {
      const filterCointestazioneNdg = client => client.cointestazione;
      const filterNonCointestazioneNdg = client => !client.cointestazione;
      const filterNdgWithClientRoleIntestari = client => client.role === ClientRole.INTESTARI.toString();
      this.ndgList = result.filter(filterNonCointestazioneNdg).map(clientVal => clientVal.ndg);
      this.ndgListForborneCall = (result.find(filterCointestazioneNdg) ?
      result.filter(filterCointestazioneNdg)
      : result.filter(filterNdgWithClientRoleIntestari)
      ).map(clientVal => clientVal.ndg);
      const fetchAnomaliesVm = new FetchAnomalies();
      fetchAnomaliesVm.proposalId = this.idProposal;
      fetchAnomaliesVm.pefProposalId = '' + this.idPef;
      fetchAnomaliesVm.ndgList = this.ndgListForborneCall;
      fetchAnomaliesVm.istruttoriaAvviata = this.fetchedMutuiDetails.istruttoriaAvviata;
      const isRimodulazione = this.finanziamentoList.find(data => data.value == this.fetchedMutuiDetails.finalita);
      fetchAnomaliesVm.rimodulazione = isRimodulazione ? isRimodulazione.remodulation : false;
      this.forborneService.getAnomaliaListAndDataToForce(fetchAnomaliesVm).subscribe(response => {
        this.anomaliaList = response;
        if (response.toForceDifficoltaFinanziaria) {
          this.fetchedMutuiDetails.diff = true;
          this.disabilitaDifficoltaFinanziariaRadio = true;
          this.visibleConcessione = true;
          this.visibleLineaForbone = true;
        }
        this.controlDataChanged();
        this.difficoltaFinanziariaChange();
        console.log(this.anomaliaList);
      }, null, () => {
        if (this.anomaliaList && this.anomaliaList.anomaliaList && this.anomaliaList.anomaliaList.length > 0) {
          if (this.fetchedMutuiDetails.diff == false) {
            this.visibleConcessione = true;
          }
        }
      });
    });
  }

  initializeEvents() {
    // Difficolta Finanziaria Change event
    this.difficoltaFinanziariaChangeEvent = [
      { eventName: 'change', eventCallBack: this.difficoltaFinanziariaChange.bind(this) },
    ];

    // Concession Change event
    this.concessionEvent = [
      { eventName: 'change', eventCallBack: this.concessionCallBack.bind(this) },
    ];

    // Finalita Change event
    this.difficoltaFinanziariaEvent = [
      { eventName: 'change', eventCallBack: this.changeFinalita.bind(this) },
    ];

    // Nota Forbone Change event
    this.notaForboneEvent = [
      { eventName: 'change', eventCallBack: this.changeNotaForbone.bind(this) },
    ];

    this.confirmForborneEvents = [
      { eventName: 'click', eventCallBack: this.onConferma.bind(this) }
    ];
  }

  loadFinancingPurposeOptions() {
    this.forborneService.selectFinancingPurposeForCategory(this.fetchedMutuiDetails.macroCategory).subscribe(
      data => {
        let financingList: LoanPurposeModel[] = data;
        financingList.map(financingData =>
          this.finanziamentoList.push(
            {
              value: financingData['codice'],
              description: financingData['descrizione'],
              remodulation: financingData.remodulation
            }
          )
        );
        this.onLoad = false;
      }, null,
      () => {
        //  Check for remodulation Data
        const finalitaObj = this.finanziamentoList.find(obj => obj.value === this.fetchedMutuiDetails.finalita);
        if (finalitaObj) {
          this.remodulationForm = finalitaObj.remodulation;
        }
      });
  }

  loadEventOptions() {
    this.productConfiguartionService.selectCodiceDescrizione().subscribe(data => {
      let codeDescriptionList: CodiceDescrizione[] = data;
      this.loanEventList = codeDescriptionList.reduce((temp, e) => {
        if (e != null) {
          temp.push({ 'description': e.descrizione, 'value': e.codice });
        }
        return temp;
      }, []);
    }, null,
      () => {
        this.fetchedMutuiDetails.evento = this.fetchedMutuiDetails.evento;
      });
  }

  ngAfterContentChecked() {
    if (this.forborneDetection) {
      if (this.forborneDetection.form.controls['finalita'] && this.forborneDetection.form.controls['finalita'].value) {
        this.forborneDetection.form.controls['finalita'].setErrors(null);
        this.forborneDetection.form.controls['finalita'].markAsTouched({ onlySelf: true });
      }
      if (this.forborneDetection.form.controls['difficoltaFinanziaria'] && this.forborneDetection.form.controls['difficoltaFinanziaria'].value != null) {
        this.forborneDetection.form.controls['difficoltaFinanziaria'].setErrors(null);
        this.forborneDetection.form.controls['difficoltaFinanziaria'].markAsTouched({ onlySelf: true });
      }
      if (this.forborneDetection.form.controls['concession'] && this.forborneDetection.form.controls['concession'].value != null) {
        this.forborneDetection.form.controls['concession'].setErrors(null);
        this.forborneDetection.form.controls['concession'].markAsTouched({ onlySelf: true });
      }
      if (this.forborneDetection.form.controls['notaForbone'] && this.forborneDetection.form.controls['notaForbone'].value != null) {
        this.forborneDetection.form.controls['notaForbone'].setErrors(null);
        this.forborneDetection.form.controls['notaForbone'].markAsTouched({ onlySelf: true });
      }
      if (this.forborneDetection.form.controls['lineaForborne'] && this.forborneDetection.form.controls['lineaForborne'].value != null) {
        this.forborneDetection.form.controls['lineaForborne'].setErrors(null);
        this.forborneDetection.form.controls['lineaForborne'].markAsTouched({ onlySelf: true });
      }
      this.forborneDetection.form.updateValueAndValidity();
    }
    this.checkNotaInvalidClass();
  }

  // Difficolta Finanziaria change method call
  difficoltaFinanziariaChange() {
    if (this.fetchedMutuiDetails.diff === true) {
      this.visibleConcessione = true;
    } else if (this.fetchedMutuiDetails.diff === false) {
      this.visibleConcessione = false;
      this.forbornePef = true;
      this.visibleLineaForbone = true;
    }
    //se è presente l'anomalia LINEA_FORBORNE, abilito il checkbox visibleConcessione
    if (this.getLineaForborne() && this.fetchedMutuiDetails.diff != null) {
      this.visibleConcessione = true;
    }

    this.controlDataChanged();
    this.lineaForboneUpdate();
    this.changeFlagsStatus();
  }

  // Concession change method call
  concessionCallBack() {
    if (this.fetchedMutuiDetails.concess) {
      this.forbornePef = false;
    } else {
      this.forbornePef = true;
    }

    this.controlDataChanged();
    this.lineaForboneUpdate();
    console.log('form', this.forborneDetection.form);
    console.log('forbornePef', this.forbornePef);
  }

  // LineaForbone update method call
  lineaForboneUpdate() {
    if ((this.fetchedMutuiDetails.diff && this.fetchedMutuiDetails.concess) ||
      (this.getLineaForborne() && this.fetchedMutuiDetails.concess)) {
      this.fetchedMutuiDetails.lineaforbone = true;
      this.forbornePef = false;
      this.dialog.open(CommonMessagePopupComponent, {
        data: { message: this.msgLineaForborne, title: '' }
      });
    } else {
      this.fetchedMutuiDetails.lineaforbone = false;
    }
    if (this.getLineaForborne()) {
      if (this.fetchedMutuiDetails.concess) {
        this.fetchedMutuiDetails.lineaforbone = true;
      } else {
        this.fetchedMutuiDetails.lineaforbone = false;
      }
    }

    this.controlDataChanged();

    this.isLineaForborneSelected.emit(this.fetchedMutuiDetails.lineaforbone);
    this.isForborneSection.emit(this.fetchedMutuiDetails.lineaforbone && this.forbornePef);
  }

  // Finalità change method call
  changeFinalita() {
    const codice = this.fetchedMutuiDetails.finalita;
    const finalitaObj = this.finanziamentoList.find(obj => obj.value === codice);
    if (finalitaObj) {
      this.remodulationForm = (finalitaObj.remodulation) ? true : false;
      if (!this.remodulationForm) {
        this.fetchedMutuiDetails.evento = null;
      }
    } else {
      this.remodulationForm = false;
    }

    this.controlDataChanged();
    this.changeFlagsStatus();
    console.log('form', this.forborneDetection.form);
  }

  changeNotaForbone() {
    this.controlDataChanged();
  }

  onConferma() {
    const question = new ForborneQuestionList();
    question.difficoltàFinanziaria = this.fetchedMutuiDetails.diff;
    question.concessionConcession = this.fetchedMutuiDetails.concess;
    question.lineaForborne = this.fetchedMutuiDetails.lineaforbone;
    question.finalitàFinanziamento = this.fetchedMutuiDetails.finalita;
    question.notaForborne = this.fetchedMutuiDetails.notaforbone;
    question.loanEvent = this.fetchedMutuiDetails.evento;
    question.praticaId = this.idProposal;
    question.pefProposalId = this.idPef;
    question.ndgList = this.ndgList;
    question.rimodulazione = this.remodulationForm;
    question.istruttoriaAvviata = this.fetchedMutuiDetails.istruttoriaAvviata;
    const saveFunction = (questionInput: ForborneQuestionList) => {
      this.productConfiguartionService.saveForborne(questionInput).
        subscribe(() => {
          this.isConfermaValid = true;
          this.saveAndEmitFlags(true);
        }, error => {
          console.log('Error occured in saveForborne service call');
        });
    };
    saveFunction(question);
  }

  saveAndEmitFlags(flag: boolean) {
    this.isForborneSection.emit(flag && this.forbornePef);
  }

  changeFlagsStatus() {
    this.saveAndEmitFlags(false);
  }

  controlDataChanged() {
    this.isConfermaValid = false;
    if (this.anomaliaList && this.anomaliaList.anomaliaList && this.anomaliaList.anomaliaList.length > 0) {
      if (this.fetchedMutuiDetails.diff === null) {
        this.visibleNota = false;
        this.fetchedMutuiDetails.notaforbone = '';
      } else {
        this.visibleNota = true;
      }
      if (this.fetchedMutuiDetails.concess === true) {
        this.visibleNota = false;
        this.fetchedMutuiDetails.notaforbone = '';
      } else if (this.fetchedMutuiDetails.concess === false) {
        this.visibleNota = true;
      } else if (this.fetchedMutuiDetails.concess === null) {
        this.visibleNota = false;
        this.fetchedMutuiDetails.notaforbone = '';
      }

    } else {
      if (this.fetchedMutuiDetails.diff && this.forbornePef) {
        this.visibleNota = true;
      } else {
        this.visibleNota = false;
        this.fetchedMutuiDetails.notaforbone = '';
      }
    }
  }

  getLineaForborne() {
    if (this.anomaliaList) {
      let lineaPresente = this.anomaliaList.anomaliaList.find(anomalia => anomalia.anomalyType === 'LINEA_FORBORNE');
      if (this.ndgList.length > 0 && lineaPresente) {
        return true;
      }
    }
    return false;
  }

  checkNotaInvalidClass() {
    if (document.querySelector('input#notaForbone')) {
      const notaInputClassName = document.querySelector('input#notaForbone').className;
      if (notaInputClassName.includes('ng-invalid') || notaInputClassName.includes('is-invalid')) {
        this.notaForborneInvalid = true;
        this.notaInvalid.emit(this.notaForborneInvalid);
        return;
      }
    }
    this.notaForborneInvalid = false;
    this.notaInvalid.emit(this.notaForborneInvalid);
  }

}
