import { Component, OnInit } from '@angular/core';
import { DialogModel, DialogRef } from 'bstore-angular-library';
import { GuaranteesModel } from 'src/app/modules/vendita/models/guarantees.model';

@Component({
  selector: 'bst-fin-gurantees-list-popup',
  templateUrl: './gurantees-list-popup.component.html',
  styleUrls: ['./gurantees-list-popup.component.scss']
})
export class GuranteesListPopupComponent implements OnInit {

  guarantees: GuaranteesModel[] = [];
  rapporto: string;

  constructor(private dialogRef: DialogRef,
    private config: DialogModel) { }

  ngOnInit() {

    if (this.config.data.numeroRapporto) {
      this.rapporto = this.config.data.numeroRapporto;
    }

    if (this.config.data.guaranteesList && this.config.data.guaranteesList.length > 0) {
      this.config.data.guaranteesList.forEach(guaranteeValue => {
        if (guaranteeValue.numeroRapporto === this.rapporto) {
          this.guarantees.push(guaranteeValue);
        }
      });
    }
  }

  onClose() {
    this.dialogRef.close('Closed');
  }

}
