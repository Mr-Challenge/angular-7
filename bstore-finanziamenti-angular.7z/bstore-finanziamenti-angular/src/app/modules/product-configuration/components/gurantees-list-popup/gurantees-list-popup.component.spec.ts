import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GuranteesListPopupComponent } from './gurantees-list-popup.component';

describe('GuranteesListPopupComponent', () => {
  let component: GuranteesListPopupComponent;
  let fixture: ComponentFixture<GuranteesListPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GuranteesListPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GuranteesListPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
