import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecondaNotaPefComponent } from './seconda-nota-pef.component';

describe('SecondaNotaPefComponent', () => {
  let component: SecondaNotaPefComponent;
  let fixture: ComponentFixture<SecondaNotaPefComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecondaNotaPefComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondaNotaPefComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
