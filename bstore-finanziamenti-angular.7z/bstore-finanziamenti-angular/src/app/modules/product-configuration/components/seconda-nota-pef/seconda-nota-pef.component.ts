import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { MutuiDetailsModel } from '../../models/MutuiDetailsModel';
import { TextFieldModel } from '../../models/TextFieldModel';
import { MutuoDetails } from '../../models/MutuoDetails';
import { isNullOrUndefined, isUndefined } from 'util';
import { GaranziaFideiussoriaInAttoFuoriAttoModel } from '../../models/GaranziaFideiussoriaInAttoFuoriAttoModel';
import { CreditLineModel } from '../../models/CreditLineModel';
import { ProductConfiguartionService } from '../../services/product-configuartion.service';
import { CheckGaranziaFideiussoriaModel } from '../../models/CheckGaranziaFideiussoriaModel';
import { combineLatest } from 'rxjs';

@Component({
  selector: 'bst-fin-seconda-nota-pef',
  templateUrl: './seconda-nota-pef.component.html',
  styleUrls: ['./seconda-nota-pef.component.scss']
})
export class SecondaNotaPefComponent implements OnInit {

  @ViewChild('secondaNotaInput') secondaNotaInput: ElementRef;

  @Input() idProposal: string;
  @Input() isMutuiChiro: boolean;
  @Input() fetchedMutuiDetails: MutuiDetailsModel;

  @Output() secondaNotaValid: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() secondaNotaTextEmitter: EventEmitter<string> = new EventEmitter<string>();

  private dettaglioMutuo: MutuoDetails;
  private mutuiDetails: TextFieldModel[] = [];
  private modifiedMutuiDetails: string[] = [];
  private finalMutuiDetails: string;
  private listOfReportNumbers: any[] = [];
  private finalCreditLineData: string;
  private isFideiussioneInAtto: CheckGaranziaFideiussoriaModel;
  public textAreaSecondaNota: string;
  lentghRichiesto: number;

  private fidiDaSostituire: CreditLineModel[];

  constructor(private productConfigurationService: ProductConfiguartionService) { }

  ngOnInit() {
    combineLatest(
      this.productConfigurationService.getDettagliMutuo(),
      this.productConfigurationService.getFidiDaSostituire(),
      this.productConfigurationService.getDettMutuoInPage(),
      this.productConfigurationService.isFideiussioneInAtto(this.idProposal))
      .subscribe(([dettMutuo, fidiDaSost, dettMutuoInPage, fideInAtto]) => {
        this.dettaglioMutuo = dettMutuo;
        this.fidiDaSostituire = fidiDaSost;
        this.mutuiDetails = dettMutuoInPage;
        this.isFideiussioneInAtto = fideInAtto;

        this.createNewPracticalNote();
        this.secondaNotaTextEmitter.emit(this.textAreaSecondaNota);
        this.validateNota();
      });
  }

  createNewPracticalNote() {
    this.modifiedMutuiDetails = [];
    this.mutuiDetails.map(res => this.modifiedMutuiDetails.push(res.name + ' : ' + this.toImporto(res.value)));
    this.finalMutuiDetails = '\n\tIMPORTO INSERIMENTO PRE-VENDITA: ' +
      this.toImporto(this.fetchedMutuiDetails.amount) +
      '\n\t' + this.modifiedMutuiDetails.join('\n\t');

    let fidiDaSostituireToPrint;
    if (this.fidiDaSostituire.length > 0) {
      this.fidiDaSostituire.forEach(res => this.listOfReportNumbers.push(res.numeroRapporto));
      fidiDaSostituireToPrint = this.prepareFidiDaSostituireToPrint(this.fidiDaSostituire, this.listOfReportNumbers);
    }
    this.finalCreditLineData = this.listOfReportNumbers.join(',');

    let textAreaMessage = '- Numero Finanziamento FICS: ' +
      this.fetchedMutuiDetails.categoriaRapporto + '/' +
      this.fetchedMutuiDetails.numeroRapporto + '\n';
    textAreaMessage = textAreaMessage + '- Numero proposta DESK: ' + this.dettaglioMutuo.codiceSimulazioneDesk + '\n';

    if (this.isMutuiChiro) {
      // using double quotes to handle the single quotes inside the literal part
      const finalitaSpecifica = this.dettaglioMutuo.finalitaSpecifica ? ('-' + this.dettaglioMutuo.finalitaSpecifica) : '';
      textAreaMessage = textAreaMessage + "- Qual'è l'esigenza specifica del cliente? : " + this.dettaglioMutuo.esigenza 
      + finalitaSpecifica + '\n';
    } else {
      textAreaMessage = textAreaMessage + '- Importo perizia: ' +
        (isNullOrUndefined(this.dettaglioMutuo.appraisalAmount) ?
          'N.D.' : this.toImporto(this.dettaglioMutuo.appraisalAmount)) + '\n';
      textAreaMessage = textAreaMessage + '- Valore immobile presunto: ' + this.dettaglioMutuo.valoreImmobile + '\n';
      textAreaMessage = textAreaMessage + '- Immobile da ipotecare è ad uso abitativo: ' + this.dettaglioMutuo.usoAbitativo + '\n';
    }

    textAreaMessage = textAreaMessage + '- Dettaglio importi mutuo: ' + this.finalMutuiDetails + '\n';

    if (this.finalCreditLineData.length !== 0 && !isUndefined(fidiDaSostituireToPrint)) {
      textAreaMessage = textAreaMessage + '- Il finanziamento sostituisce le seguenti linee di fido : ' + fidiDaSostituireToPrint + '\n';
    }

    if (!isNullOrUndefined(this.dettaglioMutuo.codiciImmobiliAssociati)
      && this.dettaglioMutuo.codiciImmobiliAssociati.length !== 0) {
      textAreaMessage = textAreaMessage + '- Codice immobile: ';
      this.dettaglioMutuo.codiciImmobiliAssociati.forEach(res => {
        textAreaMessage = textAreaMessage + res + '; ';
      });
    }
    if (this.isMutuiChiro) {
      textAreaMessage = textAreaMessage + '\n- Sono presenti le seguenti garanzie: \n';
      textAreaMessage = textAreaMessage + '\n\t- Sono presenti le garanzie fideiussorie seguenti: \n';
      const garanzieFideiussorieText = this.populateNotaFideiussoria(this.isFideiussioneInAtto.listaGaranzieFideiussorie);
      textAreaMessage = textAreaMessage + garanzieFideiussorieText;
      textAreaMessage = textAreaMessage + '\n\t- Sono presenti le garanzie di pegno seguenti: \n';
      const garanzieNonFideiussorieText = this.populateNotaFideiussoria(this.isFideiussioneInAtto.listaGaranzieNonFideiussorie);
      textAreaMessage = textAreaMessage + garanzieNonFideiussorieText;
    } else {
      if (this.isFideiussioneInAtto.hasGaranziaFideiussoria) {
        textAreaMessage = textAreaMessage + '\n- Sono presenti le garanzie fideiussorie seguenti: \n';
        const garanzieFideiussorieText = this.populateNotaFideiussoria(this.isFideiussioneInAtto.listaGaranzieFideiussorie);
        textAreaMessage = textAreaMessage + garanzieFideiussorieText;
      }
    }

    this.lentghRichiesto = textAreaMessage.length + 20;
    let notaIntegrata = this.fetchedMutuiDetails.notaPratica;
    if (notaIntegrata) {
      let startIndex = notaIntegrata.lastIndexOf(textAreaMessage);
      if (startIndex != -1) {
        notaIntegrata = notaIntegrata.substr(textAreaMessage.length - 1);
        textAreaMessage = textAreaMessage + notaIntegrata;
      }
    }
    this.textAreaSecondaNota = textAreaMessage;
  }

  populateNotaFideiussoria(listaGaranzieFideiussorie: GaranziaFideiussoriaInAttoFuoriAttoModel[]) {
    let returnMessage = '';
    if (listaGaranzieFideiussorie) {
      listaGaranzieFideiussorie.forEach(element => {

        let inAttoFuoriAttoTxt = ', ' + (element.fideiussoriaInAtto ? 'In Atto' : 'Fuori Atto');
        if (this.isMutuiChiro) {
          inAttoFuoriAttoTxt = '';
        }
        let garantiLineTxt = '';
        element.garantiList.forEach((garante, index) => {
          const instestatarioGaranziaTxt = (garante.intestazioneGarante ? garante.intestazioneGarante : '');
          const ndgItestatarioTxt = (garante.ndgGarante ? '(' + garante.ndgGarante + ')' : '');
          garantiLineTxt = garantiLineTxt + instestatarioGaranziaTxt + ' ' + ndgItestatarioTxt;
          if (element.garantiList.length > 1 && index < element.garantiList.length - 1) {
            garantiLineTxt = garantiLineTxt + ', ';
          }
        });
        const garante = element.garantiList.length > 1 ? ', Garanti ' : ', Garante ';
        returnMessage = returnMessage + '\t- Garanzia ' + element.descrizioneEstesa + inAttoFuoriAttoTxt + garante + garantiLineTxt + ' \n';

      });
    }
    return returnMessage;
  }

  prepareFidiDaSostituireToPrint(substitutionCreditLineData: CreditLineModel[], listOfReportNumbers: any[]) {
    let returnString = '\n';
    // Il finanziamento sostituisce la linea di fido n°: 4851014,4851301
    substitutionCreditLineData.forEach(fido => {
      if (fido) {
        if (listOfReportNumbers.includes(fido.numeroRapporto)) {
          const fidoAmount = this.toImporto(fido.remainingDebt.replace('.', ','));
          returnString = returnString + '\t- n° ' +
            fido.numeroFido +
            ' / ' + fido.suffissoFido +
            ', tipologia linea: ' +
            fido.type +
            ', intestatario:' +
            (fido.holder ? fido.holder.descrizione : '') +
            ', debito residuo/accordato:' + fidoAmount + '\n';
        }
      }
    });

    return returnString;
  }

  toImporto(number: any) {
    if (number) {
      number = number.toString();
      return (new Intl.NumberFormat('it-IT', {
        style: 'currency', currency: 'EUR', useGrouping: true,
        maximumFractionDigits: 2
      }).format(parseFloat(number.replace(new RegExp('[.]', 'g'), '').replace(',', '.'))));
    }
  }

  validateNota() {
    this.resize();
    if (this.textAreaSecondaNota !== '' && this.textAreaSecondaNota.length >= this.lentghRichiesto) {
      this.secondaNotaValid.emit(true);
      this.secondaNotaTextEmitter.emit(this.textAreaSecondaNota);
    } else {
      this.secondaNotaValid.emit(false);
    }
  }

  resize() {
    this.secondaNotaInput.nativeElement.style.height = this.secondaNotaInput.nativeElement.scrollHeight + 'px';
    this.secondaNotaInput.nativeElement.style.overflow = 'hidden';
  }

}
