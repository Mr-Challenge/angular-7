import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductConfigurationPageComponent } from './pages/product-configuration-page/product-configuration-page.component';

const routes: Routes = [
  { path: ':proposalId', component: ProductConfigurationPageComponent },
  { path: '', component: ProductConfigurationPageComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductConfigurationRoutingModule { }
