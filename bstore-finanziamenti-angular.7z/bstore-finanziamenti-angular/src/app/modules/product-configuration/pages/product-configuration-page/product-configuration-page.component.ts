import { AfterViewChecked, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { NgForm, NgModelGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { BreadcrumbModel, DialogService } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { StatoMutuoType } from 'src/app/constant/statoMutuo';
import { NotificationVm } from 'src/app/models/notificationVm.model';
import { ModificaPropostaPopupComponent } from 'src/app/modules/modifica-proposta/components/modifica-proposta-popup/modifica-proposta-popup.component';
import { CommonService } from 'src/app/services/common.service';
import { environment } from 'src/environments/environment';
import { MutuiDetailsModel } from '../../models/MutuiDetailsModel';
import { Proponent } from '../../models/Proponent';
import { ProponenteModel } from '../../models/ProponenteModel';
import { ProductConfiguartionService } from '../../services/product-configuartion.service';
import { NotificationService } from 'src/app/services/notification.service';

@Component({
  selector: 'bst-fin-product-configuration-page',
  templateUrl: './product-configuration-page.component.html',
  styleUrls: ['./product-configuration-page.component.scss']
})
export class ProductConfigurationPageComponent implements OnInit, AfterViewChecked {

  @ViewChild('forborneForm') public forborneForm: NgModelGroup;
  @ViewChild('substitutionForm') public substitutionForm: NgForm;
  @ViewChild('productConfig') public productConfig: NgForm;
  @ViewChild('proponentForm') public proponentForm: NgForm;

  proponentList: Proponent[];
  isLoading = true;

  onChange: (value: any) => void;
  onTouched: () => void;
  domainName = environment.devUrlJSON['npv.service.callback.url'];
  approvalProcessStarted = false;
  idProposal: string;
  idPef: string;
  suffisoId: boolean;
  fetchedMutuiDetails: MutuiDetailsModel;
  onLoadMutui = false;
  showIncompleteForborne = false;
  showIncompleteProdotto = false;
  showIncompleteAmount = false;
  showIncompleteSubstitution = false;
  showIncompleteProponent = false;
  showIncompleteSoggetti = false;
  isMutuiChiro = false;

  Evento: NotificationVm;
  proponenteModel: ProponenteModel;
  idProdotto: number;
  avvioIstruttoriaEvent: EventsModel[] = [];
  dataAvvioIstruttoria: Date = new Date();

  notaPratica: string; // Nota nel popup
  textAreaSecondaNota: string; // Nota esterna
  secondaNotaValid = false;

  public breadcrumbs: BreadcrumbModel[];
  lineaForborneSelected: boolean = false;

  constructor(private productConfigurationService: ProductConfiguartionService,
    private route: ActivatedRoute, private commonService: CommonService,
    private dialog: DialogService, private cdr: ChangeDetectorRef, private notificationService: NotificationService) {
    const queryParam = this.route.snapshot.queryParams['idProposal'];
    if (queryParam) {
      this.idProposal = JSON.parse(queryParam);
    }
    if (this.idProposal === undefined) {
      this.route.params.subscribe(params => this.idProposal = params['proposalId']);
    }
    this.proponenteModel = new ProponenteModel();

    this.breadcrumbs = [{
      label: 'Indietro',
      url: `/immobili/${this.idProposal}`,
      enabled: true,
      externalLink: false
    }];
  }

  ngOnInit() {
    this.avvioIstruttoriaEvent = [
      { eventName: 'click', eventCallBack: this.setStatus.bind(this) }
    ];

    if (this.idProposal) {
      this.commonService.isMutuoIpotecario(this.idProposal.toString()).subscribe(data =>
        this.isMutuiChiro = !data
      );

      this.commonService.fetchMutuoDetails(this.idProposal).subscribe(data => {
        this.fetchedMutuiDetails = data;
        if (this.fetchedMutuiDetails.idPef) {
          this.idPef = this.fetchedMutuiDetails.idPef.toString();
          this.getNotaPraticaData(this.fetchedMutuiDetails.notaVP);
          this.approvalProcessStarted = this.fetchedMutuiDetails.istruttoriaAvviata;
          if (this.fetchedMutuiDetails.dataAvvioIstruttoria !== null) {
            this.dataAvvioIstruttoria = this.fetchedMutuiDetails.dataAvvioIstruttoria;
          }
          this.onLoadMutui = true;
          this.cdr.detectChanges(); // detect changes and show sections
          this.suffisoId = this.fetchedMutuiDetails.preFinaziamento;
          this.productConfigurationService.setIdpef(this.idPef);
          if (this.idPef) {
            this.productConfigurationService.loadProponent(this.idProposal, this.idPef).subscribe(dataResult => {
              this.proponentList = dataResult;
              this.isLoading = false;
              this.cdr.detectChanges(); // detect changes and show sections
            });
            if (this.fetchedMutuiDetails.idProdotto) {
              this.idProdotto = this.fetchedMutuiDetails.idProdotto;
              this.productConfigurationService.setIdProdotto(this.idProdotto);

              this.productConfigurationService.loadDettagliMutuo(this.idProposal, this.idPef).subscribe(data => {
                this.productConfigurationService.setDettagliMutuo(data);
              });
            }
          }
        }
        if (this.approvalProcessStarted) {
          this.notificationService.fetchStatus(this.fetchedMutuiDetails.idPef.toString(), this.idProposal);
          // To restore the proper mortgage status if the user decide to go in STEP 1
          if (this.fetchedMutuiDetails.status !== StatoMutuoType.IN_ATTESA_LAVORAZIONE_BPI) {
            this.restoreProperMortgageStatus();
          }
        }
      });

    }
  }

  restoreProperMortgageStatus() {
    this.commonService.updateMortgageStatus(this.idProposal, StatoMutuoType.IN_ATTESA_LAVORAZIONE_BPI).subscribe(response => {
      if (response) {
        console.log('Mortgage status restored to IN_ATTESA_LAVORAZIONE_BPI');
      }
    });
  }

  ngAfterViewChecked() {
    this.cdr.detectChanges();
  }

  setStatus() {
    this.productConfigurationService.changeProposalStatus(this.idProposal,
      StatoMutuoType.IN_ATTESA_LAVORAZIONE_BPI, this.notaPratica, this.textAreaSecondaNota, this.idPef).subscribe(data => {
        console.log(data);
        this.approvalProcessStarted = true;
        console.log('Istruttoria avviata su ID PEF: ' + this.idPef);
      });
  }

  showStatus(data) {
    this.showIncompleteProdotto = data;
  }

  showAmount(data) {
    this.showIncompleteAmount = data;
  }

  substitutionStatus(data) {
    this.showIncompleteSubstitution = data;
  }

  getNotaPraticaData(data) {
    this.notaPratica = data;
  }

  setSecondaNota(data: string) {
    this.textAreaSecondaNota = data;
  }

  setValiditySecondaNota(valid: boolean) {
    this.secondaNotaValid = valid;
  }

  isFlagForCreditLines(data) {
    this.showIncompleteProponent = data;
  }

  isForborneSection(data) {
    this.showIncompleteForborne = data;
  }

  isLineaForborneSelected(data) {
    this.lineaForborneSelected = data;
  }

  isAllVisualized(data) {
    this.showIncompleteSoggetti = data;
  }

  modificaPopup() {
    this.dialog.open(ModificaPropostaPopupComponent, {
      data: { idProposal: this.idProposal },
      noCloseButton: true,
      size: 'large'
    });
  }
}
