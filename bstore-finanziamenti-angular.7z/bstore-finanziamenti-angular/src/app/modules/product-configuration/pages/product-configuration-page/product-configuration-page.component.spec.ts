import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductConfigurationPageComponent } from './product-configuration-page.component';

describe('ProductConfigurationPageComponent', () => {
  let component: ProductConfigurationPageComponent;
  let fixture: ComponentFixture<ProductConfigurationPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductConfigurationPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductConfigurationPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
