import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'bst-fin-final-page',
  templateUrl: './final-page.component.html',
  styleUrls: ['./final-page.component.scss']
})
export class FinalPageComponent implements OnInit {

  proposalId: number;
  domainName = environment.devUrlJSON['npv.service.callback.url'];

  constructor(private route: ActivatedRoute) {
    this.route.params.subscribe(params => { this.proposalId = params['proposalId']; });
  }

  ngOnInit() {
  }

  getBackgroundImageUrl() {
    return `url(${environment.devUrlJSON['bstore.finanziamenti.angular.frontend.url'] + '/assets/img/sprite.png'})`;
  }
}
