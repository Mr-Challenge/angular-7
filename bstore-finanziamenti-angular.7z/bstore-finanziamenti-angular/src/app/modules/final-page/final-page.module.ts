import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FinalPageRoutingModule } from './final-page-routing.module';
import { FinalPageComponent } from './components/final-page-component/final-page.component';
import { SharedModule } from 'src/app/shared.module';

@NgModule({
  declarations: [
    FinalPageComponent
  ],
  imports: [
    CommonModule,
    FinalPageRoutingModule,
    SharedModule
  ]
})
export class FinalPageModule { }
