import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DelibraVoucher, DiniegoDocument } from 'src/app/models/generateDoc.model';
import { EndpointsService } from 'src/app/services/endpoints.service';
import { DeliberaVoucherDocument } from 'src/app/models/deliberaVoucherDocument';
@Injectable({
  providedIn: 'root'
})
export class DeliberaService {

  constructor(private httpClient: HttpClient, private endpointsService: EndpointsService) { }
  documentFlag: boolean;

  public getDeliberaStatus(idProposta: string) {
    const parameters = new HttpParams().append('idProposta', idProposta);
    return this.httpClient.get(this.endpointsService.getDeliberaStatus, { params: parameters, responseType: 'text' });
  }

  generateDeliberaVoucher(delibraVoucher: DelibraVoucher): Observable<any> {
    return this.httpClient.post<any>(this.endpointsService.voucherDelibera, delibraVoucher);
  }

  generateDiniego(diniegoDocument: DiniegoDocument): Observable<any> {
    return this.httpClient.post<any>(this.endpointsService.generateDiniego, diniegoDocument);
  }

  sendDocumentByEmail(deliberaVoucherDocument: DeliberaVoucherDocument): Observable<any>{
    return this.httpClient.post<any>(this.endpointsService.sendDocumentByEmail, deliberaVoucherDocument);
  }

  deleteProductFromFics(idProposta: string) {
    const parameter = new HttpParams().append('idProposta', idProposta.toString());
    return this.httpClient.get(this.endpointsService.deleteProductFromFics, { params: parameter});
  }

}
