import { DeliberaRoutingModule } from './delibera-routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeliberapageComponent } from './component/deliberapage/deliberapage.component';
import { BstoreCommonModule } from '../bstore-common/bstore-common.module';

@NgModule({
  declarations: [DeliberapageComponent],
  imports: [
    CommonModule,
    DeliberaRoutingModule,
    BstoreCommonModule
  ]
})
export class DeliberaModule { }
