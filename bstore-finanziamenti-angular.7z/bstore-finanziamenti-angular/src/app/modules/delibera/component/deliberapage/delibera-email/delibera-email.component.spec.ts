import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliberaEmailComponent } from './delibera-email.component';

describe('DeliberaEmailComponent', () => {
  let component: DeliberaEmailComponent;
  let fixture: ComponentFixture<DeliberaEmailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliberaEmailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliberaEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
