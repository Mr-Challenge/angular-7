import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonPopupComponent, DialogService, OpenPdfUrlService, RedirectService } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { SelectOptionModel } from 'bstore-angular-library/lib/models/select-option-model';
import { FinDocumentType } from 'src/app/constant/documentType';
import { MortgageStepWizard } from 'src/app/constant/mortgageStepWizard';
import { StatoMutuoType } from 'src/app/constant/statoMutuo';
import { TipoProcesso } from 'src/app/constant/tipoProcesso';
import { DelibraVoucher } from 'src/app/models/generateDoc.model';
import { NdgEmail } from 'src/app/models/ndgEmail.model';
import { AbbandonaPropostaService } from 'src/app/modules/abbandona-proposta/services/abbandona-proposta.service';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { SignatureStatusModel } from 'src/app/modules/vendita/models/signature-status.model';
import { PefService } from 'src/app/modules/vendita/services/pef.service';
import { CommonService } from 'src/app/services/common.service';
import { EndpointsService } from '../../../../services/endpoints.service';
import { DeliberaService } from '../../services/deliberaservice.service';
import { DeliberaEmailComponent } from './delibera-email/delibera-email.component';
import { ContrattiSignatureType } from 'bstore-angular-library/lib/models/contrattiSignatureType';
import { ContrattiSignatureInput } from 'bstore-angular-library/lib/models/contrattiSignatureInput.model';
@Component({
  selector: 'bst-fin-deliberapage',
  templateUrl: './deliberapage.component.html',
  styleUrls: ['./deliberapage.component.scss']
})
export class DeliberapageComponent implements OnInit {

  private voucherDocGen: boolean;
  private ndgEmails: NdgEmail[];
  private clientBaseModel: BaseClientModel[] = [];

  Motivazione: SelectOptionModel[] = [
    { value: 'Rifiuto per banche dati negative', description: 'Rifiuto per banche dati negative' },
    { value: 'Valutazione fiduciaria', description: 'Valutazione fiduciaria' }
  ];

  idProposta: number;
  mutuoChirografario: boolean;
  proposalApproved: boolean;
  disableChiudi = true;
  currentMotivazione: string;
  rifiutoFlag: boolean;
  valutazioneFlag: boolean;
  document: boolean;
  servicesLoaded: boolean;
  notaFiduciaria: string;

  voucherdocumentEvents: EventsModel[];
  emailPopupEvents: EventsModel[];
  NewPageEvents: EventsModel[];
  openDocumentEvents: EventsModel[];
  MotivazioneEventsOnDropDown: EventsModel[];
  openHomePageEvents: EventsModel[];

  @ViewChild(CommonPopupComponent) commonPopupComponent: CommonPopupComponent;
  @ViewChild('notaFiduciariaInput') notaFiduciariaInput: ElementRef;
  signatureStatusModel: SignatureStatusModel;
  contrattiSignatureInput: ContrattiSignatureInput;

  constructor(private dialogservice: DialogService, private commonService: CommonService,
    private deliberaservice: DeliberaService, private router: Router, private endpointsService: EndpointsService,
    private route: ActivatedRoute, private redirectService: RedirectService,
    private openPdfService: OpenPdfUrlService, private abbandonaPropostaService: AbbandonaPropostaService,
    private pefService: PefService) {
    this.route.params.subscribe((params) => { this.idProposta = params['proposalId']; });
    this.currentMotivazione = 'Rifiuto per banche dati negative';
    this.rifiutoFlag = true;
  }

  ngOnInit() {

    this.signatureStatusModel = new SignatureStatusModel();
    this.signatureStatusModel.processId = Number(this.idProposta);
    this.signatureStatusModel.processType = TipoProcesso.VENDITA;
    this.getContrattiSignatureInput();
    this.commonService.isMutuoIpotecario(this.idProposta.toString()).subscribe(result => {
      this.mutuoChirografario = !result;
    }, null, () => {
      this.commonService.retrieveAllClient(this.idProposta.toString()).subscribe(result => {
        this.clientBaseModel = result;
      }, null, () => {
        this.deliberaservice.getDeliberaStatus(this.idProposta.toString()).subscribe(response => {
          if (response === StatoMutuoType.PRATICA_DELIBERATA) {
            this.proposalApproved = true;
            if (!this.mutuoChirografario) {
              this.checkVoucherGeneration();
            }
          } else {
            this.proposalApproved = false;
          }
          this.commonPopupComponent.createObserver();
        }, null, () => {
          if (!this.proposalApproved) {
            this.commonService.fetchMutuoDetails(this.idProposta.toString()).subscribe(mutuo => {
              if (mutuo) {
                this.pefService.getNotaPratica(mutuo.idPef.toString(), 'FIDUCIARIA').subscribe(nota => {
                  if (nota) {
                    this.notaFiduciaria = nota;
                  }
                });
              }
              this.loadPage();
            });
          } else {
            this.loadPage();
          }
        });
      });
    });


    this.openDocumentEvents = [
      { eventName: 'click', eventCallBack: this.openDocument.bind(this) }
    ];
    this.MotivazioneEventsOnDropDown = [
      { eventName: 'change', eventCallBack: this.changeDropDown.bind(this) }
    ];
    this.voucherdocumentEvents = [
      { eventName: 'click', eventCallBack: this.generateVoucherDoc.bind(this) }
    ];
    this.emailPopupEvents = [
      { eventName: 'click', eventCallBack: this.emailPopup.bind(this) }
    ];
    this.NewPageEvents = [
      { eventName: 'click', eventCallBack: this.redirectToPostDelibera.bind(this) }
    ];
    this.openHomePageEvents = [
      { eventName: 'click', eventCallBack: this.openHomePage.bind(this) }
    ];

  }

  getContrattiSignatureInput() {

    const dossierDetails = {
      processId: this.signatureStatusModel.processId,
      processType: this.signatureStatusModel.processType,
      dossierGenerationList: []
    }

    this.commonService.getContrattiSignatureInput(dossierDetails).subscribe(flagInput => {
      this.contrattiSignatureInput = {
        isFeqEnabled: flagInput.feqEnabled,
        isSendOnly: flagInput.sendOnly,
        isSignatureInProgress: flagInput.signatureInProgress,
        signatureInProgressType: flagInput.signatureInProgressType
        // sendMailForSecci: true
      }
    });
  }

  onClickFirmaAltreModalita(signType: ContrattiSignatureType) {
    if (signType) {
      // this.sendOrSignDocument(true, signType);
    }
  }

  onClickRaccogliMancanti(signType: ContrattiSignatureType) {
    if (signType) {
      // this.sendOrSignDocument(true, signType);
    }
  }

  onClickInviaMail() {
    console.log("Stampa action");
    this.generateVoucherDoc();
  }

  loadPage() {
    this.servicesLoaded = true;
    this.commonPopupComponent.createObserver();
  }

  checkVoucherGeneration() {
    const data = <SignatureStatusModel>{
      processId: this.idProposta,
      processType: TipoProcesso.VENDITA,
      docToGenerate: [FinDocumentType.VOUCHER_DELIBERA]
    };
    this.commonService.checkDocumentGenerationStatus(data).subscribe(result => {
      this.voucherDocGen = result;
    });
  }

  openHomePage() {
    this.commonService.updateMortgageStatus(this.idProposta.toString(), StatoMutuoType.ANNULLATO).subscribe(response => {
      if (response) {
        this.goToHomePage();
      }
    });
  }

  goToHomePage() {
    this.redirectService.redirectWithSpinner(this.endpointsService.homePage);
  }

  redirectToPostDelibera() {
    this.commonService.updateMortgageStatus(this.idProposta.toString(), StatoMutuoType.PRATICA_POST_DELIBERA).subscribe(response => {
      if (response) {
        this.commonService.updateProposalStep(this.idProposta.toString(), MortgageStepWizard.ELEVEN).subscribe(responseStep => {
          if (responseStep) {
            this.router.navigate(['/postDelibera', this.idProposta]);
          }
        });
      }
    });
  }

  generateVoucherDoc() {
    const voucherDelibera = new DelibraVoucher();
    voucherDelibera.idProposta = this.idProposta;
    voucherDelibera.customers = this.clientBaseModel;
    voucherDelibera.docGenerated = this.voucherDocGen;
    voucherDelibera.fea = false;
    this.deliberaservice.generateDeliberaVoucher(voucherDelibera).subscribe(response => {
      const urlList: string[] = [];
      response.forEach((url: string) => {
        urlList.push(url);
      });
      this.openPdfService.openPdfDocuments(urlList);
    });
  }

  emailPopup() {
    this.ndgEmails = [];
    this.clientBaseModel.forEach(element => {
      if (!element.cointestazione) {
        const ndgEmailObj = new NdgEmail();
        ndgEmailObj.ndg = element.ndg;
        if (element.email) {
          ndgEmailObj.emailId = element.email;
        } else {
          ndgEmailObj.emailId = '';
        }
        this.ndgEmails.push(ndgEmailObj);
      }
    });
    if (this.ndgEmails != null) {
      this.dialogservice.open(DeliberaEmailComponent, {
        data: {
          'idProposta': this.idProposta,
          'ndgEmails': this.ndgEmails,
          'clientBaseList': this.clientBaseModel,
          'docGenerated': this.voucherDocGen
        },
        size: 'large',
        title: 'INVIA EMAIL',
      });
    }
  }

  changeDropDown() {
    if (this.currentMotivazione === 'Rifiuto per banche dati negative') {
      this.rifiutoFlag = true;
      this.valutazioneFlag = false;
    } else if (this.currentMotivazione === 'Valutazione fiduciaria') {
      this.valutazioneFlag = true;
      this.rifiutoFlag = false;
    }
    this.disableChiudi = true;
  }

  openDocument() {
    if (this.rifiutoFlag) {
      this.abbandonaPropostaService.rifiutoFlagTrueProcess(this.idProposta, this.clientBaseModel);
      this.disableChiudi = false;
    } else if (this.valutazioneFlag) {
      this.abbandonaPropostaService.valutazioneFlagTrueProcess(this.idProposta, this.clientBaseModel);
      this.disableChiudi = false;
    }
    this.deliberaservice.deleteProductFromFics(this.idProposta.toString()).subscribe();
  }

  resize() {
    this.notaFiduciariaInput.nativeElement.style.height = this.notaFiduciariaInput.nativeElement.scrollHeight + 'px';
    this.notaFiduciariaInput.nativeElement.style.overflow = 'hidden';
  }

}
