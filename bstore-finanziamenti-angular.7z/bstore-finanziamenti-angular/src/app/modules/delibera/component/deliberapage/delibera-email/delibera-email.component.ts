import { Component, OnInit } from '@angular/core';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { NdgEmail } from 'src/app/models/ndgEmail.model';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { DialogModel, DialogRef } from 'bstore-angular-library';
import { DeliberaVoucherDocument } from 'src/app/models/deliberaVoucherDocument';
import { DeliberaService } from '../../../services/deliberaservice.service';
import { DelibraVoucher } from 'src/app/models/generateDoc.model';

@Component({
  selector: 'bst-fin-delibera-email',
  templateUrl: './delibera-email.component.html',
  styleUrls: ['./delibera-email.component.scss']
})
export class DeliberaEmailComponent implements OnInit {

  emailIdEvent: EventsModel[] = [];
  annullaEvent: EventsModel[] = [];
  inviaEvent: EventsModel[] = [];
  ndgEmails: NdgEmail[];
  clientBaseList: BaseClientModel[];
  inviaEmailFlag: boolean;
  idProposal: number;
  docGenerated: boolean;
  constructor(private config: DialogModel, private dialog: DialogRef, private deliberaservice: DeliberaService) {
    this.ndgEmails = [];
    this.clientBaseList = [];
   }

  ngOnInit() {
    this.emailIdEvent = [
      { eventName: 'change', eventCallBack: this.changeEmailId.bind(this) }
    ];
    this.annullaEvent = [
      { eventName: 'click', eventCallBack: this.closeModel.bind(this) }
    ];
    this.inviaEvent = [
      { eventName: 'click', eventCallBack: this.inviaEmail.bind(this) }
    ];
    this.ndgEmails = this.config.data.ndgEmails;
    this.clientBaseList = this.config.data.clientBaseList;
    this.idProposal = +this.config.data.idProposta;
    this.docGenerated = this.config.data.docGenerated;
    this.validateEmail();
  }

  changeEmailId(input) { 
    this.validateEmail();
  }
  
  inviaEmail(input){

    this.ndgEmails.forEach(ndgObj => {
      this.clientBaseList.forEach(clientBase => {
        if (clientBase.ndg === ndgObj.ndg) {
          clientBase.email = ndgObj.emailId;
        }
      });
    });
    
   const deliberaVoucherDocument = new DeliberaVoucherDocument();
   deliberaVoucherDocument.idProposal = this.idProposal;
   deliberaVoucherDocument.clientList = this.clientBaseList;
   deliberaVoucherDocument.isFea = false;
   deliberaVoucherDocument.docGenerated = this.docGenerated;
   console.log(deliberaVoucherDocument);
   this.deliberaservice.sendDocumentByEmail(deliberaVoucherDocument).subscribe(response => {
     console.log(response);
     this.closeModel('');
   },
    error => {
      console.log('Error Occur while sendingEmail In deliebra email component');
    });
  }
  
  stampa() {
    const voucherDelibera = new DelibraVoucher();
    voucherDelibera.idProposta = this.idProposal;
    voucherDelibera.customers = this.clientBaseList;
    voucherDelibera.docGenerated = false;
    voucherDelibera.fea = false;
    this.deliberaservice.generateDeliberaVoucher(voucherDelibera).subscribe((response) => {
      const urlList: Array<string> = [];
          for (const key in response) {
            urlList.push(response[key]);
          }
          urlList.forEach((url) => {
            window.open(url, '_blank');
          });
    }, error => {
        console.log('Error Occur while generateDeliberaVoucher ');
    });
  }

  closeModel(input) {
    this.dialog.close('Closed');
  }

  validateEmail() {
    this.inviaEmailFlag = true;
    this.ndgEmails.forEach((ndgEmail) => {
      if (ndgEmail.emailId.length > 0 && !this.checkEmailIdPattern(ndgEmail.emailId)) {
        this.inviaEmailFlag = false;
        return;
      }
    });
  }

  checkEmailIdPattern(emailId): boolean {
    const pattern = /^$|^(?!.{59})([a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)$/;
    if (emailId && pattern.test(emailId) === false) {
      return true;
    }
    return false;
  }

}
