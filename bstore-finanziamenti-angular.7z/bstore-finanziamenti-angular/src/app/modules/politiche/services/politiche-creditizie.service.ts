import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EndpointsService } from '../../../services/endpoints.service';
import { PoliticheCreditizie } from '../models/politicheCreditizie';
@Injectable({
  providedIn: 'root'
})
export class PoliticheCreditizieService {

  textNote: string;

  constructor(public httpClient: HttpClient, private endpointsService: EndpointsService) {
    this.textNote = 'default';
  }

  public getPoliticheCreditizie(idProposta: string) {
    const parameters = new HttpParams().append('idProposta', idProposta);
    return this.httpClient.get<PoliticheCreditizie>(this.endpointsService.loadPoliticheCreditizie, { params: parameters });
  }

  public saveNotePoliticheCreditizie(idProposal: string, step: string, textNote: string, numeroPratica: string) {
    const parameters = new HttpParams().append('idProposal', idProposal).append('step', step)
      .append('textNote', textNote).append('numeroPratica', numeroPratica);
    return this.httpClient.get<any>(this.endpointsService.saveNotePoliticheCreditizie, { params: parameters });
  }

}
