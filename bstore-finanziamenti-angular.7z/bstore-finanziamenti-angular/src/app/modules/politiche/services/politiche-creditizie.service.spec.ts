import { TestBed } from '@angular/core/testing';

import { PoliticheCreditizieService } from './politiche-creditizie.service';

describe('PoliticheCreditizieService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PoliticheCreditizieService = TestBed.get(PoliticheCreditizieService);
    expect(service).toBeTruthy();
  });
});
