export class PoliticheCreditizie {
  giudizioIndirizzo: string;
  descrizioneIndirizzo: string;
  dettaglio: string;
  macrosegmento: string;
  settore: string;
  semaforoSettoreAttivitaEconomica: string;
  fascia: string;
  semaforoClasseRating: string;
  coerenza: string;
  areaGeografica: string;
  semaforoAreaGeografica: string;
  sowtarget: string;
  quotaMax: string;
  sowproposta: string;
  quotomedia: string;
  effettivo: string;
  teorico: string;
  flagEccezione: Boolean;
  numeroPratica: string;
  descrizioneCoerenzaPc: string;
  semaforoCoerenzaPc: string;
  notaCreditizia: string;
}
