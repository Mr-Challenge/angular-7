import { BstoreCommonModule } from './../bstore-common/bstore-common.module';
import { PoliticheRoutingModule } from './politiche-routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PolitichecreditizieComponent } from './component/politichecreditizie/politichecreditizie.component';

@NgModule({
  declarations: [PolitichecreditizieComponent],
  imports: [
    CommonModule,
    BstoreCommonModule,
    PoliticheRoutingModule
  ]
})
export class PoliticheModule { }