import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BreadcrumbModel, DialogService } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { PartiCorrelate } from 'src/app/models/PartiCorrelate';
import { ModificaPropostaPopupComponent } from 'src/app/modules/modifica-proposta/components/modifica-proposta-popup/modifica-proposta-popup.component';
import { PartiCorrelateServiceService } from 'src/app/modules/parti-correlate/services/parti-correlate-service.service';
import { RestituisciBpiPopupSectionComponent } from 'src/app/modules/restituisci-bpi-popup-section/restituisci-bpi-popup-section.component';
import { CommonService } from 'src/app/services/common.service';
import { environment } from 'src/environments/environment';
import { PoliticheCreditizie } from '../../models/politicheCreditizie';
import { PoliticheCreditizieService } from './../../services/politiche-creditizie.service';
import { MortgageStepWizard } from 'src/app/constant/mortgageStepWizard';

@Component({
  selector: 'bst-fin-politichecreditizie',
  templateUrl: './politichecreditizie.component.html',
  styleUrls: ['./politichecreditizie.component.scss']
})
export class PolitichecreditizieComponent implements OnInit {

  politicheCreditizie: PoliticheCreditizie;
  partiCorrelate: PartiCorrelate;
  dettaglio = 'COERENTE';
  idProposal: string;
  openBPIPopup: EventsModel[] = [];
  goToPartiCorrelate: EventsModel[] = [];
  domainName = environment.devUrlJSON['npv.service.callback.url'];
  breadcrumbs: BreadcrumbModel[];

  constructor(private router: Router, private partiCorrelateService: PartiCorrelateServiceService,
    private commonService: CommonService, private politichecreditizieservice: PoliticheCreditizieService,
    private dialogservice: DialogService, private route: ActivatedRoute) {
    this.politicheCreditizie = new PoliticheCreditizie();
    this.partiCorrelate = new PartiCorrelate();
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.idProposal = params['proposalId'];
    });

    this.goToPartiCorrelate = [
      { eventName: 'click', eventCallBack: this.saveNotePoliticheCreditizie.bind(this) }
    ];

    this.openBPIPopup = [
      { eventName: 'click', eventCallBack: this.openRestituisciBPIPopup.bind(this) }
    ];

    if (this.idProposal) {
      this.politichecreditizieservice.getPoliticheCreditizie(this.idProposal).subscribe((data) => {
        this.politicheCreditizie = data;
      });
    }

    this.breadcrumbs = [
      {
        label: 'Indietro',
        url: `/sintesi/${this.idProposal}`,
        enabled: true,
        externalLink: false
      }
    ];
  }

  openRestituisciBPIPopup() {
    this.dialogservice.open(RestituisciBpiPopupSectionComponent, {
      data: { idProposal: this.idProposal, idPef: this.politicheCreditizie.numeroPratica },
      size: 'large',
      title: 'PROPOSTA ' + this.idProposal + ' RESTITUITA CON MODIFICA',
    });
  }

  saveNotePoliticheCreditizie() {
    this.politichecreditizieservice.textNote = this.politicheCreditizie.notaCreditizia;
    if (this.idProposal) {
      this.politichecreditizieservice.saveNotePoliticheCreditizie(this.idProposal,
        MortgageStepWizard.SIX, this.politichecreditizieservice.textNote, this.politicheCreditizie.numeroPratica).subscribe(data => {
          if (data) {
            this.partiCorrelateService.getPartiCorrelate(this.idProposal).subscribe((resp) => {
              this.partiCorrelate = resp;
              if (this.canISkipPartiCorrelate(this.partiCorrelate)) {
                this.redirectToRilevazioneForborne();
              } else {
                this.redirectToPartiCorrelate();
              }
            });
          }
        });
    }
  }

  private canISkipPartiCorrelate(partiCorrelate: PartiCorrelate) {
    if (partiCorrelate.listaSoggettoRilevante === null &&
      partiCorrelate.notaCorrelazione === '' &&
      partiCorrelate.numeroElementiTotali === 0 &&
      partiCorrelate.outputDaisy === '') {
      return true;
    } else {
      return false;
    }
  }

  abbandonaPropostaPopup() {
    localStorage.setItem('previousPage', 'politiche');
    this.router.navigate(['/abbandona', this.idProposal]);
  }

  modificaPopup() {
    this.dialogservice.open(ModificaPropostaPopupComponent, {
      data: { idProposal: this.idProposal },
      noCloseButton: true,
      size: 'large'
    }
    );
  }

  redirectToRilevazioneForborne() {
    this.commonService.updateProposalStep(this.idProposal, MortgageStepWizard.SEVEN).subscribe();
    this.router.navigate(['/rilevazioneForborne', this.idProposal]);
  }

  redirectToPartiCorrelate() {
    this.router.navigate(['/partiCorrelate', this.idProposal]);
  }

}
