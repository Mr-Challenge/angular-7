import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PolitichecreditizieComponent } from './politichecreditizie.component';

describe('PolitichecreditizieComponent', () => {
  let component: PolitichecreditizieComponent;
  let fixture: ComponentFixture<PolitichecreditizieComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PolitichecreditizieComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PolitichecreditizieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
