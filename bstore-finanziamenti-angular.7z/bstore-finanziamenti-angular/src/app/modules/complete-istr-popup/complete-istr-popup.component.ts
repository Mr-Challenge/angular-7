import { Component, OnInit } from '@angular/core';
import { DialogModel, DialogRef, RedirectService } from 'bstore-angular-library';
import { NotificationVm } from 'src/app/models/notificationVm.model';
import { CommonService } from 'src/app/services/common.service';
import { EndpointsService } from 'src/app/services/endpoints.service';

@Component({
  selector: 'bst-fin-complete-istr-popup',
  templateUrl: './complete-istr-popup.component.html',
  styleUrls: ['./complete-istr-popup.component.scss']
})
export class CompleteIstrPopupComponent implements OnInit {

  ProposalId: string;
  updatedResult: boolean;
  notificaVm: NotificationVm;
  notifica: String;

  constructor(public dialogRef: DialogRef, private commonService: CommonService, public config: DialogModel,
    private redirectService: RedirectService, private endpointsService: EndpointsService) { }

  ngOnInit() {
    this.ProposalId = this.config.data.idProposal;
    this.notificaVm = this.config.data.notificaVm;
    this.notificaVm.idPraticaBstore = this.ProposalId;
    this.notifica = this.notificaVm.notifica;
  }

  onClose() {
    this.redirectService.redirectWithSpinner(this.endpointsService.homePage);
  }

  modificaProposta() {
    this.commonService.updateProposalStepStatusAfterNotification(this.notificaVm).subscribe(response => {
      if (response) {
        this.redirectService.redirectWithSpinner('/sintesi/' + this.ProposalId);
      }
    });
  }

}
