import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompleteIstrPopupComponent } from './complete-istr-popup.component';

describe('CompleteIstrPopupComponent', () => {
  let component: CompleteIstrPopupComponent;
  let fixture: ComponentFixture<CompleteIstrPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompleteIstrPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompleteIstrPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
