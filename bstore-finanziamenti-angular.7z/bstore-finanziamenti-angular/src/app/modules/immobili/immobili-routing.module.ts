import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ImmobiliStartingPageComponent } from './components/immobili-starting-page/immobili-starting-page.component';
import { ImmobileCensusComponent } from './components/immobile-census/immobile-census.component';
import { ImmobileDetailComponent } from './components/immobile-detail/immobile-detail.component';

const routes: Routes = [
  { path: ':proposalId', component: ImmobiliStartingPageComponent },
  { path: ':proposalId/nuovoImmobile', component: ImmobileCensusComponent },
  { path: ':proposalId/dettaglio/:codiceImmobile', component: ImmobileDetailComponent },
  { path: ':proposalId/:codiceImmobile', component: ImmobiliStartingPageComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ImmobiliRoutingModule { }
