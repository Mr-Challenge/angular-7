import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImmobiliSearchComponent } from './immobili-search.component';

describe('ImmobiliSearchComponent', () => {
  let component: ImmobiliSearchComponent;
  let fixture: ComponentFixture<ImmobiliSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImmobiliSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImmobiliSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
