import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { SelectOptionModel } from 'bstore-angular-library/lib/models/select-option-model';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { ImmobiliService } from '../../services/immobili-service';
import { CercaImmobileInput } from '../../models/cercaImmobileInput.model';
import { ImmobiliSearchType } from 'src/app/models/immobiliSearchTypeEnum.model';
import { CorporateSearchResult } from 'src/app/models/corporateSearchResult';
import { CercaImmobileOutput } from '../../models/cercaImmobileOutput';

@Component({
  selector: 'bst-fin-immobili-search',
  templateUrl: './immobili-search.component.html',
  styleUrls: ['./immobili-search.component.scss']
})
export class ImmobiliSearchComponent implements OnInit {
  searchFlag: boolean;
  searchdata: string;
  myErrorMessage: string;
  showErrorMessages: boolean;
  searchBoxPlaceholder: string;

  corporateSearchResults: CorporateSearchResult[];
  corporateSearches: Array<CorporateSearchResult> = [];
  searchOptionKey: string;
  cercaImmobileOutputList: CercaImmobileOutput[];
  @Output() listCercaImmobileOutput = new EventEmitter();

  constructor(private immobiliService: ImmobiliService) {
    this.searchFlag = false;
  }

  dropDownEvents: EventsModel[];
  searchEvents: EventsModel[];
  searchInput: EventsModel[];
  searchOptions: SelectOptionModel[] = [
    {
      value: 'COGNOME E NOME',
      description: 'COGNOME E NOME'
    },
    {
      value: 'NDG',
      description: 'NDG'
    },
    {
      value: 'CODICE IMMOBILE',
      description: 'CODICE IMMOBILE'
    }
  ];

  ngOnInit() {
    this.searchInput = [
      { eventName: 'keydown', eventCallBack: this.searchInputData.bind(this) }
    ];

    this.dropDownEvents = [
      { eventName: 'change', eventCallBack: this.dropDownChange.bind(this) }
    ];

    this.searchEvents = [
      { eventName: 'click', eventCallBack: this.OnSearchClick.bind(this) }
    ];

    this.searchOptionKey = this.searchOptions.find(obj => obj.description === 'COGNOME E NOME').value;
    this.searchBoxPlaceholder = 'Es. Rossi Mario';
    this.myErrorMessage = 'Inserire almeno tre lettere per poter effettuare la ricerca';
  }

  /* entered input to be searched */
  searchInputData(input, event) {
    if (event.code === 'Enter') {
      this.OnSearchClick();
    }
  }

  /* dropdown change event */
  dropDownChange(input, event) {
    this.searchdata = '';
    this.searchFlag = false;
    if (event.target.value === 'COGNOME E NOME') {
      this.searchBoxPlaceholder = 'Es. Rossi Mario';
    } else if (event.target.value === 'NDG') {
      this.searchBoxPlaceholder = 'Es. 11977299';
    } else {
      this.searchBoxPlaceholder = 'Es. 2510001';
    }
  }

  /* clicked on search button */
  OnSearchClick() {
    if (this.searchdata.length !== 0) {
      if (this.searchOptionKey === 'COGNOME E NOME') {
        this.searchClientDataFromName();
      } else {
        const cercaImmobileInput = new CercaImmobileInput();
        if (this.searchOptionKey === 'NDG') {
          cercaImmobileInput.searchType = ImmobiliSearchType.NDG;
        } else {
          cercaImmobileInput.searchType = ImmobiliSearchType.CODICE_IMMOBILE;
        }
        cercaImmobileInput.searchKey = this.searchdata;
        this.cercaImmobile(cercaImmobileInput);
      }
    }
  }

  /* REST call to searchClientDataFromName */
  searchClientDataFromName() {
    if (this.searchdata.length > 0) {
      this.immobiliService.searchClientDataFromName(this.searchdata).
        subscribe(response => {
          this.corporateSearchResults = response.body;
        },
          error => {
            console.log('Error occured in searchClientDataFromName service call');
          }, () => {
            console.log(this.corporateSearchResults);
            if (this.corporateSearchResults && this.corporateSearchResults.length > 0) {
              this.searchFlag = true;
            } else {
              this.searchFlag = false;
            }
          });
    }
  }

  /* on clicked on cerca link */
  cerca(corporateSearchResult: CorporateSearchResult) {
    const cercaImmobileInput = new CercaImmobileInput();
    cercaImmobileInput.searchKey = corporateSearchResult.ndg;
    cercaImmobileInput.searchType = ImmobiliSearchType.NDG;
    this.cercaImmobile(cercaImmobileInput);
  }

  /* REST call to cercaImmobile */
  cercaImmobile(cercaImmobileInput: CercaImmobileInput) {
    this.immobiliService.cercaImmobile(cercaImmobileInput).
      subscribe(response => {
        this.cercaImmobileOutputList = response;
      }, error => {
        console.log('Error occured in cercaImmobile service call');
      }, () => {
        // use this list 'this.cercaImmobileOutputList' to render page
        if (this.cercaImmobileOutputList.length > 0) {
          this.listCercaImmobileOutput.emit(this.cercaImmobileOutputList);
        }
      });
  }
}
