import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonPopupComponent } from 'bstore-angular-library';

@Component({
  selector: 'bst-fin-immobile-detils',
  templateUrl: './immobile-detail.component.html',
  styleUrls: ['./immobile-detail.component.scss']
})

export class ImmobileDetailComponent implements OnInit {

  proposalId: string;

  @ViewChild(CommonPopupComponent) commonPopupComponent: CommonPopupComponent;

  constructor(public route: ActivatedRoute) {
    this.route.params.subscribe(params => {
      this.proposalId = params['proposalId'];
    });
  }

  ngOnInit() {
  }

}
