import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImmobileDetailComponent } from './immobile-detail.component';

describe('ImmobileDetailComponent', () => {
  let component: ImmobileDetailComponent;
  let fixture: ComponentFixture<ImmobileDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImmobileDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImmobileDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
