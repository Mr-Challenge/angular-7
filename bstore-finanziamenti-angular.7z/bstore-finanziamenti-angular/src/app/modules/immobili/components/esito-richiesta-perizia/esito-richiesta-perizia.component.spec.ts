import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EsitoRichiestaPeriziaComponent } from './esito-richiesta-perizia.component';

describe('EsitoRichiestaPerizia', () => {
  let component: EsitoRichiestaPeriziaComponent;
  let fixture: ComponentFixture<EsitoRichiestaPeriziaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EsitoRichiestaPeriziaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EsitoRichiestaPeriziaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
