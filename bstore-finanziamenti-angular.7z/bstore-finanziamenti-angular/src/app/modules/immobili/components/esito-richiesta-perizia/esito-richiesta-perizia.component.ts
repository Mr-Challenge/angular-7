import { Component, OnInit, Input } from '@angular/core';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { DialogRef, DialogModel } from 'bstore-angular-library';
import { Router } from '@angular/router';
import { ImmobiliService } from '../../services/immobili-service';
import { CommonService } from 'src/app/services/common.service';
import { StatoMutuoType } from 'src/app/constant/statoMutuo';

@Component({
  selector: 'bst-fin-esito-richiesta-perizia',
  templateUrl: './esito-richiesta-perizia.component.html',
  styleUrls: ['./esito-richiesta-perizia.component.scss']
})
export class EsitoRichiestaPeriziaComponent implements OnInit {

  message: string;
  okEvents: EventsModel[] = [];

  constructor(public dialog: DialogRef, private commonService: CommonService, public immobiliService: ImmobiliService, public router: Router, public config: DialogModel) { }

  ngOnInit() {

    if (this.config.data.id !== undefined) {
      this.message = 'Richiesta ' + this.config.data.id + ' confermata e inviata con successo';
    }

    this.okEvents = [
      { eventName: 'click', eventCallBack: this.periziaOkPopup.bind(this) }
    ];

  }
  periziaOkPopup() {
    const statoMutuoPerizia: string = this.config.data.callbackUrl === '/postDelibera' ?
      StatoMutuoType.IN_ATTESA_ESITO_PERIZIA_POST_DELIBERA : StatoMutuoType.IN_ATTESA_ESITO_PERIZIA_PRE_DELIBERA;

    this.commonService.updateMortgageStatus(this.config.data.proposalId, statoMutuoPerizia).subscribe(response => {
      if (response) {
        this.router.navigateByUrl(this.config.data.callbackUrl + '/' + this.config.data.proposalId).then(e => {
          if (e) {
            this.dialog.close('Closed');
          }
        });
      }
    }, () => {
      console.log('Error While Calling Update Mortgage Status Service');
    });
  }

}
