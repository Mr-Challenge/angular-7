import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImmobiliStartingPageComponent } from './immobili-starting-page.component';

describe('ImmobiliStartingPageComponent', () => {
  let component: ImmobiliStartingPageComponent;
  let fixture: ComponentFixture<ImmobiliStartingPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImmobiliStartingPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImmobiliStartingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
