import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogService, BreadcrumbModel } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { InterviewService } from 'src/app/modules/interview/services/interview.service';
import { ModificaPropostaPopupComponent } from 'src/app/modules/modifica-proposta/components/modifica-proposta-popup/modifica-proposta-popup.component';
import { CodeDescription } from 'src/app/modules/product-configuration/models/CodeDescription';
import { environment } from 'src/environments/environment';
import { EndpointsService } from '../../../../services/endpoints.service';
import { CercaImmobileOutput } from '../../models/cercaImmobileOutput';
import { ImmobiliService } from '../../services/immobili-service';
import { InviaPeriziaComponent } from '../invia-perizia/invia-perizia.component';
import { CommonService } from 'src/app/services/common.service';
import { StatoMutuoType } from 'src/app/constant/statoMutuo';
import { MortgageStepWizard } from 'src/app/constant/mortgageStepWizard';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { SezioneImmobiliChiroPopUpComponent } from '../sezione-immobili-chiro-pop-up/sezione-immobili-chiro-pop-up.component';

@Component({
  selector: 'bst-fin-immobili-starting-page',
  templateUrl: './immobili-starting-page.component.html',
  styleUrls: ['./immobili-starting-page.component.scss']
})
export class ImmobiliStartingPageComponent implements OnInit {

  modificaEvents: EventsModel[] = [];
  configuraProdottoEvents: EventsModel[] = [];
  indietroUrl: string;
  aggiungiImmobileDisabled: boolean;
  aggiungiImmobile: EventsModel[] = [];
  proposalId: string;
  interviewAdditionalData: CodeDescription[] = [];
  finalitaPrevalente: CodeDescription;
  ClientBaseList: BaseClientModel[] = [];
  cercaImmobileOutputList: CercaImmobileOutput[] = [];
  domainName = environment.devUrlJSON['npv.service.callback.url'];
  flagConfiguraProdotto = true;
  showBreadcrumbAndTooltip = false;
  hideRichiediPerizia = false;
  public breadcrumbs: BreadcrumbModel[];
  isMutuiChiro: boolean;
  codiceImmobili?: string;

  constructor(public dialog: DialogService, private commonService: CommonService,
    public immobiliService: ImmobiliService, public interviewService: InterviewService,
    public router: Router, public route: ActivatedRoute,
    private endpointsService: EndpointsService) {
    this.route.params.subscribe(params => {
      this.proposalId = params['proposalId'];
      this.codiceImmobili = params['codiceImmobile'];
      this.indietroUrl = this.endpointsService.openVendita + this.proposalId;
    });
  }

  ngOnInit() {
    this.aggiungiImmobileDisabled = true;

    this.modificaEvents = [
      { eventName: 'click', eventCallBack: this.immobileModifica.bind(this) }
    ];

    this.configuraProdottoEvents = [
      { eventName: 'click', eventCallBack: this.goToConfiguraProdotto.bind(this) }
    ];

    this.aggiungiImmobile = [
      { eventName: 'click', eventCallBack: this.nuovoImmobile.bind(this) }
    ];

    if (!this.showBreadcrumbAndTooltip) {
      this.breadcrumbs = [{
        label: 'Indietro',
        url: `/vendita/${this.proposalId}`,
        enabled: true,
        externalLink: false
      }];
    } else {
      this.breadcrumbs = [{
        label: 'Indietro',
        url: `/vendita/${this.proposalId}`,
        enabled: false,
        externalLink: false
      }];
    }

    this.commonService.isMutuoIpotecario(this.proposalId).subscribe(response => {
        this.isMutuiChiro = !response;
    });

    if(this.codiceImmobili != undefined && this.codiceImmobili != null){
      this.dialog.open(SezioneImmobiliChiroPopUpComponent, {
      data: {proposalId: this.proposalId, codiceImmobile: this.codiceImmobili},
      noCloseButton: true,
      size: 'large'
    });
  }
  }

  showInviaPeriziaPopup(input) {
    this.dialog.open(InviaPeriziaComponent, {
      title: 'INVIA PERIZIA'
    });
  }


  immobileModifica() {
    this.immobiliService.setImmobileDetailPage('modifica');
    this.router.navigate(['/immobili', this.proposalId, 'dettaglio']);
  }

  nuovoImmobile() {
    this.router.navigate(['/immobili', this.proposalId, 'nuovoImmobile']);
  }

  goToConfiguraProdotto() {
    this.commonService.updateMortgageStatus(this.proposalId, StatoMutuoType.CONFIGURAZIONE_PRODOTTO).subscribe(response => {
      if (response) {
        this.commonService.updateProposalStep(this.proposalId, MortgageStepWizard.THREE).subscribe(response => {
          if (response) {
            this.router.navigate(['/product', this.proposalId]);
          }
        },
          error => {
            console.log('Error While Calling Update Proposal Step Service');
          });
      }
    },
      error => {
        console.log('Error While Calling Update Mortgage Status Service');
      });
  }


  modificaPopup() {
    const dialogRef = this.dialog.open(ModificaPropostaPopupComponent, {
      data: { idProposal: this.proposalId },
      noCloseButton: true,
      size: 'large'
    }
    );
  }

  // all output events

  listCercaImmobileOutput(list: CercaImmobileOutput[]) {
    this.cercaImmobileOutputList = list;
  }

  configuraProdottoFlag(configuraProdottoFlag: boolean) {
    this.flagConfiguraProdotto = configuraProdottoFlag;
  }

  breadcrumbAndTooltip(breadcrumbAndTooltip: boolean) {
    this.showBreadcrumbAndTooltip = breadcrumbAndTooltip;
  }

  aggiungiImmobileFlag(aggiungiImmobileFlag: boolean) {
    this.aggiungiImmobileDisabled = aggiungiImmobileFlag;
  }
}
