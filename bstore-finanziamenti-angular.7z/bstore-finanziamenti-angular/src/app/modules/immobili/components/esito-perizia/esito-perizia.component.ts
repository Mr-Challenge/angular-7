import { Component, OnInit, Input } from '@angular/core';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { DialogRef, DialogModel } from 'bstore-angular-library';
import { Router } from '@angular/router';


@Component({
  selector: 'bst-fin-esito-perizia',
  templateUrl: './esito-perizia.component.html',
  styleUrls: ['./esito-perizia.component.scss']
})
export class EsitoPeriziaComponent implements OnInit {


  message: string;
  okEvents: EventsModel[] = [];
  constructor(public dialog: DialogRef, public router: Router, public config: DialogModel) { }

  ngOnInit() {

    if (this.config.data.id !== undefined) {
      this.message = 'Richiesta ' + this.config.data.id + ' inserita con successo';
    }

    this.okEvents = [
      { eventName: 'click', eventCallBack: this.PeriziaOkPopup.bind(this) }
    ];

  }
  PeriziaOkPopup(input) {
    // to redirect to immobili page
    if (this.config.data.request === 'infoRichasta') {
      this.router.navigateByUrl('/immobili').then(e => {
        if (e) {
          this.dialog.close('Closed');
        }
      }
      );
    } else {
      this.dialog.close('Closed');
    }
  }

}
