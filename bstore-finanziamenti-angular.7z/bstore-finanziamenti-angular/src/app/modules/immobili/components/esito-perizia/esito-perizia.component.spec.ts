import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EsitoPeriziaComponent } from './esito-perizia.component';

describe('EsitoPeriziaComponent', () => {
  let component: EsitoPeriziaComponent;
  let fixture: ComponentFixture<EsitoPeriziaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EsitoPeriziaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EsitoPeriziaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
