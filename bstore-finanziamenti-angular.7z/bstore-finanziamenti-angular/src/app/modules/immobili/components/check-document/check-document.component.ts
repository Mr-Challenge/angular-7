import { Component, OnInit } from '@angular/core';
import { DialogRef } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';

@Component({
  selector: 'bst-fin-check-document',
  templateUrl: './check-document.component.html',
  styleUrls: ['./check-document.component.scss']
})
export class CheckDocumentComponent implements OnInit {
  okEvents: EventsModel[] = [];
  constructor(public dialog: DialogRef) { }

  ngOnInit() {
    this.okEvents = [
      {eventName: 'click', eventCallBack: this.closeOkDocument.bind(this)},
    ];
  }
  closeOkDocument(input) {
    this.dialog.close('closed');
  }

}
