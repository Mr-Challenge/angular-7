import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DettaglioImmobileButtonComponent } from './dettaglio-immobile-button.component';

describe('DettaglioImmobileButtonComponent', () => {
  let component: DettaglioImmobileButtonComponent;
  let fixture: ComponentFixture<DettaglioImmobileButtonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DettaglioImmobileButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DettaglioImmobileButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
