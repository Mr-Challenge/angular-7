import { Component, OnInit, Input } from '@angular/core';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { ImmobiliService } from '../../services/immobili-service';
import { Router } from '@angular/router';

@Component({
  selector: 'bst-fin-dettaglio-immobile-button',
  templateUrl: './dettaglio-immobile-button.component.html',
  styleUrls: ['./dettaglio-immobile-button.component.scss']
})
export class DettaglioImmobileButtonComponent implements OnInit {

  @Input() codiceImmobile: string;
  @Input() proposalId: string;
  @Input() callBackUrl: string;

  dettaglioEvent: EventsModel[] = [];

  constructor(private immobiliService: ImmobiliService, private router: Router) { }

  ngOnInit() {
    this.dettaglioEvent = [
      { eventName: 'click', eventCallBack: this.dettaglioImmobile.bind(this) }
    ];
  }

  dettaglioImmobile() {
    this.immobiliService.setImmobileDetailPage('dettaglio');
    this.router.navigate([this.callBackUrl, this.proposalId, 'dettaglio', this.codiceImmobile]);
  }

}
