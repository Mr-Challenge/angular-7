import { Component, OnInit } from '@angular/core';
import { DialogRef, DialogService } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { CheckDocumentComponent } from '../check-document/check-document.component';

@Component({
  selector: 'bst-fin-upload-document',
  templateUrl: './upload-document.component.html',
  styleUrls: ['./upload-document.component.scss']
})
export class UploadDocumentComponent implements OnInit {
  annullaEvents: EventsModel[] = [];
  okEvents: EventsModel[] = [];
  constructor(public dialog: DialogRef, public dialogservice: DialogService) { }

  ngOnInit() {
    this.annullaEvents = [
      { eventName: 'click', eventCallBack: this.close.bind(this) }
    ];
    this.okEvents = [
      { eventName: 'click', eventCallBack: this.okClose.bind(this) },
      { eventName: 'click', eventCallBack: this.showCheckUploadedDocumentPopup.bind(this) }
    ];
  }

  close(input) {
    this.dialog.close('closed');
  }

  okClose() {
    this.dialog.close('close on ok');
  }

  showCheckUploadedDocumentPopup(input) {
    this.dialogservice.open(CheckDocumentComponent, {
      title: 'Upload documento'
    });
  }
}
