import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RichiediPeriziaButtonComponent } from './richiedi-perizia-button.component';

describe('RichiediPeriziaButtonComponent', () => {
  let component: RichiediPeriziaButtonComponent;
  let fixture: ComponentFixture<RichiediPeriziaButtonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RichiediPeriziaButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RichiediPeriziaButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
