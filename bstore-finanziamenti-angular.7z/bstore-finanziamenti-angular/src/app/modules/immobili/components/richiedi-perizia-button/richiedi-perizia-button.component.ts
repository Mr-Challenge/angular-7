import { Component, OnInit, Input } from '@angular/core';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { PeriziaPopupComponent } from '../perizia-popup/perizia-popup.component';
import { DialogService } from 'bstore-angular-library';
import { ImmobiliService } from '../../services/immobili-service';
import { PeriziaService } from 'src/app/modules/richiedi-perizia/services/perizia.service';
import { PeriziaProcessStatus } from 'src/app/modules/richiedi-perizia/models/periziaProcessStatus';
import { RichiestaPeriziaProcessStatus } from 'src/app/modules/richiedi-perizia/models/richiestaPeriziaProcessStatus';
@Component({
  selector: 'bst-fin-richiedi-perizia-button',
  templateUrl: './richiedi-perizia-button.component.html',
  styleUrls: ['./richiedi-perizia-button.component.scss']
})
export class RichiediPeriziaButtonComponent implements OnInit {

  @Input() codiceImmobile: string;
  @Input() proposalId: string;
  @Input() disableButton: boolean;
  @Input() callBackUrl: string;
  @Input() statoPerizia: string;

  richiediPeriziaEvent: EventsModel[] = [];

  listaProprietari: any;
  richiestaPeriziaProcessStatus: RichiestaPeriziaProcessStatus;
  isDipendente: Boolean;
  hideRadioButton: boolean;

  constructor(private dialog: DialogService, private immobiliService: ImmobiliService, private periziaService: PeriziaService) { }

  ngOnInit() {
    this.richiediPeriziaEvent = [
      { eventName: 'click', eventCallBack: this.richiediPerizia.bind(this) }
    ];

    this.immobiliService.getImmobiliDetails(this.codiceImmobile).subscribe(data => {
      this.listaProprietari = data.listaProprietari;
    }, null, () => {
      this.periziaService.getRichiestaPeriziaProcessStatus(this.codiceImmobile, this.statoPerizia).subscribe(response => {
        this.richiestaPeriziaProcessStatus = response;
      }, null, () => {
        if (this.richiestaPeriziaProcessStatus.status === PeriziaProcessStatus.INITIAL) {
          this.periziaService.checkForConvenzioneDipendenti(this.listaProprietari).subscribe(data => {
            if (data) {
              this.isDipendente = true;
            } else {
              this.isDipendente = null;
            }
          });
        } else {
          this.hideRadioButton = true;
        }
      });
    });
  }

  richiediPerizia() {
    this.dialog.open(PeriziaPopupComponent, {
      size: 'large',
      noCloseButton: true,
      data: {
        proposalId: this.proposalId, codiceImmobile: this.codiceImmobile, callBackUrl: this.callBackUrl,
        statoPerizia: this.statoPerizia, isDipendente: this.isDipendente, hideRadioButton: this.hideRadioButton
      }
    });
  }

}
