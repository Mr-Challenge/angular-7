import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SezioneImmobiliChiroPopUpComponent } from './sezione-immobili-chiro-pop-up.component';

describe('SezioneImmobiliChiroPopUpComponent', () => {
  let component: SezioneImmobiliChiroPopUpComponent;
  let fixture: ComponentFixture<SezioneImmobiliChiroPopUpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SezioneImmobiliChiroPopUpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SezioneImmobiliChiroPopUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
