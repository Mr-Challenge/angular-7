import { Component, OnInit } from '@angular/core';
import { DialogRef, DialogModel } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { Router } from '@angular/router';
import { StatoMutuoType } from 'src/app/constant/statoMutuo';
import { MortgageStepWizard } from 'src/app/constant/mortgageStepWizard';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'bst-fin-sezione-immobili-chiro-pop-up',
  templateUrl: './sezione-immobili-chiro-pop-up.component.html',
  styleUrls: ['./sezione-immobili-chiro-pop-up.component.scss']
})
export class SezioneImmobiliChiroPopUpComponent implements OnInit {

  nuovoImmobili: EventsModel[] = [];
  configuraProdottoEvents: EventsModel[] = [];

  proposalId: string;
  codiceImmobile: string;

  constructor(public dialog: DialogRef, public config: DialogModel, public router: Router,private commonService: CommonService) { 
    this.proposalId = this.config.data.proposalId;
    this.codiceImmobile = this.config.data.codiceImmobile;
    console.log(this.config.data.proposalId);  
  }

  ngOnInit() {

    this.nuovoImmobili = [
      { eventName: 'click', eventCallBack: this.nuovoImmobile.bind(this) }
      
    ];
    this.configuraProdottoEvents = [
      { eventName: 'click', eventCallBack: this.goToConfiguraProdotto.bind(this) }
    ];

  }


   
  nuovoImmobile() {
    this.router.navigate(['/immobili', this.proposalId, 'nuovoImmobile']);
    this.dialog.close('Closed');

  }

  goToConfiguraProdotto() {
    this.commonService.updateMortgageStatus(this.proposalId, StatoMutuoType.CONFIGURAZIONE_PRODOTTO).subscribe(response => {
      if (response) {
        this.commonService.updateProposalStep(this.proposalId, MortgageStepWizard.THREE).subscribe(response => {
          if (response) {
            this.router.navigate(['/product', this.proposalId]);
          }
        },
          error => {
            console.log('Error While Calling Update Proposal Step Service');
          });
      }
    },
      error => {
        console.log('Error While Calling Update Mortgage Status Service');
      });
      this.dialog.close('Closed');
  }

}
