import { Component, OnInit } from '@angular/core';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { DialogRef, DialogService, DialogModel } from 'bstore-angular-library';
import { EsitoPeriziaComponent } from '../esito-perizia/esito-perizia.component';

@Component({
  selector: 'bst-fin-invia-perizia',
  templateUrl: './invia-perizia.component.html',
  styleUrls: ['./invia-perizia.component.scss']
})
export class InviaPeriziaComponent implements OnInit {
  annullaEvents: EventsModel[] = [];
  okEvents: EventsModel[] = [];
  id: string;
  constructor(public dialog: DialogRef, public dialogservice: DialogService, public config: DialogModel) { }
  ngOnInit() {
    this.annullaEvents = [
      { eventName: 'click', eventCallBack: this.close.bind(this) }
    ];
    this.okEvents = [
      { eventName: 'click', eventCallBack: this.ok.bind(this) }
    ];

  }
  close(input) {
    this.dialog.close('closed');
  }
  ok(input) {
    this.dialog.close('ok');
  }
}


