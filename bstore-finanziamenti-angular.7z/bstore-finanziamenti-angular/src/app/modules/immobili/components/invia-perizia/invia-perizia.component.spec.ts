import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InviaPeriziaComponent } from './invia-perizia.component';

describe('InviaPeriziaComponent', () => {
  let component: InviaPeriziaComponent;
  let fixture: ComponentFixture<InviaPeriziaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InviaPeriziaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InviaPeriziaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
