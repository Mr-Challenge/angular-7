import { AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonPopupComponent, TextInputComponent } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { SelectOptionModel } from 'bstore-angular-library/lib/models/select-option-model';
import { environment } from 'src/environments/environment';
import { AssociaImmobili } from '../../models/associaImmobili';
import { CercaImmobileOutput } from '../../models/cercaImmobileOutput';
import { Data } from '../../models/data.model';
import { DestinazioneEconomicaPrevalente } from '../../models/destinazioneEconomicaPrevalente.enum';
import { Disponibilita } from '../../models/disponibilita.enum';
import { Fonte } from '../../models/fonte.enum';
import { Geographical } from '../../models/geographical.model';
import { ImmobileDetail } from '../../models/immobiledetail.model';
import { ImpiegoAttivita } from '../../models/impiegoAttivita.enum';
import { StatoImmobile } from '../../models/statoImmobile.enum';
import { TipoImmobile } from '../../models/tipoImmobile.enum';
import { TipoProprieta } from '../../models/tipoProprieta.enum';
import { TipoProprietario } from '../../models/tipoProprietario.enum';
import { Valutazione } from '../../models/valutazione.model';
import { ImmobiliService } from '../../services/immobili-service';
import { CommonService } from 'src/app/services/common.service';
import { ClientRole } from 'src/app/models/clientRole.enum';

declare var $: any;
@Component({
  selector: 'bst-fin-immobile-census',
  templateUrl: './immobile-census.component.html',
  styleUrls: ['./immobile-census.component.scss']
})
export class ImmobileCensusComponent implements OnInit, AfterViewInit {

  tipoImmobileSelect: SelectOptionModel[] = [];
  statoImmobileSelect: SelectOptionModel[] = [];
  disponibilitaSelect: SelectOptionModel[] = [];
  impiegoAttivitaSelect: SelectOptionModel[] = [];
  destinazioneEconomicaPrevalenteSelect: SelectOptionModel[] = [];
  fonteSelect: SelectOptionModel[] = [];
  tipoProprietaSelect: SelectOptionModel[] = [];
  ndgProprietaSelect: SelectOptionModel[] = [];
  provinciaList: Geographical[] = [];
  provinciaSelect: SelectOptionModel[] = [];
  provinciaEvent: EventsModel[] = [];
  comuneList: Geographical[] = [];
  comuneSelect: SelectOptionModel[] = [];
  tipoImmobile: string;
  statoImmobile: string;
  disponibilita: string;
  destinazioneEconomicaPrevalente: string;
  fonte: string;
  tipoProprieta: string;
  provincia: string;
  comune: string;
  confermaEvent: EventsModel[] = [];
  immobileDetails: ImmobileDetail;
  proposalId: string;
  codiceImmobili: string;
  isMutuiChiro: boolean;

  domainName = environment.devUrlJSON['npv.service.callback.url'];
  tipoEvent: EventsModel[] = [];
  tipoErrorMsg: string;
  superficieEvent: EventsModel[] = [];
  superficieErrorMsg: string;
  nrEvent: EventsModel[] = [];
  nrErrorMsg: string;
  vaniEvent: EventsModel[] = [];
  vaniErrorMsg: string;
  indirizzoEvent: EventsModel[] = [];
  indirizzoErrorMsg: string;
  numeroCivicoEvent: EventsModel[] = [];
  numeroCivicoErrorMsg: string;
  capEvent: EventsModel[] = [];
  capErrorMsg: string;
  statoImmobileEvent: EventsModel[] = [];
  statoImmobileErrorMsg: string;
  economicaPrevalenteEvent: EventsModel[] = [];
  economicaPrevalenteErrorMsg: string;
  commercialeEvent: EventsModel[] = [];
  commercialeErrorMsg: string;
  meseEvent: EventsModel[] = [];
  meseErrorMsg: string;
  annoEvent: EventsModel[] = [];
  annoErrorMsg: string;
  fonteEvent: EventsModel[] = [];
  fonteErrorMsg: string;
  cercaImmobileOutputList: CercaImmobileOutput[];
  SelezionatoEvent: EventsModel[] = [];
  aggiungiEvent: EventsModel[] = [];
  selezionatos: boolean;
  showAssociaProposta: boolean;
  selezionatoList: CercaImmobileOutput[];
  quotaEvent: EventsModel[] = [];
  quotaValidation: boolean;
  proprietarioList: any = [
    { ndg: '', descrizione: '', tipoProprietario: '', quota: '', flagAcquistoVendita: '' }
  ];
  @ViewChild('immobileCensus') form: NgForm;
  @ViewChild('superficie') superficie: TextInputComponent;
  @ViewChild('no') no: TextInputComponent;
  @ViewChild(CommonPopupComponent) commonPopupComponent: CommonPopupComponent;

  valid: boolean = false;
  allClientList: any[] = [];
  ndgProprietaEvent: EventsModel[] = [];

  proprietariAnagraficaCache: any = {};

  constructor(private immobiliService: ImmobiliService, private commonService: CommonService, public route: ActivatedRoute,
    public router: Router, private cdRef: ChangeDetectorRef) {
    this.route.params.subscribe(params => this.proposalId = params['proposalId']);
  }

  ngOnInit() {

    window.scrollTo(0, 0);
    this.immobileDetails = new ImmobileDetail();
    this.immobileDetails.idProposta = this.proposalId;
    const valutazione = new Valutazione();
    const data = new Data();
    this.immobileDetails.valutazione = valutazione;
    this.immobileDetails.valutazione.data = data;
    this.quotaValidation = false;
    this.showAssociaPropostaSection();
    this.fillNdgProprietaList();
    this.provinciaEvent = [
      { eventName: 'change', eventCallBack: this.getComuneByProvinces.bind(this) }
    ];

    this.confermaEvent = [
      { eventName: 'click', eventCallBack: this.conferma.bind(this) }
    ];

    this.SelezionatoEvent = [
      { eventName: 'change', eventCallBack: this.Selezionato.bind(this) }
    ];

    this.ndgProprietaEvent = [
      { eventName: 'change', eventCallBack: this.updateAnagrafica.bind(this) }
    ];

    this.aggiungiEvent = [
      { eventName: 'click', eventCallBack: this.aggiungiImmobili.bind(this) }
    ];

    this.quotaEvent = [
      { eventName: 'blur', eventCallBack: this.quotaCheck.bind(this) }
    ];

    this.superficieEvent = [
      { eventName: 'blur', eventCallBack: this.controllaColore.bind(this) },
      { eventName: 'click', eventCallBack: this.controllaColore.bind(this) }
    ];

    this.nrEvent = [
      { eventName: 'blur', eventCallBack: this.controllaColore.bind(this) },
      { eventName: 'click', eventCallBack: this.controllaColore.bind(this) }
    ];

    this.fillDropDownList();
    /* Provincia dropDown values */
    this.getProvincesByNation();
  }

  ngAfterViewInit() {
    this.form.statusChanges.subscribe(() => {
      if (this.form) {
        this.valid = this.form.invalid || this.quotaValidation;
        if (!this.valid && (this.superficie.dataModel || this.no.dataModel)) {
          this.valid = false;
        } else {
          this.valid = true;
        }
      }
    }, error => { }, () => {
      this.commonPopupComponent.createObserver();
    });
  }

  controllaColore() {
    if (!(this.superficie.dataModel) && (this.superficie.templateRef.touched || this.superficie.templateRef.dirty)) {
      $("#superficie").addClass("is-invalid");
    } else {
      $("#superficie").removeClass("is-invalid");
    }
    if (!(this.superficie.dataModel) && (this.no.templateRef.touched || this.no.templateRef.dirty)) {
      $("#nr").addClass("is-invalid");
    } else {
      $("#nr").removeClass("is-invalid");
    }
    if (this.superficie.dataModel || this.no.dataModel) {
      $("#nr").removeClass("is-invalid");
      $("#superficie").removeClass("is-invalid");
    }
  }

  /* EVENT FUNCTION TO FILTER CHECKED CERCAIMMOBILEOUTPUT FROM LIST */
  Selezionato(input, event) {
    this.selezionatoList = this.cercaImmobileOutputList.filter(obj => obj.selezionatoFlag === true);
    if (this.selezionatoList.length > 0) {
      this.selezionatos = true;
    } else {
      this.selezionatos = false;
    }
  }

  /* EVENT FUNCTION TO PASS CHECKED CERCAIMMOBILEOUTPUT FROM LIST USING REST CALL TO AssociaImmobili */
  aggiungiImmobili() {
    const codiceList: number[] = [];
    const associaImmobili = new AssociaImmobili();
    associaImmobili.idProposta = +this.proposalId;
    this.selezionatoList.forEach(obj => {
      if (obj.selezionatoFlag) {
        codiceList.push(Number(obj.codice));
      }
    });
    associaImmobili.immobiliCodeList = codiceList;
    this.immobiliService.associaImmobili(associaImmobili).
      subscribe(response => {
        if (response) {
          this.router.navigate(['/immobili', this.proposalId]);
        }
      }, error => {
        console.log('Error occured in aggiungiImmobili service call');
      }, () => {

      });
  }

  fillDropDownList() {
    this.setDropDownList(this.tipoImmobileSelect, TipoImmobile);
    this.setDropDownList(this.statoImmobileSelect, StatoImmobile);
    this.setDropDownList(this.disponibilitaSelect, Disponibilita);
    this.setDropDownList(this.impiegoAttivitaSelect, ImpiegoAttivita);
    this.setDropDownList(this.destinazioneEconomicaPrevalenteSelect, DestinazioneEconomicaPrevalente);
    this.setDropDownList(this.fonteSelect, Fonte);
    this.setDropDownList(this.tipoProprietaSelect, TipoProprieta);
  }

  /* This Method is use to set dropdownvalue base on the enum as input parameter*/
  setDropDownList(inputSelect: SelectOptionModel[], enumName: any) {
    Object.keys(enumName).filter(key => {
      inputSelect.push({ 'description': enumName[key], 'value': key });
    });
  }

  /* This method is used to fill Provincia dropDown values  */
  getProvincesByNation() {
    const geographical = new Geographical();
    geographical.codice = '086';
    this.immobiliService.getProvincesByNation(geographical).subscribe(data => {
      this.provinciaList = data;
      if (this.provinciaList != null) {
        this.provinciaSelect = this.provinciaList.reduce((temp, e) => {
          if (e.codice != null && e.descrizione != null) {
            temp.push({ 'description': e.descrizione, 'value': e.codice });
          }
          return temp;
        }, []);
      }
    }, error => {
      console.log('error while calling getProvincesByNation', error);
    });
  }

  /* This method is used to fill Comune dropDown values based on  Provincia selected   */
  getComuneByProvinces(input, event) {
    const codice = event.target.value;
    if (codice != null) {
      const geographical = new Geographical();
      geographical.codice = codice;
      this.immobiliService.getComuneByProvinces(geographical).subscribe(data => {
        this.comuneList = data;
        if (this.comuneList != null) {
          this.comuneSelect = this.comuneList.reduce((temp, e) => {
            if (e.codice != null && e.descrizione != null) {
              temp.push({ 'description': e.descrizione, 'value': e.descrizione });
            }
            return temp;
          }, []);
        }
      },
        error => {
          console.log('error while calling getProvincesByNation', error);
        });
    }

  }

  addRiga() {
    this.proprietarioList.push({});
  }

  conferma() {
    if (this.immobileDetails.no !== undefined && this.immobileDetails.vani !== undefined) {
      this.immobileDetails.numeroVani = this.immobileDetails.no + '.' + this.immobileDetails.vani;
    }
    this.immobileDetails.listaProprietari = this.proprietarioList;
    this.immobileDetails.listaProprietari.forEach(element => {
      if (element.acquiVendi === undefined || element.acquiVendi === '') {
        element.flagAcquistoVendita = null;
      } else if (element.acquiVendi.toUpperCase() === 'A') {
        element.flagAcquistoVendita = TipoProprietario['0'];
      } else if (element.acquiVendi.toUpperCase() === 'V') {
        element.flagAcquistoVendita = TipoProprietario['1'];
      }
    });
    this.immobiliService.inserisciImmobile(this.immobileDetails).subscribe(
      data => {
          console.log(data);        
          this.codiceImmobili = data;
          this.router.navigate(['/immobili', this.proposalId, ...(this.isMutuiChiro ? [this.codiceImmobili] : [])]);
      },
      error => {
        console.log('error while calling inserisciImmobile', error);
      });
  }

  onSubmit(immobilieDetailsForm: NgForm) {
    console.log('onSubmit');
  }

  /* FUNCTION TO GET LIST FROM CHILD COMPONENT */
  listCercaImmobileOutput(listCercaImmobileOutput) {
    this.cercaImmobileOutputList = listCercaImmobileOutput;
  }

  /* Delete Riga row using trash icon */
  deleteRiga(index) {

    // clear proprietari anagrafe cache
    const ndg = this.proprietarioList[index].ndg;
    if (ndg) {
      delete this.proprietariAnagraficaCache[ndg];
    }

    this.proprietarioList.splice(index, 1);
    this.quotaCheck();
  }

  onImmobile() {
    this.router.navigate(['/immobili', this.proposalId]);
  }

  quotaCheck() {
    let quotaCount = 0;
    this.proprietarioList.forEach(element => {
      if (element) {
        quotaCount = Number(quotaCount) + Number(element.quota);
      }
    });
    if (quotaCount === 100) {
      this.quotaValidation = false;
    } else {
      this.quotaValidation = true;
    }
    this.cdRef.detectChanges();
  }

  trackByFn(index, item) {
    return index; // or item.id
  }

  fillNdgProprietaList() {
    this.commonService.retrieveAllClient(this.proposalId).subscribe(response => {
      this.allClientList = response;
      console.log(response);
    }, null, () => {
      if (this.allClientList != null) {
        this.ndgProprietaSelect = this.allClientList.reduce((clientList, e) => {
          if ((e.role === ClientRole.INTESTARI.toString() || e.role === ClientRole.TERZO.toString()) && !e.cointestazione) {
            clientList.push({ 'description': e.ndg, 'value': e.ndg })
          }
          return clientList;
        }, []);
      }
    });
  }

  updateAnagrafica() {

    // to avoid uncontrolled growth of the anagrafica cache:
    // 1 - create copy of the main cache
    // 2 - empty main cache
    // 3 - use copied cache to retrive data
    // 4 - update main cache cache only with current ndg data
    const proprietariAnagraficaCacheCopy = this.proprietariAnagraficaCache;
    this.proprietariAnagraficaCache = {};

    if (this.proprietarioList && this.allClientList) {
      this.proprietarioList.forEach(proprietario => {

        // ndg must be valorized
        if (proprietario.ndg) {

          // check if we already have the value in cache
          if (proprietariAnagraficaCacheCopy[proprietario.ndg]) {

            console.log('ndg ' + proprietario.ndg + ': cache found');
            proprietario.descrizione = proprietariAnagraficaCacheCopy[proprietario.ndg].denominazione;

            // update main cache
            this.proprietariAnagraficaCache[proprietario.ndg] = proprietariAnagraficaCacheCopy[proprietario.ndg];

          } else {

            console.log('ndg ' + proprietario.ndg + ': cache not found, searching...');
            this.immobiliService.getSearchClient(proprietario.ndg, 2, 'SEARCH_BY_NDG').subscribe(
              data => {
                // we must have exactly 1 result
                if (data && data.results && data.results.length == 1 && data.results[0].denominazione) {

                  proprietario.descrizione = data.results[0].denominazione;

                  // update main cache
                  this.proprietariAnagraficaCache[proprietario.ndg] = data.results[0];

                } else {
                  this.resetProprietario(proprietario);
                  console.log('ndg ' + proprietario.ndg + ': got not valid result');
                }
              },
              error => { this.resetProprietario(proprietario); },
              () => { }
            );

          }

        } else {
          // empty ndg -> clear description
          console.log('ndg ' + proprietario.ndg + ': is empty');
          this.resetProprietario(proprietario);
        }

      });
    }

  }

  showAssociaPropostaSection() {
    this.commonService.isMutuoIpotecario(this.proposalId).subscribe(response => {
         this.showAssociaProposta = this.immobileDetails.associaProposta = response;
         this.isMutuiChiro = !response;
    });
  }

  private resetProprietario(proprietario: any) {
    if (proprietario) {
      proprietario.descrizione = null;
      proprietario.tipoProprietario = null;
      proprietario.quota = null;
      proprietario.flagAcquistoVendita = null;
    }
  }

}
