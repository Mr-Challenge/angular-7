import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImmobileCensusComponent } from './immobile-census.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
describe('ImmobileCensusComponent', () => {
  let component: ImmobileCensusComponent;
  let fixture: ComponentFixture<ImmobileCensusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImmobileCensusComponent ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImmobileCensusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
