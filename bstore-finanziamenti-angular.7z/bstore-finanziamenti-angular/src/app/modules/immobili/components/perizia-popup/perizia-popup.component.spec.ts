import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PeriziaPopupComponent } from './perizia-popup.component';

describe('PeriziaPopupComponent', () => {
  let component: PeriziaPopupComponent;
  let fixture: ComponentFixture<PeriziaPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PeriziaPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PeriziaPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
