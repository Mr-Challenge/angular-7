import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { DialogModel, DialogRef } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { PeriziaService } from 'src/app/modules/richiedi-perizia/services/perizia.service';
@Component({
  selector: 'bst-fin-perizia-popup',
  templateUrl: './perizia-popup.component.html',
  styleUrls: ['./perizia-popup.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PeriziaPopupComponent implements OnInit {

  annullaEvent: EventsModel[] = [];
  procediEvent: EventsModel[] = [];

  isDipendente: Boolean;
  hideRadioButton: boolean;

  constructor(public dialog: DialogRef, public router: Router, public periziaService: PeriziaService,
    public config: DialogModel) { }

  ngOnInit() {
    this.annullaEvent = [{ eventName: 'click', eventCallBack: this.closeModel.bind(this) }];
    this.procediEvent = [
      { eventName: 'click', eventCallBack: this.redirectToPerizia.bind(this) },
      { eventName: 'click', eventCallBack: this.closeModel.bind(this) }
    ];

    this.isDipendente = this.config.data.isDipendente;
    this.hideRadioButton = this.config.data.hideRadioButton;
  }

  closeModel(input) {
    this.dialog.close('Closed');
  }

  close() {
    this.dialog.close('Closed');
  }

  redirectToPerizia() {
    this.router.navigate(['/nuovaPerizia', this.config.data.proposalId, this.config.data.codiceImmobile],
      {
        queryParams: {
          callBackUrl: this.config.data.callBackUrl,
          statoPerizia: this.config.data.statoPerizia,
          convDipendenti: this.isDipendente
        },
        queryParamsHandling: 'merge',
      });
    this.closeModel('Closed');
  }
}
