export class AssociaImmobili {
    immobiliCodeList?: number[];
    idProposta?: number;
}
