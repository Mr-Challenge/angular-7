export class Data {
    anno: string;
    mese: string;
}


