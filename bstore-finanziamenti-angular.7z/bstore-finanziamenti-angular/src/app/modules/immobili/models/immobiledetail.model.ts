import { TipoImmobile } from './tipoImmobile.enum';
import { StatoImmobile } from './statoImmobile.enum';
import { Disponibilita } from './disponibilita.enum';
import { DestinazioneEconomicaPrevalente } from './destinazioneEconomicaPrevalente.enum';
import { Valutazione } from './valutazione.model';
import { Proprietario } from './proprietario.model';
import { ImpiegoAttivita } from './impiegoAttivita.enum';
import { StatoImmobileList } from './statoImmobileList.model';

export class ImmobileDetail {
    tipo?: TipoImmobile;
    superficie?: number;
    no?: number;
    vani?: number = 0;
    indirizzo?: string;
    numeroVani?: string;
    numeroCivico?: string;
    cap?: string;
    comune?: string;
    provincia?: string;
    statoImmobile?: StatoImmobile;
    statoImmobileList?: StatoImmobileList[];
    disponibilita?: Disponibilita;
    valutazione?: Valutazione;
    destinazioneEconomicaPrevalente?: DestinazioneEconomicaPrevalente;
    listaProprietari: Proprietario[];
    immobileAcquisto?: boolean;
    associaProposta?: boolean;
    donazione?: boolean;
    flagIpoteca?: boolean;
    statoDonazione?: string;
    impiegoAttivita?: ImpiegoAttivita;
    idProposta?: string;

}