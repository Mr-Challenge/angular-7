import { ImmobiliSearchType } from 'src/app/models/immobiliSearchTypeEnum.model';

export class CercaImmobileInput {
    searchKey?: string;
    searchType?: ImmobiliSearchType;
}
