import { TipoProprieta } from './tipoProprieta.enum';
import { TipoProprietario } from './tipoProprietario.enum';

export class Proprietario {
    ndg?: string;
    descrizione?: string;
    tipoProprietario?: TipoProprieta;
    flagAcquistoVendita?: TipoProprietario;
    quota?: number;
    acquiVendi?: string;

}

