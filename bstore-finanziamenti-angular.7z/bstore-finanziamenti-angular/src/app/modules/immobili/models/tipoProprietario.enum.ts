export enum TipoProprietario {
    ACQUIRENTE,
    VENDITORE
}
