export class CercaImmobileOutput {
    codice?: string;
    stato?: StatoImmobile;
    tipo?: string;
    superficie?: number;
    indirizzo?: string;
    comune?: string;
    provincia?: string;
    numeroCivico?: string;
    interno?: string;
    flagTipoNDG?: string;
    flagCompletezzaInformazioni?: CompletezzaInfoImmobile;
    statoGravameIpoteca?: StatoGravame;
    flagIpoteca?: boolean;
    numeroRapportiIpoteca?: number;
    rapportoIpoteca?: Ipoteca[];
    idPerizia?: string;
    nomeDocumento?: string;
    documentoPerizia?: string;
    statoPerizia?: PeriziaStatus;
    deleteStatus?: boolean;
    disableRichiediPerizia?: boolean;
    selezionatoFlag?: boolean;
    fileData?: any;
    pdfUrl?: any;
}

export enum StatoImmobile {
    IMMOBILE_ATTIVO_NDG_ATTIVO,
    IMMOBILE_ATTIVO_NDG_ESTINTO,
    IMMOBILE_ESTINTO
}

export enum CompletezzaInfoImmobile {
    COMPLETO,
    INCOMPLETO
}

export enum StatoGravame {
    GRAVAME_PRESENTE,
    GRAVAME_STATO_DA_3_A_6,
    PROPRIETARIO_LEAS
}

export class Ipoteca {
    servizio?: string;
    filiale?: string;
    categoria?: string;
    rapporto?: string;
}

export enum PeriziaStatus {
    VALIDA,
    SCADUTA,
    IN_LAVORAZIONE,
    MANCANTE
}
