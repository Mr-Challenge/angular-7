export enum DestinazioneEconomicaPrevalente {
    VENDITA = ('VENDITA'),
    LOCAZIONE = ('LOCAZIONE'),
    ALTRA_DESTINAZIONE_PROPRIETARIO = ('UTILIZ.DAL PROPR.O ALTRA DEST.')
}
