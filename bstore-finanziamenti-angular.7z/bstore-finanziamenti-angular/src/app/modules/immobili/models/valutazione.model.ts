import { Fonte } from './fonte.enum';
import { Data } from './data.model';


export class Valutazione {
    valore?: number;
    fonte: Fonte;
    data: Data;
    valoreDiRicostruzione: number;
}

