import { CodeDescription } from 'src/app/models/codeDescription';

export class Geographical extends CodeDescription {
    parent?: string;
    descrizioneEscape?: string;
}
