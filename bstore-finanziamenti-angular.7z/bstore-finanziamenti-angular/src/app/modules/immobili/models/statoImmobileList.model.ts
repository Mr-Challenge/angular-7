export class StatoImmobileList{
    value?: string;
    description?: string;
    
}