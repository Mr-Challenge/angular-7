export enum ImpiegoAttivita {
  SI = ('SI'),
  NO = ('NO'),
  NON_NOTO = ('NON NOTO')
}
