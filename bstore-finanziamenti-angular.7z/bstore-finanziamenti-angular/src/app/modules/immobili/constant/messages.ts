
export const Messages = {
    mandatory: '*Obbligatorio'
};
