import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CorporateSearchResult } from 'src/app/models/corporateSearchResult';
import { environment } from 'src/environments/environment';
import { EndpointsService } from "../../../services/endpoints.service";
import { AssociaImmobili } from '../models/associaImmobili';
import { CercaImmobileInput } from '../models/cercaImmobileInput.model';
import { CercaImmobileOutput } from '../models/cercaImmobileOutput';
import { Geographical } from '../models/geographical.model';
import { ImmobileDetail } from '../models/immobiledetail.model';

@Injectable({
  providedIn: 'root'
})
export class ImmobiliService {

  redirectPageName: string;

  constructor(private httpClient: HttpClient, private endpointsService: EndpointsService) { }


  setImmobileDetailPage(pageName: string) {
    this.redirectPageName = pageName;
  }

  getImmobileDetailPage() {
    return this.redirectPageName;
  }

  rimuoviImmobileDaProposta(codiceImmobile: string, idProposal: string): Observable<any> {
    const params = new HttpParams();
    const parameters = params.append('codiceImmobile', codiceImmobile).append('idProposal', idProposal);
    return this.httpClient.get(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}` +
      '/api/rimuoviImmobileDaProposta', { params: parameters, observe: 'response' });
  }

  getImmobiliCodici(idProposta) {
    const params = new HttpParams();
    const parameters = params.append('idProposta', idProposta);
    return this.httpClient.get<any>(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}` +
      '/api/trovaCodiceImmobili', { params: parameters });
  }

  getDominioArca(valoreRicostruzione) {
    const params = new HttpParams();
    const parameters = params.append('valoreRicostruzione', valoreRicostruzione);
    return this.httpClient.get<any>(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}` +
      '/api/getDomainioArca', { params: parameters });
  }

  getProvincesByNation(geographical: Geographical): Observable<any> {
    return this.httpClient.post<Geographical[]>(this.endpointsService.provincesByNation, geographical);
  }

  getComuneByProvinces(geographical: Geographical): Observable<any> {
    return this.httpClient.post<Geographical[]>(this.endpointsService.comuneByProvinces, geographical);
  }

  inserisciImmobile(immobileDetail: ImmobileDetail): Observable<any> {
    return this.httpClient.post<any>(this.endpointsService.inserisciImmobile, immobileDetail, { responseType: 'text' as 'json' });
  }

  recuperaDatiImmobileDaNdg(ndg: string): Observable<any> {
    const params = new HttpParams();
    const parameters = params.append('ndg', ndg);
    return this.httpClient.get<CercaImmobileOutput[]>(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}` +
      '/api/recuperaDatiImmobileDaNdg', { params: parameters, observe: 'response' });
  }

  cercaImmobile(cercaImmobileInput: CercaImmobileInput): Observable<any> {
    return this.httpClient.post<CercaImmobileOutput>(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}` +
      '/api/cercaImmobile', cercaImmobileInput);
  }

  searchClientDataFromName(name: string): Observable<any> {
    const params = new HttpParams();
    const parameters = params.append('name', name);
    return this.httpClient.get<CorporateSearchResult[]>(`${environment.devUrlJSON['npv.service.callback.url']}` +
      '/api/searchClientDataFromName', { params: parameters, observe: 'response' });
  }

  getImmobiliDetails(codiceImmobile: string) {
    const params = new HttpParams();
    const parameters = params.append('codiceImmobile', codiceImmobile);
    return this.httpClient.get<ImmobileDetail>(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}`
      + '/api/recuperaDatiImmobile', { params: parameters });
  }

  recuperaImmobiliProposta(idProposta: string): Observable<any> {
    const params = new HttpParams();
    const parameters = params.append('idProposta', idProposta);
    return this.httpClient.get(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}` +
      '/api/recuperaImmobiliProposta', { params: parameters, observe: 'response' });
  }

  associaImmobili(associaImmobili: AssociaImmobili): Observable<any> {
    return this.httpClient.post<AssociaImmobili>(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}` +
      '/api/associaImmobili', associaImmobili);
  }

  getrecuperaDatiImmobile(codiceImmobile) {
    const params = new HttpParams();
    const parameters = params.append('codiceImmobile', codiceImmobile);
    return this.httpClient.get<any>(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}` +
      '/api/recuperaDatiImmobile', { params: parameters });
  }

  getDettaglioImmobili(idProposal) {
    const params = new HttpParams();
    const parameters = params.append('idProposal', idProposal);
    return this.httpClient.get<any>(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}` +
      '/api/getDettaglioImmobili', { params: parameters });
  }

  getSearchClient(ndg: string, pageLimit: number, searchType: string): Observable<any> {
    const searchQuery = {
      'query': ndg,
      'pageLimit': pageLimit,
      'searchType': searchType,
    }
    const url = `${environment.devUrlJSON['npv.service.callback.url']}` + '/api/getSearchedConnectionsNG';
    return this.httpClient.post<any>(url, searchQuery);
  }

}
