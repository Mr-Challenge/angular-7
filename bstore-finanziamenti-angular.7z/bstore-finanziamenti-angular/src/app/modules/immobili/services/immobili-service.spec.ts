import { TestBed } from '@angular/core/testing';

import { ImmobiliService } from './immobili-service';

describe('ImmobiliServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ImmobiliService = TestBed.get(ImmobiliService);
    expect(service).toBeTruthy();
  });
});
