import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BstoreAngularLibraryModule } from 'bstore-angular-library';
import { SharedModule } from 'src/app/shared.module';
import { ImmobileCensusComponent } from './components/immobile-census/immobile-census.component';
import { ImmobileDetailComponent } from './components/immobile-detail/immobile-detail.component';
import { ImmobiliSearchComponent } from './components/immobili-search/immobili-search.component';
import { ImmobiliStartingPageComponent } from './components/immobili-starting-page/immobili-starting-page.component';
import { ImmobiliRoutingModule } from './immobili-routing.module';

@NgModule({
  declarations: [
    ImmobiliStartingPageComponent,
    ImmobiliSearchComponent,
    ImmobileCensusComponent,
    ImmobileDetailComponent
  ],
  imports: [
    CommonModule,
    ImmobiliRoutingModule,
    BstoreAngularLibraryModule,
    FormsModule,
    SharedModule
  ]
})
export class ImmobiliModule { }
