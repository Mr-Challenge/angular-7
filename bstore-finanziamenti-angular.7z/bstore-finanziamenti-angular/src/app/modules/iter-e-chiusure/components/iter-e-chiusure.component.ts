import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BreadcrumbModel, DialogService } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { StatoMutuoType } from 'src/app/constant/statoMutuo';
import { NotificationVm } from 'src/app/models/notificationVm.model';
import { CommonService } from 'src/app/services/common.service';
import { environment } from 'src/environments/environment';
import { ModificaPropostaPopupComponent } from '../../modifica-proposta/components/modifica-proposta-popup/modifica-proposta-popup.component';
import { MutuiDetailsModel } from '../../product-configuration/models/MutuiDetailsModel';
import { RestituisciBpiPopupSectionComponent } from '../../restituisci-bpi-popup-section/restituisci-bpi-popup-section.component';
import { IterChiusureTableData } from '../models/IterChiusureTableData';
import { IterEChiusureService } from '../services/iter-e-chiusure-service';
import { NotificationService } from 'src/app/services/notification.service';

@Component({
  selector: 'bst-fin-iter-e-chiusure',
  templateUrl: './iter-e-chiusure.component.html',
  styleUrls: ['./iter-e-chiusure.component.scss']
})
export class IterEChiusureComponent implements OnInit {

  public breadcrumbs: BreadcrumbModel[];

  saveEvents: EventsModel[];
  iterList: IterChiusureTableData[];
  deliberaStarted: boolean;
  today: Date = new Date();
  idProposal: string;
  fetchedMutuiDetails: MutuiDetailsModel;
  numeroPratica: string;
  tooltipMessage: string;
  progress = 40;
  showProgressTooltipFlag: boolean;
  openBPIPopup: EventsModel[];
  domainName = environment.devUrlJSON['npv.service.callback.url'];
  notificaVm: NotificationVm;

  constructor(private dialogservice: DialogService,
    private iterEChiusureService: IterEChiusureService, private commonService: CommonService,
    private router: Router, private route: ActivatedRoute, private notificationService: NotificationService) {
    this.iterList = [];
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.idProposal = params['proposalId'];

      this.breadcrumbs = [{
        label: 'Indietro',
        url: `/sceltaProponente/${this.idProposal}`,
        enabled: true,
        externalLink: false
      }];
    });

    this.saveEvents = [
      { eventName: 'click', eventCallBack: this.callsavemortgagestatus.bind(this) }];

    this.openBPIPopup = [
      { eventName: 'click', eventCallBack: this.openRestituisciBPIPopup.bind(this) }];

    if (this.idProposal) {
      this.commonService.fetchMutuoDetails(this.idProposal).subscribe(data => {
        this.fetchedMutuiDetails = data;

        const status = this.fetchedMutuiDetails.status;
        if (status === StatoMutuoType.IN_ATTESA_DELIBERA) {
          this.editProgressBarForAttesaDelibera();
          this.deliberaStarted = true;
          this.notificationService.fetchStatus(this.fetchedMutuiDetails.idPef.toString(), this.idProposal);

        } else {
          if (this.fetchedMutuiDetails.idPef) {
            this.numeroPratica = this.fetchedMutuiDetails.idPef.toString();
            if (this.numeroPratica) {
              this.iterEChiusureService.getIterChiusureTableData(this.numeroPratica).subscribe((response) => {
                this.iterList = response;
              });
            }
          }
        }
      });
    }

  }

  private editProgressBarForAttesaDelibera() {
    this.tooltipMessage = 'In attesa di delibera';
    this.progress = 50;
    this.showProgressTooltipFlag = true;
  }

  openRestituisciBPIPopup() {
    this.dialogservice.open(RestituisciBpiPopupSectionComponent, {
      data: { idProposal: this.idProposal, idPef: this.numeroPratica },
      size: 'large',
      title: 'PROPOSTA ' + this.idProposal + ' RESTITUITA CON MODIFICA',
    });
  }

  callsavemortgagestatus() {
    if (this.idProposal) {
      this.iterEChiusureService.saveIterChiusureDataAndUpdateStatus(this.idProposal,
        this.numeroPratica, StatoMutuoType.IN_ATTESA_DELIBERA).subscribe((respo) => {
          this.deliberaStarted = respo;
          if (this.deliberaStarted) {
            this.editProgressBarForAttesaDelibera();
          }
        });
    }
  }

  abbandonaPropostaPopup() {
    localStorage.setItem('previousPage', 'iterechiusure');
    this.router.navigate(['/abbandona', this.idProposal]);
  }

  modificaPopup() {
    this.dialogservice.open(ModificaPropostaPopupComponent, {
      data: { idProposal: this.idProposal },
      noCloseButton: true,
      size: 'large'
    });
  }

}
