import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IterEChiusureComponent } from './iter-e-chiusure.component';

describe('IterEChiusureComponent', () => {
  let component: IterEChiusureComponent;
  let fixture: ComponentFixture<IterEChiusureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IterEChiusureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IterEChiusureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
