import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BstoreCommonModule } from '../bstore-common/bstore-common.module';
import { IterEChiusureRoutingModule } from './iter-e-chiusure-routing.module';
import { IterEChiusureComponent } from './components/iter-e-chiusure.component';

@NgModule({
  declarations: [IterEChiusureComponent],
  imports: [
    CommonModule,
    BstoreCommonModule,
    IterEChiusureRoutingModule,

  ]
})
export class IterEChiusureModule { }
