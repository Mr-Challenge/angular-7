export class IterChiusureTableData {

    operativita: string;
    denominazione: string;
    livello: number;
    dataParere?: Date;
    parere?: string;
    nota?: string;
}