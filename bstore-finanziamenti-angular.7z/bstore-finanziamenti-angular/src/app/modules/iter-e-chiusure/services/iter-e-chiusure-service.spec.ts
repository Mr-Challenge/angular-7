import { TestBed } from '@angular/core/testing';

import { IterEChiusureService } from './iter-e-chiusure-service';

describe('IterEChiusureServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: IterEChiusureService = TestBed.get(IterEChiusureService);
    expect(service).toBeTruthy();
  });
});
