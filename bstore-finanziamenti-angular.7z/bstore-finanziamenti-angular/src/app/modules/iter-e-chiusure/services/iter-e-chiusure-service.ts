import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EndpointsService } from "../../../services/endpoints.service";
import { IterChiusureTableData } from '../models/IterChiusureTableData';
import { NotificationVm } from 'src/app/models/notificationVm.model';

@Injectable({
  providedIn: 'root'
})
export class IterEChiusureService {

  constructor(public httpClient: HttpClient, private endpointsService: EndpointsService) { }

  public getIterChiusureTableData(numeroPratica: string) {
    let parameters = new HttpParams().append('numeroPratica', numeroPratica);
    return this.httpClient.get<IterChiusureTableData[]>(this.endpointsService.getIterChiusureData, { params: parameters });

  }

  public saveIterChiusureDataAndUpdateStatus(idProposal: string, numeroPratica: string, mortgageStatus: string) {
    let parameters = new HttpParams().append('idProposal', idProposal).append('numeroPratica', numeroPratica).append('mortgageStatus', mortgageStatus);
    return this.httpClient.get<boolean>(this.endpointsService.saveIterChiusureDataAndUpdateStatus, { params: parameters });

  }
}
