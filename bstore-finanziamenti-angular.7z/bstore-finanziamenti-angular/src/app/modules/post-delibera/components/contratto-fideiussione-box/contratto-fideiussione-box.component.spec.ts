import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContrattoFideiussioneBoxComponent } from './contratto-fideiussione-box.component';

describe('ContrattoFideiussioneBoxComponent', () => {
  let component: ContrattoFideiussioneBoxComponent;
  let fixture: ComponentFixture<ContrattoFideiussioneBoxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContrattoFideiussioneBoxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContrattoFideiussioneBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
