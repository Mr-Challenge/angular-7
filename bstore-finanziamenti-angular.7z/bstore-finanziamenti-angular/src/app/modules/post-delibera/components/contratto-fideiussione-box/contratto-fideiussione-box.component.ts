import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { GaranzieGaranti } from 'src/app/modules/vendita/models/garanzie-garanti.model';
import { ContrattoFideiussioneService } from '../../services/contratto-fideiussione.service';

@Component({
  selector: 'bst-fin-contratto-fideiussione-box',
  templateUrl: './contratto-fideiussione-box.component.html',
  styleUrls: ['./contratto-fideiussione-box.component.scss']
})
export class ContrattoFideiussioneBoxComponent implements OnInit {

  @Input() idProposal;
  @Input() fideiussioneSigned: boolean;
  @Output() raccogliFirme: EventEmitter<any> = new EventEmitter();

  garanzieGarantiList: GaranzieGaranti[] = [];

  constructor(private contrattoFideiussioneService: ContrattoFideiussioneService) { }

  ngOnInit() {
    this.garanzieGarantiList = this.contrattoFideiussioneService.getGaranzieGarantiList();
  }

  emitRaccogliFirme() {
    this.raccogliFirme.emit();
  }

}
