import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { InsuranceDetail } from 'src/app/components/polizze-protezione-common/services/insurance-detail';
import { TipoProcesso } from 'src/app/constant/tipoProcesso';
import { PostDeliberaData } from 'src/app/models/post-delibera/postDeliberaData.model';
import { PostDeliberaPolizzaProtezione } from 'src/app/models/post-delibera/postDeliberaPolizzaProtezione.model';
import { PostDeliberaPolizzeProtezione } from 'src/app/models/post-delibera/postDeliberaPolizzeProtezione.model';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { MutuiDetailsModel } from 'src/app/modules/product-configuration/models/MutuiDetailsModel';
import { PostDeliberaService } from '../../services/post-delibera.service';

@Component({
  selector: 'bst-fin-gestione-polizze-chiro',
  templateUrl: './gestione-polizze-chiro.component.html',
  styleUrls: ['./gestione-polizze-chiro.component.scss']
})
export class GestionePolizzeChiroComponent implements OnInit {

  @Input() fetchMutuoDetailsResponse: MutuiDetailsModel;
  @Input() postDeliberaPageStatus: any;
  @Input() postDeliberaData: PostDeliberaData;
  @Input() intestatari: BaseClientModel[];

  proposalId: string;
  disabilitaConferma: boolean;
  savePolizzeProtezioneEvent: EventsModel[];
  allCompleto: boolean;
  isPolizzaProtezioneSectionValid: boolean;
  isPolizzaProtezioneSectionEmpty: boolean;
  insuranceDetail: InsuranceDetail[] = [];
  isAsync: boolean;

  polizzeProtezioneList: PostDeliberaPolizzaProtezione[] = [];
  polizzeProtezioneListToSave: PostDeliberaPolizzaProtezione[] = [];

  constructor(private postDeliberaService: PostDeliberaService, private route: ActivatedRoute) {
    this.route.params.subscribe(params => this.proposalId = params['proposalId']);
  }

  ngOnInit() {

    this.postDeliberaService.getAllCompleto().subscribe(result => {
      this.allCompleto = result;
    });

    this.postDeliberaService.getpostDeliberaPageStatus().subscribe(data => {
      this.setPolizzeStatus();
    });

    this.intestatari.forEach(() => {
      this.insuranceDetail.push(new InsuranceDetail());
    });

    this.savePolizzeProtezioneEvent = [
      { eventName: 'click', eventCallBack: this.savePolizzeProtezione.bind(this) }
    ];

    if (this.postDeliberaData && this.postDeliberaData.polizzeProtezioneList) {
      this.polizzeProtezioneList = this.postDeliberaData.polizzeProtezioneList;
    }
  }

  controllaConferma() {
    if (this.isPolizzaProtezioneSectionValid || this.isPolizzaProtezioneSectionEmpty) {
      this.disabilitaConferma = false;
    } else {
      this.disabilitaConferma = true;
    }

    if (this.postDeliberaPageStatus.gestionePolizze) {
      this.postDeliberaPageStatus.gestionePolizze = false;
      this.postDeliberaService.setpostDeliberaPageStatusChiro(this.postDeliberaPageStatus);
    }
  }

  gestionePolizzaProtezioneSectionValid(event: boolean) {
    this.isPolizzaProtezioneSectionValid = event;
    this.controllaConferma();
  }

  gestionePolizzaProtezioneSectionEmpty(event: boolean) {
    this.isPolizzaProtezioneSectionEmpty = event;
    this.controllaConferma();
  }

  fillListPolizzeToSave(list: PostDeliberaPolizzaProtezione[]) {
    this.polizzeProtezioneListToSave = list;
  }

  savePolizzeProtezione() {
    const postDeliberaPolizze: PostDeliberaPolizzeProtezione = new PostDeliberaPolizzeProtezione();
    postDeliberaPolizze.idProcesso = Number(this.proposalId);
    postDeliberaPolizze.tipoProcesso = TipoProcesso.VENDITA;

    postDeliberaPolizze.polizzeProtezioneList = this.polizzeProtezioneListToSave;

    this.postDeliberaService.savePolizzeProtezione(postDeliberaPolizze).subscribe(response => {
      if (response) {
        this.completeSezionePolizze(true);
      }
    });

  }

  asyncFilled(event: boolean) {
    this.isAsync = event;
  }

  setPolizzeStatus() {
    if (this.isAsync && this.postDeliberaPageStatus.qav && !this.postDeliberaPageStatus.gestionePolizze) {
      this.completeSezionePolizze(true);
    }
  }

  private completeSezionePolizze(event: boolean) {
    this.disabilitaConferma = event;
    this.postDeliberaPageStatus.gestionePolizze = event;
    this.postDeliberaService.setpostDeliberaPageStatusChiro(this.postDeliberaPageStatus);
  }
}

