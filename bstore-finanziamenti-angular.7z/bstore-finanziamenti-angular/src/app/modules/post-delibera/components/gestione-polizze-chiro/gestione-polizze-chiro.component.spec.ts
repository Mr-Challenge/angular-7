import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GestionePolizzeChiroComponent } from './gestione-polizze-chiro.component';

describe('GestionePolizzeChiroComponent', () => {
  let component: GestionePolizzeChiroComponent;
  let fixture: ComponentFixture<GestionePolizzeChiroComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GestionePolizzeChiroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GestionePolizzeChiroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
