import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ContrattiSignatureType, RedirectService } from 'bstore-angular-library';
import { DateModel } from 'bstore-angular-library/lib/models/date-model';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { Observable, forkJoin } from 'rxjs';
import { FinDocumentType } from 'src/app/constant/documentType';
import { TipoProcesso } from 'src/app/constant/tipoProcesso';
import { DocumentGeneration } from 'src/app/models/documentGeneration.model';
import { DossierGeneration, GenerateDoc, RichiestaRiduzioneImporti } from 'src/app/models/generateDoc.model';
import { MortgageSimulationPage } from 'src/app/models/mortgageSimulationPage';
import { PostDeliberaData } from 'src/app/models/post-delibera/postDeliberaData.model';
import { PostDeliberaDatiGenerali } from 'src/app/models/post-delibera/postDeliberaDatiGenerali.model';
import { ImmobileDetail } from 'src/app/modules/immobili/models/immobiledetail.model';
import { StatoImmobile } from 'src/app/modules/immobili/models/statoImmobile.enum';
import { StatoImmobileList } from 'src/app/modules/immobili/models/statoImmobileList.model';
import { PostDeliberaService } from 'src/app/modules/post-delibera/services/post-delibera.service';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { SignatureStatusModel } from 'src/app/modules/vendita/models/signature-status.model';
import { CommonService } from 'src/app/services/common.service';
import { EndpointsService } from '../../../../../../services/endpoints.service';
import { MutuiDetailsModel } from 'src/app/modules/product-configuration/models/MutuiDetailsModel';
import { ContrattiSignatureInput } from 'bstore-angular-library/lib/models/contrattiSignatureInput.model';
import { DossierDocSigner } from 'src/app/models/dossierDocSigner.model';
import { ContrattiDocument } from 'src/app/models/contrattiDocument';

@Component({
  selector: 'bst-fin-dati-stipula-generali',
  templateUrl: './dati-stipula-generali.component.html',
  styleUrls: ['./dati-stipula-generali.component.scss']
})
export class DatiStipulaGeneraliComponent implements OnInit {

  @Input() fetchMutuoDetailsResponse: MutuiDetailsModel;
  @Input() immobileData: any[];
  @Input() postDeliberaPageStatus: any;
  @Input() postDeliberaData: PostDeliberaData;
  @Input() mainUser: BaseClientModel;
  @Input() intestatari: BaseClientModel[];
  @Input() jointHeading: BaseClientModel;

  numero: any;
  richiestaRiduzioneFlag: boolean;
  generateString: string;
  datiEvents: EventsModel[] = [];
  inputRichiestaRiduzioneEvent: EventsModel[] = [];
  inputConfermaEvent: EventsModel[] = [];
  isDateValid: boolean;
  flag: boolean;
  errorMessage: boolean;
  idProposal: string;
  dataDiPresuntaStipulaText: DateModel;
  mortgageSimulationPage: MortgageSimulationPage;
  importoDiStipulaText: string;
  importoDiStipula: number;
  ErrorMessagedataimportoDiStipu = 'L\'importo oggetto di stipula deve essere minore o uguale all\'importo del mutuo deliberato';
  errorMessagedataimortodelMutuodeliberato: string = 'L\'importo di prima erogazione deve essere minore o '
    + 'uguale all\'importo del mutuo oggetto di stipula.';
  statoAvanzamentoLavori: boolean;
  statoImmobileSelect: any = [];
  statoImmobile: StatoImmobileList[] = [];
  dettaglioImmobile: ImmobileDetail;
  requiredImportoStipula: boolean;
  showErrorMessagesRequiredImportoStipula: boolean;
  datePickerErrorMessage: string;
  date: Date;
  stipulaGeneraliData: any;
  stipulaGeneraliEvent: EventsModel[] = [];
  importoPrimaErogazioneEvent: EventsModel[] = [];
  importoPrimaErogazione: number;
  datiGeneraliForm: FormGroup;
  firmaButton: boolean;
  showImportoPrimaErogazione: boolean;
  disabilitaCalendario: Observable<any>;

  raccogliFirmeAbilitato: boolean;
  importoStipulaAmount: number;
  docStipulaSigned: boolean;
  datiStipulaDocGenerated: boolean;
  stipulaDate: String;

  docType: string = FinDocumentType.RICHIESTA_RIDUZIONE_IMPORTI;
  contrattiSignatureInput: ContrattiSignatureInput;
  dossierGenerationArr: DossierGeneration[] = [];
  contrattiSignatureType: ContrattiSignatureType;
  documentGenerationList: DocumentGeneration[] = [];
  signatureStatusModel: SignatureStatusModel;

  constructor(public postDeliberaService: PostDeliberaService, private commonService: CommonService,
    public immobileDetails: ImmobileDetail, private route: ActivatedRoute,
    private endpointsService: EndpointsService, private redirectService: RedirectService) {
    this.route.params.subscribe(params => this.idProposal = params['proposalId']);
  }

  ngOnInit() {

    this.signatureStatusModel = new SignatureStatusModel();
    this.signatureStatusModel.processId = Number(this.idProposal);
    this.signatureStatusModel.processType = TipoProcesso.VENDITA;
    const documentGenerationList: ContrattiDocument[] = [];
    documentGenerationList.push({ toSign: true, docType: this.docType });
    this.signatureStatusModel.documents = documentGenerationList;
    this.dossierGenerationArr = this.createDossierGenerationList();
    this.getContrattiSignatureInput();
    this.datiGeneraliForm = new FormGroup({
      dataDiPresuntaStipula: new FormControl(),
      importoStipula: new FormControl(),
      importoPrimaErogazione: new FormControl()
    });
    this.datiGeneraliForm.statusChanges.subscribe(
      data =>
        this.firmaButton = this.datiGeneraliForm.valid
    );
    this.postDeliberaService.getStipulaDate().subscribe(date => {
      this.stipulaDate = date;
      this.postDeliberaService.getDisabilitaCambioDate().subscribe(data => {
        this.disabilitaCalendario = data;
        this.postDeliberaService.getDateValid().subscribe(resp => {
          this.isDateValid = resp;
        });
      });
      if (date) {
        this.postDeliberaPageStatus.datiStipulaGeneraliData.dataDiPresuntaStipula
          = new Date(date.year, date.month - 1, date.day);
        this.postDeliberaService.updatePostDeliberaData(this.postDeliberaPageStatus);
      }
    });

    this.inputRichiestaRiduzioneEvent = [
      { eventName: 'click', eventCallBack: this.richiestaRiduzioneClicked.bind(this) }
    ];

    this.inputConfermaEvent = [
      { eventName: 'click', eventCallBack: this.confermaClicked.bind(this) }
    ];

    this.mortgageSimulationPage = new MortgageSimulationPage();

    this.showRichiestaRiduzioneBtn();
    this.getstatoImmobileSelect();
    this.showRichiestaRiduzioneBtn();

    if (this.postDeliberaData && this.postDeliberaData.importoStipula) {
      this.datiGeneraliForm.get('importoStipula')
        .setValue(this.postDeliberaData.importoStipula ? this.postDeliberaData.importoStipula : '');
      this.setImportoStipulaAmount(this.postDeliberaData.importoStipula);

      this.datiGeneraliForm.get('importoPrimaErogazione')
        .setValue(this.postDeliberaData.importoPrimaErogazione ? this.postDeliberaData.importoPrimaErogazione : '');
      this.setImportoPrimaErogazione(this.postDeliberaData.importoPrimaErogazione);

      this.setSectionData();
      this.checkSignatureStatus();
    }

  }

  getContrattiSignatureInput() {

    const dossierDetails = {
      processId: this.signatureStatusModel.processId,
      processType: this.signatureStatusModel.processType,
      dossierGenerationList: this.dossierGenerationArr
    }

    this.commonService.getContrattiSignatureInput(dossierDetails).subscribe(flagInput => {
      this.contrattiSignatureInput = {
        isFeqEnabled: flagInput.feqEnabled,
        isSendOnly: flagInput.sendOnly,
        isSignatureInProgress: flagInput.signatureInProgress,
        signatureInProgressType: flagInput.signatureInProgressType
        // sendMailForSecci: true
      }
    });
  }

  onClickFirmaAltreModalita(signType: ContrattiSignatureType) {
    if (signType) {
      this.contrattiSignatureType = signType;
      this.inviaRichiesta(true);
    }
  }

  onClickRaccogliMancanti(signType: ContrattiSignatureType) {
    if (signType) {
      this.contrattiSignatureType = signType;
      this.inviaRichiesta(true);
    }
  }

  onClickInviaMail() {
    // this.sendOrSignDocument(true, null);
  }

  private checkSignatureStatus() {
    const data = <SignatureStatusModel>{
      processId: Number(this.idProposal),
      processType: TipoProcesso.VENDITA,
      docToGenerate: [FinDocumentType.RICHIESTA_RIDUZIONE_IMPORTI]
    };
    const dataBis = <SignatureStatusModel>{
      processId: Number(this.idProposal),
      processType: TipoProcesso.VENDITA,
      docToGenerate: [FinDocumentType.DATI_STIPULA]
    };

    forkJoin([this.commonService.checkSignatureStatus(data), this.commonService.checkDocumentGenerationStatus(dataBis)])
      .subscribe(results => {
        this.docStipulaSigned = results[0];
        this.datiStipulaDocGenerated = results[1];

        if (this.docStipulaSigned) {
          this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaGenerali = this.docStipulaSigned;
        } else {
          if (Number(this.postDeliberaData.importoStipula) === Number(this.fetchMutuoDetailsResponse.importoRichiesto.toString())) {
            this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaGenerali = true;
          } else {
            this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaGenerali = false;
          }
        }
        this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
        this.setSectionData();
        this.createInputForDatiStipulaDoc(false);
      });
  }

  async createInputForDatiStipulaDoc(toRegenerate: boolean) {
    if (toRegenerate && this.datiStipulaDocGenerated) {
      const data = <SignatureStatusModel>{
        processId: Number(this.idProposal),
        processType: TipoProcesso.VENDITA,
        docToGenerate: [FinDocumentType.DATI_STIPULA]
      };
      this.deleteDoc(data);
    }
    const documentData = await this.generateDocumentGenerationData(toRegenerate);
    const datiStipulaDocument = {
      isGeneratedDocument: true,
      documentData: documentData
    };
    this.postDeliberaPageStatus.datiStipulaDocument = datiStipulaDocument;
    this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
  }

  private deleteDoc(signatureStatus: SignatureStatusModel) {
    this.commonService.deleteDocuments(signatureStatus).subscribe();
  }

  generateDocumentGenerationData(toRegenerate: boolean) {
    const documentData = {
      alreadyGenerated: toRegenerate ? false : this.datiStipulaDocGenerated,
      idProposta: this.idProposal,
      numero: this.idProposal,
      clients: this.intestatari,
      jointHeading: this.jointHeading,
      importoDelibera: this.fetchMutuoDetailsResponse.importoRichiesto,
      importoStipula: this.importoStipulaAmount,
      importoPrimaErogazione: this.statoAvanzamentoLavori ? this.importoPrimaErogazione : 0,
      processId: Number(this.idProposal),
      processType: TipoProcesso.VENDITA
    };
    return documentData;
  }

  getstatoImmobileSelect() {
    this.statoAvanzamentoLavori = this.immobileData.every(data => data.statoImmobile !== StatoImmobile.FINITO);
    this.postDeliberaPageStatus.datiStipulaGeneraliData.statoAvanzamentoLavori = this.statoAvanzamentoLavori;
    this.postDeliberaPageStatus.datiStipulaGeneraliData.importoPrimaErogazione =
      this.datiGeneraliForm.controls.importoPrimaErogazione.value;
    this.postDeliberaPageStatus.datiStipulaGeneraliData.importoStipula =
      this.datiGeneraliForm.controls.importoStipula.value;
    this.postDeliberaService.updatePostDeliberaData(this.postDeliberaPageStatus);
  }

  inviaRichiesta(sign: boolean) {
    this.createInputForDatiStipulaDoc(true);
    const postDeliberaDatiGenerali: PostDeliberaDatiGenerali = new PostDeliberaDatiGenerali();

    postDeliberaDatiGenerali.idProcesso = Number(this.idProposal);
    postDeliberaDatiGenerali.importoPrimaErogazione = this.importoPrimaErogazione;
    postDeliberaDatiGenerali.importoStipula = this.importoStipulaAmount;
    postDeliberaDatiGenerali.tipoProcesso = TipoProcesso.VENDITA;

    this.postDeliberaService.saveDatiGeneraliStipula(postDeliberaDatiGenerali).subscribe(esito => {
      if (esito && sign) {
        this.goToGenerateRichiestaRiduzione();
      } else if (esito && !sign) {
        this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaGenerali = true;
        this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
      }
    });
  }

  richiestaRiduzioneClicked() {
    this.inviaRichiesta(true);
  }

  confermaClicked() {
    this.inviaRichiesta(false);
  }

  goToGenerateRichiestaRiduzione() {
    const generateDoc = new GenerateDoc();
    generateDoc.processId = Number(this.idProposal);
    generateDoc.processType = TipoProcesso.VENDITA;
    generateDoc.callbackUrl = this.endpointsService.callbackToPostDelibera + this.idProposal;
    generateDoc.paramsGenerateEndpoint = {};
    const documentGenerationArr: DocumentGeneration[] = [];
    const docObj = new DocumentGeneration();
    docObj.documentType = FinDocumentType.RICHIESTA_RIDUZIONE_IMPORTI;
    docObj.mainNdg = this.mainUser.ndg;
    docObj.signers = this.intestatari;
    docObj.jointHeading = this.jointHeading;
    documentGenerationArr.push(docObj);
    const richiestaRiduzioneImporti = new RichiestaRiduzioneImporti();
    richiestaRiduzioneImporti.cointestazione = this.jointHeading;
    richiestaRiduzioneImporti.customers = this.intestatari;
    richiestaRiduzioneImporti.idProposta = this.idProposal;
    richiestaRiduzioneImporti.lineaCredito = this.fetchMutuoDetailsResponse.importoRichiesto;
    richiestaRiduzioneImporti.lineaDeliberata = this.fetchMutuoDetailsResponse.importoRichiesto;
    richiestaRiduzioneImporti.lineaRidotta = this.importoStipulaAmount;
    generateDoc.documentList = documentGenerationArr;
    generateDoc.paramsGenerateEndpoint = richiestaRiduzioneImporti;
    generateDoc.generateEndpoint = this.endpointsService.richiestaRiduzioneEndPoint;
    generateDoc.deliveredEndpoint = this.endpointsService.setDocumentsDelivered;
    generateDoc.dossiers = this.dossierGenerationArr;
    // this.saveRichiestaRiduzioneDoc(generateDoc);
    this.commonService.saveInSession(generateDoc, this.signatureStatusModel, true, this.contrattiSignatureType, this.contrattiSignatureInput.isSignatureInProgress);
  }

  saveRichiestaRiduzioneDoc(generateDoc) {
    this.commonService.saveContrattiInputInSession(generateDoc).subscribe(null,
      null, () => {
        const signatureStatus = new SignatureStatusModel();
        signatureStatus.processId = parseInt(this.idProposal, 0);
        signatureStatus.processType = TipoProcesso.VENDITA;
        signatureStatus.docToGenerate = [];
        signatureStatus.docToGenerate.push(FinDocumentType.RICHIESTA_RIDUZIONE_IMPORTI);
        this.redirectService.redirectWithSpinner(this.endpointsService.openContratti
          + '/' + encodeURIComponent(JSON.stringify(signatureStatus)));
      });
  }

  showRichiestaRiduzioneBtn() {
    if (this.mortgageSimulationPage.amount < this.importoDiStipulaText) {
      this.richiestaRiduzioneFlag = true;
    } else {
      this.richiestaRiduzioneFlag = false;
    }
  }

  importoPrimaErogazioneDisable() {
    this.showImportoPrimaErogazione = this.datiGeneraliForm.get('dataDiPresuntaStipula').invalid;
  }

  changestipulaDate(event) {
    this.datePickerErrorMessage = ' ';
    const stipulaDate = this.datiGeneraliForm.get('dataDiPresuntaStipula').value;
    const date = stipulaDate.year + '-' +
      stipulaDate.month.toString().padStart(2, '0') + '-' +
      stipulaDate.day.toString().padStart(2, '0');
    if (date.length === 10) {
      this.postDeliberaService.checkValidStipulaPrevistaDate(date).subscribe(data => {
        this.isDateValid = data.valid;
        this.datePickerErrorMessage = data.message;
        if (this.isDateValid) {
          this.postDeliberaPageStatus.datiStipulaGeneraliData.dataDiPresuntaStipula
            = new Date(stipulaDate.year, stipulaDate.month - 1, stipulaDate.day);
          this.postDeliberaService.updatePostDeliberaData(this.postDeliberaPageStatus);
          this.postDeliberaService.setDateValid(this.isDateValid);
        }
      });
    }
  }

  setSectionData() {
    this.postDeliberaPageStatus.datiStipulaGeneraliData.importoDiStipula = this.importoStipulaAmount;
    this.postDeliberaPageStatus.datiStipulaGeneraliData.importoPrimaErogazione = this.importoPrimaErogazione;
    this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
    this.postDeliberaService.setImportoDiStipula(this.importoStipulaAmount);
    this.postDeliberaService.setImportoPrimaErogazione(this.importoPrimaErogazione);
  }

  setImportoStipulaAmount(value) {
    this.docStipulaSigned = false;
    this.importoStipulaAmount = value;
    this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaGenerali = false;
    this.importoPrimaErogazioneDisable();
    this.setSectionData();
  }

  setImportoPrimaErogazione(value) {
    this.docStipulaSigned = false;
    this.importoPrimaErogazione = value;
    this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaGenerali = false;
    this.setSectionData();
  }

  createDossierGenerationList(): DossierGeneration[] {
    // const intestatari = this.clientBaseList.filter(holder => !holder.cointestazione && holder.role === MortgageClientRoles.INTESTATARI);
    // const mainUser = this.commonService.getMainUser(this.clientBaseList.filter(holder => holder.role === MortgageClientRoles.INTESTATARI));
    // const jointHeading = this.clientBaseList.filter(holder => holder.cointestazione)[0];

    const dossierGenerationArr: DossierGeneration[] = [];
    const documentGenerationArr: DocumentGeneration[] = [];
    const dossierDocSignerArr: DossierDocSigner[] = [];
    const dossierObj = new DossierGeneration();
    dossierObj.groupBy = 'SIGNER';
    dossierObj.onlyFeaSign = false;
    dossierObj.onlyPaperSign = true;
    const docObj = new DocumentGeneration();
    docObj.titolo = this.docType;
    docObj.documentType = this.docType;
    docObj.mainNdg = this.mainUser.ndg;
    docObj.signers = this.intestatari;
    // docObj.jointHeading = this.jointHeading;
    docObj.mainClient = { ndg: this.mainUser.ndg, naturaGiuridica: (!this.mainUser.cointestazione) ? 'PERSONA_FISICA' : 'COINTESTAZIONE' };
    docObj.toSign = true;
    docObj.toReprint = false;
    docObj.mandatory = true;
    const dossierDocSignerObj = new DossierDocSigner();
    dossierDocSignerObj.ndg = this.mainUser.ndg;
    dossierDocSignerObj.type = this.mainUser.role;
    dossierDocSignerObj.mandatory = true;
    dossierDocSignerArr.push(dossierDocSignerObj);
    docObj.dossierDocSigners = dossierDocSignerArr;
    documentGenerationArr.push(docObj);
    dossierObj.documents = documentGenerationArr;
    this.documentGenerationList = documentGenerationArr;
    dossierGenerationArr.push(dossierObj);
    return dossierGenerationArr;
  }

}
