import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ContrattiSignatureType, RedirectService } from 'bstore-angular-library';
import { ContrattiRedirectInput } from 'bstore-angular-library/lib/models/contrattiRedirectInput.model';
import { ContrattiSignatureInput } from 'bstore-angular-library/lib/models/contrattiSignatureInput.model';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { SelectOptionModel } from 'bstore-angular-library/lib/models/select-option-model';
import { FinDocumentType } from 'src/app/constant/documentType';
import { TipoProcesso } from 'src/app/constant/tipoProcesso';
import { ContrattiDocument } from 'src/app/models/contrattiDocument';
import { DocumentGeneration } from 'src/app/models/documentGeneration.model';
import { DossierDocSigner } from 'src/app/models/dossierDocSigner.model';
import { ContoAddebitoDetailsModel, ContoModel, DossierGeneration, GenerateDoc, ModuloAccreditoAddebito } from 'src/app/models/generateDoc.model';
import { PostDeliberaData } from 'src/app/models/post-delibera/postDeliberaData.model';
import { PostDeliberaDatiRichiedente } from 'src/app/models/post-delibera/postDeliberaDatiRichiedente.model';
import { ModulisticaPraticheService } from 'src/app/modules/post-delibera/services/modulistica-pratiche.service';
import { PostDeliberaService } from 'src/app/modules/post-delibera/services/post-delibera.service';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { MutuiDetailsModel } from 'src/app/modules/product-configuration/models/MutuiDetailsModel';
import { SignatureStatusModel } from 'src/app/modules/vendita/models/signature-status.model';
import { CommonService } from 'src/app/services/common.service';
import { EndpointsService } from '../../../../../../services/endpoints.service';
@Component({
  selector: 'bst-fin-dati-stipula-richiedente',
  templateUrl: './dati-stipula-richiedente.component.html',
  styleUrls: ['./dati-stipula-richiedente.component.scss']
})
export class DatiStipulaRichiedenteComponent implements OnInit {

  @Input() fetchMutuoDetailsResponse: MutuiDetailsModel;
  @Input() postDeliberaPageStatus: any;
  @Input() postDeliberaData: PostDeliberaData;
  @Input() mainUser: BaseClientModel;
  @Input() intestatari: BaseClientModel[];
  @Input() mutuoChirografario: boolean;
  documentGenerationList: DocumentGeneration[] = [];
  @ViewChild('datiStipulaForm') datiStipulaForm: NgForm;
  signatureStatusModel: SignatureStatusModel;
  idProposal: any;
  accreditoContentField: string;
  addebitoContentField: string;
  accreditos: any[];
  accreditosdropdown: SelectOptionModel[];
  tmpAccountsTop: string;
  tmpAccountsBottom: string;
  inputEvents: EventsModel[] = [];
  saveDatiRichiedenteChiro: EventsModel[] = [];
  addebitoDetailList: ContoAddebitoDetailsModel[] = []
  disableConferma: boolean;
  generateDoc: GenerateDoc;
  altro = {
    value: 'ALTRO',
    description: 'ALTRO'
  };
  importoDiStipula: any;
  dataDiPresuntaStipula: any;
  bonifico: SelectOptionModel[] = [];
  addebito: SelectOptionModel[];
  accountListWithIban: any[];

  raccogliFirmeAbilitato: boolean;
  moduliFirmati: boolean;

  modalitaErogazioneMuto: string;
  isPartitaDCModalita: boolean;
  docType: string = FinDocumentType.MODULO_ACCREDITO_ADDEBITO_RATE;
  contrattiSignatureInput: ContrattiSignatureInput;
  dossierGenerationArr: DossierGeneration[] = [];
  contrattiSignatureType: ContrattiSignatureType;
  constructor(private modulisticaPraticheService: ModulisticaPraticheService,
    private commonService: CommonService, private endpointsService: EndpointsService,
    private postDeliberaService: PostDeliberaService, private route: ActivatedRoute, private redirectService: RedirectService) {
    this.accreditos = [];
    this.accreditosdropdown = [];
    this.route.params.subscribe(params => this.idProposal = params['proposalId']);
  }

  ngOnInit() {

    this.signatureStatusModel = new SignatureStatusModel();
    this.signatureStatusModel.processId = Number(this.idProposal);
    this.signatureStatusModel.processType = TipoProcesso.VENDITA;
    const documentGenerationList: ContrattiDocument[] = [];
    documentGenerationList.push({ toSign: true, docType: this.docType });
    this.signatureStatusModel.documents = documentGenerationList;
    this.dossierGenerationArr = this.createDossierGenerationList();
    this.getContrattiSignatureInput();
    if (this.mutuoChirografario) {
      this.bonifico.push({ 'description': 'Bonifico su C/C', 'value': 'bonifico' });
      this.bonifico.push({ 'description': 'Partita D/C (Debitori/Creditori)', 'value': 'partitaDC' });
    } else {
      this.bonifico.push({ 'description': 'Bonifico su C/C', 'value': 'bonifico' });
    }

    this.modalitaErogazioneMuto = this.bonifico.find(obj => obj.value === 'bonifico').value;

    this.inputEvents = [
      { eventName: 'click', eventCallBack: this.raccogliFirmeClicked.bind(this) }
    ];

    this.saveDatiRichiedenteChiro = [
      { eventName: 'click', eventCallBack: this.saveData.bind(this) }
    ];

    if (this.mutuoChirografario) {
      this.datiStipulaForm.valueChanges.subscribe(() => {
        this.checkFormChanges();
      });
    }

    const listNdg: String[] = [];
    this.intestatari.forEach(client => listNdg.push(client.ndg));
    this.modulisticaPraticheService.getBankAccountsListDetails(listNdg).subscribe(accountList => {
      if (accountList !== null) {
        accountList.forEach(data => {
          const account = [];
          account['value'] = data.ibanCode;
          account['description'] = data.filialeConto + '/' + data.number.toString();
          this.accreditos.push(account);
        });
        this.fillAccountDetailList(accountList);
      }
    }, null, () => {
      this.accreditos.push(this.altro);
      this.accreditosdropdown = this.accreditos;
      if (this.postDeliberaData && (this.postDeliberaData.ibanAccredito || this.postDeliberaData.ibanAddebito)) {
        if (this.postDeliberaData.ibanAccredito && this.accreditos[0].description !== 'ALTRO') {
          if (this.postDeliberaData.modalitaAccredito) {
            this.modalitaErogazioneMuto = this.postDeliberaData.modalitaAccredito;
            this.changeModalitaErogazioneMuto();
          }

          const result = this.accreditosdropdown.find(data => data.value === this.postDeliberaData.ibanAccredito);
          if (result) {
            this.tmpAccountsTop = result.value;
          } else if (this.postDeliberaData.ibanAccredito && result == undefined) {
            this.tmpAccountsTop = 'ALTRO';
          }
        } else {
          this.tmpAccountsTop = this.altro.value;
        }
        if (this.postDeliberaData.ibanAddebito && this.accreditos[0].description !== 'ALTRO') {
          const result = this.accreditosdropdown.find(data => data.value === this.postDeliberaData.ibanAddebito);
          if (result) {
            this.tmpAccountsBottom = result.value;
          } else if (this.postDeliberaData.ibanAddebito && result == undefined) {
            this.tmpAccountsBottom = 'ALTRO';
          }
        } else {
          this.tmpAccountsBottom = this.altro.value;
        }
        this.accreditoContentField = this.postDeliberaData.ibanAccredito;
        this.addebitoContentField = this.postDeliberaData.ibanAddebito;

        if (this.postDeliberaData.ibanAddebito) {
          this.setContoAddebitoDetails(this.postDeliberaData.ibanAddebito);
        }

        if (this.postDeliberaData.ibanAccredito) {
          this.setContoAccreditoDetails(this.postDeliberaData.ibanAccredito);
        }

        this.controllaAbilitaRaccoltaFirme();
        if (!this.mutuoChirografario) {
          this.checkSignatureStatus();
        }
      } else if (this.accreditos[0].description === 'ALTRO') {
        this.tmpAccountsTop = this.altro.value;
        this.tmpAccountsBottom = this.altro.value;
      }
    });

    if (!this.mutuoChirografario) {
      this.postDeliberaService.getImportoDiStipula().subscribe(data => {
        this.importoDiStipula = data;
      });
      this.postDeliberaService.getStipulaDate().subscribe(date => {
        if (date) {
          this.dataDiPresuntaStipula = new Date(date.year, date.month - 1, date.day);
        }
      });
    }
  }

  checkFormChanges() {
    const modalitaEr = this.bonifico.find(val => val.value === this.modalitaErogazioneMuto);
    let isMod = false;
    if (modalitaEr) {
      isMod = true;
    }

    let contoAccreditovalid = false;
    if (this.tmpAccountsTop === 'ALTRO') {
      contoAccreditovalid = true;
    } else {
      this.accreditosdropdown.forEach(v => {
        if (v.value === this.tmpAccountsTop) {
          contoAccreditovalid = true;
          return;
        }
      });
    }

    let ibanAccreditoValid = false;
    const ibanAccreditoControl = this.datiStipulaForm.controls.ibanAccredito;
    if (ibanAccreditoControl && ibanAccreditoControl.value && ibanAccreditoControl.value.length == 27) {
      ibanAccreditoValid = true;
    }

    let contoAddebitovalid = false;
    if (this.tmpAccountsBottom === 'ALTRO') {
      contoAddebitovalid = true;
    } else {
      this.accreditosdropdown.forEach(v => {
        if (v.value === this.tmpAccountsBottom) {
          contoAddebitovalid = true;
          return;
        }
      });
    }

    let ibanAddebitoValid = false;
    const ibanAddebitoControl = this.datiStipulaForm.controls.ibanAddebito;
    if (ibanAddebitoControl && ibanAddebitoControl.value && ibanAddebitoControl.value.length == 27) {
      ibanAddebitoValid = true;
    }

    if (isMod && contoAccreditovalid && ibanAccreditoValid && contoAddebitovalid && ibanAddebitoValid) {
      if (this.datiStipulaForm.pristine) {
        this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaRichiedente = true;
        this.disableConferma = true;
      } else {
        this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaRichiedente = false;
        this.disableConferma = false;
      }
    } else {
      this.disableConferma = true;
      this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaRichiedente = false;
    }

    let isModified = false;
    if ((this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaRichiedente
      && !this.postDeliberaPageStatus.datiStipulaEdErogazione_current) ||
      (!this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaRichiedente
        && this.postDeliberaPageStatus.datiStipulaEdErogazione_current)) {
      isModified = true;
    }
    if (isModified) {
      this.postDeliberaService.setpostDeliberaPageStatusChiro(this.postDeliberaPageStatus);
    }
  }

  private checkSignatureStatus() {
    const data = <SignatureStatusModel>{
      processId: Number(this.idProposal),
      processType: TipoProcesso.VENDITA,
      docToGenerate: [FinDocumentType.MODULO_ACCREDITO_ADDEBITO_RATE]
    };
    this.commonService.checkSignatureStatus(data).subscribe(response => {
      this.moduliFirmati = response;
      this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaRichiedente = this.moduliFirmati;
      this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
    });
  }

  getContrattiSignatureInput() {

    const dossierDetails = {
      processId: this.signatureStatusModel.processId,
      processType: this.signatureStatusModel.processType,
      dossierGenerationList: this.dossierGenerationArr
    }

    this.commonService.getContrattiSignatureInput(dossierDetails).subscribe(flagInput => {
      this.contrattiSignatureInput = {
        isFeqEnabled: flagInput.feqEnabled,
        isSendOnly: flagInput.sendOnly,
        isSignatureInProgress: flagInput.signatureInProgress,
        signatureInProgressType: flagInput.signatureInProgressType
        // sendMailForSecci: true
      }
    });
  }

  onClickFirmaAltreModalita(signType: ContrattiSignatureType) {
    if (signType) {
      this.contrattiSignatureType = signType;
      this.raccogliFirmeClicked();
    }
  }

  onClickRaccogliMancanti(signType: ContrattiSignatureType) {
    if (signType) {
      this.contrattiSignatureType = signType;
      this.raccogliFirmeClicked();
    }
  }

  onClickInviaMail() {
    // this.sendOrSignDocument(true, null);
  }

  saveData() {
    const postDeliberaDatiRichiedente: PostDeliberaDatiRichiedente = new PostDeliberaDatiRichiedente();
    postDeliberaDatiRichiedente.idProcesso = this.idProposal;
    postDeliberaDatiRichiedente.tipoProcesso = TipoProcesso.VENDITA;

    postDeliberaDatiRichiedente.modalitaAccredito = this.modalitaErogazioneMuto;
    postDeliberaDatiRichiedente.ibanAccredito = this.accreditoContentField;
    postDeliberaDatiRichiedente.ibanAddebito = this.addebitoContentField;
    this.postDeliberaService.saveDatiRichiedenteStipula(postDeliberaDatiRichiedente).subscribe(result => {
      if (result) {
        this.disableConferma = true;
        this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaRichiedente = true;
        this.postDeliberaService.setpostDeliberaPageStatusChiro(this.postDeliberaPageStatus);
        this.setContoAddebitoDetails(this.addebitoContentField);
        this.setContoAccreditoDetails(this.accreditoContentField);
      }
    });
  }

  raccogliFirmeClicked() {
    const postDeliberaDatiRichiedente: PostDeliberaDatiRichiedente = new PostDeliberaDatiRichiedente();
    postDeliberaDatiRichiedente.idProcesso = this.idProposal;
    postDeliberaDatiRichiedente.tipoProcesso = TipoProcesso.VENDITA;
    postDeliberaDatiRichiedente.modalitaAccredito = null;
    postDeliberaDatiRichiedente.ibanAccredito = this.accreditoContentField;
    postDeliberaDatiRichiedente.ibanAddebito = this.addebitoContentField;
    this.postDeliberaService.saveDatiRichiedenteStipula(postDeliberaDatiRichiedente).subscribe(result => {
      if (result) {
        this.goToGeneratePrecontract();
      }
    }, err => {
      console.log('error calling saveDatiRichiedenteStipula');
      this.goToGeneratePrecontract();
    });
  }

  goToGeneratePrecontract() {
    const generateDoc = new GenerateDoc();
    generateDoc.processId = Number(this.idProposal);

    const param: ModuloAccreditoAddebito = new ModuloAccreditoAddebito();
    param.processId = this.idProposal;
    param.importoMutuo = this.fetchMutuoDetailsResponse.amount;
    param.durataMutuo = Number(this.fetchMutuoDetailsResponse.durata);
    param.idPef = this.fetchMutuoDetailsResponse.idPef;
    param.processType = TipoProcesso.VENDITA;
    param.dataStipula = this.dataDiPresuntaStipula;

    let numContoAddebito = 0;
    const descContoAddebito = this.accreditosdropdown.find(data => data.value === this.addebitoContentField);
    if (descContoAddebito) {
      numContoAddebito = Number(descContoAddebito.description.split('/')[1]);
    }

    let numContoAccredito = 0;
    const descContoAccredito = this.accreditosdropdown.find(data => data.value === this.accreditoContentField);
    if (descContoAccredito) {
      numContoAccredito = Number(descContoAccredito.description.split('/')[1]);
    }

    const contoAddebito: ContoModel = new ContoModel();
    contoAddebito.numero = numContoAddebito;
    contoAddebito.intestazione = this.intestatari[0].name + ' ' + this.intestatari[0].surname;
    contoAddebito.iban = this.addebitoContentField;
    param.contoAddebito = contoAddebito;

    const contoAccredito: ContoModel = new ContoModel();
    contoAccredito.numero = numContoAccredito;
    contoAccredito.intestazione = this.intestatari[0].name + ' ' + this.intestatari[0].surname;
    contoAccredito.iban = this.accreditoContentField;
    param.contoAccredito = contoAccredito;

    generateDoc.paramsGenerateEndpoint = param;
    generateDoc.processType = TipoProcesso.VENDITA;
    generateDoc.callbackUrl = this.endpointsService.callbackToPostDelibera + this.idProposal;
    // const documentGenerationArr: DocumentGeneration[] = [];
    // const docObj = new DocumentGeneration();
    // docObj.documentType = FinDocumentType.MODULO_ACCREDITO_ADDEBITO_RATE;
    param.clientList = this.intestatari;
    // docObj.signers = this.intestatari;
    // docObj.mainNdg = this.mainUser.ndg;
    // documentGenerationArr.push(docObj);
    generateDoc.documentList = this.documentGenerationList;
    generateDoc.generateEndpoint = this.endpointsService.generateModuloAccreditoAddebitoRate;
    generateDoc.deliveredEndpoint = this.endpointsService.setDocumentsDelivered;
    // this.saveModuloAccreditoAddebitoRateGenDoc(generateDoc);
    generateDoc.dossiers = this.dossierGenerationArr;
    this.commonService.saveInSession(generateDoc, this.signatureStatusModel, true, this.contrattiSignatureType, this.contrattiSignatureInput.isSignatureInProgress);
  }

  saveModuloAccreditoAddebitoRateGenDoc(generateDoc: GenerateDoc) {
    this.commonService.saveContrattiInputInSession(generateDoc).subscribe(() => {
      const signatureStatus = new SignatureStatusModel();
      signatureStatus.processId = Number(this.idProposal);
      signatureStatus.processType = TipoProcesso.VENDITA;
      signatureStatus.docToGenerate = [];
      signatureStatus.docToGenerate.push(FinDocumentType.MODULO_ACCREDITO_ADDEBITO_RATE);
      this.redirectService.redirectWithSpinner(this.endpointsService.openContratti
        + '/' + encodeURIComponent(JSON.stringify(signatureStatus)));
    });
  }

  updateIban() {
    this.postDeliberaPageStatus.datiStipulaRichiedenteData.accreditoContentField = this.accreditoContentField;
    this.postDeliberaPageStatus.datiStipulaRichiedenteData.addebitoContentField = this.addebitoContentField;
    this.postDeliberaService.updatePostDeliberaData(this.postDeliberaPageStatus);
  }

  public publishIbanContoDiAccredito(iban) {
    this.postDeliberaService.setIbanContoDiAccredito(iban);
  }

  toUpperADDEBITO() {
    this.addebitoContentField = this.addebitoContentField.toUpperCase();
  }

  toUpperCaseACCREDITO() {
    this.accreditoContentField = this.accreditoContentField.toUpperCase();
  }

  controllaAbilitaRaccoltaFirme() {
    if (!this.mutuoChirografario) {
      if (this.accreditoContentField && this.accreditoContentField.length === 27
        && this.addebitoContentField && this.addebitoContentField.length === 27) {
        this.moduliFirmati = false;
        this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaRichiedente = false;
        this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
        this.raccogliFirmeAbilitato = true;
      } else {
        this.raccogliFirmeAbilitato = false;
      }
    }
  }

  // Method is use to change MODALITA DI EROGAZIONE DEL MUTUO filed value
  changeModalitaErogazioneMuto() {
    if (this.modalitaErogazioneMuto === 'partitaDC') {
      this.tmpAccountsTop = this.accreditos.find(obj => obj.value === 'ALTRO').value;
      this.isPartitaDCModalita = true;
    } else {
      this.tmpAccountsTop = undefined;
      this.isPartitaDCModalita = false;
    }
  }

  fillAccountDetailList(data: any[]) {
    data.forEach(account => {
      this.addebitoDetailList.push({
        iban: account.ibanCode,
        branch: account.filialeConto,
        service: account.codiceServizio,
        number: account.number,
        category: account.categoriaRapporto,
        intestazioneCompleta: account.intestazione,
        accountNoBper: false
      });
    });
  }

  setContoAddebitoDetails(iban: string) {
    let addebitoDetail: ContoAddebitoDetailsModel = new ContoAddebitoDetailsModel();
    if (this.tmpAccountsBottom !== 'ALTRO') {
      addebitoDetail = this.addebitoDetailList.find(conto => conto.iban === iban);
      this.postDeliberaService.setAltroContoAddebito(false);
    } else {
      addebitoDetail.iban = this.addebitoContentField;
      addebitoDetail.accountNoBper = true;
      this.postDeliberaService.setAltroContoAddebito(true);
    }
    this.postDeliberaService.setContoAddebitoDetails(addebitoDetail);
  }

  setContoAccreditoDetails(iban: string) {
    let accreditoDetail: ContoAddebitoDetailsModel = new ContoAddebitoDetailsModel();
    if (this.tmpAccountsBottom !== 'ALTRO') {
      accreditoDetail = this.addebitoDetailList.find(conto => conto.iban === iban);
    } else {
      accreditoDetail.iban = this.accreditoContentField;
      accreditoDetail.accountNoBper = true;
    }
    this.postDeliberaService.setContoAccreditoDetails(accreditoDetail);
  }

  createDossierGenerationList(): DossierGeneration[] {
    // const intestatari = this.clientBaseList.filter(holder => !holder.cointestazione && holder.role === MortgageClientRoles.INTESTATARI);
    // const mainUser = this.commonService.getMainUser(this.clientBaseList.filter(holder => holder.role === MortgageClientRoles.INTESTATARI));
    // const jointHeading = this.clientBaseList.filter(holder => holder.cointestazione)[0];

    const dossierGenerationArr: DossierGeneration[] = [];
    const documentGenerationArr: DocumentGeneration[] = [];
    const dossierDocSignerArr: DossierDocSigner[] = [];
    const dossierObj = new DossierGeneration();
    dossierObj.groupBy = 'SIGNER';
    dossierObj.onlyFeaSign = false;
    dossierObj.onlyPaperSign = true;
    const docObj = new DocumentGeneration();
    docObj.titolo = this.docType;
    docObj.documentType = this.docType;
    docObj.mainNdg = this.mainUser.ndg;
    docObj.signers = this.intestatari;
    // docObj.jointHeading = this.jointHeading;
    docObj.mainClient = { ndg: this.mainUser.ndg, naturaGiuridica: (!this.mainUser.cointestazione) ? 'PERSONA_FISICA' : 'COINTESTAZIONE' };
    docObj.toSign = true;
    docObj.toReprint = false;
    docObj.mandatory = true;
    const dossierDocSignerObj = new DossierDocSigner();
    dossierDocSignerObj.ndg = this.mainUser.ndg;
    dossierDocSignerObj.type = this.mainUser.role;
    dossierDocSignerObj.mandatory = true;
    dossierDocSignerArr.push(dossierDocSignerObj);
    docObj.dossierDocSigners = dossierDocSignerArr;
    documentGenerationArr.push(docObj);
    dossierObj.documents = documentGenerationArr;
    this.documentGenerationList = documentGenerationArr;
    dossierGenerationArr.push(dossierObj);
    return dossierGenerationArr;
  }
}
