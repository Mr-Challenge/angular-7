import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatiStipulaErogazioneComponent } from './dati-stipula-erogazione.component';

describe('DatiStipulaErogazioneComponent', () => {
  let component: DatiStipulaErogazioneComponent;
  let fixture: ComponentFixture<DatiStipulaErogazioneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatiStipulaErogazioneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatiStipulaErogazioneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
