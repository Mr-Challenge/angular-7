import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatiStipulaGeneraliComponent } from './dati-stipula-generali.component';

describe('DatiStipulaGeneraliComponent', () => {
  let component: DatiStipulaGeneraliComponent;
  let fixture: ComponentFixture<DatiStipulaGeneraliComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatiStipulaGeneraliComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatiStipulaGeneraliComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
