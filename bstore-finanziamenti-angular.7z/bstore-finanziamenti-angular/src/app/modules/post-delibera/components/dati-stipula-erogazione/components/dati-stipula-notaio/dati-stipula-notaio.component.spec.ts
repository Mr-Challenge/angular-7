import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatiStipulaNotaioComponent } from './dati-stipula-notaio.component';

describe('DatiStipulaNotaioComponent', () => {
  let component: DatiStipulaNotaioComponent;
  let fixture: ComponentFixture<DatiStipulaNotaioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatiStipulaNotaioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatiStipulaNotaioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
