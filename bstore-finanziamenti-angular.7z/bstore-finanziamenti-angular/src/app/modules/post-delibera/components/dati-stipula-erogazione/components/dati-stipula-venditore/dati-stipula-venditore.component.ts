import { formatDate } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RedirectService } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { SelectOptionModel } from 'bstore-angular-library/lib/models/select-option-model';
import { forkJoin } from 'rxjs';
import { FinDocumentType } from 'src/app/constant/documentType';
import { TipoProcesso } from 'src/app/constant/tipoProcesso';
import { DocumentGeneration } from 'src/app/models/documentGeneration.model';
import { Assegno, AssegnoBonifico, Beneficiario, BeneficiarioDtl, DisposizioneBonificoInEuroParam, DossierGeneration, EmissioneAssegniParam, GenerateDoc, ModalitaPagamento, Presentatore, RichiestaAssegni, TipoLiquidazione } from 'src/app/models/generateDoc.model';
import { PostDeliberaData } from 'src/app/models/post-delibera/postDeliberaData.model';
import { PostDeliberaDatiVenditore } from 'src/app/models/post-delibera/postDeliberaDatiVenditore.model';
import { PostDeliberaSezioneVenditore } from 'src/app/models/post-delibera/postDeliberaSezioneVenditore.model';
import { PostDeliberaService } from 'src/app/modules/post-delibera/services/post-delibera.service';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { SignatureStatusModel } from 'src/app/modules/vendita/models/signature-status.model';
import { CommonService } from 'src/app/services/common.service';
import { EndpointsService } from 'src/app/services/endpoints.service';

@Component({
  selector: 'bst-fin-dati-stipula-venditore',
  templateUrl: './dati-stipula-venditore.component.html',
  styleUrls: ['./dati-stipula-venditore.component.scss']
})
export class DatiStipulaVenditoreComponent implements OnInit {

  @Input() postDeliberaPageStatus: any;
  @Input() postDeliberaData: PostDeliberaData;
  @Input() mainUser: BaseClientModel;
  @Input() intestatari: BaseClientModel[];
  @Input() jointHeading: BaseClientModel;

  idProposal: string;
  importoErrorMsg: string;
  isValidImportoTotal = true;
  formArray: FormArray;
  venditoreFormGroup: FormGroup;
  dataDiPresuntaStipula: any;
  showRaccogliFirmeVenditore: boolean;
  moduliFirmati: boolean;
  canIDeleteDocs: boolean;

  addVenditoreForm: EventsModel[] = [];
  raccogliFirmeEvent: EventsModel[] = [];

  accreditoOptions: SelectOptionModel[] = [
    {
      value: 'true',
      description: 'Bonifico su C/C'
    },
    {
      value: 'false',
      description: 'Assegno circolare'
    }
  ];

  constructor(private formBuilder: FormBuilder, private commonService: CommonService,
    private route: ActivatedRoute,
    private endpointsService: EndpointsService,
    private redirectService: RedirectService,
    private postDeliberaService: PostDeliberaService) {
    this.route.params.subscribe(params => this.idProposal = params['proposalId']);
  }

  ngOnInit() {
    this.checkSignatureStatus();

    this.postDeliberaService.getImportoPrimaErogazione().subscribe((data) => {
      if (this.venditoreFormGroup &&
        this.venditoreFormGroup.get('venditores')['controls'][0].get('importo').value !== '') { this.validateImporto(); }
    });
    this.postDeliberaService.getImportoDiStipula().subscribe((data) => {
      if (this.venditoreFormGroup &&
        this.venditoreFormGroup.get('venditores')['controls'][0].get('importo').value !== '') { this.validateImporto(); }
    });
    this.raccogliFirmeEvent = [
      { eventName: 'click', eventCallBack: this.raccogliFirme.bind(this) }
    ];


    this.addVenditoreForm = [
      { eventName: 'click', eventCallBack: this.addVenditori.bind(this) }
    ];

    this.initializeVenditori();
    this.venditoreFormGroup.valueChanges.subscribe(() => {
      this.validateImporto();
      this.moduliFirmati = false;
      this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaVenditore = false;
      this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
      this.verifyIfShowRaccogliFirme();
    });

    this.dataDiPresuntaStipula = this.postDeliberaPageStatus.datiStipulaGeneraliData.dataDiPresuntaStipula;

    this.verifyIfShowRaccogliFirme();
  }

  addVenditori() {
    this.addItem('', '', '', '');
  }

  private checkSignatureStatus() {
    const data = <SignatureStatusModel>{
      processId: Number(this.idProposal),
      processType: TipoProcesso.VENDITA,
      docToGenerate: [FinDocumentType.EMISSIONE_ASSEGNI]
    };

    const dataBis = <SignatureStatusModel>{
      processId: Number(this.idProposal),
      processType: TipoProcesso.VENDITA,
      docToGenerate: [FinDocumentType.DISPOSIZIONE_BONIFICO]
    };

    forkJoin([this.commonService.checkSignatureStatus(data), this.commonService.checkSignatureStatus(dataBis)]).subscribe(completed => {
      this.moduliFirmati = completed[0] || completed[1];
      this.canIDeleteDocs = this.moduliFirmati;
      this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaVenditore = this.moduliFirmati;
      this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
    });


  }

  raccogliFirme() {

    // DELETE THE DOCUMENT IF WE ARE SIGNING FOR THE SECOND TIME
    if (this.canIDeleteDocs) {
      const dataToDelete = <SignatureStatusModel>{
        processId: Number(this.idProposal),
        processType: TipoProcesso.VENDITA,
        docToGenerate: [FinDocumentType.EMISSIONE_ASSEGNI, FinDocumentType.DISPOSIZIONE_BONIFICO]
      };
      forkJoin([this.commonService.deleteDocuments(dataToDelete)]).subscribe();
    }

    const venditoriList: PostDeliberaDatiVenditore[] = [];
    const postDeliberaSezioneVenditore: PostDeliberaSezioneVenditore = new PostDeliberaSezioneVenditore();

    postDeliberaSezioneVenditore.idProcesso = Number(this.idProposal);
    postDeliberaSezioneVenditore.tipoProcesso = TipoProcesso.VENDITA;

    const venditores = this.venditoreFormGroup.get('venditores').value;
    venditores.forEach(venditore => {
      const datiVenditore: PostDeliberaDatiVenditore = new PostDeliberaDatiVenditore();
      datiVenditore.nomeCognome = venditore.nameECognome;
      datiVenditore.importo = parseFloat(this.postDeliberaService.stringToDouble(venditore.importo));

      if (venditore.modalitaDiAccredito === 'true') {
        datiVenditore.modalitaAccredito = 'BONIFICO';
        datiVenditore.ibanAccredito = venditore.iban;
      } else {
        datiVenditore.modalitaAccredito = 'ASSEGNO';
        datiVenditore.ibanAccredito = null;
      }
      venditoriList.push(datiVenditore);
    });

    postDeliberaSezioneVenditore.venditoriList = venditoriList;

    this.postDeliberaService.saveDatiVenditoreStipula(postDeliberaSezioneVenditore).subscribe(result => {
      if (result) {
        const bonificoList = venditores.filter(obj => obj.modalitaDiAccredito === 'true');
        const assegnoList = venditores.filter(obj => obj.modalitaDiAccredito === 'false');
        this.assembleInputDoc(bonificoList, assegnoList);
      }
    })
  }

  assembleInputDoc(bonificoList, assegnoList) {
    const generateDoc = new GenerateDoc();
    generateDoc.processId = Number(this.idProposal);
    generateDoc.processType = TipoProcesso.VENDITA;
    generateDoc.callbackUrl = this.endpointsService.callbackToPostDelibera + this.idProposal;
    generateDoc.paramsGenerateEndpoint = {};
    const dossier = new DossierGeneration();
    dossier.groupBy = 'SIGNER';
    generateDoc.dossiers.push(dossier);

    const assegnoBonifico = new AssegnoBonifico();
    assegnoBonifico.disposizioneBonificoInEuroVm = [];

    if (bonificoList.length > 0) {
      bonificoList.forEach(bonifico => {
        const docBonifico = new DocumentGeneration();

        docBonifico.signers = this.intestatari;
        docBonifico.mainNdg = this.mainUser.ndg;
        docBonifico.documentType = FinDocumentType.DISPOSIZIONE_BONIFICO;
        docBonifico.titolo = 'Bonifico ' + bonifico.nameECognome;
        dossier.documents.push(docBonifico);

        const presentatore = new Presentatore();
        presentatore.ndg = this.mainUser.ndg;
        presentatore.toRefresh = true;

        const tipoLiquidazione = new TipoLiquidazione();
        tipoLiquidazione.tipo = 'CC';
        tipoLiquidazione.ccAddebito = this.postDeliberaData.ibanAddebito;
        tipoLiquidazione.intestazione = this.mainUser.name + ' ' + this.mainUser.surname;
        tipoLiquidazione.dataEsecuzione = formatDate(this.dataDiPresuntaStipula, 'dd-MM-yyyy', 'en-US');

        const beneficiarioDtl = new BeneficiarioDtl();
        beneficiarioDtl.iban = bonifico.iban;
        beneficiarioDtl.valutaBeneficiario = formatDate(this.dataDiPresuntaStipula, 'dd-MM-yyyy', 'en-US');
        beneficiarioDtl.dataEsecuzione = formatDate(this.dataDiPresuntaStipula, 'dd-MM-yyyy', 'en-US');
        beneficiarioDtl.nome = bonifico.nameECognome;

        const beneficiario = new Beneficiario();
        beneficiario.tipoRichiesta = 'ORDINARIO';
        beneficiario.importo = bonifico.importo;
        beneficiario.tipoLiquidazione = tipoLiquidazione;
        beneficiario.beneficiarioInput = beneficiarioDtl;

        const disposizioneBonificoInEuroVm = new DisposizioneBonificoInEuroParam();
        disposizioneBonificoInEuroVm.idProposta = Number(this.idProposal);
        disposizioneBonificoInEuroVm.clients = this.intestatari;
        disposizioneBonificoInEuroVm.jointHeading = this.jointHeading;
        disposizioneBonificoInEuroVm.beneficiario = beneficiario;
        disposizioneBonificoInEuroVm.presentatoreInputlist.push(presentatore);

        assegnoBonifico.disposizioneBonificoInEuroVm.push(disposizioneBonificoInEuroVm);
      });
    }

    if (assegnoList.length > 0) {
      const docAssegno = new DocumentGeneration();
      const richiestaAssegni: RichiestaAssegni = new RichiestaAssegni();
      const modalitaPagamento: ModalitaPagamento = new ModalitaPagamento();

      docAssegno.signers = this.intestatari;
      docAssegno.mainNdg = this.mainUser.ndg;
      docAssegno.documentType = FinDocumentType.EMISSIONE_ASSEGNI;
      dossier.documents.push(docAssegno);

      modalitaPagamento.iban = this.postDeliberaData.ibanAddebito;
      modalitaPagamento.intestazione = this.mainUser.name + ' ' + this.mainUser.surname;

      const emissioneAssegniDocumentVm: EmissioneAssegniParam = new EmissioneAssegniParam();

      let totaleImporti = 0;
      assegnoList.forEach(data => {
        const assegno: Assegno = new Assegno();
        assegno.ordinatario = data.nameECognome;
        assegno.importo = Number(this.postDeliberaService.stringToDouble(data.importo));
        totaleImporti = totaleImporti + Number(this.postDeliberaService.stringToDouble(data.importo));
        assegno.tipo = 'NT';
        richiestaAssegni.listaAssegni.push(assegno);
      });

      richiestaAssegni.modalitaPagamento = modalitaPagamento;
      richiestaAssegni.totale = totaleImporti;

      emissioneAssegniDocumentVm.clientList = this.intestatari;
      emissioneAssegniDocumentVm.jointHeading = this.jointHeading;
      emissioneAssegniDocumentVm.processId = this.idProposal;
      emissioneAssegniDocumentVm.processType = TipoProcesso.VENDITA;
      emissioneAssegniDocumentVm.richiestaAssegniVm = richiestaAssegni;
      assegnoBonifico.emissioneAssegniDocumentVm = emissioneAssegniDocumentVm;
    }

    generateDoc.generateEndpoint = this.endpointsService.generateAssegnoBonifico;
    generateDoc.paramsGenerateEndpoint = assegnoBonifico;

    this.saveVenditoreGenDoc(generateDoc);

  }

  saveVenditoreGenDoc(generateDoc: GenerateDoc) {
    this.commonService.saveContrattiInputInSession(generateDoc).subscribe(() => {
      const signatureStatus = new SignatureStatusModel();
      signatureStatus.processId = Number.parseInt(this.idProposal, 10);
      signatureStatus.processType = TipoProcesso.VENDITA;
      signatureStatus.docToGenerate = [];
      generateDoc.dossiers.forEach(dossier => {
        dossier.documents.forEach(doc => {
          signatureStatus.docToGenerate.push(doc.documentType);
        });
      });
      this.redirectService.redirectWithSpinner(this.endpointsService.openContratti + '/'
        + encodeURIComponent(JSON.stringify(signatureStatus)));
    });
  }

  validateImporto() {
    const venditores = this.venditoreFormGroup.get('venditores').value;
    if (this.venditoreFormGroup.get('venditores').value[0].importo !== 0) {
      const importoTotal = venditores.reduce((total, data) =>
        total = total + this.toDecimal(data.importo)
        , 0);
      if (this.postDeliberaPageStatus.datiStipulaGeneraliData.statoAvanzamentoLavori) {
        this.importoErrorMsg = "L\'importo da corrispondere a titolo di pagamento dell\'immobile deve essere uguale all\'importo di prima erogazione";
        if (importoTotal === this.postDeliberaPageStatus.datiStipulaGeneraliData.importoPrimaErogazione) {
          this.isValidImportoTotal = true;
        } else {
          this.isValidImportoTotal = false;
        }
      } else {
        this.importoErrorMsg = "L\'importo da corrispondere a titolo di pagamento dell\'immobile deve essere uguale all\'importo di stipula";
        if (importoTotal === this.postDeliberaPageStatus.datiStipulaGeneraliData.importoDiStipula) {
          this.isValidImportoTotal = true;
        } else {
          this.isValidImportoTotal = false;
        }
      }
      if (!this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaVenditore) {
        this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaVenditore = false;
        this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
      }
    }

  }

  toDecimal(number) {
    if ((parseFloat(number).toString()).indexOf('NaN')) {
      return parseFloat(number.replace(new RegExp('[.]', 'g'), '').replace(',', '.'));
    }
    return 0;
  }

  initializeVenditori(): void {
    this.venditoreFormGroup = this.formBuilder.group({
      venditores: this.formBuilder.array([])
    });
    if (this.postDeliberaData && this.postDeliberaData.venditoriList) {
      this.populateVenditori();
    } else {
      this.addItem('', '', '', '');
    }
  }

  populateVenditori(): void {
    this.venditoreFormGroup = this.formBuilder.group({
      venditores: this.formBuilder.array([])
    });
    this.postDeliberaData.venditoriList.forEach(vendi => {
      this.addItem(vendi['nomeCognome'], vendi['modalitaAccredito'], vendi['importo'].toString(), vendi['ibanAccredito']);
    });
    this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaVenditore = true;
    this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
  }

  addItem(nameECognome, modalitaDiAccredito, importo, iban) {
    this.formArray = this.venditoreFormGroup.get('venditores') as FormArray;
    this.formArray.push(this.createVenditore(nameECognome, modalitaDiAccredito, importo, iban));
  }

  createVenditore(nameECognome, modalitaDiAccredito, importo, iban) {
    modalitaDiAccredito = (modalitaDiAccredito === 'BONIFICO') ? 'true' : 'false';
    return this.formBuilder.group({
      nameECognome: [nameECognome, Validators.required],
      modalitaDiAccredito: [modalitaDiAccredito, Validators.required],
      importo: [importo, Validators.required],
      iban: [iban, this.ValidateIBan],
    });
  }

  removeVenditory(i) {
    this.formArray = this.venditoreFormGroup.get('venditores') as FormArray;
    this.formArray.removeAt(i);
    this.validateImporto();
  }

  controllaChangeVenditore(index) {
    this.venditoreFormGroup.get(['venditores', index, 'iban']).setValue('');
  }

  ValidateIBan(control: AbstractControl) {
    if (control.root.get('modalitaDiAccredito') && control.root.get('modalitaDiAccredito').value === 'false') {
      return { validUrl: true };
    } else if (control.root.get('modalitaDiAccredito') && control.root.get('modalitaDiAccredito').value === 'true' &&
      control.value.length === 27) {
      return { validUrl: true };
    } else {
      return null;
    }
  }

  verifyIfShowRaccogliFirme() {
    const venditores = this.venditoreFormGroup.get('venditores').value;
    let totale = 0;
    let validi = 0;
    venditores.forEach(element => {
      totale++;
      element.iban = element.modalitaDiAccredito === 'true' ? element.iban : '';
      if (element.nameECognome && this.validateImporto && ((element.modalitaDiAccredito === 'true' && element.iban)
        || (element.modalitaDiAccredito === 'false'))) {
        this.isValidImportoTotal ? validi++ : false;
      }
    });

    if (totale === validi) {
      this.showRaccogliFirmeVenditore = true;
    } else {
      this.showRaccogliFirmeVenditore = false;
    }
  }
}


