import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatiStipulaRichiedenteComponent } from './dati-stipula-richiedente.component';

describe('DatiStipulaRichiedenteComponent', () => {
  let component: DatiStipulaRichiedenteComponent;
  let fixture: ComponentFixture<DatiStipulaRichiedenteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatiStipulaRichiedenteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatiStipulaRichiedenteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
