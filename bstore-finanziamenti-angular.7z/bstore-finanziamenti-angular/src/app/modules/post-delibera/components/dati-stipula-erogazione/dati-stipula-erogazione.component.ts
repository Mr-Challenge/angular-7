import { Component, Input, OnInit } from '@angular/core';
import { PostDeliberaData } from 'src/app/models/post-delibera/postDeliberaData.model';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { PostDeliberaService } from '../../services/post-delibera.service';
import { MutuiDetailsModel } from 'src/app/modules/product-configuration/models/MutuiDetailsModel';

@Component({
  selector: 'bst-fin-dati-stipula-erogazione',
  templateUrl: './dati-stipula-erogazione.component.html',
  styleUrls: ['./dati-stipula-erogazione.component.scss']
})
export class DatiStipulaErogazioneComponent implements OnInit {

  @Input() fetchMutuoDetailsResponse: MutuiDetailsModel;
  @Input() postDeliberaPageStatus: any;
  @Input() immobileData: any[];
  @Input() postDeliberaData: PostDeliberaData;
  @Input() mainUser: BaseClientModel;
  @Input() intestatari: BaseClientModel[];
  @Input() jointHeading: BaseClientModel;
  @Input() mutuoChirografario: boolean;

  allCompleto: boolean;
  datiStipulaTooltipMessage: string;

  constructor(private postDeliberaService: PostDeliberaService) {
  }

  ngOnInit() {
    this.datiStipulaTooltipMessage = !this.mutuoChirografario ?
      'La sezione si sblocca dopo il completamento di Adempimenti Normativi, Gestione Perizie e Polizze' :
      'La sezione si sblocca dopo il completamento di QAV e Polizze';

    this.postDeliberaService.getAllCompleto().subscribe(result => {
      this.allCompleto = result;
    });
  }
}









