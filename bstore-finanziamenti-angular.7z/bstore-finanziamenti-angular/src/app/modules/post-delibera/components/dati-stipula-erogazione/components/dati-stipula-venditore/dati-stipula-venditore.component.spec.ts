import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatiStipulaVenditoreComponent } from './dati-stipula-venditore.component';

describe('DatiStipulaVenditoreComponent', () => {
  let component: DatiStipulaVenditoreComponent;
  let fixture: ComponentFixture<DatiStipulaVenditoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatiStipulaVenditoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatiStipulaVenditoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
