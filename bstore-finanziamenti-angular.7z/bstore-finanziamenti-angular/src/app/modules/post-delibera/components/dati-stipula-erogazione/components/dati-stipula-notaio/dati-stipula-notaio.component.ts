import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { TipoProcesso } from 'src/app/constant/tipoProcesso';
import { PostDeliberaData } from 'src/app/models/post-delibera/postDeliberaData.model';
import { PostDeliberaDatiNotaio } from 'src/app/models/post-delibera/postDeliberaDatiNotaio.model';
import { CercaRubricaNotaiserviceService } from 'src/app/modules/post-delibera/services/cerca-rubrica-notaiservice.service';
import { PostDeliberaService } from 'src/app/modules/post-delibera/services/post-delibera.service';

@Component({
  selector: 'bst-fin-dati-stipula-notaio',
  templateUrl: './dati-stipula-notaio.component.html',
  styleUrls: ['./dati-stipula-notaio.component.scss']
})
export class DatiStipulaNotaioComponent implements OnInit {

  @Input() postDeliberaData: PostDeliberaData;
  @Input() postDeliberaPageStatus: any;

  notatioDetailList: any[] = [];
  notaioDetail: any = {};
  saveNotaioEvent: EventsModel[] = [];
  idProposal: string;
  searchKey: string;
  disableSaveNotaio: boolean;

  constructor(private postDeliberaService: PostDeliberaService,
    private cercaRubricaNotaiserviceService: CercaRubricaNotaiserviceService, private route: ActivatedRoute) {
    this.route.params.subscribe(params => { this.idProposal = params['proposalId']; });
  }

  ngOnInit() {
    this.saveNotaioEvent = [
      { eventName: 'click', eventCallBack: this.saveNotaio.bind(this) },
    ];

    if (this.postDeliberaData && this.postDeliberaData.notaio !== null) {
      this.searchKey = this.postDeliberaData.notaio;
      this.notaioDetail.filtroFullName = this.postDeliberaData.notaio;
      this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaNotaio = true;
      this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
    }
    this.disableSaveNotaio = true;
  }

  saveNotaio() {
    const notaioData: PostDeliberaDatiNotaio = new PostDeliberaDatiNotaio();
    notaioData.idProcesso = Number(this.idProposal);
    notaioData.tipoProcesso = TipoProcesso.VENDITA;
    notaioData.notaio = this.searchKey;
    notaioData.notaioEmail = this.notaioDetail.filtroEmail;
    this.postDeliberaService.saveNotaio(notaioData).subscribe(response => {
      this.disableSaveNotaio = response;
      this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaNotaio = true;
      this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
    });
  }

  fetchListData(event) {
    this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaNotaio = false;
    this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
    this.notatioDetailList = [];
    if (event.key === 'Enter') {
      this.eseguiRicercaEvent();
    }
  }

  eseguiRicercaEvent() {
    this.cercaRubricaNotaiserviceService.getNotatioList(this.searchKey.trim()).subscribe((respo) => {
      this.notatioDetailList = respo;
      this.disableSaveNotaio = false;
      if (this.notatioDetailList.length === 0) {
        this.notaioDetail['filtroFullName'] = null;
        this.notaioDetail['telefono'] = null;
        this.notaioDetail['filtroEmail'] = null;
        this.notatioDetailList = null;
        this.disableSaveNotaio = true;
      } else if (this.notatioDetailList.length === 1) {
        this.selectNotaio(this.notatioDetailList[0]);
      }
    });
  }

  selectNotaio(notatioData) {
    if (notatioData) {
      this.searchKey = notatioData.filtroNome + ' ' + notatioData.filtroCognome;
      this.notaioDetail['filtroFullName'] = notatioData.filtroNome + ' ' + notatioData.filtroCognome;
      this.notaioDetail['telefono'] = notatioData.telefono.replace('/', '');
      this.notaioDetail['filtroEmail'] = notatioData.filtroEmail;
    }
    this.notatioDetailList = [];
  }

}
