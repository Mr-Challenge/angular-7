import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DemoPostDeliberaStartingPageComponent } from './demo-post-delibera-starting-page.component';

describe('DemoPostDeliberaStartingPageComponent', () => {
  let component: DemoPostDeliberaStartingPageComponent;
  let fixture: ComponentFixture<DemoPostDeliberaStartingPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DemoPostDeliberaStartingPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DemoPostDeliberaStartingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
