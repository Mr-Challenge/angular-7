import { Component, OnInit } from '@angular/core';
import { PostDeliberaService } from '../../services/post-delibera.service';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { CommonService } from 'src/app/services/common.service';
import { ActivatedRoute } from '@angular/router';
import { MortgageClientRoles } from 'src/app/constant/mortgageClientRoles';

@Component({
  selector: 'bst-fin-demo-post-delibera-starting-page',
  templateUrl: './demo-post-delibera-starting-page.component.html',
  styleUrls: ['./demo-post-delibera-starting-page.component.scss']
})
export class DemoPostDeliberaStartingPageComponent implements OnInit {

  postDeliberaPageStatus: any;
  numeroRapportoMutuo: string;
  mainUser: BaseClientModel;
  proposalId: string;

  constructor(
    private postDeliberaService: PostDeliberaService,
    private commonService: CommonService,
    private route: ActivatedRoute) {
    this.route.params.subscribe(params => this.proposalId = params['proposalId']);
  }

  ngOnInit() {
    this.postDeliberaService.getpostDeliberaPageStatus().subscribe((data) => {
      this.postDeliberaPageStatus = data;
    });

    this.commonService.retrieveAllClient(this.proposalId).subscribe(response => {
      //this.intestatari = response.filter(holder => !holder.cointestazione && holder.role === MortgageClientRoles.INTESTATARI);
      this.mainUser = this.commonService.getMainUser(response.filter(holder => holder.role === MortgageClientRoles.INTESTATARI));
      //this.jointHeading = response.filter(holder => holder.cointestazione)[0];
      //this.garanti = response.filter(holder => !holder.cointestazione && holder.role === MortgageClientRoles.GARANTI);

      if (this.mainUser) {
        //this.setNumeroRapportoMutuo();
        this.numeroRapportoMutuo = "FIX-ME";
      }
    });
  }

}
