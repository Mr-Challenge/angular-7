import { AfterViewChecked, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogService } from 'bstore-angular-library';
import { FinMonitorStatus } from 'src/app/constant/finMonitorStatus';
import { MortgageClientRoles } from 'src/app/constant/mortgageClientRoles';
import { PostDeliberaTooltipStatus } from 'src/app/constant/postDeliberaTooltipStatus';
import { StatoMutuoType } from 'src/app/constant/statoMutuo';
import { TipoProcesso } from 'src/app/constant/tipoProcesso';
import { AllegatoPraticaUrl } from 'src/app/models/allegatoPraticaUrl.model';
import { CodiceDescrizione } from 'src/app/models/CodiceDescrizione.model';
import { PostDeliberaData } from 'src/app/models/post-delibera/postDeliberaData.model';
import { PostDeliberaStampaTecnicaPef } from 'src/app/models/post-delibera/postDeliberaStampaTecnicaPef.model';
import { ImmobiliService } from 'src/app/modules/immobili/services/immobili-service';
// tslint:disable-next-line: max-line-length
import { ModificaPropostaPopupComponent } from 'src/app/modules/modifica-proposta/components/modifica-proposta-popup/modifica-proposta-popup.component';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { MutuiDetailsModel } from 'src/app/modules/product-configuration/models/MutuiDetailsModel';
import { ProductConfiguartionService } from 'src/app/modules/product-configuration/services/product-configuartion.service';
import { CommonService } from 'src/app/services/common.service';
import { environment } from 'src/environments/environment';
import { ModulisticaPraticheService } from '../../services/modulistica-pratiche.service';
import { PostDeliberaService } from '../../services/post-delibera.service';
@Component({
  selector: 'bst-fin-post-delibera-starting-page',
  templateUrl: './post-delibera-starting-page.component.html',
  styleUrls: ['./post-delibera-starting-page.component.scss']
})
export class PostDeliberaStartingPageComponent implements OnInit, AfterViewChecked {

  codiceDescrizione: CodiceDescrizione;
  isLavorazioneCompletata: boolean;
  isBloccata = false;
  progressPer: number;
  showProgressTooltipFlag: boolean;
  colorChange: string;
  tooltipMessage: string;
  proposalId: string;
  numeroRapportoMutuo: string;
  bstoreStatus: string;
  fetchMutuoDetailsResponse: MutuiDetailsModel;
  canLoadNextComponents: boolean;
  domainName = environment.devUrlJSON['npv.service.callback.url'];
  postDeliberaPageStatus: any;
  immobileData: any[];
  postDeliberaData: PostDeliberaData = new PostDeliberaData();
  postDeliberaDataFlag: boolean;
  allCompleto: boolean;
  showIngaggiaComponent = true;

  mainUser: BaseClientModel;
  intestatari: BaseClientModel[];
  jointHeading: BaseClientModel;
  garanti: BaseClientModel[];

  mutuoChirografario: boolean;
  retrieveStampaTecnica = true;

  constructor(private modulisticaPraticheService: ModulisticaPraticheService,
    private productConfiguartionService: ProductConfiguartionService,
    private postDeliberaService: PostDeliberaService, private immobiliService: ImmobiliService,
    private route: ActivatedRoute, private commonService: CommonService,
    private dialogservice: DialogService, private router: Router, private cdRef: ChangeDetectorRef) {
    this.route.params.subscribe(params => this.proposalId = params['proposalId']);
  }

  ngOnInit() {

    this.postDeliberaService.getpostDeliberaPageStatus().subscribe((data) => {
      this.postDeliberaPageStatus = data;
    });

    this.commonService.isMutuoIpotecario(this.proposalId).subscribe(response => {
      this.mutuoChirografario = !response;
    }, null, () => {
      if (!this.mutuoChirografario) {
        this.immobiliService.getDettaglioImmobili(this.proposalId).subscribe(data =>
          this.immobileData = data
        );
      }
      this.postDeliberaService.fetchPostDeliberaData(this.proposalId, TipoProcesso.VENDITA).subscribe(data => {
        this.postDeliberaData = data;
        this.postDeliberaDataFlag = true;
        if (!this.mutuoChirografario && this.postDeliberaData && this.postDeliberaData.dataIngaggioUfficioFin) {
          this.allCompleto = true;
          this.postDeliberaService.setAllCompleto(this.allCompleto);
          this.postDeliberaPageStatus.datiStipulaEdErogazione.datiStipulaGenerali = true;
          this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
        } else if (this.mutuoChirografario && this.postDeliberaData && this.postDeliberaData.dataErogazione) {
          this.allCompleto = true;
          this.postDeliberaService.setAllCompleto(this.allCompleto);
        }
        if (this.postDeliberaData && this.postDeliberaData.urlPefTecnica && this.postDeliberaData.classeDocumentalePefTecnica) {
          const allegatoPraticaUrl: AllegatoPraticaUrl = new AllegatoPraticaUrl();
          allegatoPraticaUrl.fileUrl = this.postDeliberaData.urlPefTecnica;
          allegatoPraticaUrl.classeDocumentale = this.postDeliberaData.classeDocumentalePefTecnica;
          this.postDeliberaService.setPefDoc(allegatoPraticaUrl);
          this.retrieveStampaTecnica = false;
        }
        console.log(this.postDeliberaData);
      }, null, () => {
        if (this.postDeliberaData && this.postDeliberaData.dataPrimaAperturaPostDelibera) {
          this.retrieveAllClientDetails();
        } else {
          this.postDeliberaService.saveFirstPdAccess(this.proposalId, TipoProcesso.VENDITA).subscribe(result => {
            if (result) {
              this.retrieveAllClientDetails();
            }
          });
        }
      });
    });
  }

  ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }

  private setNumeroRapportoMutuo() {
    this.productConfiguartionService.retrieveNumeroRapportoMutuo(this.proposalId).subscribe(numeroRapportoMutuo => {
      this.numeroRapportoMutuo = numeroRapportoMutuo;
      if (this.numeroRapportoMutuo) {
        this.callCommonServices();
      }
    });
  }

  retrieveAllClientDetails() {
    this.commonService.retrieveAllClient(this.proposalId).subscribe(response => {
      this.intestatari = response.filter(holder => !holder.cointestazione && holder.role === MortgageClientRoles.INTESTATARI);
      this.mainUser = this.commonService.getMainUser(response.filter(holder => holder.role === MortgageClientRoles.INTESTATARI));
      this.jointHeading = response.filter(holder => holder.cointestazione)[0];
      this.garanti = response.filter(holder => !holder.cointestazione && holder.role === MortgageClientRoles.GARANTI);

      if (this.mainUser) {
        this.setNumeroRapportoMutuo();
      }
    });
  }

  private getInserisciConsensoSICList(numeroPratica: number) {
    this.modulisticaPraticheService.getInserisciConsensoSICList(numeroPratica, this.proposalId).subscribe();
  }

  private evaluateStatus(finMonitorStatus: string) {
    switch (finMonitorStatus) {
      case FinMonitorStatus.DOCUMENTI_RICEVUTI:
        if (this.bstoreStatus === StatoMutuoType.DOCUMENTI_RICEVUTI) {
          this.editProgressBar(true, PostDeliberaTooltipStatus.DOCUMENTI_RICEVUTI, 80, 'yellow');
        } else {
          this.commonService.updateMortgageStatus(this.proposalId, StatoMutuoType.DOCUMENTI_RICEVUTI).subscribe(result => {
            if (result) {
              this.editProgressBar(true, PostDeliberaTooltipStatus.DOCUMENTI_RICEVUTI, 80, 'yellow');
            }
          });
        }
        break;
      case FinMonitorStatus.ISTRUTTORIA:
      case FinMonitorStatus.LAVORAZIONE_SOSPESA:
      case FinMonitorStatus.ATTESA_GARANZIA_FONDI:
      case FinMonitorStatus.IN_LAVORAZIONE:
        if (this.bstoreStatus === StatoMutuoType.IN_ATTESA_MINUTA) {
          this.editProgressBar(true, PostDeliberaTooltipStatus.IN_ATTESA_MINUTA_CONTRATTUALE, 90, 'yellow');
        } else {
          this.commonService.updateMortgageStatus(this.proposalId, StatoMutuoType.IN_ATTESA_MINUTA).subscribe(result => {
            if (result) {
              this.editProgressBar(true, PostDeliberaTooltipStatus.IN_ATTESA_MINUTA_CONTRATTUALE, 90, 'yellow');
            }
          });
        }
        break;
      case FinMonitorStatus.BLOCCATA:
        this.isBloccata = true;
        if (this.bstoreStatus === StatoMutuoType.BLOCCATO) {
          this.editProgressBar(true, PostDeliberaTooltipStatus.BLOCCATO_SERVIZIO_FIN, 80, 'red');
        } else {
          this.commonService.updateMortgageStatus(this.proposalId, StatoMutuoType.BLOCCATO).subscribe(result => {
            if (result) {
              this.editProgressBar(true, PostDeliberaTooltipStatus.BLOCCATO_SERVIZIO_FIN, 80, 'red');
            }
          });
        }
        break;
      case FinMonitorStatus.LAVORAZIONE_COMPLETATA:
        this.isLavorazioneCompletata = true;
        if (this.bstoreStatus === StatoMutuoType.MINUTA_OV_DISPONIBILI) {
          this.editProgressBar(true, PostDeliberaTooltipStatus.OV_DISPONIBILI, 100, 'blue');
        } else {
          this.commonService.updateMortgageStatus(this.proposalId, StatoMutuoType.MINUTA_OV_DISPONIBILI).subscribe(result => {
            if (result) {
              // CR #35271 - Commented the sms sending to the client in this case, uncomment in case of opposite requirement
              // this.intestatari.forEach(holder => {
              //   if (holder.phoneOtp !== '') {
              //     this.commonService.sendSms(holder.phoneOtp).subscribe();
              //   }
              // });
              this.editProgressBar(true, PostDeliberaTooltipStatus.OV_DISPONIBILI, 100, 'blue');
            }
          });
        }
        break;
      case FinMonitorStatus.EROGAZIONE_COMPLETA:
        this.isLavorazioneCompletata = true;
        if (this.bstoreStatus === StatoMutuoType.EROGATO) {
          this.editProgressBar(true, PostDeliberaTooltipStatus.FIN_EROGATO, 100, 'blue');
        } else {
          this.commonService.updateMortgageStatus(this.proposalId, StatoMutuoType.EROGATO).subscribe(result => {
            if (result) {
              this.editProgressBar(true, PostDeliberaTooltipStatus.FIN_EROGATO, 100, 'blue');
            }
          });
        }
        break;
      case FinMonitorStatus.RINUNCIATA:
      case FinMonitorStatus.RIFIUTATA:
      case FinMonitorStatus.ANNULLATA:
        if (this.bstoreStatus === StatoMutuoType.ANNULLATO) {
          this.editProgressBar(true, PostDeliberaTooltipStatus.ANNULLATA, 100, 'red');
        } else {
          this.commonService.updateMortgageStatus(this.proposalId, StatoMutuoType.ANNULLATO).subscribe(result => {
            if (result) {
              this.editProgressBar(true, PostDeliberaTooltipStatus.ANNULLATA, 100, 'red');
            }
          });
        }
        break;
      default:
        if (this.bstoreStatus === StatoMutuoType.DOCUMENTI_RICEVUTI) {
          this.editProgressBar(true, PostDeliberaTooltipStatus.DOCUMENTI_RICEVUTI, 80, 'yellow');
        } else if (this.bstoreStatus === StatoMutuoType.IN_ATTESA_MINUTA) {
          this.editProgressBar(true, PostDeliberaTooltipStatus.IN_ATTESA_MINUTA_CONTRATTUALE, 90, 'yellow');
        } else if (this.bstoreStatus === StatoMutuoType.BLOCCATO) {
          this.editProgressBar(true, PostDeliberaTooltipStatus.BLOCCATO_SERVIZIO_FIN, 80, 'red');
        } else if (this.bstoreStatus === StatoMutuoType.MINUTA_OV_DISPONIBILI) {
          this.editProgressBar(true, PostDeliberaTooltipStatus.OV_DISPONIBILI, 100, 'blue');
        } else if (this.bstoreStatus === StatoMutuoType.EROGATO) {
          this.editProgressBar(true, PostDeliberaTooltipStatus.FIN_EROGATO, 100, 'blue');
        } else if (this.bstoreStatus === StatoMutuoType.ANNULLATO) {
          this.editProgressBar(true, PostDeliberaTooltipStatus.ANNULLATA, 100, 'red');
        } else {
          this.editProgressBar(false, '', 70, 'yellow');
        }
        break;
    }
    this.canLoadNextComponents = true;
    if (this.retrieveStampaTecnica) {
      this.retrieveAndSaveStampaTecnicaPef();
    }
  }

  private editProgressBar(showTooltip: boolean, tooltipMessage: string, progressBarPerc: number, progressBarColor: string) {
    this.showProgressTooltipFlag = showTooltip;
    this.tooltipMessage = tooltipMessage;
    this.progressPer = progressBarPerc;
    this.colorChange = progressBarColor;
  }

  private callCommonServices() {
    this.commonService.fetchMutuoDetails(this.proposalId).subscribe(fetchMutuoDetails => {
      this.fetchMutuoDetailsResponse = fetchMutuoDetails;
      this.bstoreStatus = this.fetchMutuoDetailsResponse.status;
      this.getInserisciConsensoSICList(this.fetchMutuoDetailsResponse.idPef);
    }, null, () => {
      if (!this.mutuoChirografario) {
        this.verificaStato();
      } else {
        // Default progress bar for chiro
        this.editProgressBar(false, '', 70, 'yellow');
        this.canLoadNextComponents = true;
      }
    });
  }

  private retrieveAndSaveStampaTecnicaPef() {
    const stampaTecnica: PostDeliberaStampaTecnicaPef = new PostDeliberaStampaTecnicaPef();
    stampaTecnica.idProcesso = Number(this.proposalId);
    stampaTecnica.tipoProcesso = TipoProcesso.VENDITA;
    stampaTecnica.idPef = this.fetchMutuoDetailsResponse.idPef;

    this.postDeliberaService.retrieveAndSaveStampaTecnicaPef(stampaTecnica).subscribe(response => {
      if (response) {
        console.log('url stampa tecnica Pef salvato');
      }
    }, error => {
      if (error.status === 504) {
        this.retrieveAndSaveStampaTecnicaPef();
      }
    });
  }

  private verificaStato() {
    this.postDeliberaService.getLeggiStatoPratica(this.numeroRapportoMutuo).subscribe(response => {
      this.codiceDescrizione = response;
      // To uncomment if you want to simulate different FinMonitorStatus
      // this.codiceDescrizione.descrizione = FinMonitorStatus.LAVORAZIONE_COMPLETATA;
      this.evaluateStatus(this.codiceDescrizione.descrizione);
    });
  }

  abbandonaPropostaPopup() {
    localStorage.setItem('previousPage', 'postDelibera');
    this.router.navigate(['/abbandona', this.proposalId]);
  }

  modificaPopup() {
    this.dialogservice.open(ModificaPropostaPopupComponent, {
      data: { idProposal: this.proposalId },
      noCloseButton: true,
      size: 'large'
    });
  }

  hideIngaggiaComponent(event: boolean) {
    this.showIngaggiaComponent = false;
  }

  ufficioIngaggiato(event: boolean) {
    if (event) {
      this.verificaStato();
      this.isBloccata = false;
      this.postDeliberaService.setAllCompleto(true);
    }
  }

  stampatoEdErogato(event: boolean) {
    if (event) {
      this.editProgressBar(true, PostDeliberaTooltipStatus.FIN_EROGATO, 100, 'blue');
      this.postDeliberaService.setAllCompleto(true);
    }
  }

}
