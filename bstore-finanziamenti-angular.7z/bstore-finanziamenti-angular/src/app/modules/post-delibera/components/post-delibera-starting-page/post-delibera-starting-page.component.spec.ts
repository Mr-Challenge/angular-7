import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PostDeliberaStartingPageComponent } from './post-delibera-starting-page.component';

describe('PostDeliberaStartingPageComponent', () => {
  let component: PostDeliberaStartingPageComponent;
  let fixture: ComponentFixture<PostDeliberaStartingPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PostDeliberaStartingPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PostDeliberaStartingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
