import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BpertwainUtilsService, OpenPdfUrlService } from 'bstore-angular-library';
import { FinMonitorExtraDocs } from 'src/app/constant/finMonitorExtraDoc';
import { AllegatoPratica } from 'src/app/models/allegatoPratica.model';
import { RestituisciPerizia } from 'src/app/models/postDelibera.model';
import { ImmobiliService } from 'src/app/modules/immobili/services/immobili-service';
import { ModulisticaPraticheService } from 'src/app/modules/post-delibera/services/modulistica-pratiche.service';
import { PostDeliberaService } from 'src/app/modules/post-delibera/services/post-delibera.service';
import { CommonService } from 'src/app/services/common.service';
import { AllegatoPraticaUrl } from 'src/app/models/allegatoPraticaUrl.model';
import { AllegatoPraticaContent } from 'src/app/models/allegatoPraticaContent.model';
import { LeggiModuliPratica } from 'src/app/models/leggiModuliPratica.model';
import { DocumentazioneCommonComponent } from '../documentazione-common/documentazione-common.component';
import { MutuiDetailsModel } from 'src/app/modules/product-configuration/models/MutuiDetailsModel';

@Component({
  selector: 'bst-fin-documentazione-generica',
  templateUrl: './documentazione-generica.component.html',
  styleUrls: ['./documentazione-generica.component.scss']
})
export class DocumentazioneGenericaComponent extends DocumentazioneCommonComponent implements OnInit {

  @Input() fetchMutuoDetailsResponse: MutuiDetailsModel;
  @Input() extraDocuments: LeggiModuliPratica[] = [];
  @Input() polizzaDoc: AllegatoPraticaUrl;
  @Input() datiStipula: AllegatoPraticaUrl;
  @Input() polizzaPersonalizzata: boolean;

  pefDoc: AllegatoPraticaUrl;
  proposalId: any;
  restituisciPerizia: RestituisciPerizia;
  immobileAssociates: any[];
  codiceImmobile: any;
  simulationDetails: any[];
  urlEsitoDeroga: string;
  allegatoPraticaList: any[] = new Array<AllegatoPratica>();
  today = new Date();

  showPeriziaDoc = false;
  showDerogaDoc = false;
  showPolizzaDoc = false;
  showStipulaDoc = false;
  showPefDoc = false;

  constructor(protected bpertwainUtils: BpertwainUtilsService, protected modulisticaPraticheService: ModulisticaPraticheService,
    private postDeliberaService: PostDeliberaService, private route: ActivatedRoute, protected commonService: CommonService,
    private immobiliService: ImmobiliService, protected openPdfUrlService: OpenPdfUrlService) {
    super(bpertwainUtils, commonService, openPdfUrlService, modulisticaPraticheService);
    this.route.params.subscribe(params => {
      this.proposalId = params['proposalId'];
    });
  }

  ngOnInit() {
    this.postDeliberaService.getPefDoc().subscribe(res => {
      this.pefDoc = res;
    });
    this.getCodModuliForExtraDocs(this.extraDocuments);
  }

  getCodModuliForExtraDocs(extraDocuments: any[]) {
    extraDocuments.forEach(extraDoc => {
      if (extraDoc.tag.toUpperCase() === FinMonitorExtraDocs.RIEPILOGO_PERIZIA) {
        this.retrieveDocConfermaPerizia(extraDoc.codDoc);
      } else if (extraDoc.tag.toUpperCase() === FinMonitorExtraDocs.PLAB_DELIBERATO) {
        this.getAutorizzazioneCondizioni(extraDoc.codDoc);
      } else if (extraDoc.tag.toUpperCase() === FinMonitorExtraDocs.SIMULAZIONE_POLIZZA && !this.polizzaPersonalizzata) {
        this.addPolizzeDocToDocList(extraDoc.codDoc);
      } else if (extraDoc.tag.toUpperCase() === FinMonitorExtraDocs.DATI_STIPULA) {
        this.addDatiStipulaDocToDocList(extraDoc.codDoc);
      } else if (extraDoc.tag.toUpperCase() === FinMonitorExtraDocs.PEF_TECNICA) {
        this.addPefDocToDocList(extraDoc.codDoc);
      }
    });
  }

  downloadDocPerizia() {
    this.openDocument(this.restituisciPerizia);
  }

  retrieveDocConfermaPerizia(codModulo: string) {
    this.immobiliService.getImmobiliCodici(this.proposalId).subscribe(res => {
      this.immobileAssociates = res;
      if (this.immobileAssociates) {
        this.immobileAssociates.forEach(obj => {
          this.codiceImmobile = obj;
        });
      }
    }, null, () => {
      this.postDeliberaService.retrieveRestituisciPeriziaDetails(this.codiceImmobile).subscribe(result => {
        this.restituisciPerizia = result;
        this.setAllegatoPraticaList(codModulo, this.restituisciPerizia.nomeFile, this.restituisciPerizia.file);
      });
    });
    this.showPeriziaDoc = true;
  }

  getAutorizzazioneCondizioni(codModulo: string) {
    this.postDeliberaService.retrieveSimulationDetails(this.proposalId).subscribe(res => {
      this.simulationDetails = res;
      this.simulationDetails.forEach(obj => {
        if (obj.urlEsitoDeroga != null) {
          this.urlEsitoDeroga = this.openPdfUrlService.convertUrl(obj.urlEsitoDeroga);
        }
      });
      this.urlToBase64(this.urlEsitoDeroga, codModulo, 'AutorizzazioneCondizioni.pdf');
    });
    this.showDerogaDoc = true;
  }

  addPefDocToDocList(codModulo: string) {
    if (this.pefDoc) {
      this.setAllegatoPraticaLinkList(codModulo, this.pefDoc.fileUrl, this.pefDoc.classeDocumentale);
      this.showPefDoc = true;
    }
  }

  addPolizzeDocToDocList(codModulo: string) {
    if (this.polizzaDoc) {
      this.setAllegatoPraticaLinkList(codModulo, this.polizzaDoc.fileUrl, this.polizzaDoc.classeDocumentale);
      this.showPolizzaDoc = true;
    }
  }

  addDatiStipulaDocToDocList(codModulo: string) {
    if (this.datiStipula) {
      this.setAllegatoPraticaLinkList(codModulo, this.datiStipula.fileUrl, this.datiStipula.classeDocumentale);
      this.showStipulaDoc = true;
    }
  }

  urlToBase64(url: string, codModulo: string, pdfName: string) {
    if (url != null) {
      this.postDeliberaService.getConfig(url, 'arraybuffer').subscribe(res => {
        const TYPED_ARRAY = new Uint8Array(res);
        const STRING_CHAR = TYPED_ARRAY.reduce((data, byte) => {
          return data + String.fromCharCode(byte);
        }, '');
        const base64String = btoa(STRING_CHAR);
        this.setAllegatoPraticaList(codModulo, pdfName, base64String);
      });
    }
  }

  setAllegatoPraticaList(codeModulo, fileName, fileContent) {
    const allegatoPratica = new AllegatoPraticaContent();
    allegatoPratica.codModulo = codeModulo;
    allegatoPratica.fileName = fileName;
    allegatoPratica.numeroPratica = this.numeroRapportoMutuo;
    allegatoPratica.fileContent = fileContent;
    this.allegatoPraticaList.push(allegatoPratica);
    this.postDeliberaService.setAllegatoPraticaList(this.allegatoPraticaList);
  }

  setAllegatoPraticaLinkList(codeModulo, fileUrl, classeDocumentale) {
    const allegatoPratica = new AllegatoPraticaUrl();
    allegatoPratica.codModulo = codeModulo;
    allegatoPratica.fileUrl = fileUrl;
    allegatoPratica.numeroPratica = this.numeroRapportoMutuo;
    allegatoPratica.classeDocumentale = classeDocumentale;
    this.allegatoPraticaList.push(allegatoPratica);
    this.postDeliberaService.setAllegatoPraticaList(this.allegatoPraticaList);
  }

  openDerogaDoc() {
    if (this.urlEsitoDeroga) {
      this.openPdfUrlService.openPdfDocument(this.urlEsitoDeroga);
    }
  }

  openPolizzaDoc() {
    if (this.polizzaDoc) {
      this.openPdfUrlService.openPdfDocument(this.polizzaDoc.fileUrl);
    }
  }

  openPefDoc() {
    if (this.pefDoc) {
      this.openPdfUrlService.openPdfDocument(this.pefDoc.fileUrl);
    }
  }

  openDatiStipulaDoc() {
    if (this.datiStipula) {
      this.openPdfUrlService.openPdfDocument(this.datiStipula.fileUrl);
    }
  }
}
