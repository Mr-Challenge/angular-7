import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentazioneCommonComponent } from './documentazione-common.component';

describe('DocumentazioneCommonComponent', () => {
  let component: DocumentazioneCommonComponent;
  let fixture: ComponentFixture<DocumentazioneCommonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentazioneCommonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentazioneCommonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
