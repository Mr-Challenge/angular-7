import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentazioneEventualeComponent } from './documentazione-eventuale.component';

describe('DocumentazioneEventualeComponent', () => {
  let component: DocumentazioneEventualeComponent;
  let fixture: ComponentFixture<DocumentazioneEventualeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentazioneEventualeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentazioneEventualeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
