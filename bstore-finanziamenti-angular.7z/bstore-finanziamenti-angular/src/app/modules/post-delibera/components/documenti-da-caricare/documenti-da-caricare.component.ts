import { Component, Input, OnInit } from '@angular/core';
import { ModulisticaPraticheService } from '../../services/modulistica-pratiche.service';
import { FinMonitorExtraDocs } from 'src/app/constant/finMonitorExtraDoc';
import { PostDeliberaService } from '../../services/post-delibera.service';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { AllegatoPratica } from 'src/app/models/allegatoPratica.model';
import { AllegatoPraticaUrl } from 'src/app/models/allegatoPraticaUrl.model';
import { LeggiModuliPratica } from 'src/app/models/leggiModuliPratica.model';
import { MutuoDetails } from 'src/app/modules/product-configuration/models/MutuoDetails';
import { MutuoDetailsComponent } from 'src/app/modules/product-configuration/components/mutuo-details/mutuo-details.component';
import { MutuiDetailsModel } from 'src/app/modules/product-configuration/models/MutuiDetailsModel';

@Component({
  selector: 'bst-fin-documenti-da-caricare',
  templateUrl: './documenti-da-caricare.component.html',
  styleUrls: ['./documenti-da-caricare.component.scss']
})
export class DocumentiDaCaricareComponent implements OnInit {

  @Input() numeroRapportoMutuo: string;
  @Input() postDeliberaPageStatus: any;
  @Input() mainUser: BaseClientModel;
  @Input() isBloccata: boolean;
  @Input() fetchMutuoDetailsResponse: MutuiDetailsModel;

  documentsData: LeggiModuliPratica[] = [];
  genericaDocumentazione: LeggiModuliPratica[] = [];
  eventualeDocumentazione: LeggiModuliPratica[] = [];
  extraDocuments: LeggiModuliPratica[];
  polizzaDoc: AllegatoPraticaUrl;
  datiStipula: AllegatoPraticaUrl;
  polizzaPersonalizzata: boolean;
  initialized: boolean;
  allCompleto: boolean;

  polizzaDocOk = false;
  datiStipulaDocOk = false;

  constructor(private modulisticaPraticheService: ModulisticaPraticheService, private postDeliberaService: PostDeliberaService) {
    this.polizzaDoc = new AllegatoPraticaUrl();
    this.datiStipula = new AllegatoPraticaUrl();
  }

  ngOnInit() {
    this.postDeliberaService.getAllCompleto().subscribe(result => {
      this.allCompleto = result;
    });

    if (this.postDeliberaPageStatus.datiStipulaEdErogazione_current) {
      this.initSezioneDocumenti();
    }
    this.postDeliberaPageStatus.documentiDaCaricare.documentazioneEventuale = true;
    this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
  }

  manditoryDocUploaded(data) {
    if (this.postDeliberaPageStatus.documentiDaCaricare.documentazioneGenerica !== data) {
      this.postDeliberaPageStatus.documentiDaCaricare.documentazioneGenerica = data;
      this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
    }
  }

  initSezioneDocumenti() {
    if (!this.initialized) {
      this.postDeliberaService.getFirstPolizzaPersonalizzata().subscribe(resp => {
        this.polizzaPersonalizzata = resp;
        this.modulisticaPraticheService.getLeggiModuliPratica(this.numeroRapportoMutuo, this.mainUser.ndg).subscribe(response => {
          this.documentsData = response;
          this.genericaDocumentazione = this.documentsData.filter(obj => obj.tipo === 'O' &&
            (obj.tag === '' || obj.tag === '*' ||
              (obj.tag.toUpperCase() === FinMonitorExtraDocs.SIMULAZIONE_POLIZZA && this.polizzaPersonalizzata)));
          this.manditoryDocUploaded(this.genericaDocumentazione.every(doc => ((doc.file || doc.url) && doc.nomeFile
            && doc.stato !== 'NON CONFORME') ? true : false));
          this.eventualeDocumentazione = this.documentsData.filter(obj => obj.tipo === 'F');
          this.extraDocuments = this.documentsData.filter(obj => obj.tag !== '');
        });
        if (!this.polizzaPersonalizzata) {
          this.generatePolizzeDocument();
        }
        this.generateDatiStipulaDoc();
        this.initialized = true;
        this.postDeliberaPageStatus.documentiDaCaricare.documentazioneEventuale = true;
        this.postDeliberaService.setpostDeliberaPageStatus(this.postDeliberaPageStatus);
      });
    }
  }

  generatePolizzeDocument() {
    if (this.postDeliberaPageStatus.polizzeSectionData.isGenerateDocument) {
      const docData = this.postDeliberaPageStatus.polizzeSectionData.documentData;
      this.postDeliberaService.generateDocument(docData).subscribe(doc => {
        this.polizzaDoc.fileUrl = doc.fileUrl;
        this.polizzaDoc.classeDocumentale = doc.classeDocumentale;
        this.postDeliberaPageStatus.polizzeSectionData.isGenerateDocument = false;
        this.postDeliberaService.updatePostDeliberaData(this.postDeliberaPageStatus);
        this.polizzaDocOk = true;
      });
    }
  }

  generateDatiStipulaDoc() {
    if (this.postDeliberaPageStatus.datiStipulaDocument.isGeneratedDocument) {
      const docData = this.postDeliberaPageStatus.datiStipulaDocument.documentData;
      this.postDeliberaService.generateDocumentStipula(docData).subscribe(doc => {
        this.datiStipula.fileUrl = doc.fileUrl;
        this.datiStipula.classeDocumentale = doc.classeDocumentale;
        this.postDeliberaPageStatus.datiStipulaDocument.isGeneratedDocument = false;
        this.postDeliberaService.updatePostDeliberaData(this.postDeliberaPageStatus);
        this.datiStipulaDocOk = true;
      });
    }
  }
}
