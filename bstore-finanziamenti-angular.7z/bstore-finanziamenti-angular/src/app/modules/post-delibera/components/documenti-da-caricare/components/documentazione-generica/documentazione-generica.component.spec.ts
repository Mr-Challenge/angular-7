import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentazioneGenericaComponent } from './documentazione-generica.component';

describe('DocumentazioneGenericaComponent', () => {
  let component: DocumentazioneGenericaComponent;
  let fixture: ComponentFixture<DocumentazioneGenericaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentazioneGenericaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentazioneGenericaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
