import { Component, Input, OnInit } from '@angular/core';
import { BpertwainUtilsService, OpenPdfUrlService } from 'bstore-angular-library';
import { ModulisticaPraticheService } from 'src/app/modules/post-delibera/services/modulistica-pratiche.service';
import { environment } from 'src/environments/environment';
import { CommonService } from 'src/app/services/common.service';
import { AllegatoPratica } from 'src/app/models/allegatoPratica.model';
import { DocumentazioneCommonComponent } from '../documentazione-common/documentazione-common.component';
@Component({
  selector: 'bst-fin-documentazione-eventuale',
  templateUrl: './documentazione-eventuale.component.html',
  styleUrls: ['./documentazione-eventuale.component.scss']
})
export class DocumentazioneEventualeComponent extends DocumentazioneCommonComponent implements OnInit {

  constructor(protected bpertwainUtils: BpertwainUtilsService, protected modulisticaPraticheService: ModulisticaPraticheService,
    protected commonService: CommonService, protected openPdfUrlService: OpenPdfUrlService) {
    super(bpertwainUtils, commonService, openPdfUrlService, modulisticaPraticheService);
  }

  ngOnInit() {
  }

}
