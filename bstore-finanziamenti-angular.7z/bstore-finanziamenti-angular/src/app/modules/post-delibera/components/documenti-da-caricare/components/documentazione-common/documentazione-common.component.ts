import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { LeggiModuliPratica } from 'src/app/models/leggiModuliPratica.model';
import { BpertwainUtilsService, OpenPdfUrlService } from 'bstore-angular-library';
import { CommonService } from 'src/app/services/common.service';
import { AllegatoPratica } from 'src/app/models/allegatoPratica.model';
import { environment } from 'src/environments/environment';
import { ModulisticaPraticheService } from 'src/app/modules/post-delibera/services/modulistica-pratiche.service';
import { AllegatoPraticaUrl } from 'src/app/models/allegatoPraticaUrl.model';
import { LogDetailsModel } from 'bstore-angular-library/lib/models/log-details-model';

@Component({
  selector: 'bst-fin-documentazione-common',
  template: 'NO UI TO BE FOUND HERE!'
})

export class DocumentazioneCommonComponent implements OnInit {

  @Input() numeroRapportoMutuo: string;
  @Input() genericaDocumentazione: LeggiModuliPratica[] = [];
  @Output() manditoryDocUploaded = new EventEmitter();

  documentData: any;
  blob: any;
  logDetailsModel: LogDetailsModel = {};
  domainName = environment.devUrlJSON['npv.service.callback.url'];

  constructor(protected bpertwainUtils: BpertwainUtilsService,
    protected commonService: CommonService,
    protected openPdfUrlService: OpenPdfUrlService,
    protected modulisticaPraticheService: ModulisticaPraticheService) {

  }

  ngOnInit() {
    this.logDetailsModel.section = 'Vendita'; // Default value if not override
  }

  openDocument(obj) {
    if (obj.url) {
      this.openPdfUrlService.openPdfDocument(obj.url);
    } else {
      const fileExt = obj.nomeFile.split('.').pop();
      const b64Data = obj.file;
      const contentType = 'application/' + fileExt;
      const data = this.commonService.b64toBlob(b64Data, contentType, 512);
      const blob = new Blob([data], { type: 'application/octet-stream' });
      const downloadURL = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadURL;
      link.download = obj.nomeFile;
      link.click();
    }
  }

  uploadDoc(event, document) {
    this.documentUploadFunction(event, document);
  }

  documentUploadFunction(event, document) {
    const self = this;

    const successFunctionArchive = (archivedDocumentResult) => {
      const allegatoPratica: AllegatoPraticaUrl = {
        fileUrl: archivedDocumentResult[0].url,
        codModulo: archivedDocumentResult[0].documentData.codDoc,
        numeroPratica: self.numeroRapportoMutuo,
        classeDocumentale: archivedDocumentResult[0].documentData.categoriaDiDocumento
      };
      self.uploadToFinMonitor(allegatoPratica);
      self.genericaDocumentazione.forEach((document, index) => {
        if (document.codDoc === archivedDocumentResult[0].documentData.codDoc) {
          if (document.stato === 'NON CONFORME') {
            document.stato = 'REUPLOAD';
          }
          document.url = archivedDocumentResult[0].url,
            document.nomeFile = archivedDocumentResult[0].documentData.nomeFile;
        }
      });
    };
    const errorFunction = (errorData) => {
      console.log('from acquire error callback', errorData);
    };

    const successFunctionHandle = (handleFile) => {
      this.bpertwainUtils.documentArchive(successFunctionArchive, errorFunction, environment.bperTwainMock, this.domainName, this.logDetailsModel);
    };

    this.bpertwainUtils.handleFileSelect(event, document, successFunctionHandle, errorFunction, environment.bperTwainMock);

  }

  scanDocument(document) {
    const self = this;

    const successFunctionArchive = (archivedDocumentResult) => {
      const allegatoPratica: AllegatoPraticaUrl = {
        fileUrl: archivedDocumentResult[0].url,
        codModulo: archivedDocumentResult[0].documentData.codDoc,
        numeroPratica: self.numeroRapportoMutuo,
        classeDocumentale: archivedDocumentResult[0].documentData.categoriaDiDocumento
      };
      self.uploadToFinMonitor(allegatoPratica);
      self.genericaDocumentazione.forEach((document, index) => {
        if (document.codDoc === archivedDocumentResult[0].documentData.codDoc) {
          if (document.stato === 'NON CONFORME') {
            document.stato = 'REUPLOAD';
          }
          document.url = archivedDocumentResult[0].url,
            document.nomeFile = archivedDocumentResult[0].documentData.nomeFile;
        }
      });
    };

    const errorFunction = (errorData) => {
      console.log('from acquire error callback', errorData);
    };

    const successFunctionAcquire = (handleFile) => {
      this.bpertwainUtils.documentArchive(successFunctionArchive, errorFunction, environment.bperTwainMock, this.domainName, this.logDetailsModel);
    };
    this.bpertwainUtils.documentAcquire(successFunctionAcquire, errorFunction, environment.bperTwainMock, document, this.domainName, this.logDetailsModel);
  }

  uploadToFinMonitor(allegatoPratica) {
    this.modulisticaPraticheService.attachLinkFile(allegatoPratica).subscribe(() => {
      this.manditoryDocUploaded.emit(this.genericaDocumentazione.every(doc => ((doc.file || doc.url)
        && doc.stato !== 'NON CONFORME') ? true : false));
    });
  }

  deleteDocument(codModulo, index, generica) {
    this.modulisticaPraticheService.rimuoviModuloPratica(codModulo.codDoc, this.numeroRapportoMutuo).subscribe(() => {
      this.genericaDocumentazione[index]['file'] = null;
      this.genericaDocumentazione[index]['nomeFile'] = null;
      this.genericaDocumentazione[index]['url'] = null;
      if (generica) {
        this.genericaDocumentazione = this.genericaDocumentazione.filter((obj) => obj.tipo === 'O');
        this.genericaDocumentazione.filter(doc => doc.codDoc === codModulo.codDoc)[0].stato = '';
        this.manditoryDocUploaded.emit(this.genericaDocumentazione.every(doc => ((doc.file || doc.url) && doc.nomeFile
          && doc.stato !== 'NON CONFORME') ? true : false));
      }
    });
  }
}
