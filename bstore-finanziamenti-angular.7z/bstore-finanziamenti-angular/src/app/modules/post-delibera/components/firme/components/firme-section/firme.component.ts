import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ContrattiSignatureType, RedirectService } from 'bstore-angular-library';
import { ContrattiSignatureInput } from 'bstore-angular-library/lib/models/contrattiSignatureInput.model';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { forkJoin } from 'rxjs';
import { FinDocumentType } from 'src/app/constant/documentType';
import { FinMonitorStatus } from 'src/app/constant/finMonitorStatus';
import { MortgageStepWizard } from 'src/app/constant/mortgageStepWizard';
import { StatoMutuoType } from 'src/app/constant/statoMutuo';
import { TipoProcesso } from 'src/app/constant/tipoProcesso';
import { CodiceDescrizione } from 'src/app/models/CodiceDescrizione.model';
import { ContrattiDocument } from 'src/app/models/contrattiDocument';
import { DocumentGeneration } from 'src/app/models/documentGeneration.model';
import { DossierDocSigner } from 'src/app/models/dossierDocSigner.model';
import { DossierGeneration, GenerateDoc, OffertaVincolanteAccettazione } from 'src/app/models/generateDoc.model';
import { ContrattoFideiussioneService } from 'src/app/modules/post-delibera/services/contratto-fideiussione.service';
import { OffertaVincolanteService } from 'src/app/modules/post-delibera/services/offerta-vincolante.service';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { MutuiDetailsModel } from 'src/app/modules/product-configuration/models/MutuiDetailsModel';
import { SignatureStatusModel } from 'src/app/modules/vendita/models/signature-status.model';
import { CommonService } from 'src/app/services/common.service';
import { EndpointsService } from '../../../../../../services/endpoints.service';
import { PostDeliberaService } from '../../../../services/post-delibera.service';

@Component({
  selector: 'bst-fin-firme-page',
  templateUrl: './firme.component.html',
  styleUrls: ['./firme.component.scss']
})
export class FirmeComponent implements OnInit {

  @Input() fetchMutuoDetailsResponse: MutuiDetailsModel;
  @Input() codiceDescrizione: CodiceDescrizione;
  @Input() numeroRapportoMutuo: string;
  @Input() mainUser: BaseClientModel;
  @Input() intestatari: BaseClientModel[];
  @Input() jointHeading: BaseClientModel;
  @Input() garanti: BaseClientModel[];

  @Output() hideIngaggiaComponent: EventEmitter<boolean> = new EventEmitter<boolean>();

  offertaVincolanteRicezioneEvents: EventsModel[] = [];
  offertaVincolanteAccettazioneEvents: EventsModel[] = [];
  goToFinalPage: EventsModel[] = [];

  idProposal: string;
  listOfFiles: any;
  leggiContrattiList: any;

  fideiussioneSigned: boolean;
  ovrSigned: boolean;
  ovaSigned: boolean;

  hasFideiussione: boolean;

  showProsegui: boolean;
  today = Date.now();

  showOVDocs: boolean;
  docType: string;
  contrattiSignatureInput: ContrattiSignatureInput;
  contrattiSignatureInput1: ContrattiSignatureInput;
  contrattiSignatureInput2: ContrattiSignatureInput;
  dossierGenerationArr: DossierGeneration[] = [];
  contrattiSignatureType: ContrattiSignatureType;
  documentGenerationList: DocumentGeneration[] = [];
  signatureStatusModel: SignatureStatusModel;
  dossier: DossierGeneration;

  constructor(private commonService: CommonService, private postDeliberaService: PostDeliberaService,
    private route: ActivatedRoute, private endpointsService: EndpointsService,
    private redirectService: RedirectService, public contrattoFideiussioneService: ContrattoFideiussioneService,
    private offertaVincolanteService: OffertaVincolanteService) {
    this.route.params.subscribe(params => { this.idProposal = params['proposalId']; });
  }

  ngOnInit() {

    this.signatureStatusModel = new SignatureStatusModel();
    this.signatureStatusModel.processId = Number(this.idProposal);
    this.signatureStatusModel.processType = TipoProcesso.VENDITA;
    const documentGenerationList: ContrattiDocument[] = [];
    documentGenerationList.push({ toSign: true, docType: this.docType });
    this.signatureStatusModel.documents = documentGenerationList;
    this.getContrattiSignatureInput();

    // PERIMETRO MCD
    this.showOVDocs = this.fetchMutuoDetailsResponse.perimeter === 'M';

    this.contrattoFideiussioneService.getGaranzieData(this.garanti, this.idProposal);

    this.contrattoFideiussioneService.hasFideiussione().subscribe(result => {
      this.hasFideiussione = result;
    });

    this.offertaVincolanteRicezioneEvents = [
      { eventName: 'click', eventCallBack: this.generateOffertaVincolanteRicezioneClicked.bind(this) }
    ];

    this.offertaVincolanteAccettazioneEvents = [
      { eventName: 'click', eventCallBack: this.generateOffertaVincolanteAccettazioneClicked.bind(this) }
    ];

    this.goToFinalPage = [
      { eventName: 'click', eventCallBack: this.finallyTheEnd.bind(this) }
    ];

    this.checkSignatureStatus();
    this.executeLeggiContrattiGenerati(this.numeroRapportoMutuo);
  }

  getContrattiSignatureInput() {

    const dossierDetails = {
      processId: this.signatureStatusModel.processId,
      processType: this.signatureStatusModel.processType,
      docType: FinDocumentType.OFFERTA_VINCOLANTE_RICEZIONE,
      dossierGenerationList: this.createDossierGenerationList(FinDocumentType.OFFERTA_VINCOLANTE_RICEZIONE)
    }

    const dossierDetails1 = {
      processId: this.signatureStatusModel.processId,
      processType: this.signatureStatusModel.processType,
      docType: FinDocumentType.OFFERTA_VINCOLANTE_ACCETTAZIONE,
      dossierGenerationList: this.createDossierGenerationList(FinDocumentType.OFFERTA_VINCOLANTE_ACCETTAZIONE)
    }

    const dossierDetails2 = {
      processId: this.signatureStatusModel.processId,
      processType: this.signatureStatusModel.processType,
      docType: FinDocumentType.GARANZIA_FIDEIUSSIONE,
      dossierGenerationList: this.prepareContrattiFideiussioneDossier()
    }

    if (!this.hasFideiussione) {
      forkJoin([this.commonService.getContrattiSignatureInput(dossierDetails), this.commonService.getContrattiSignatureInput(dossierDetails1)]).subscribe(flagInput => {
        this.contrattiSignatureInput = {
          isFeqEnabled: flagInput[0].feqEnabled,
          isSendOnly: flagInput[0].sendOnly,
          isSignatureInProgress: flagInput[0].signatureInProgress,
          signatureInProgressType: flagInput[0].signatureInProgressType
          // sendMailForSecci: true
        };
        this.contrattiSignatureInput1 = {
          isFeqEnabled: flagInput[1].feqEnabled,
          isSendOnly: flagInput[1].sendOnly,
          isSignatureInProgress: flagInput[1].signatureInProgress,
          signatureInProgressType: flagInput[1].signatureInProgressType
          // sendMailForSecci: true
        };
      });
    } else {
      this.commonService.getContrattiSignatureInput(dossierDetails2).subscribe(flagInput => {
        this.contrattiSignatureInput2 = {
          isFeqEnabled: flagInput.feqEnabled,
          isSendOnly: flagInput.sendOnly,
          isSignatureInProgress: flagInput.signatureInProgress,
          signatureInProgressType: flagInput.signatureInProgressType
          // sendMailForSecci: true
        }
      });
    }

  }

  onClickFirmaAltreModalita(signType: ContrattiSignatureType, documentType: string) {
    if (signType) {
      this.contrattiSignatureType = signType;
      if (FinDocumentType.GARANZIA_FIDEIUSSIONE == documentType) {
        this.docType = documentType;
        this.signatureStatusModel.documents[0].docType = this.docType;
        this.generateContrattoFideiussioneClicked();
      } else if (FinDocumentType.OFFERTA_VINCOLANTE_RICEZIONE == documentType) {
        this.docType = documentType;
        this.dossierGenerationArr = this.createDossierGenerationList(this.docType);
        this.signatureStatusModel.documents[0].docType = this.docType;
        this.generateOffertaVincolanteRicezioneClicked();
      } else if (FinDocumentType.OFFERTA_VINCOLANTE_ACCETTAZIONE == documentType) {
        this.docType = documentType;
        this.dossierGenerationArr = this.createDossierGenerationList(this.docType);
        this.signatureStatusModel.documents[0].docType = this.docType;
        this.generateOffertaVincolanteAccettazioneClicked();
      }
      // this.raccogliFirmeClicked();
    }
  }

  onClickRaccogliMancanti(documentType: string) {
  }

  onClickInviaMail() {
  }

  private checkSignatureStatus() {
    const data = <SignatureStatusModel>{
      processId: Number(this.idProposal),
      processType: TipoProcesso.VENDITA,
      docToGenerate: [FinDocumentType.GARANZIA_FIDEIUSSIONE]
    };

    const dataBis = <SignatureStatusModel>{
      processId: Number(this.idProposal),
      processType: TipoProcesso.VENDITA,
      docToGenerate: [FinDocumentType.OFFERTA_VINCOLANTE_RICEZIONE]
    };

    const dataTris = <SignatureStatusModel>{
      processId: Number(this.idProposal),
      processType: TipoProcesso.VENDITA,
      docToGenerate: [FinDocumentType.OFFERTA_VINCOLANTE_ACCETTAZIONE]
    };

    forkJoin([this.commonService.checkSignatureStatus(data), this.commonService.checkSignatureStatus(dataBis),
    this.commonService.checkSignatureStatus(dataTris)]).subscribe(completed => {
      this.fideiussioneSigned = completed[0];
      this.ovrSigned = completed[1];
      this.ovaSigned = completed[2];
      this.checkStatoPratica(this.fideiussioneSigned, this.ovrSigned, this.ovaSigned);
    });

  }

  private checkStatoPratica(fideiussioneSigned: boolean, ovrSigned: boolean, ovaSigned: boolean) {
    const checkFideiussione = this.hasFideiussione ? fideiussioneSigned : true;
    const checkOv = this.showOVDocs ? ovaSigned && ovrSigned : true;

    const allSigned = checkFideiussione && checkOv;

    this.showProseguiIpo(allSigned);
  }

  private showProseguiIpo(allSigned: boolean) {
    if (allSigned && this.codiceDescrizione.descrizione === FinMonitorStatus.EROGAZIONE_COMPLETA) {
      // FINANZIAMENTO EROGATO!!!
      this.commonService.updateMortgageStatus(this.idProposal, StatoMutuoType.EROGATO).subscribe(response => {
        if (response) {
          this.showProsegui = true;
          this.hideIngaggiaComponent.emit(true);
        }
      });
    }
  }

  finallyTheEnd() {
    this.commonService.updateProposalStep(this.idProposal, MortgageStepWizard.TWELVE).subscribe(result => {
      if (result) {
        this.redirectService.redirectWithSpinner(this.endpointsService.goToEndPage + this.idProposal);
      }
    });
  }

  openFile(file) {
    const b64Data = file.file;
    const contentType = 'application/pdf';
    const data = this.commonService.b64toBlob(b64Data, contentType, 512);
    const blob = new Blob([data], { type: 'application/octet-stream' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = file.nomeFile;
    link.click();
  }

  executeLeggiContrattiGenerati(numeroRapportoMutuo) {
    this.postDeliberaService.executeLeggiContrattiGenerati(numeroRapportoMutuo).subscribe(response => {
      this.listOfFiles = response;
      this.leggiContrattiList = this.listOfFiles.leggiContrattiList;
    });
  }

  generateContrattoFideiussioneClicked() {
    const dossierGenerationArr: DossierGeneration[] = [];
    this.contrattoFideiussioneService.goToGenerateContrattoFideiussione(this.idProposal,
      this.intestatari, this.jointHeading, this.fetchMutuoDetailsResponse.idPef, this.signatureStatusModel,
      dossierGenerationArr, this.contrattiSignatureType, this.contrattiSignatureInput2);
  }

  generateOffertaVincolanteRicezioneClicked() {
    const dossierGenerationArr: DossierGeneration[] = this.createDossierGenerationList(FinDocumentType.OFFERTA_VINCOLANTE_RICEZIONE);
    this.offertaVincolanteService.goToGenerateOffertaVincolanteRicezione(this.idProposal, this.mainUser,
      this.intestatari, this.jointHeading, this.fetchMutuoDetailsResponse, false, this.signatureStatusModel,
      dossierGenerationArr, this.contrattiSignatureType, this.contrattiSignatureInput);
  }

  generateOffertaVincolanteAccettazioneClicked() {
    const dossierGenerationArr: DossierGeneration[] = this.createDossierGenerationList(FinDocumentType.OFFERTA_VINCOLANTE_ACCETTAZIONE);
    this.goToGenerateOffertaVincolanteAccettazione(this.signatureStatusModel,
      dossierGenerationArr, this.contrattiSignatureType, this.contrattiSignatureInput1);
  }

  goToGenerateOffertaVincolanteAccettazione(signatureStatusModel: SignatureStatusModel, dossierGenerationArr: DossierGeneration[],
    contrattiSignatureType: ContrattiSignatureType, contrattiSignatureInput: ContrattiSignatureInput) {
    const generateDoc = new GenerateDoc();
    generateDoc.processId = Number(this.idProposal);
    generateDoc.processType = TipoProcesso.VENDITA;
    generateDoc.callbackUrl = this.endpointsService.callbackToPostDelibera + this.idProposal;
    generateDoc.paramsGenerateEndpoint = {};
    const documentGenerationArr: DocumentGeneration[] = [];
    const docObj = new DocumentGeneration();
    docObj.documentType = FinDocumentType.OFFERTA_VINCOLANTE_ACCETTAZIONE;
    docObj.mainNdg = this.mainUser.ndg;
    docObj.signers = this.intestatari;
    docObj.onlyFeaSign = true;
    documentGenerationArr.push(docObj);
    const offertaVincolanteAccettazione = new OffertaVincolanteAccettazione();
    offertaVincolanteAccettazione.cointestazione = this.jointHeading;
    offertaVincolanteAccettazione.customers = this.intestatari;
    offertaVincolanteAccettazione.dataRicezioneOfferta = new Date();
    offertaVincolanteAccettazione.idProposta = generateDoc.processId;
    generateDoc.documentList = documentGenerationArr;
    generateDoc.paramsGenerateEndpoint = offertaVincolanteAccettazione;
    generateDoc.generateEndpoint = this.endpointsService.offertaVincolanteAccettazioneEndPoint;
    generateDoc.deliveredEndpoint = this.endpointsService.setDocumentsDelivered;
    // this.saveOffertaVincolanteAccettazioneGenDoc(generateDoc);
    generateDoc.dossiers = dossierGenerationArr;
    this.commonService.saveInSession(generateDoc, signatureStatusModel, true, contrattiSignatureType, contrattiSignatureInput.isSignatureInProgress);
  }

  saveOffertaVincolanteAccettazioneGenDoc(generateDoc) {
    this.commonService.saveContrattiInputInSession(generateDoc).subscribe(() => {
      const signatureStatus = new SignatureStatusModel();
      signatureStatus.processId = Number(this.idProposal);
      signatureStatus.processType = TipoProcesso.VENDITA;
      signatureStatus.docToGenerate = [FinDocumentType.OFFERTA_VINCOLANTE_ACCETTAZIONE];
      this.redirectService.redirectWithSpinner(this.endpointsService.openContratti + '/'
        + encodeURIComponent(JSON.stringify(signatureStatus)));
    });
  }

  createDossierGenerationList(docType: string): DossierGeneration[] {
    // const intestatari = this.clientBaseList.filter(holder => !holder.cointestazione && holder.role === MortgageClientRoles.INTESTATARI);
    // const mainUser = this.commonService.getMainUser(this.clientBaseList.filter(holder => holder.role === MortgageClientRoles.INTESTATARI));
    // const jointHeading = this.clientBaseList.filter(holder => holder.cointestazione)[0];

    const dossierGenerationArr: DossierGeneration[] = [];
    const documentGenerationArr: DocumentGeneration[] = [];
    const dossierDocSignerArr: DossierDocSigner[] = [];
    const dossierObj = new DossierGeneration();
    dossierObj.groupBy = 'SIGNER';
    dossierObj.onlyFeaSign = true;
    dossierObj.onlyPaperSign = false;
    const docObj = new DocumentGeneration();
    docObj.titolo = docType;
    docObj.documentType = docType;
    docObj.mainNdg = this.mainUser.ndg;
    docObj.signers = this.intestatari;
    // docObj.jointHeading = this.jointHeading;
    docObj.mainClient = { ndg: this.mainUser.ndg, naturaGiuridica: (!this.mainUser.cointestazione) ? 'PERSONA_FISICA' : 'COINTESTAZIONE' };
    docObj.toSign = true;
    docObj.toReprint = false;
    docObj.mandatory = true;
    const dossierDocSignerObj = new DossierDocSigner();
    dossierDocSignerObj.ndg = this.mainUser.ndg;
    dossierDocSignerObj.type = this.mainUser.role;
    dossierDocSignerObj.mandatory = true;
    dossierDocSignerArr.push(dossierDocSignerObj);
    docObj.dossierDocSigners = dossierDocSignerArr;
    documentGenerationArr.push(docObj);
    dossierObj.documents = documentGenerationArr;
    dossierGenerationArr.push(dossierObj);
    return dossierGenerationArr;
  }

  prepareContrattiFideiussioneDossier(): DossierGeneration[] {
    const dossierGenerationArr: DossierGeneration[] = [];
    const documentGenerationArr: DocumentGeneration[] = [];
    const dossierDocSignerArr: DossierDocSigner[] = [];

    const dossierObj = new DossierGeneration();
    dossierObj.groupBy = 'SIGNER';
    dossierObj.onlyFeaSign = true;
    dossierObj.onlyPaperSign = false;

    this.contrattoFideiussioneService.garanzieGarantiList.forEach(garanzia => {
      const garantiInt: BaseClientModel[] = [];
      let count = 0;
      garanzia.garanti.forEach(garante => {
        // It's a workaround for contratti sign, because this is the only case
        // in which we have no holder to sign, only garanti, if I put all INT the FEA sign will fail,
        // cause of multiple 'titolari' in the input
        if (count === 0) {
          const garanteInt = { ...garante, role: 'INT' };
          garantiInt.push(garanteInt);
        } else {
          garantiInt.push(garante);
        }
        count++;
      });
      this.garanti = garantiInt;
      const docObj = new DocumentGeneration();
      docObj.titolo = FinDocumentType.GARANZIA_FIDEIUSSIONE;
      docObj.documentType = FinDocumentType.GARANZIA_FIDEIUSSIONE;
      docObj.mainNdg = garantiInt[0].ndg;
      docObj.signers = garantiInt;
      docObj.jointHeading = null;
      docObj.toSign = true;
      docObj.toReprint = false;
      docObj.mandatory = true;
      docObj.mainClient = { ndg: this.mainUser.ndg, naturaGiuridica: (!this.mainUser.cointestazione) ? 'PERSONA_FISICA' : 'COINTESTAZIONE' };
      const dossierDocSignerObj = new DossierDocSigner();
      dossierDocSignerObj.ndg = this.mainUser.ndg;
      dossierDocSignerObj.type = this.mainUser.role;
      dossierDocSignerObj.mandatory = true;
      dossierDocSignerArr.push(dossierDocSignerObj);
      docObj.dossierDocSigners = dossierDocSignerArr;
      documentGenerationArr.push(docObj);
      dossierObj.documents = documentGenerationArr;
      dossierGenerationArr.push(dossierObj);
    });
    return dossierGenerationArr;
  }
}
