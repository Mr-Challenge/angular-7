import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonPopupComponent } from 'bstore-angular-library';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'bst-fin-post-delibera-dettaglio-immobile',
  templateUrl: './post-delibera-dettaglio-immobile.component.html',
  styleUrls: ['./post-delibera-dettaglio-immobile.component.scss']
})
export class PostDeliberaDettaglioImmobileComponent implements OnInit {

  proposalId: string;

  @ViewChild(CommonPopupComponent) commonPopupComponent: CommonPopupComponent;

  constructor(public route: ActivatedRoute) {
    this.route.params.subscribe(params => {
      this.proposalId = params['proposalId'];
    });
  }

  ngOnInit() {
  }

}
