import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PostDeliberaDettaglioImmobileComponent } from './post-delibera-dettaglio-immobile.component';

describe('PostDeliberaDettaglioImmobileComponent', () => {
  let component: PostDeliberaDettaglioImmobileComponent;
  let fixture: ComponentFixture<PostDeliberaDettaglioImmobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PostDeliberaDettaglioImmobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PostDeliberaDettaglioImmobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
