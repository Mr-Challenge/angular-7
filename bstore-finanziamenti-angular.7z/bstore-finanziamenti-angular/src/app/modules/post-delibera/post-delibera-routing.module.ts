
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChatComponentComponent } from './components/chat-component/chat-component.component';
import { PostDeliberaDettaglioImmobileComponent } from './components/post-delibera-dettaglio-immobile/post-delibera-dettaglio-immobile.component';
import { PostDeliberaStartingPageComponent } from './components/post-delibera-starting-page/post-delibera-starting-page.component';
import { QuestionarioAdeguataVerificaComponent } from './components/questionario-adeguata-verifica/questionario-adeguata-verifica.component';
import { QuestionarioAdeguataComponent } from './components/questionario-adeguata/questionario-adeguata.component';

const routes: Routes = [
  { path: 'dettaglio/:codiceImmobile', component: PostDeliberaDettaglioImmobileComponent },
  {
    path: '',
    children: [
      { path: '', component: PostDeliberaStartingPageComponent },
      { path: 'QAV/QAVAngular', component: QuestionarioAdeguataVerificaComponent },
      { path: 'QAV/QAVAngular/:start', component: QuestionarioAdeguataVerificaComponent },
      { path: 'QAV/QAVAngular/:sez-a', component: QuestionarioAdeguataVerificaComponent },
      { path: 'QAV/QAVAngular/:sez-b', component: QuestionarioAdeguataVerificaComponent },
      { path: 'QAV/QAVAngular/:sez-c', component: QuestionarioAdeguataVerificaComponent },
      { path: 'QAV/QAVAngular/:sez-c-occ', component: QuestionarioAdeguataVerificaComponent },
      { path: 'QAV/QAVAngular/:sez-e1', component: QuestionarioAdeguataVerificaComponent },
      { path: 'QAV/QAVAngular/:sez-d', component: QuestionarioAdeguataVerificaComponent },
      { path: 'QAV/QAVAngular/:sez-e2', component: QuestionarioAdeguataVerificaComponent },
      { path: 'QAV/QAVAngular/:menu1', component: QuestionarioAdeguataVerificaComponent },
      { path: 'QAV/QAVAngular/:menu2', component: QuestionarioAdeguataVerificaComponent },
      { path: 'QAV/QAVAngular/:qavDataForm', component: QuestionarioAdeguataVerificaComponent },
      { path: 'QAV/QAVAngular/:test', component: QuestionarioAdeguataVerificaComponent },
      { path: 'QAVManagement', component: QuestionarioAdeguataComponent }
    ]
  }, { path: 'chatCompnent', component: ChatComponentComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PostDeliberaRoutingModule { }
