import { TestBed } from '@angular/core/testing';

import { SecciService } from './secci.service';

describe('SecciService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SecciService = TestBed.get(SecciService);
    expect(service).toBeTruthy();
  });
});
