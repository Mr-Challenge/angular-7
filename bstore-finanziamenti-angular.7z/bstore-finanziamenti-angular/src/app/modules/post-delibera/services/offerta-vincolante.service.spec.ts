import { TestBed } from '@angular/core/testing';

import { OffertaVincolanteService } from './offerta-vincolante.service';

describe('OffertaVincolanteService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OffertaVincolanteService = TestBed.get(OffertaVincolanteService);
    expect(service).toBeTruthy();
  });
});
