import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { DatiStipulaErogazione } from 'src/app/models/datiStipulaErogazione.model';
import { DocumentiCaricare } from 'src/app/models/documentiCaricare.model';
import { ImpostaDataPresuntaStipula } from 'src/app/models/impostaDataPresuntaStipula.model';
import { MessaggioChat } from 'src/app/models/MessaggioChat.model';
import { PostDeliberaData } from 'src/app/models/post-delibera/postDeliberaData.model';
import { PostDeliberaDatiGenerali } from 'src/app/models/post-delibera/postDeliberaDatiGenerali.model';
import { PostDeliberaDatiRichiedente } from 'src/app/models/post-delibera/postDeliberaDatiRichiedente.model';
import { PostDeliberaPolizze } from 'src/app/models/post-delibera/postDeliberaPolizze.model';
import { PostDeliberaSezioneVenditore } from 'src/app/models/post-delibera/postDeliberaSezioneVenditore.model';
import { PostDelibera, RestituisciPerizia } from 'src/app/models/postDelibera.model';
import { SimulazioneMutuo } from 'src/app/models/simulazioneMutuo';
import { environment } from 'src/environments/environment';
import { EndpointsService } from '../../../services/endpoints.service';
import { BaseClientModel } from '../../product-configuration/models/BaseClientModel';
import { PostDeliberaDatiNotaio } from 'src/app/models/post-delibera/postDeliberaDatiNotaio.model';
import { PostDeliberaDataIngaggioFin } from 'src/app/models/post-delibera/postDeliberaDataIngaggioFin.model';
import { AllegatoPratica } from 'src/app/models/allegatoPratica.model';
import { AllegatoPraticaUrl } from 'src/app/models/allegatoPraticaUrl.model';
import { PostDeliberaPolizzeProtezione } from 'src/app/models/post-delibera/postDeliberaPolizzeProtezione.model';
import { PostDeliberaDataErogazione } from 'src/app/models/post-delibera/postDeliberaDataErogazione.model';
import { MailNoBperModel } from 'src/app/models/mailNoBper.model';
import { ContoAddebitoDetailsModel } from 'src/app/models/generateDoc.model';
import { ErogazioneFinanziamentoModel } from 'src/app/models/erogazioneFin.model';
import { PostDeliberaStampaTecnicaPef } from 'src/app/models/post-delibera/postDeliberaStampaTecnicaPef.model';

@Injectable({
  providedIn: 'root'
})
export class PostDeliberaService {

  isStepComp: boolean;
  isExpand: boolean;
  redirectPageName: string;
  genericaDocumentazioneShared: any[];
  allegatoPraticaList: AllegatoPratica[];
  isDateValid: boolean;
  polizzaPersonalizzata: boolean;

  constructor(private httpClient: HttpClient, private endpointsService: EndpointsService) { }


  postDeliberaPageStatus: {
    qav: boolean;
    qav_current: boolean;

    gestionePerizie: boolean;
    gestionePerizie_current: boolean;

    gestionePolizze: boolean;
    gestionePolizze_current: boolean;

    datiStipulaEdErogazione: {
      datiStipulaGenerali: boolean;
      datiStipulaRichiedente: boolean;
      // datiStipulaVenditore: boolean;
      datiStipulaNotaio: boolean;
    },
    datiStipulaEdErogazione_current: boolean;
    documentiDaCaricare: {
      documentazioneGenerica: boolean;
      documentazioneEventuale: boolean;
    },
    documentiDaCaricare_current: boolean,
    firmePage: boolean;
    firmePage_current: boolean;
    ingaggiaUfficio: boolean;
    ingaggiaUfficio_current: boolean;
    polizzeSectionData: any;
    datiStipulaDocument: any;
    datiStipulaGeneraliData: {
      statoAvanzamentoLavori: boolean;
      importoStipula: number;
      importoPrimaErogazione: number;
      dataDiPresuntaStipula: Date;
    },
    datiStipulaRichiedenteData: {
      accreditoContentField: string;
      addebitoContentField: string;
    }
  } = {
      qav: false,
      qav_current: false,

      gestionePerizie: false,
      gestionePerizie_current: false,

      gestionePolizze: false,
      gestionePolizze_current: false,

      datiStipulaEdErogazione: {
        datiStipulaGenerali: false,
        datiStipulaRichiedente: false,
        // datiStipulaVenditore: false,
        datiStipulaNotaio: false,
      },
      datiStipulaEdErogazione_current: false,
      documentiDaCaricare: {
        documentazioneGenerica: false,
        documentazioneEventuale: false,
      },
      documentiDaCaricare_current: false,
      firmePage: false,
      firmePage_current: false,
      ingaggiaUfficio: false,
      ingaggiaUfficio_current: false,
      datiStipulaDocument: {
        isGenerateDocument: false,
        documentData: []
      },
      polizzeSectionData: {
        isGenerateDocument: false,
        immobilesData: [],
        holdersData: []
      },
      datiStipulaGeneraliData: {
        statoAvanzamentoLavori: null,
        importoStipula: 0,
        importoPrimaErogazione: 0,
        dataDiPresuntaStipula: null
      },
      datiStipulaRichiedenteData: {
        accreditoContentField: '',
        addebitoContentField: ''
      }
    };
  stipulaDate: Date;
  disabilitaCambioDate: any;
  emitpostDeliberaPageStatus: BehaviorSubject<any> = new BehaviorSubject<any>(this.postDeliberaPageStatus);
  emitStipulaDate: BehaviorSubject<any> = new BehaviorSubject<any>(this.stipulaDate);
  emitDisabilitaCambioDate: BehaviorSubject<any> = new BehaviorSubject<any>(this.disabilitaCambioDate);
  emitValidDate: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(this.isDateValid);
  emitPolizzaPersonalizzata: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(this.polizzaPersonalizzata);

  contoAddebitoDetails: BehaviorSubject<ContoAddebitoDetailsModel> = new BehaviorSubject<ContoAddebitoDetailsModel>(null);
  contoAccreditoDetails: BehaviorSubject<ContoAddebitoDetailsModel> = new BehaviorSubject<ContoAddebitoDetailsModel>(null);
  altroContoAddebito: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  listaImportoPremios: BehaviorSubject<number[]> = new BehaviorSubject<number[]>(null);

  pefDoc: BehaviorSubject<AllegatoPraticaUrl> = new BehaviorSubject<AllegatoPraticaUrl>(null);

  setpostDeliberaPageStatus(data) {
    this.postDeliberaPageStatus.qav_current = data.qav;
    this.postDeliberaPageStatus.gestionePerizie_current = data.gestionePerizie;
    this.postDeliberaPageStatus.gestionePolizze_current = data.gestionePolizze;
    this.postDeliberaPageStatus.datiStipulaEdErogazione_current =
      Object.keys(data.datiStipulaEdErogazione)
        .every(key => data.datiStipulaEdErogazione[key]);
    this.postDeliberaPageStatus.documentiDaCaricare_current =
      Object.keys(data.documentiDaCaricare)
        .every(key => data.documentiDaCaricare[key]);

    if (!this.postDeliberaPageStatus.qav) {
      this.postDeliberaPageStatus.gestionePerizie_current = false;
    }
    if (!this.postDeliberaPageStatus.gestionePerizie_current) {
      this.postDeliberaPageStatus.gestionePolizze_current = false;
    }
    if (!this.postDeliberaPageStatus.gestionePolizze_current) {
      this.postDeliberaPageStatus.datiStipulaEdErogazione_current = false;
    }
    this.emitpostDeliberaPageStatus.next(this.postDeliberaPageStatus);
  }

  setpostDeliberaPageStatusChiro(data) {
    this.postDeliberaPageStatus.qav_current = data.qav;
    this.postDeliberaPageStatus.gestionePolizze_current = data.gestionePolizze;
    this.postDeliberaPageStatus.datiStipulaEdErogazione_current
      = data.datiStipulaEdErogazione.datiStipulaRichiedente;

    if (!this.postDeliberaPageStatus.qav) {
      this.postDeliberaPageStatus.gestionePolizze_current = false;
    }
    if (!this.postDeliberaPageStatus.gestionePolizze_current) {
      this.postDeliberaPageStatus.datiStipulaEdErogazione_current = false;
    }
    this.emitpostDeliberaPageStatus.next(this.postDeliberaPageStatus);
  }

  getpostDeliberaPageStatus() {
    return this.emitpostDeliberaPageStatus.asObservable();
  }

  setStipulaDate(date) {
    this.emitStipulaDate.next(date);
  }

  setDateValid(isDateValid: boolean) {
    this.emitValidDate.next(isDateValid);
  }

  getDateValid() {
    return this.emitValidDate.asObservable();
  }

  getStipulaDate() {
    return this.emitStipulaDate.asObservable();
  }

  setDisabilitaCambioDate(date) {
    this.emitDisabilitaCambioDate.next(date);
  }

  getDisabilitaCambioDate() {
    return this.emitDisabilitaCambioDate.asObservable();
  }

  postDelibera: {
    flag1: false,
    flag2: false,
    flag3: false,
    flag4: false,
    flag5: false,
    flag6: false
  };

  datiStipulaErogazione: {
    flag4_1: false,
    flag4_2: false,
    flag4_3: false,
    flag4_4: false
  };

  documentiCaricare: {
    flag5_1: false,
    flag5_2: false
  };

  emitpostDeliberaStatus: BehaviorSubject<PostDelibera> = new BehaviorSubject<PostDelibera>(this.postDelibera);
  setpostDeliberaStatusFlag = this.emitpostDeliberaStatus.asObservable();

  emitdatiStipulaErogazioneStatus: BehaviorSubject<DatiStipulaErogazione> =
    new BehaviorSubject<DatiStipulaErogazione>(this.datiStipulaErogazione);

  setdatiStipulaErogazioneStatusFlag = this.emitdatiStipulaErogazioneStatus.asObservable();

  emitdocumentiCaricareStatus: BehaviorSubject<DocumentiCaricare> =
    new BehaviorSubject<DocumentiCaricare>(this.documentiCaricare);
  setdocumentiCaricareStatusFlag = this.emitdocumentiCaricareStatus.asObservable();

  updatePostDeliberaData(preventivoSetObj: PostDelibera) {
    this.emitpostDeliberaStatus.next(preventivoSetObj);
  }

  updateDatiStipulaErogazione(datiStipulaObj: DatiStipulaErogazione) {
    this.emitdatiStipulaErogazioneStatus.next(datiStipulaObj);
  }

  updateDocumentiCaricare(documentiObj: DocumentiCaricare) {
    this.emitdocumentiCaricareStatus.next(documentiObj);
  }

  private importoStipula = new BehaviorSubject<number>(0);
  getImportoDiStipula(): Observable<any> {
    return this.importoStipula.asObservable();
  }

  setImportoDiStipula(importoDiStipulaValue: number) {
    this.importoStipula.next(importoDiStipulaValue);
  }

  private allCompleto = new BehaviorSubject<boolean>(false);
  getAllCompleto(): Observable<any> {
    return this.allCompleto.asObservable();
  }

  setAllCompleto(allCompleto: boolean) {
    this.allCompleto.next(allCompleto);
  }

  private statoAvanzamentoLavori = new BehaviorSubject('');
  getStatoAvanzamentoLavoriStatus(): Observable<any> {
    return this.statoAvanzamentoLavori.asObservable();
  }

  setStatoAvanzamentoLavoriStatus(statoAvanzamentoLavoriStatus: any) {
    this.statoAvanzamentoLavori.next(statoAvanzamentoLavoriStatus);
  }

  private importoPrimaErogazione = new BehaviorSubject(0);
  getImportoPrimaErogazione(): Observable<any> {
    return this.importoPrimaErogazione.asObservable();
  }

  setImportoPrimaErogazione(importoPrimaErogazioneValue: number) {
    this.importoPrimaErogazione.next(importoPrimaErogazioneValue);
  }

  setImmobileDetailPage(pageName: string) {
    this.redirectPageName = pageName;
  }

  getImmobileDetailPage() {
    return this.redirectPageName;
  }

  getChatMessages(numeroPratica: string): Observable<MessaggioChat[]> {
    const parameters = new HttpParams().append('numeroPratica', numeroPratica);
    return this.httpClient.get<MessaggioChat[]>(this.endpointsService.getMessaggiChat, { params: parameters });
  }

  marksMessageRead(numeroPratica: string, idMessaggio: string) {
    const firstParam = new HttpParams().append('numeroPratica', numeroPratica).append('idMessaggio', idMessaggio);
    return this.httpClient.get<string>(this.endpointsService.segnaMessaggioLettoChat, { params: firstParam });
  }

  sendChatMessage(numeroPratica: string, testoMessaggio: string) {
    const parameters = new HttpParams().append('numeroPratica', numeroPratica).append('testoMessaggio', testoMessaggio);
    return this.httpClient.get<string>(this.endpointsService.inviaMessaggioChat, { params: parameters });
  }

  private dataDiPresuntaStipula = new BehaviorSubject('');
  getDataDiPresuntaStipula(): Observable<any> {
    return this.dataDiPresuntaStipula.asObservable();
  }

  setDataDiPresuntaStipula(DataDiPresuntaStipulaText: any) {
    this.dataDiPresuntaStipula.next(DataDiPresuntaStipulaText);
  }

  setPefDoc(value: AllegatoPraticaUrl) {
    this.pefDoc.next(value);
  }

  getPefDoc(): Observable<AllegatoPraticaUrl> {
    return this.pefDoc.asObservable();
  }

  public executeLeggiContrattiGenerati(numPratica: string): Observable<BaseClientModel[]> {
    const parameters = new HttpParams().append('numPratica', numPratica);
    return this.httpClient.get<any>(this.endpointsService.leggiContrattiGenerati, { params: parameters });
  }

  getLeggiStatoPratica(numeroPratica: string) {
    const params = new HttpParams();
    const parameters = params.append('numeroPratica', numeroPratica);
    return this.httpClient.get<any>(this.endpointsService.leggiStatoPratica, { params: parameters });
  }


  generateDocument(docData): Observable<AllegatoPraticaUrl> {
    return this.httpClient.post<AllegatoPraticaUrl>(this.endpointsService.generatePreventiviPolizze, docData);
  }

  generateDocumentStipula(docData): Observable<AllegatoPraticaUrl> {
    return this.httpClient.post<AllegatoPraticaUrl>(this.endpointsService.generateDatiStipula, docData);
  }

  retrieveRestituisciPeriziaDetails(codiceImmobile: string): Observable<RestituisciPerizia> {
    const params = new HttpParams();
    const parameters = params.append('idImmobile', codiceImmobile);
    return this.httpClient.get<RestituisciPerizia>(this.endpointsService.restituisciPeriziaDetails, { params: parameters });
  }

  public retrieveSimulationDetails(proposalId: string): Observable<SimulazioneMutuo[]> {
    const parameters = new HttpParams().append('idProposal', proposalId);
    return this.httpClient.get<SimulazioneMutuo[]>(this.endpointsService.retrieveSimulationDetails, { params: parameters });
  }

  public getConfig(configUrl, responseType) {
    let headers = new HttpHeaders();
    headers = headers.set('Accept', 'application/pdf');
    return this.httpClient.get(configUrl, { headers: headers, responseType: responseType });
  }

  impostaDataPresuntaStipula(impostaDataPresuntaStipula: ImpostaDataPresuntaStipula): Observable<boolean> {
    return this.httpClient.post<boolean>(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/impostaDataPresuntaStipula`, impostaDataPresuntaStipula);
  }

  private ibanContoDiAccredito = new BehaviorSubject('');
  getIbanContoDiAccredito(): Observable<any> {
    return this.ibanContoDiAccredito.asObservable();
  }

  setIbanContoDiAccredito(ibanContoDiAccreditoValue: string) {
    this.ibanContoDiAccredito.next(ibanContoDiAccreditoValue);
  }

  setFirstPolizzaPersonalizzata(polizzaPersonalizzata: boolean) {
    this.emitPolizzaPersonalizzata.next(polizzaPersonalizzata);
  }

  getFirstPolizzaPersonalizzata(): Observable<any> {
    return this.emitPolizzaPersonalizzata.asObservable();
  }

  setAllegatoPraticaList(allegatoPraticaList: AllegatoPratica[]) {
    this.allegatoPraticaList = allegatoPraticaList;
  }

  getAllegatoPraticaList() {
    return this.allegatoPraticaList;
  }

  setContoAccreditoDetails(contoAccredito: ContoAddebitoDetailsModel) {
    this.contoAccreditoDetails.next(contoAccredito);
  }

  setContoAddebitoDetails(contoAddebito: ContoAddebitoDetailsModel) {
    this.contoAddebitoDetails.next(contoAddebito);
  }

  setAltroContoAddebito(isAltro: boolean) {
    this.altroContoAddebito.next(isAltro);
  }

  setListaImportoPremios(lista: number[]) {
    this.listaImportoPremios.next(lista);
  }

  checkValidStipulaPrevistaDate(date: string) {
    const params = new HttpParams();
    const parameters = params.append('date', date);
    return this.httpClient.get<any>(this.endpointsService.checkValidStipulaPrevistaDate, { params: parameters });
  }

  stringToDouble(importo: string) {
    let lastComma = importo.lastIndexOf(',');
    let lastDot = importo.lastIndexOf('.');
    let numSeparato = [];
    let result;
    if (lastComma === undefined && lastDot === undefined) {
      result = importo;
    } else if (importo.split('.').length === 2 && lastDot > lastComma) {
      numSeparato = importo.split('.');
      let sepMigliaia = /\,/gi;
      numSeparato[0] = numSeparato[0].replace(sepMigliaia, '');
      result = numSeparato[0] + '.' + numSeparato[1];
    } else if (importo.split(',').length === 2 && lastComma > lastDot) {
      numSeparato = importo.split(',');
      let sepMigliaia = /\./gi;
      numSeparato[0] = numSeparato[0].replace(sepMigliaia, '');
      result = numSeparato[0] + '.' + numSeparato[1];
    } else {
      let sepMigliaia = /\./gi;
      result = importo.replace(sepMigliaia, '');
      sepMigliaia = /\,/gi;
      result = result.replace(sepMigliaia, '');
    }
    return result;
  }

  saveFirstPdAccess(idProcesso: string, tipoProcesso: string): Observable<any> {
    const params = new HttpParams();
    const parameters = params.append('idProcesso', idProcesso).append('tipoProcesso', tipoProcesso);
    return this.httpClient.get<PostDeliberaData>(this.endpointsService.saveFirstPdAccess, { params: parameters });
  }

  retrieveAndSaveStampaTecnicaPef(data: PostDeliberaStampaTecnicaPef): Observable<any> {
    const params = new HttpParams();
    const parameters = params.append('skipTimeout', 'YES');
    return this.httpClient.post<PostDeliberaStampaTecnicaPef>(this.endpointsService.retrieveAndSaveStampaTecnicaPef, data, { params: parameters });
  }

  savePolizze(data: PostDeliberaPolizze): Observable<any> {
    return this.httpClient.post<PostDeliberaPolizze>(this.endpointsService.savePolizze, data);
  }

  savePolizzeProtezione(data: PostDeliberaPolizzeProtezione): Observable<any> {
    return this.httpClient.post<PostDeliberaPolizzeProtezione>(this.endpointsService.savePolizzeProtezione, data);
  }

  saveNotaio(data: PostDeliberaDatiNotaio): Observable<any> {
    return this.httpClient.post<PostDeliberaDatiNotaio>(this.endpointsService.saveNotaio, data);
  }

  saveDatiGeneraliStipula(data: PostDeliberaDatiGenerali): Observable<any> {
    return this.httpClient.post<PostDeliberaDatiGenerali>(this.endpointsService.saveDatiGeneraliStipula, data);
  }

  saveDatiRichiedenteStipula(data: PostDeliberaDatiRichiedente): Observable<any> {
    return this.httpClient.post<PostDeliberaDatiRichiedente>(this.endpointsService.saveDatiRichiedenteStipula, data);
  }

  saveDatiVenditoreStipula(data: PostDeliberaSezioneVenditore): Observable<any> {
    return this.httpClient.post<PostDeliberaSezioneVenditore>(this.endpointsService.saveDatiVenditoreStipula, data);
  }

  saveDataIngaggioFin(data: PostDeliberaDataIngaggioFin): Observable<any> {
    return this.httpClient.post<PostDeliberaDataIngaggioFin>(this.endpointsService.saveDataIngaggioFin, data);
  }

  saveDataErogazione(data: PostDeliberaDataErogazione): Observable<any> {
    return this.httpClient.post<PostDeliberaDataErogazione>(this.endpointsService.saveDataErogazione, data);
  }

  fetchPostDeliberaData(idProcesso: string, tipoProcesso: string): Observable<any> {
    const params = new HttpParams();
    const parameters = params.append('idProcesso', idProcesso).append('tipoProcesso', tipoProcesso);
    return this.httpClient.get<PostDeliberaData>(this.endpointsService.fetchPostDeliberaData, { params: parameters });
  }

  sendMailForAccountNoBper(data: MailNoBperModel): Observable<any> {
    return this.httpClient.post<MailNoBperModel>(this.endpointsService.sendMailForAccountNoBper, data);
  }

  erogazioneFinanziamento(data: ErogazioneFinanziamentoModel): Observable<any> {
    return this.httpClient.post<ErogazioneFinanziamentoModel>(this.endpointsService.erogazioneFinanziamento, data);
  }

  canEnableStampaErogaButton(idPef: number): Observable<any> {
    const params = new HttpParams();
    const parameters = params.append('idPef', idPef.toString());
    return this.httpClient.get<number>(this.endpointsService.canEnableStampaErogaButton, { params: parameters });
  }

}
