import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AllegatoPratica } from 'src/app/models/allegatoPratica.model';
import { QavDataRetrieveInput } from '../../../models/QavDataRetrieveInput';
import { EndpointsService } from '../../../services/endpoints.service';
import { LeggiModuliPratica } from 'src/app/models/leggiModuliPratica.model';

@Injectable({
  providedIn: 'root'
})
export class ModulisticaPraticheService {

  constructor(private httpClient: HttpClient, private endpointsService: EndpointsService) { }

  allegaModuloPratica(allegatoPratica: AllegatoPratica[]): Observable<boolean> {
    return this.httpClient.post<boolean>(this.endpointsService.allegaModuloPratica, allegatoPratica);
  }

  getLeggiModuliPratica(numeroPratica, mainNdg) {
    const params = new HttpParams();
    const parameters = params.append('numeroPratica', numeroPratica).append('mainNdg', mainNdg);
    return this.httpClient.get<LeggiModuliPratica[]>(this.endpointsService.getLeggiModuliPratica, { params: parameters });
  }

  rimuoviModuloPratica(codModulo, numeroPratica): Observable<boolean> {
    const params = new HttpParams();
    const parameters = params.append('codModulo', codModulo).append('numeroPratica', numeroPratica);
    return this.httpClient.delete<any>(this.endpointsService.rimuoviModuloPratica, { params: parameters });
  }

  getBankAccountsListDetails(ndgList: String[]) {
    return this.httpClient.post<any>(this.endpointsService.loadBankAccountLists, ndgList);
  }

  getInserisciConsensoSICList(numeroPratica, proposalId) {
    const params = new HttpParams();
    const parameters = params.append('idProposal', proposalId).append('numeroPratica', numeroPratica);
    return this.httpClient.get<any>(this.endpointsService.inserisciConsensoSICList, { params: parameters });
  }

  getKycProductVm(idProposal: string) {
    const config = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
    return this.httpClient.post<any>(this.endpointsService.retrieveKycProductVm, idProposal, config);
  }

  checkQAVPregressiDB(idProposal: string) {
    const params = new HttpParams();
    const parameters = params.append('idProposal', idProposal);
    return this.httpClient.get<boolean>(this.endpointsService.checkQAVPregressiDB, { params: parameters });
  }

  getQavDataFromKYCProductVm(qavDataRetrieveInput: QavDataRetrieveInput) {
    return this.httpClient.post<any>(this.endpointsService.retrieveQavDataFromKYCProductVm, qavDataRetrieveInput);
  }

  attachLinkFile(allegatoPratica: AllegatoPratica): Observable<boolean> {
    return this.httpClient.post<boolean>(this.endpointsService.attachLinkFile, allegatoPratica);
  }

}
