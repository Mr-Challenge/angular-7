import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CercaRubricaNotaiserviceService {

  constructor(private httpClient: HttpClient) { }

  getNotatioList(notaio: string) {
    const params = new HttpParams();
    const parameters = params.append('notaio', notaio);
    return this.httpClient.get<any>(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/getCercaRubricaNotai`, { params: parameters });
  }
}
