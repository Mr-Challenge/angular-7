import { TestBed } from '@angular/core/testing';

import { QuestionarioAdeguataVerificaIntegrationService } from './questionario-adeguata-verifica-integration.service';

describe('QuestionarioAdeguataVerificaIntegrationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: QuestionarioAdeguataVerificaIntegrationService = TestBed.get(QuestionarioAdeguataVerificaIntegrationService);
    expect(service).toBeTruthy();
  });
});
