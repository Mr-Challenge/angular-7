import { Injectable } from '@angular/core';
import { ContrattiSignatureType, RedirectService } from 'bstore-angular-library';
import { BehaviorSubject, Observable } from 'rxjs';
import { FinDocumentType } from 'src/app/constant/documentType';
import { TipoProcesso } from 'src/app/constant/tipoProcesso';
import { DocumentGeneration } from 'src/app/models/documentGeneration.model';
import { ContrattoFideiussione, DossierGeneration, GenerateDoc, NdgImportoGaranzia } from 'src/app/models/generateDoc.model';
import { CommonService } from 'src/app/services/common.service';
import { EndpointsService } from 'src/app/services/endpoints.service';
import { isNull } from 'util';
import { BaseClientModel } from '../../product-configuration/models/BaseClientModel';
import { GuaranteesModel } from '../../vendita/models/guarantees.model';
import { SignatureStatusModel } from '../../vendita/models/signature-status.model';
import { PefService } from '../../vendita/services/pef.service';
import { v4 as uuidv4 } from 'uuid';
import { GaranzieGaranti } from '../../vendita/models/garanzie-garanti.model';
import { ContrattiSignatureInput } from 'bstore-angular-library/lib/models/contrattiSignatureInput.model';

@Injectable({
  providedIn: 'root'
})
export class ContrattoFideiussioneService {

  garanzieListFuoriAtto: GuaranteesModel[] = [];
  importoGaranziaList: NdgImportoGaranzia[] = [];
  garanzieGarantiList: GaranzieGaranti[] = [];

  hasFideiussioneDoc: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  constructor(private endpointsService: EndpointsService, private pefService: PefService,
    private commonService: CommonService, private redirectService: RedirectService) { }

  getGaranzieData(garanti: BaseClientModel[], idProposal: string) {
    this.pefService.getVenditaPageData(Number(idProposal)).subscribe(response => {
      if (!isNull(response)) {
        this.garanzieListFuoriAtto =
          response.guaranteeList.filter(garanzia => garanzia.inAttoFlag !== 'In atto' && garanzia.intestazione);
      }
      if (this.garanzieListFuoriAtto.length > 0) {

        this.garanzieListFuoriAtto.forEach(garanziaFuoriAtto => {
          garanziaFuoriAtto.uniqueId = uuidv4();
          this.garanzieGarantiList.push({ garanzia: garanziaFuoriAtto, garanti: [] });
        });

        this.garanzieListFuoriAtto.forEach(garanziaFuoriAtto => {
          garanti.forEach(garanteBaseClient => {
            garanziaFuoriAtto.garantiList.forEach(garanteGaranzia => {
              if (garanteBaseClient.ndg === garanteGaranzia.ndgGarante.toString()) {
                this.garanzieGarantiList.forEach(element => {
                  if (element.garanzia.uniqueId === garanziaFuoriAtto.uniqueId) {
                    element.garanti.push(garanteBaseClient);
                  }
                });
              }
            });
          });
        });
      }
      if (this.garanzieListFuoriAtto !== undefined && this.garanzieListFuoriAtto.length > 0) {
        this.hasFideiussioneDoc.next(true);
      }
    });
  }

  hasFideiussione(): Observable<boolean> {
    return this.hasFideiussioneDoc.asObservable();
  }

  getGaranzieGarantiList(): GaranzieGaranti[] {
    return this.garanzieGarantiList;
  }

  goToGenerateContrattoFideiussione(idProposal: string, intestatari: BaseClientModel[],
    jointHeading: BaseClientModel, idPef: number, signatureStatusModel: SignatureStatusModel, dossierGenerationArr: DossierGeneration[],
    contrattiSignatureType: ContrattiSignatureType, contrattiSignatureInput: ContrattiSignatureInput) {
    const generateDoc = new GenerateDoc();
    generateDoc.processId = Number(idProposal);
    generateDoc.processType = TipoProcesso.VENDITA;
    generateDoc.callbackUrl = this.endpointsService.callbackToPostDelibera + idProposal;
    generateDoc.paramsGenerateEndpoint = {};
    generateDoc.documentList = [];

    const dossier = new DossierGeneration();
    dossier.groupBy = 'SIGNER';
    dossier.onlyFeaSign = false;
    dossier.onlyPaperSign = true;
    generateDoc.dossiers.push(dossier);

    const contrattiFideiussioneList: ContrattoFideiussione[] = [];

    this.garanzieGarantiList.forEach(garanzia => {
      const garantiInt: BaseClientModel[] = [];
      let count = 0;
      garanzia.garanti.forEach(garante => {
        // It's a workaround for contratti sign, because this is the only case
        // in which we have no holder to sign, only garanti, if I put all INT the FEA sign will fail,
        // cause of multiple 'titolari' in the input
        if (count === 0) {
          const garanteInt = { ...garante, role: 'INT' };
          garantiInt.push(garanteInt);
        } else {
          garantiInt.push(garante);
        }
        count++;
      });
      const docObj = new DocumentGeneration();
      docObj.documentType = FinDocumentType.GARANZIA_FIDEIUSSIONE;
      docObj.mainNdg = garantiInt[0].ndg;
      docObj.signers = garantiInt;
      docObj.jointHeading = null;
      docObj.toSign = true;
      docObj.toReprint = false;
      docObj.mandatory = true;
      dossier.documents.push(docObj);
      dossierGenerationArr.push(dossier);
      const contrattoFideiussione = new ContrattoFideiussione();
      contrattoFideiussione.customers = intestatari;
      contrattoFideiussione.guarantor = garantiInt;
      contrattoFideiussione.idProposta = generateDoc.processId;
      contrattoFideiussione.jointHeading = jointHeading;
      contrattoFideiussione.idPef = idPef;
      contrattoFideiussione.importoGaranzia = garanzia.garanzia.importo;
      contrattoFideiussione.numeroGaranzia = garanzia.garanzia.numeroGaranzia;
      contrattiFideiussioneList.push(contrattoFideiussione);
    });

    generateDoc.paramsGenerateEndpoint = contrattiFideiussioneList;
    generateDoc.generateEndpoint = this.endpointsService.contrattoFideiussioneEndPoint;
    generateDoc.deliveredEndpoint = this.endpointsService.setDocumentsDelivered;
    generateDoc.dossiers = dossierGenerationArr;
    this.commonService.saveInSession(generateDoc, signatureStatusModel, true, contrattiSignatureType, contrattiSignatureInput.isSignatureInProgress);
    // this.saveContrattoFideiussioneGenDoc(generateDoc, idProposal);
  }

  saveContrattoFideiussioneGenDoc(generateDoc: GenerateDoc, idProposal: string) {
    this.commonService.saveContrattiInputInSession(generateDoc).subscribe(() => {
      const signatureStatus = new SignatureStatusModel();
      signatureStatus.processId = Number(idProposal);
      signatureStatus.processType = TipoProcesso.VENDITA;
      signatureStatus.docToGenerate = [];
      generateDoc.dossiers.forEach(dossier => {
        dossier.documents.forEach(doc => {
          signatureStatus.docToGenerate.push(doc.documentType);
        });
      });
      this.redirectService.redirectWithSpinner(this.endpointsService.openContratti + '/'
        + encodeURIComponent(JSON.stringify(signatureStatus)));
    });
  }
}
