import { TestBed } from '@angular/core/testing';

import { CercaRubricaNotaiserviceService } from './cerca-rubrica-notaiservice.service';

describe('CercaRubricaNotaiserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CercaRubricaNotaiserviceService = TestBed.get(CercaRubricaNotaiserviceService);
    expect(service).toBeTruthy();
  });
});
