import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { combineLatest, Observable, of } from 'rxjs';
import { finalize, map, switchMap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { EndpointsService } from '../../../services/endpoints.service';
@Injectable({
  providedIn: 'root'
})
export class QuestionarioAdeguataVerificaIntegrationService {

  isLoaded = false;

  constructor(private http: HttpClient, private endpointsService: EndpointsService) { }

  loadApp() {
    if (this.isLoaded) {
      return of(false);
    }
    return this.http.get<{
      assetsByChunkName: Record<string, string>
    }>(this.endpointsService.questionarioAdeguataVerificaAsset).pipe(
      map(stats => stats.assetsByChunkName),
      switchMap(assetMap => combineLatest(
        this.loadAssets(assetMap)
      )),
      finalize(() => this.isLoaded = true),
      map(results => results.every(Boolean))
    );
  }

  private loadAssets(assetMap: Record<string, string>) {
    return Object.values(assetMap)
      .map(filename => new Observable<boolean>(subscriber => {
        let element: HTMLScriptElement | HTMLLinkElement;
        if (filename.endsWith('.css')) {
          element = document.createElement('link');
          element.rel = 'stylesheet';
          element.href = environment.devUrlJSON['external.integration.questionario.adeguata.verifica'] + `/${filename}`;
        } else if (filename.endsWith('.js')) {
          element = document.createElement('script');
          element.src = environment.devUrlJSON['external.integration.questionario.adeguata.verifica'] + `/${filename}`;
        } else {
          subscriber.error(Error('Unexpected resource: ${filename}'));
          subscriber.complete();
        }
        element.addEventListener('load', () => {
          subscriber.next(true);
          subscriber.complete();
        });
        element.addEventListener('error', () => {
          subscriber.error(Error(`Couldn't load ${filename}`));
          subscriber.complete();
        });
        document.body.appendChild(element);
      }));
  }
}
