import { TestBed } from '@angular/core/testing';

import { ModulisticaPraticheService } from './modulistica-pratiche.service';

describe('ModulisticaPraticheService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ModulisticaPraticheService = TestBed.get(ModulisticaPraticheService);
    expect(service).toBeTruthy();
  });
});
