import { TestBed } from '@angular/core/testing';

import { ContrattoFideiussioneService } from './contratto-fideiussione.service';

describe('ContrattoFideiussioneService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ContrattoFideiussioneService = TestBed.get(ContrattoFideiussioneService);
    expect(service).toBeTruthy();
  });
});
