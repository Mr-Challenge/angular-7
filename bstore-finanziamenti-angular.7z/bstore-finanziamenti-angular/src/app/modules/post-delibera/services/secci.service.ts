import { Injectable } from '@angular/core';
import { EndpointsService } from 'src/app/services/endpoints.service';
import { CommonService } from 'src/app/services/common.service';
import { ContrattiSignatureType, RedirectService } from 'bstore-angular-library';
import { BaseClientModel } from '../../product-configuration/models/BaseClientModel';
import { MutuiDetailsModel } from '../../product-configuration/models/MutuiDetailsModel';
import { DocumentGeneration } from 'src/app/models/documentGeneration.model';
import { GenerateDoc, Secci, ContoAddebitoDetailsModel, DossierGeneration } from 'src/app/models/generateDoc.model';
import { TipoProcesso } from 'src/app/constant/tipoProcesso';
import { FinDocumentType } from 'src/app/constant/documentType';
import { SignatureStatusModel } from '../../vendita/models/signature-status.model';
import { ContrattiSignatureInput } from 'bstore-angular-library/lib/models/contrattiSignatureInput.model';

@Injectable({
  providedIn: 'root'
})
export class SecciService {

  constructor(private endpointsService: EndpointsService,
    private commonService: CommonService, private redirectService: RedirectService) { }

  goToGenerateSecci(idProposal: number, mainUser: BaseClientModel, intestatari: BaseClientModel[],
    jointHeading: BaseClientModel, fetchMutuoDetailsResponse: MutuiDetailsModel, garanti: BaseClientModel[],
    signatureStatusModel: SignatureStatusModel, dossierGenerationArr: DossierGeneration[],
    contrattiSignatureType: ContrattiSignatureType, contrattiSignatureInput: ContrattiSignatureInput) {
    const generateDoc = new GenerateDoc();
    generateDoc.processId = Number(idProposal);
    generateDoc.processType = TipoProcesso.VENDITA;
    generateDoc.callbackUrl = this.endpointsService.callbackToPostDelibera + idProposal;
    generateDoc.paramsGenerateEndpoint = {};
    const documentGenerationArr: DocumentGeneration[] = [];
    const docObj = new DocumentGeneration();
    docObj.documentType = FinDocumentType.SECCI_MUTUO;
    docObj.mainNdg = mainUser.ndg;
    docObj.signers = intestatari;
    documentGenerationArr.push(docObj);

    const secci = new Secci();
    secci.idProposta = generateDoc.processId;
    secci.idProdotto = fetchMutuoDetailsResponse.idProdotto;
    secci.idFics = fetchMutuoDetailsResponse.idFics;
    secci.customers = intestatari;
    secci.guarantors = garanti;
    secci.cointestazione = jointHeading;
    secci.perimeter = fetchMutuoDetailsResponse.perimeter;
    secci.idPef = fetchMutuoDetailsResponse.idPef;
    secci.amount = fetchMutuoDetailsResponse.amount;
    generateDoc.documentList = documentGenerationArr;
    generateDoc.paramsGenerateEndpoint = secci;
    generateDoc.generateEndpoint = this.endpointsService.generateSecciMutuoChiro;
    generateDoc.deliveredEndpoint = this.endpointsService.setDocumentsDelivered;
    // this.saveSecci(generateDoc, secci.idProposta);
    generateDoc.dossiers = dossierGenerationArr;
    this.commonService.saveInSession(generateDoc, signatureStatusModel, true, contrattiSignatureType, contrattiSignatureInput.isSignatureInProgress);

  }

  saveSecci(generateDoc, idProposal) {
    this.commonService.saveContrattiInputInSession(generateDoc).subscribe(response => {
      if (response) {
        const signatureStatus = new SignatureStatusModel();
        signatureStatus.processId = Number(idProposal);
        signatureStatus.processType = TipoProcesso.VENDITA;
        signatureStatus.docToGenerate = [FinDocumentType.SECCI_MUTUO];
        this.redirectService.redirectWithSpinner(this.endpointsService.openContratti
          + '/' + encodeURIComponent(JSON.stringify(signatureStatus)));
      }
    });
  }
}
