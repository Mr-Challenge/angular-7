import { Injectable } from '@angular/core';
import { DossierGeneration, GenerateDoc, OffertaVincolanteRicezione } from 'src/app/models/generateDoc.model';
import { TipoProcesso } from 'src/app/constant/tipoProcesso';
import { DocumentGeneration } from 'src/app/models/documentGeneration.model';
import { FinDocumentType } from 'src/app/constant/documentType';
import { SignatureStatusModel } from '../../vendita/models/signature-status.model';
import { EndpointsService } from 'src/app/services/endpoints.service';
import { CommonService } from 'src/app/services/common.service';
import { ContrattiSignatureType, RedirectService } from 'bstore-angular-library';
import { BaseClientModel } from '../../product-configuration/models/BaseClientModel';
import { MutuiDetailsModel } from '../../product-configuration/models/MutuiDetailsModel';
import { ContrattiSignatureInput } from 'bstore-angular-library/lib/models/contrattiSignatureInput.model';

@Injectable({
  providedIn: 'root'
})
export class OffertaVincolanteService {

  constructor(private endpointsService: EndpointsService,
    private commonService: CommonService, private redirectService: RedirectService) { }

  goToGenerateOffertaVincolanteRicezione(idProposal: string, mainUser: BaseClientModel, intestatari: BaseClientModel[],
    jointHeading: BaseClientModel, fetchMutuoDetailsResponse: MutuiDetailsModel, chirografario: boolean,
    signatureStatusModel: SignatureStatusModel, dossierGenerationArr: DossierGeneration[],
    contrattiSignatureType: ContrattiSignatureType, contrattiSignatureInput: ContrattiSignatureInput) {
    const generateDoc = new GenerateDoc();
    generateDoc.processId = Number(idProposal);
    generateDoc.processType = TipoProcesso.VENDITA;
    generateDoc.callbackUrl = this.endpointsService.callbackToPostDelibera + idProposal;
    generateDoc.paramsGenerateEndpoint = {};
    const documentGenerationArr: DocumentGeneration[] = [];
    const docObj = new DocumentGeneration();
    docObj.documentType = FinDocumentType.OFFERTA_VINCOLANTE_RICEZIONE;
    docObj.mainNdg = mainUser.ndg;
    docObj.signers = intestatari;
    docObj.onlyFeaSign = true;
    documentGenerationArr.push(docObj);
    const offertaVincolanteRicezione = new OffertaVincolanteRicezione();
    offertaVincolanteRicezione.cointestazione = jointHeading;
    offertaVincolanteRicezione.customers = intestatari;
    offertaVincolanteRicezione.dataScadenza = new Date();
    offertaVincolanteRicezione.durataMutuo = Number(fetchMutuoDetailsResponse.durata);
    offertaVincolanteRicezione.fondiario = true;
    offertaVincolanteRicezione.idProposta = generateDoc.processId;
    offertaVincolanteRicezione.importoMutuo = fetchMutuoDetailsResponse.amount;
    offertaVincolanteRicezione.tipoGaranzia = !chirografario ? 'I' : 'N';
    offertaVincolanteRicezione.usoAbitativo = true;
    generateDoc.documentList = documentGenerationArr;
    generateDoc.paramsGenerateEndpoint = offertaVincolanteRicezione;
    generateDoc.generateEndpoint = this.endpointsService.offertaVincolanteRicezioneEndPoint;
    generateDoc.deliveredEndpoint = this.endpointsService.setDocumentsDelivered;
    // this.saveOffertaVincolanteRicezioneGenDoc(generateDoc, idProposal);
    generateDoc.dossiers = dossierGenerationArr;
    this.commonService.saveInSession(generateDoc, signatureStatusModel, true, contrattiSignatureType, contrattiSignatureInput.isSignatureInProgress);
  }

  saveOffertaVincolanteRicezioneGenDoc(generateDoc, idProposal) {
    this.commonService.saveContrattiInputInSession(generateDoc).subscribe(() => {
      const signatureStatus = new SignatureStatusModel();
      signatureStatus.processId = Number(idProposal);
      signatureStatus.processType = TipoProcesso.VENDITA;
      signatureStatus.docToGenerate = [FinDocumentType.OFFERTA_VINCOLANTE_RICEZIONE];
      this.redirectService.redirectWithSpinner(this.endpointsService.openContratti + '/'
        + encodeURIComponent(JSON.stringify(signatureStatus)));
    });
  }

}
