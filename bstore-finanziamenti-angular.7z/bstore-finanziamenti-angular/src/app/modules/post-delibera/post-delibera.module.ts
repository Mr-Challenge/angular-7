import { APP_BASE_HREF, CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared.module';
import { BstoreCommonModule } from '../bstore-common/bstore-common.module';
import { ImmobileDetail } from '../immobili/models/immobiledetail.model';
import { ItalianCurrencyPipeSharedModule } from '../simulations/italianCurrencyPipeShared.modules';
import { ChatComponentComponent } from './components/chat-component/chat-component.component';
import { DatiStipulaGeneraliComponent } from './components/dati-stipula-erogazione/components/dati-stipula-generali/dati-stipula-generali.component';
import { DatiStipulaNotaioComponent } from './components/dati-stipula-erogazione/components/dati-stipula-notaio/dati-stipula-notaio.component';
import { DatiStipulaRichiedenteComponent } from './components/dati-stipula-erogazione/components/dati-stipula-richiedente/dati-stipula-richiedente.component';
import { DatiStipulaVenditoreComponent } from './components/dati-stipula-erogazione/components/dati-stipula-venditore/dati-stipula-venditore.component';
import { DatiStipulaErogazioneComponent } from './components/dati-stipula-erogazione/dati-stipula-erogazione.component';
import { DocumentazioneEventualeComponent } from './components/documenti-da-caricare/components/documentazione-eventuale/documentazione-eventuale.component';
import { DocumentazioneGenericaComponent } from './components/documenti-da-caricare/components/documentazione-generica/documentazione-generica.component';
import { DocumentiDaCaricareComponent } from './components/documenti-da-caricare/documenti-da-caricare.component';
import { FirmeComponent } from './components/firme/components/firme-section/firme.component';
import { GestionePerizieComponent } from './components/gestione-perizie/gestione-perizie.component';
import { GestionePolizzeComponent } from './components/gestione-polizze/gestione-polizze.component';
import { IngaggiaUfficioComponent } from './components/ingaggia-ufficio/ingaggia-ufficio.component';
import { PostDeliberaStartingPageComponent } from './components/post-delibera-starting-page/post-delibera-starting-page.component';
import { QuestionarioAdeguataVerificaComponent } from './components/questionario-adeguata-verifica/questionario-adeguata-verifica.component';
import { QuestionarioAdeguataComponent } from './components/questionario-adeguata/questionario-adeguata.component';
import { PostDeliberaRoutingModule } from './post-delibera-routing.module';
import { QuestionarioAdeguataVerificaIntegrationService } from './services/questionario-adeguata-verifica-integration.service';
import { PostDeliberaDettaglioImmobileComponent } from './components/post-delibera-dettaglio-immobile/post-delibera-dettaglio-immobile.component';
import { DemoPostDeliberaStartingPageComponent } from './components/demo-post-delibera-starting-page/demo-post-delibera-starting-page.component';
import { DocumentazioneCommonComponent } from './components/documenti-da-caricare/components/documentazione-common/documentazione-common.component';
import { GestionePolizzeChiroComponent } from './components/gestione-polizze-chiro/gestione-polizze-chiro.component';
import { StampaErogaChiroComponent } from './components/stampa-eroga-chiro/stampa-eroga-chiro.component';
import { ContrattoFideiussioneBoxComponent } from './components/contratto-fideiussione-box/contratto-fideiussione-box.component';
@NgModule({
  declarations: [
    PostDeliberaStartingPageComponent,
    QuestionarioAdeguataVerificaComponent,
    GestionePerizieComponent,
    GestionePolizzeComponent,
    GestionePolizzeChiroComponent,
    StampaErogaChiroComponent,
    DatiStipulaErogazioneComponent,
    DocumentiDaCaricareComponent,
    DatiStipulaGeneraliComponent,
    DatiStipulaRichiedenteComponent,
    DatiStipulaVenditoreComponent,
    DatiStipulaNotaioComponent,
    DocumentazioneGenericaComponent,
    DocumentazioneEventualeComponent,
    QuestionarioAdeguataComponent,
    QuestionarioAdeguataVerificaComponent,
    IngaggiaUfficioComponent,
    ChatComponentComponent,
    FirmeComponent,
    PostDeliberaDettaglioImmobileComponent,
    DemoPostDeliberaStartingPageComponent,
    DocumentazioneCommonComponent,
    ContrattoFideiussioneBoxComponent
  ],
  imports: [
    CommonModule,
    BstoreCommonModule,
    PostDeliberaRoutingModule,
    HttpClientModule,
    SharedModule,
    ItalianCurrencyPipeSharedModule
  ],
  providers: [
    QuestionarioAdeguataVerificaIntegrationService,
    ImmobileDetail,
    {
      provide: APP_BASE_HREF,
      useFactory: () => window['bstoreAppPath'] || null
    }
  ],
  entryComponents: [
    QuestionarioAdeguataComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PostDeliberaModule { }
