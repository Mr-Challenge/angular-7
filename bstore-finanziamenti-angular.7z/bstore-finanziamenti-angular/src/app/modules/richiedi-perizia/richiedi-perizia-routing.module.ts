import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RichiediPeriziaPageComponent } from './components/richiedi-perizia-page/richiedi-perizia-page.component';


const routes: Routes = [
  { path: '', component: RichiediPeriziaPageComponent },
  { path: ':proposalId/:codiceImmobile', component: RichiediPeriziaPageComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RichiediPeriziaRoutingModule { }
