import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BstoreAngularLibraryModule } from 'bstore-angular-library';
import { RichiediPeriziaRoutingModule } from './richiedi-perizia-routing.module';

import { BstoreCommonModule } from '../bstore-common/bstore-common.module';
import { RichiediPeriziaPageComponent } from './components/richiedi-perizia-page/richiedi-perizia-page.component';
@NgModule({
  declarations: [RichiediPeriziaPageComponent],
  imports: [
    CommonModule,
    RichiediPeriziaRoutingModule,
    BstoreAngularLibraryModule,
    BstoreCommonModule
  ]
})
export class RichiediPeriziaModule { }
