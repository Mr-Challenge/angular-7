import { RichiestaPeriziaProcessStatus } from './richiestaPeriziaProcessStatus';

export class CreaNuovaRichiestaPeriziaOutput {

    tipologiaPerizia?: string[];
    tipoPerito?: string[];
    provider?: string[];
    sessionId?: string;

    richiestaPeriziaProcessStatus: RichiestaPeriziaProcessStatus;
}
