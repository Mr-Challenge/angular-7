import { DocumentiPerizia } from './documentiPerizia.model';

export class ConfermaRichiestaPeriziaInput {

    sessionId?: string;
    idRichiestaPerizia?: string;
    flagConfermaAnnulla?: boolean;
    documentiPeriziaList?: DocumentiPerizia[];
    codiceImmobile?: string;
    idProposta?: number;
}
