import { BaseClientModel } from '../../product-configuration/models/BaseClientModel';
import { RichiestaPeriziaProcessStatus } from './richiestaPeriziaProcessStatus';

export class CreaNuovaRichiestaPeriziaInput {
    idProposta?: number;
    codiceImmobile?: string;
    clients?: BaseClientModel[];
    flagLegge32?: boolean;
    flagImmobileAsta?: boolean;
    flagSALFiglio?: boolean;
    flagSALPadre?: boolean;
    richiestaPeriziaProcessStatus: RichiestaPeriziaProcessStatus;
    flagDipendente?: boolean;
}
