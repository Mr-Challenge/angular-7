export class DocumentiPerizia {

    flagObbligatorio?: boolean;
    downloadUpload?: string;
    idDoc?: string;
    descrizione?: string;
    idFileNet?: string;
    classeDocumentale?: string;
    linkFileNet?: string;
    obbligatorio?: string;
    operativita?: string;
    showUpload: boolean = true;
    flagDownloadUpload: any;
}


