import { DocumentiPerizia } from './documentiPerizia.model';
import { BaseClientModel } from '../../product-configuration/models/BaseClientModel';

export class ChecklistInput {
    clientList?: BaseClientModel[];
    idProposta?: string;
    documentiPeriziaVm?: DocumentiPerizia[];
    generated: boolean;
    idPerizia: string;
}
