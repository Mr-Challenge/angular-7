import { Contact } from './contact.model';
import { RichiestaPeriziaProcessStatus } from './richiestaPeriziaProcessStatus';

export class ConfermaDatiPeriziaInput {
    mattina?: boolean;
    pranzo?: boolean;
    pomeriggio?: boolean;
    sera?: boolean;
    contactVm?: Contact[];
    tipoPerizia?: string;
    tipoPerito: string;
    provider?: string;
    sessionId?: string;

    codiceImmobile: string;

    richiestaPeriziaProcessStatus: RichiestaPeriziaProcessStatus;

}
