export class Contact {

  ndg: string;
  tipoContatto: string;
  nome: string;
  cognome: string;
  telefono1: string;
  telefono2: string;
  email: string;
  flagProprietario: boolean;
  flagClienteBanca: boolean;
}
