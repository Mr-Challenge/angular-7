import { PeriziaProcessStatus } from './periziaProcessStatus';

export class RichiestaPeriziaProcessStatus {

    sessionId?: string;
    idRichiestaPerizia?: number;
    idPerizia?: number;
    status?: PeriziaProcessStatus;
}
