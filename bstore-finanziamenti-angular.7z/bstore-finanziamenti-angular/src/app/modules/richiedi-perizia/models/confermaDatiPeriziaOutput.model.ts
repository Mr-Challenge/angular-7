import { DocumentiPerizia } from './documentiPerizia.model';
import { BperTwainDocDaAcquisireVm } from 'src/app/models/bperTwainDocDaAcquisire.model';

export class ConfermaDatiPeriziaOutput {
    flagDocCrif?: boolean;
    idRichiestaPerizia?: string;
    documentiPeriziaVm?: DocumentiPerizia[];

    docDaAcquisire?: BperTwainDocDaAcquisireVm[];
}
