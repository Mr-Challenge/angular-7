import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BpertwainUtilsService, CommonPopupComponent, DialogService, NpvErrorServiceService, OpenPdfUrlService } from 'bstore-angular-library';
import { ErrorMessageModel } from 'bstore-angular-library/lib/models/error-message-model';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { LogDetailsModel } from 'bstore-angular-library/lib/models/log-details-model';
import { SelectOptionModel } from 'bstore-angular-library/lib/models/select-option-model';
import { StaticDocs } from 'src/app/constant/staticDocs';
import { EsitoPeriziaComponent } from 'src/app/modules/immobili/components/esito-perizia/esito-perizia.component';
import { EsitoRichiestaPeriziaComponent } from 'src/app/modules/immobili/components/esito-richiesta-perizia/esito-richiesta-perizia.component';
import { InviaPeriziaComponent } from 'src/app/modules/immobili/components/invia-perizia/invia-perizia.component';
import { UploadDocumentComponent } from 'src/app/modules/immobili/components/upload-document/upload-document.component';
import { ImmobiliService } from 'src/app/modules/immobili/services/immobili-service';
import { BaseClientModel } from 'src/app/modules/product-configuration/models/BaseClientModel';
import { CommonService } from 'src/app/services/common.service';
import { environment } from 'src/environments/environment';
import { ChecklistInput } from '../../models/checklistInput.model';
import { ConfermaDatiPeriziaInput } from '../../models/confermaDatiPeriziaInput.model';
import { ConfermaDatiPeriziaOutput } from '../../models/confermaDatiPeriziaOutput.model';
import { ConfermaRichiestaPeriziaInput } from '../../models/confermaRichiestaPeriziaInput.model';
import { Contact } from '../../models/contact.model';
import { CreaNuovaRichiestaPeriziaInput } from '../../models/creaNuovaRichiestaPeriziaInput.model';
import { CreaNuovaRichiestaPeriziaOutput } from '../../models/creaNuovaRichiestaPeriziaOutput.model';
import { DocumentiPerizia } from '../../models/documentiPerizia.model';
import { PeriziaProcessStatus } from '../../models/periziaProcessStatus';
import { RichiestaPeriziaProcessStatus } from '../../models/richiestaPeriziaProcessStatus';
import { PeriziaService } from '../../services/perizia.service';
@Component({
  selector: 'bst-fin-richiedi-perizia-page',
  templateUrl: './richiedi-perizia-page.component.html',
  styleUrls: ['./richiedi-perizia-page.component.scss']
})
export class RichiediPeriziaPageComponent implements OnInit {

  inviaPeriziaEvents: EventsModel[] = [];
  aggiungiEvents: EventsModel[] = [];
  contactsToSave: Contact[] = [];
  aggiungiArray: Contact[] = [];
  ruolo1: string;
  ruolo2: string;
  Nome: string;
  ndg: string;
  cognome: string;
  telefonoPrincipale: string;
  telefonoSecondario: string;
  Email: string;
  salvabuttonEvents: EventsModel[] = [];
  flag: string;
  status: boolean;
  tipologiaPeriziaSelect: SelectOptionModel[] = [];
  tipoPeritoSelect: SelectOptionModel[] = [];
  providerSelect: SelectOptionModel[] = [];
  tipologiaPerizia: string;
  tipoPerito: string;
  provider: string;
  confermaDatiPeriziaInput: ConfermaDatiPeriziaInput;
  confermaDatiPeriziaOutput: ConfermaDatiPeriziaOutput;
  confermaRichiestaPeriziaInput: ConfermaRichiestaPeriziaInput;
  documentiPeriziaList: DocumentiPerizia[] = [];
  creaNuovaRichiestaPeriziaOutput: CreaNuovaRichiestaPeriziaOutput;
  proposalId: any;
  codiceImmobile: string;
  ClientBaseList: BaseClientModel[] = [];
  creaNuovaRichiestaPeriziaInput: CreaNuovaRichiestaPeriziaInput;
  flagImmobileAsta: boolean;
  flagSALPadre: boolean;
  question8BooleanAnswer: boolean;
  stampaMandatoEvent: EventsModel[] = [];
  telefonoPricipaleFlag: boolean;
  mattina: boolean;
  pranzo: boolean;
  pranzoRequired: boolean;
  pomeriggio: boolean;
  pomeriggioRequired: boolean;
  sera: boolean;
  seraRequired: boolean;
  disableSalva = true;
  checkBoxEvent: EventsModel[] = [];
  telefonoPrincipaleEvent: EventsModel[] = [];
  dynamicFieldEvent: EventsModel[] = [];
  sezioneDocumenti: any;
  sessionId: string;
  richiestaPeriziaProcessStatus: RichiestaPeriziaProcessStatus;
  idPerizia: Number;
  indexNumber: number;
  uploadOrDeleteFile: boolean;
  contactEvent: EventsModel[] = [];
  callbackUrl: string;
  isDocumentsUploaded: boolean;
  listaProprietari: any;
  dynamicFieldFlag = true;
  statoPerizia: string;
  generateDocumentEvent: EventsModel[] = [];
  disableConferma = true;
  urlList = [];
  logDetailsModel: LogDetailsModel = {};
  domainName = environment.devUrlJSON['npv.service.callback.url'];
  isDipendente: boolean;

  @ViewChild(CommonPopupComponent) commonPopupComponent: CommonPopupComponent;

  constructor(private bpertwainUtils: BpertwainUtilsService, private commonService: CommonService,
    private dialog: DialogService, private periziaService: PeriziaService, private immobiliService: ImmobiliService,
    private route: ActivatedRoute, private openPdfUrlService: OpenPdfUrlService,
    private router: Router, private errorService: NpvErrorServiceService) {

    this.route.params.subscribe(params => {
      this.proposalId = params['proposalId'];
      this.codiceImmobile = params['codiceImmobile'];
    });

    this.route.queryParams.subscribe(params => {
      this.callbackUrl = params['callBackUrl'];
      this.statoPerizia = params['statoPerizia'];
      this.isDipendente = params['convDipendenti'] === 'true';
    });
  }

  ngOnInit() {
    if (this.proposalId) {
      this.logDetailsModel.numeroPropostaVenditaOPV = this.proposalId;
    } else {
      this.logDetailsModel.section = 'Perizia';
    }

    this.immobiliService.getImmobiliDetails(this.codiceImmobile).subscribe(data => {
      this.listaProprietari = data.listaProprietari;
    });

    this.mattina = false;
    this.pranzo = false;
    this.pomeriggio = false;
    this.sera = false;

    this.inviaPeriziaEvents = [
      { eventName: 'click', eventCallBack: this.openPopup.bind(this) }
    ];

    this.salvabuttonEvents = [
      { eventName: 'click', eventCallBack: this.showSalvaPopup.bind(this) }
    ];

    this.aggiungiEvents = [
      { eventName: 'click', eventCallBack: this.addRowFunction.bind(this) }
    ];

    this.stampaMandatoEvent = [
      { eventName: 'click', eventCallBack: this.openDocument.bind(this) }
    ];

    this.checkBoxEvent = [
      { eventName: 'change', eventCallBack: this.validationCheckBox.bind(this) }
    ];

    this.telefonoPrincipaleEvent = [
      { eventName: 'blur', eventCallBack: this.telefonoPrincipaleValidation.bind(this) }
    ];

    this.contactEvent = [
      { eventName: 'blur', eventCallBack: this.emailValidation.bind(this) }
    ];

    this.dynamicFieldEvent = [
      { eventName: 'keyup', eventCallBack: this.dynamicFieldValidation.bind(this) }
    ];

    this.generateDocumentEvent = [
      { eventName: 'click', eventCallBack: this.generateDocument.bind(this) }
    ];

    this.ruolo1 = 'Richiedente Principale';
    this.ruolo2 = 'Contatto';
    this.confermaDatiPeriziaInput = new ConfermaDatiPeriziaInput();
    this.confermaRichiestaPeriziaInput = new ConfermaRichiestaPeriziaInput();
    this.creaNuovaRichiestaPeriziaOutput = new CreaNuovaRichiestaPeriziaOutput();

    this.telefonoPricipaleFlag = true;

    this.retrieveAllClient();

  }

  openPopup() {
    const ref = this.dialog.open(InviaPeriziaComponent, {
      title: 'INVIA PERIZIA'
    });
    ref.afterClosed.subscribe(result => {
      const msg: string = result;
      if (msg === 'ok') {
        this.archiveDocs();
      }
    });
  }

  archiveDocs() {
    if (this.isDocumentsUploaded) {
      this.showInviaPeriziaPopup();
    } else {
      const successFunction = (archivedDocumentResult) => {
        console.log('from archived success callback - archivedDocumentResult2', archivedDocumentResult);
        // Input for documenti perizia
        this.confermaRichiestaPeriziaInput.documentiPeriziaList = [];
        archivedDocumentResult.forEach(document => {
          const doc = new DocumentiPerizia();
          doc.idFileNet = document.documentId;
          doc.linkFileNet = document.url;
          doc.descrizione = document.acquireResult.fileName;
          doc.idDoc = document.documentData.idDocumento;
          if (!doc.idDoc) {
            const error: ErrorMessageModel = {
              message: 'id documento mancante',
              details: [
                {
                  code: 'ng',
                  message: 'document: ' + JSON.stringify(doc)
                }
              ]
            };
            this.errorService.openErrorPopup(error);
          }
          this.confermaRichiestaPeriziaInput.documentiPeriziaList.push(doc);
        });
        this.isDocumentsUploaded = true;
        this.showInviaPeriziaPopup();
      };
      const errorFunction = (errorData) => {
        this.isDocumentsUploaded = false;
        console.log('from archive error callback', errorData);
      };
      this.bpertwainUtils.documentArchive(successFunction, errorFunction, environment.bperTwainMock, this.domainName, this.logDetailsModel);
    }
  }

  /* open Popup on click of Conferma button */
  showInviaPeriziaPopup() {
    this.confermaRichiestaPeriziaInput.sessionId = this.sessionId;
    this.confermaRichiestaPeriziaInput.idRichiestaPerizia = this.confermaDatiPeriziaOutput.idRichiestaPerizia;
    this.confermaRichiestaPeriziaInput.flagConfermaAnnulla = true;
    this.confermaRichiestaPeriziaInput.codiceImmobile = this.codiceImmobile;
    this.confermaRichiestaPeriziaInput.idProposta = this.proposalId;

    this.confermaRichiestaPerizia(this.confermaRichiestaPeriziaInput);
  }

  uploadDoc(event, index) {
    this.indexNumber = index;
    this.uploadOrDeleteFile = true;
    this.documentUploadFunction(event, index);
  }

  removeDoc(event, index) {
    this.indexNumber = index;
    this.uploadOrDeleteFile = false;
    for (let i = 0; i <= this.documentiPeriziaList.length; i++) {
      if (i === this.indexNumber && !this.uploadOrDeleteFile) {
        this.documentiPeriziaList[i].showUpload = true;
      }
    }
  }

  documentUploadFunction(event, index) {
    const successFunction = (archivedDocumentResult) => {
      console.log('from acquired success callback', archivedDocumentResult);
      for (let i = 0; i <= this.documentiPeriziaList.length; i++) {
        if (i === this.indexNumber && this.uploadOrDeleteFile) {
          this.documentiPeriziaList[i].showUpload = false;
        }
      }
      this.isDocumentsUploaded = false;
    };
    const errorFunction = (errorData) => {
      console.log('from acquired error callback', errorData);
    };

    this.bpertwainUtils.handleFileSelect(event, this.sezioneDocumenti[index], successFunction, errorFunction, environment.bperTwainMock);
    const ref = this.dialog.open(UploadDocumentComponent, {

    });
    ref.afterClosed.subscribe(result => {
      const msg: string = result;
      if (msg === 'closed') {
        this.uploadOrDeleteFile = false;
        for (let i = 0; i <= this.documentiPeriziaList.length; i++) {
          if (i === this.indexNumber && !this.uploadOrDeleteFile) {
            this.documentiPeriziaList[i].showUpload = true;
          }
        }
      }
    });
  }

  confermaRichiestaPerizia(confermaRichiestaPeriziaInput: ConfermaRichiestaPeriziaInput) {
    this.periziaService.confermaRichiestaPerizia(confermaRichiestaPeriziaInput).subscribe(response => {
      this.idPerizia = response;
      if (this.idPerizia !== undefined) {
        this.dialog.open(EsitoRichiestaPeriziaComponent, {
          title: 'Info',
          data: { id: this.idPerizia, proposalId: this.proposalId, callbackUrl: this.callbackUrl }
        });
      }
    }, (err) => {
      console.log('error from conferma service', err);
      console.log('Error occured in confermaRichiestaPerizia service call');
    });
  }

  // Open Popup on Click of SALVA button
  showSalvaPopup() {
    this.confermaDatiPeriziaInput.mattina = this.mattina;
    this.confermaDatiPeriziaInput.pranzo = this.pranzo;
    this.confermaDatiPeriziaInput.pomeriggio = this.pomeriggio;
    this.confermaDatiPeriziaInput.sera = this.sera;
    const contact = new Contact();

    contact.ndg = this.ndg;
    contact.nome = this.Nome;
    contact.cognome = this.cognome;
    contact.email = this.Email;
    contact.telefono1 = this.telefonoPrincipale;
    contact.telefono2 = this.telefonoSecondario;
    contact.tipoContatto = this.ruolo1;

    contact.flagProprietario = true;
    contact.flagClienteBanca = true;

    this.contactsToSave = [];
    this.contactsToSave.push(contact);

    for (let index = 0; index < this.aggiungiArray.length; index++) {
      const element = this.aggiungiArray[index];
      const contact1 = new Contact();
      contact1.ndg = element.ndg;

      contact1.flagProprietario = false;
      contact1.flagClienteBanca = false;

      contact1.nome = element.nome;
      contact1.cognome = element.cognome;
      contact1.email = element.email;
      contact1.telefono1 = element.telefono1;
      contact1.telefono2 = element.telefono2;
      contact1.tipoContatto = this.ruolo2;
      this.contactsToSave.push(contact1);
    }
    this.confermaDatiPeriziaInput.contactVm = this.contactsToSave;
    this.confermaDatiPeriziaInput.tipoPerizia = this.tipologiaPerizia;
    this.confermaDatiPeriziaInput.tipoPerito = this.tipoPerito;
    this.confermaDatiPeriziaInput.provider = this.provider;
    this.confermaDatiPeriziaInput.sessionId = this.sessionId;

    this.confermaDatiPeriziaInput.codiceImmobile = this.codiceImmobile;
    this.confermaDatiPeriziaInput.richiestaPeriziaProcessStatus = this.richiestaPeriziaProcessStatus;
    this.confermaDatiPerizia();
  }

  confermaDatiPerizia() {
    this.periziaService.confermaDatiPerizia(this.confermaDatiPeriziaInput).subscribe(data => {
      this.confermaDatiPeriziaOutput = data;

      this.sezioneDocumenti = this.confermaDatiPeriziaOutput.docDaAcquisire;

      this.documentiPeriziaList = [];
      this.confermaDatiPeriziaOutput.documentiPeriziaVm.forEach(element => {
        const documentiPeriziaObj = new DocumentiPerizia();
        documentiPeriziaObj.descrizione = element.descrizione;
        if (element.flagObbligatorio) {
          documentiPeriziaObj.obbligatorio = 'Obbligatorio';
          documentiPeriziaObj.operativita = 'allegare il file richiesto';
        } else {
          documentiPeriziaObj.obbligatorio = 'Facoltativo';
          documentiPeriziaObj.operativita = 'allegare il file se richiesto';
        }
        documentiPeriziaObj.downloadUpload = element.downloadUpload;
        documentiPeriziaObj.idDoc = element.idDoc;

        this.documentiPeriziaList.push(documentiPeriziaObj);
      });

      if (this.richiestaPeriziaProcessStatus.status !== PeriziaProcessStatus.DATA_CONFIRMED) {
        this.openSalvaPopup();
      }
      this.disableSalva = true;
      this.commonPopupComponent.createObserver();
    });
  }

  openSalvaPopup() {
    if (this.confermaDatiPeriziaOutput.idRichiestaPerizia !== undefined) {
      this.dialog.open(EsitoPeriziaComponent, {
        title: 'Info',
        data: { id: this.confermaDatiPeriziaOutput.idRichiestaPerizia }
      });
    }
  }

  /* Add new row */
  addRowFunction(input, event) {
    const contact = new Contact();
    contact.nome = '';
    contact.cognome = '';
    contact.email = '';
    contact.telefono1 = '';
    contact.telefono2 = '';
    this.aggiungiArray.push(contact);

    this.dynamicFieldFlag = false;

    this.requiredFieldValidation();
  }

  /* Delete row using trash icon */
  deleteRow(index) {
    this.aggiungiArray.splice(index, 1);

    if (this.aggiungiArray.length == 0) {
      this.dynamicFieldFlag = true;
      this.requiredFieldValidation();
    }
  }

  openDocument(event) {
    this.disableConferma = false;
    const documentKeys = [];
    let urlList = [];
    documentKeys.push(StaticDocs.CHECKLIST_CRIF);
    documentKeys.push(StaticDocs.MANDATO_CRIF);
    this.commonService.getListStaticDocumentsByKey(documentKeys).subscribe(response => {
      urlList = response;
      this.openPdfUrlService.openPdfDocuments(urlList);
    },
      error => {
        console.log('error while opening document');
      });
  }

  generateDocument() {
    const listNdg: string[] = [];

    if (this.urlList.length > 0) {
      this.openPdfUrlService.openPdfDocuments(this.urlList);
    } else {
      const checkListInput: ChecklistInput = new ChecklistInput();
      if (this.ClientBaseList == null) {
        this.retrieveAllClient();
      }
      checkListInput.clientList = this.ClientBaseList;
      checkListInput.idProposta = this.proposalId;
      checkListInput.idPerizia = this.confermaDatiPeriziaOutput.idRichiestaPerizia;
      checkListInput.documentiPeriziaVm = this.confermaDatiPeriziaOutput.documentiPeriziaVm;
      this.periziaService.getListGeneratedDocuments(checkListInput).subscribe(response => {
        this.disableConferma = false;
        this.urlList = response;
        this.openPdfUrlService.openPdfDocuments(this.urlList);
      },
        error => {
          console.log('error while opening document');
        });
    }
  }

  retrieveAllClient() {
    this.commonService.retrieveAllClient(this.proposalId).
      subscribe(response => {
        this.ClientBaseList = response;
        this.getRichiestaPeriziaProcessStatus();
        this.fillClientData();
      }, error => {
        console.log('Error occured in retrieveAllClient service call');
      }, () => {
        console.log(this.ClientBaseList);
      });
  }

  getRichiestaPeriziaProcessStatus() {
    this.periziaService.getRichiestaPeriziaProcessStatus(this.codiceImmobile, this.statoPerizia).subscribe(
      response => {
        this.richiestaPeriziaProcessStatus = response;
        this.creaNuovaRichiestaPerizia();
      }, () => {
        console.log('Error occured in getRichiestaPeriziaProcessStatus service call');
      });
  }

  creaNuovaRichiestaPerizia() {
    const creaNuovaRichiestaPeriziaInput = new CreaNuovaRichiestaPeriziaInput();
    creaNuovaRichiestaPeriziaInput.codiceImmobile = this.codiceImmobile;
    creaNuovaRichiestaPeriziaInput.clients = this.ClientBaseList;
    creaNuovaRichiestaPeriziaInput.idProposta = this.proposalId;
    creaNuovaRichiestaPeriziaInput.flagImmobileAsta = false;
    creaNuovaRichiestaPeriziaInput.flagLegge32 = this.question8BooleanAnswer;
    creaNuovaRichiestaPeriziaInput.flagSALFiglio = false;
    creaNuovaRichiestaPeriziaInput.flagSALPadre = false;
    creaNuovaRichiestaPeriziaInput.richiestaPeriziaProcessStatus = this.richiestaPeriziaProcessStatus;
    creaNuovaRichiestaPeriziaInput.flagDipendente = this.isDipendente;
    this.periziaService.creaNuovaRichiestaPerizia(creaNuovaRichiestaPeriziaInput).subscribe(
      response => {
        this.creaNuovaRichiestaPeriziaOutput = response;
        this.setDatiDiRichiesta(this.creaNuovaRichiestaPeriziaOutput);

        if (this.richiestaPeriziaProcessStatus.status === PeriziaProcessStatus.DATA_CONFIRMED) {
          this.disableSalva = true;
          this.showSalvaPopup();
        }

      }, () => {
        this.requiredFieldValidation();
        console.log('Error occured in creaNuovaRichiestaPerizia service call');
      }, () => {
        this.requiredFieldValidation();
      });
  }

  /* This method is setting Tipologia Periza ,Tipo Perito,Provide dropdownList value in Richiedi Perizia Page */
  setDatiDiRichiesta(creaNuovaRichiestaPeriziaOutput: CreaNuovaRichiestaPeriziaOutput) {

    this.tipologiaPeriziaSelect = creaNuovaRichiestaPeriziaOutput.tipologiaPerizia.reduce((temp, e) => {
      if (e != null) {
        temp.push({ 'description': e, 'value': e });
      }
      return temp;
    }, []);

    console.log(this.tipologiaPeriziaSelect[0]);

    this.tipologiaPerizia = this.tipologiaPeriziaSelect[0].value;

    this.tipoPeritoSelect = creaNuovaRichiestaPeriziaOutput.tipoPerito.reduce((temp, e) => {
      if (e != null) {
        temp.push({ 'description': e, 'value': e });
      }
      return temp;
    }, []);

    this.tipoPerito = this.tipoPeritoSelect[0].value;

    this.providerSelect = creaNuovaRichiestaPeriziaOutput.provider.reduce((temp, e) => {
      if (e != null) {
        temp.push({ 'description': e, 'value': e });
      }
      return temp;
    }, []);

    this.provider = this.providerSelect[0].value;
    this.sessionId = creaNuovaRichiestaPeriziaOutput.sessionId;
  }

  fillClientData() {
    this.ndg = this.ClientBaseList[0].ndg;
    this.Nome = this.ClientBaseList[0].name;
    this.telefonoPrincipale = this.ClientBaseList[0].phone;
    this.cognome = this.ClientBaseList[0].surname;
    this.telefonoSecondario = this.ClientBaseList[0].phone;

    if (this.ClientBaseList[0].emailOtp === '') {
      if (this.ClientBaseList[0].email) {
        this.Email = this.ClientBaseList[0].email.toLowerCase();
      }
    } else {
      this.Email = this.ClientBaseList[0].emailOtp.toLowerCase();
    }
  }

  validationCheckBox(input, event) {
    this.requiredFieldValidation();
  }

  dynamicFieldValidation() {

    let nomi = 0;
    let cognomi = 0;
    let telefoni = 0;

    for (let i = 0; i < this.aggiungiArray.length; i++) {

      const element = this.aggiungiArray[i];

      if (element.nome) {
        if (element.nome.length > 0) {
          nomi++;
        }
      }
      if (element.cognome) {
        if (element.cognome.length > 0) {
          cognomi++;
        }
      }

      if (element.telefono1) {
        if (element.telefono1.length > 0) {
          telefoni++;
        }
      }
    }

    if (nomi === this.aggiungiArray.length && cognomi === this.aggiungiArray.length && telefoni === this.aggiungiArray.length) {
      this.dynamicFieldFlag = true;
    } else {
      this.dynamicFieldFlag = false;
    }

    this.requiredFieldValidation();
  }

  telefonoPrincipaleValidation() {
    if (this.telefonoPrincipale) {
      this.telefonoPricipaleFlag = true;
    } else {
      this.telefonoPricipaleFlag = false;
    }
    this.requiredFieldValidation();
  }

  requiredFieldValidation() {
    if ((this.telefonoPricipaleFlag) && this.tipologiaPerizia !== undefined &&
      this.tipoPerito !== undefined && this.provider !== undefined && this.dynamicFieldFlag) {
      this.disableSalva = false;
    } else {
      this.disableSalva = true;
    }
  }

  emailValidation() {
    this.disableSalva = false;
    for (let index = 0; index < this.aggiungiArray.length; index++) {
      const element = this.aggiungiArray[index];
      if (element.email && this.checkEmailIdPattern(element.email)) {
        this.disableSalva = true;
        break;
      }
    }
    if (this.Email && this.checkEmailIdPattern(this.Email)) {
      this.disableSalva = true;
    }
    if (!this.disableSalva) {
      this.requiredFieldValidation();
    }

  }

  checkEmailIdPattern(emailId): boolean {
    const pattern = /^$|^(?!.{59})([a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)$/;
    if (emailId && pattern.test(emailId) === false) {
      return true;
    }
    return false;
  }

  goBack() {
    this.router.navigate([this.callbackUrl, this.proposalId]);
  }
}
