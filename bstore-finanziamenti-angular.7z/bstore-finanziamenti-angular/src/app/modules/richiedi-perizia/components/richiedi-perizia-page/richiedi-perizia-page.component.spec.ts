import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RichiediPeriziaPageComponent } from './richiedi-perizia-page.component';

describe('RichiediPeriziaPageComponent', () => {
  let component: RichiediPeriziaPageComponent;
  let fixture: ComponentFixture<RichiediPeriziaPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RichiediPeriziaPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RichiediPeriziaPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
