import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EndpointsService } from 'src/app/services/endpoints.service';
import { environment } from 'src/environments/environment';
import { ChecklistInput } from '../models/checklistInput.model';
import { ConfermaDatiPeriziaInput } from '../models/confermaDatiPeriziaInput.model';
import { ConfermaDatiPeriziaOutput } from '../models/confermaDatiPeriziaOutput.model';
import { ConfermaRichiestaPeriziaInput } from '../models/confermaRichiestaPeriziaInput.model';
import { CreaNuovaRichiestaPeriziaInput } from '../models/creaNuovaRichiestaPeriziaInput.model';
import { CreaNuovaRichiestaPeriziaOutput } from '../models/creaNuovaRichiestaPeriziaOutput.model';
import { RichiestaPeriziaProcessStatus } from '../models/richiestaPeriziaProcessStatus';

@Injectable({
  providedIn: 'root'
})
export class PeriziaService {

  constructor(private httpClient: HttpClient,
    private endpointsService: EndpointsService) { }

  /* real service call for confermaDatiPerizia*/
  confermaDatiPerizia(confermaDatiPeriziaInput: ConfermaDatiPeriziaInput): Observable<ConfermaDatiPeriziaOutput> {
    return this.httpClient.post<ConfermaDatiPeriziaOutput>(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/confermaDatiPerizia`, confermaDatiPeriziaInput);
  }

  /* real service call for confermaRichiestaPerizia*/
  confermaRichiestaPerizia(confermaRichiestaPeriziaInput: ConfermaRichiestaPeriziaInput): Observable<Number> {
    return this.httpClient.post<Number>(this.endpointsService.confermaRichiestaPerizia, confermaRichiestaPeriziaInput);
  }

  getListGeneratedDocuments(data: ChecklistInput) {
    // modificare l'url del servizio da chiamare, sostituire /api/getListStaticDocuments con il nuovo RequestMapping
    return this.httpClient.post<String[]>(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/generateChecklistDocument`, data);
  }

  /* real service call for creaNuovaRichiestaPerizia*/
  creaNuovaRichiestaPerizia(creaNuovaRichiestaPeriziaInput: CreaNuovaRichiestaPeriziaInput): Observable<any> {
    return this.httpClient.post<CreaNuovaRichiestaPeriziaOutput>
      (`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/creaNuovaRichiestaPerizia`, creaNuovaRichiestaPeriziaInput);
  }

  getRichiestaPeriziaProcessStatus(codiceImmobile: string, statoPerizia: string) {
    const params = new HttpParams();
    const parameters = params.append('codiceImmobile', codiceImmobile).append('statoPerizia', statoPerizia);
    return this.httpClient.get<RichiestaPeriziaProcessStatus>(`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}`
      + '/api/getRichiestaPeriziaProcessStatus', { params: parameters });
  }

  /* real service call for convenzioneDipendenti*/
  checkForConvenzioneDipendenti(listaProprietari: any): Observable<any> {
    return this.httpClient.post<any>
      (`${environment.devUrlJSON['bstore.finanziamenti.frontend.url']}/api/checkForConvenzioneDipendenti`, listaProprietari);
  }

}
