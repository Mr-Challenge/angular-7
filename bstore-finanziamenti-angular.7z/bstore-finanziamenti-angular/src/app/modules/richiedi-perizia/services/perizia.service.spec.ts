import { TestBed } from '@angular/core/testing';

import { PeriziaService } from './perizia.service';

describe('PeriziaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PeriziaService = TestBed.get(PeriziaService);
    expect(service).toBeTruthy();
  });
});
