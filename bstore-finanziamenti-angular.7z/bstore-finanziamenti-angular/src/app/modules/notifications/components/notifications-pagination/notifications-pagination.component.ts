import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { PaginationService } from '../../services/pagination.service';
import { NotificationsService } from '../../services/notifications.service';
import { MutuiNotification } from '../../models/mutuiNotification';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'bst-fin-notifications-pagination',
  templateUrl: './notifications-pagination.component.html',
  styleUrls: ['./notifications-pagination.component.scss']
})
export class NotificationsPaginationComponent implements OnInit {

  notifications:  MutuiNotification[];
  @Output() pagerEmitter: EventEmitter<any> = new EventEmitter<any>();
  @Output() pagedItemsEmitter: EventEmitter<any> = new EventEmitter<any>();
  @Input() pager:any = {};
  pagedItems: any[];
  i:any;
  constructor(private notificationsService: NotificationsService,private paginationService: PaginationService,
    private route: ActivatedRoute, private router: Router) {
    }

  ngOnInit() {
    this.notificationsService.getNotifications().subscribe(
      data =>{ this.notifications = data;
      this.setPage(1);
    });
   }
   setPage(page: number) {
    // get pager object from service
    this.pager = this.paginationService.getPager(this.notifications.length, page);

    // get current page of items
    this.pagedItems = this.notifications.slice(this.pager.startIndex, this.pager.endIndex + 1);
    this.pagerEmitter.emit(this.pager);
    this.pagedItemsEmitter.emit(this.pagedItems);
  }
  }
