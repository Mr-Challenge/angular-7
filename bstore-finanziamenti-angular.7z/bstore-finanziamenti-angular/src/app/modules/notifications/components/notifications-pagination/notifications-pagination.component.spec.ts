import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotificationsPaginationComponent } from './notifications-pagination.component';

describe('NotificationsPaginationComponent', () => {
  let component: NotificationsPaginationComponent;
  let fixture: ComponentFixture<NotificationsPaginationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotificationsPaginationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotificationsPaginationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
