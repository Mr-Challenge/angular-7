import { Component, OnInit } from '@angular/core';
import { NotificationsService } from '../../services/notifications.service';
import { MutuiNotification } from '../../models/mutuiNotification';
import { ActivatedRoute, Router } from '@angular/router';
import { PaginationService } from '../../services/pagination.service';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';

@Component({
  selector: 'bst-fin-notifications-table',
  templateUrl: './notifications-table.component.html',
  styleUrls: ['./notifications-table.component.scss']
})
export class NotificationsTableComponent implements OnInit {

  notifications: MutuiNotification[];
  pager: any = {};
  pagedItems: any[];
  demoEvents: EventsModel[];
  checkedVal: any[] = [];
  selectReadNotifications: boolean = false;
  selectUnreadNotifications: boolean = false;
  constructor(private notificationsService: NotificationsService, private paginationService: PaginationService,
    private route: ActivatedRoute, private router: Router) {
  }

  ngOnInit() {}
// getting these values from notifications-pagination
    getPager(data){
    this.pager = data;
    }
    getPagedItems(data){
      this.pagedItems = data;
    }

// getting these values from notifications-bar, on click of one checkbox
    selectedAllEmitter(data) {
      this.selectReadNotifications = data;
      this.selectUnreadNotifications = data;
    }

// getting these values from notifications-bar, on select of any value from dropdown
    EmittedDropDownValue(data) {
      if (data === 'Tutti') {
      this.selectReadNotifications = true;
      this.selectUnreadNotifications = true;
      } else if (data === 'Nessuno' || data === 'noValueSelected') {
        this.selectReadNotifications = false;
        this.selectUnreadNotifications = false;
      } else if (data === 'GiÃ  letti') {
        this.selectReadNotifications = true;
        this.selectUnreadNotifications = false;
      } else if (data === 'Da leggere') {
        this.selectReadNotifications = false;
        this.selectUnreadNotifications = true;
      }
    }

// getting these values from notifications-bar
    getPagedItemsFromBar(data){
      this.pagedItems = data;
    }
    getPagerValue(data){
      this.pager = data;
    }

}