import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SelectOptionModel } from 'bstore-angular-library/lib/models/select-option-model';
import { MutuiNotification } from '../../models/mutuiNotification';
import { NotificationsService } from '../../services/notifications.service';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { PaginationService } from '../../services/pagination.service';

@Component({
  selector: 'bst-fin-notifications-bar',
  templateUrl: './notifications-bar.component.html',
  styleUrls: ['./notifications-bar.component.scss']
})
export class NotificationsBarComponent implements OnInit {

@Input() pager: any = {};
notifications: MutuiNotification[];
  date: string;
  mostRecentDate: Date;
  checkedVal: any[] = [];
  color: any;
  selectedAll: boolean = false;
  @Output() selectedAllEmitter: EventEmitter<any> = new EventEmitter<any>();
  @Output() DropDownValueEmitter: EventEmitter<any> = new EventEmitter<any>();
  @Output() pagerValueEmitter: EventEmitter<any> = new EventEmitter<any>();
  @Output() pagedItemsEmitter: EventEmitter<any> = new EventEmitter<any>();
  pagerValue: any = {};
  pagedItems: any[];
  public colors: SelectOptionModel[] = [
    {
      value: 'Tutti',
      description: 'Tutti',
    },
    {
      value: 'Nessuno',
      description: 'Nessuno',
      checked: true
    },
    {
      value: 'GiÃ  letti',
      description: 'GiÃ  letti'
    },
    {
      value: 'Da leggere',
      description: 'Da leggere'
    }
  ];
  demoEvents: EventsModel[];
  demoEventsForDropdown: EventsModel[];
  constructor(private notificationsService: NotificationsService, private paginationService: PaginationService) {
  }

  ngOnInit() {
    this.demoEvents = [
      { eventName: 'change', eventCallBack: this.selectAll.bind(this) }
    ];

    this.demoEventsForDropdown = [
      { eventName: 'change', eventCallBack: this.changeCallBack.bind(this) }
    ];

    this.notificationsService.getNotifications().subscribe(
      data => { this.notifications = data;
    this.setPage(1);

      this.mostRecentDate = new Date(Math.max.apply(null, this.notifications.map( e => {
        return new Date(e.date);
    })));

    var mostRecentObject = this.notifications.filter( e => { 
        var d = new Date( e.date ); 
        return d.getTime() == this.mostRecentDate.getTime();
    })[0];
    });
  }

  selectAll(input,event){
    if (event.target.checked) {
      this.checkedVal.push(event.target.value);
      this.selectedAll = true;
      this.selectedAllEmitter.emit(this.selectedAll);
    } else {
      this.checkedVal.splice(this.checkedVal.indexOf(event.target.value), 1 );
      this.selectedAll = false;
      this.selectedAllEmitter.emit(this.selectedAll);
    }
  }

  changeCallBack(input, event) {
    if (event.target.value) {
      this.DropDownValueEmitter.emit(event.target.value);
    } else {
      this.DropDownValueEmitter.emit('noValueSelected');
    }
  }

  setPage(page: number) {
    // get pager object from service
    this.pagerValue = this.paginationService.getPager(this.notifications.length, page);

    // get current page of items
    this.pagedItems = this.notifications.slice(this.pagerValue.startIndex, this.pagerValue.endIndex + 1);
    this.pagerValueEmitter.emit(this.pagerValue);
    this.pagedItemsEmitter.emit(this.pagedItems);
  }

}