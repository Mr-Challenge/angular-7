import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BstoreCommonModule } from '../bstore-common/bstore-common.module';
import { FormsModule } from '@angular/forms';
import { NotificationsPageComponent } from './pages/notifications-page/notifications-page.component';
import { NotificationsTableComponent } from './components/notifications-table/notifications-table.component';
import { NotificationsPaginationComponent } from './components/notifications-pagination/notifications-pagination.component';
import { NotificationsRoutingModule } from './notifications-routing.module';
import { NotificationsBarComponent } from './components/notifications-bar/notifications-bar.component';

@NgModule({
  declarations: [
    NotificationsPageComponent,
    NotificationsTableComponent,
    NotificationsPaginationComponent,
    NotificationsBarComponent],
  imports: [
    BstoreCommonModule,
    NotificationsRoutingModule,
    FormsModule
  ]
})
export class NotificationsModule { }
