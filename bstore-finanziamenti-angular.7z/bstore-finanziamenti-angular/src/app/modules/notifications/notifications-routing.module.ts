import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NotificationsPageComponent } from './pages/notifications-page/notifications-page.component';
import { NotificationsPaginationComponent } from './components/notifications-pagination/notifications-pagination.component';

const routes: Routes = [
{ path: '', component: NotificationsPageComponent},
{ path: 'note/:id', component: NotificationsPaginationComponent}
];
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class NotificationsRoutingModule { }