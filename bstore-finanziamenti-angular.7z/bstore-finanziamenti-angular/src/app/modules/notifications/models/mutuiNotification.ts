export class MutuiNotification {
    description: string;
    proposalId: string;
    heading: string;
    date: string;
    time: string;
    unread: boolean;
}