import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {MutuiNotification} from 'src/app/modules/notifications/models/mutuiNotification';
import {Observable} from 'rxjs';
import {EndpointsService} from "../../../services/endpoints.service";

@Injectable({
  providedIn: 'root'
})
export class NotificationsService {

  constructor(private httpClient: HttpClient, private endpointsService: EndpointsService) { }

  public getNotifications(): Observable<MutuiNotification[]>{
    return this.httpClient.get<MutuiNotification[]>(this.endpointsService.loadNotifications);
  }
}
