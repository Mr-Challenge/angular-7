import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bst-fin-notifications-page',
  templateUrl: './notifications-page.component.html',
  styleUrls: ['./notifications-page.component.scss']
})
export class NotificationsPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
