import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SurveyBuilderPageComponent } from './survey-builder-page.component';

describe('SurveyBuilderPageComponent', () => {
  let component: SurveyBuilderPageComponent;
  let fixture: ComponentFixture<SurveyBuilderPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SurveyBuilderPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SurveyBuilderPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
