import { Component, OnInit } from '@angular/core';
import { SurveyBuilderServiceService } from '../../services/survey-builder-service.service';
import { SurveyQuestion } from 'src/app/modules/interview/models/surveyQuestion';
import { Survey } from 'src/app/modules/interview/models/survey';
import { SurveySection } from 'src/app/modules/interview/models/survey-section';
import { SurveyWrapper } from 'src/app/modules/interview/models/survey-wrapper';
import { createHostListener } from '@angular/compiler/src/core';

@Component({
  selector: 'bst-fin-survey-builder-page',
  templateUrl: './survey-builder-page.component.html',
  styleUrls: ['./survey-builder-page.component.scss']
})
export class SurveyBuilderPageComponent implements OnInit {

  json: string;
  map: Map<string, SurveyQuestion> = new Map();
  temp: SurveyQuestion;
  category: string;
  surveyWrapper: SurveyWrapper;

  constructor(public interviewService: SurveyBuilderServiceService) {
    this.json = '';
  }

  ngOnInit() {
    console.log('This is your json:', this.json);
    // IMPORTANT!!!!! choose your category
    //this.category = 'MUTUI_IPOTECARI_CASA';
    // this.category = 'ALTRI_MUTUI_IPOTECARI';
    this.category = 'MUTUI_CHIROGRAFARI_DIPENDENTI';
    //this.category = 'MUTUI_CHIROGRAFARI_CASA';
    //this.category='ALTRI_MUTUI_CHIROGRAFARI';
    this.initializeSurveyJson();
    this.initializeQuestionMap();
  }

  private initializeSurveyJson(): void {
    this.surveyWrapper = new SurveyWrapper();
    const survey = new Survey();
    survey.type = 'INTERVISTA_' + this.category;
    survey.version = 1;
    survey.title = null;
    survey.description = null;
    survey.sections = [];
    const section = new SurveySection();
    section.sectionId = null;
    section.title = null;
    section.description = null;
    section.additionalData = new Object();
    section.additionalData.numMaxQuestions = 5;
    section.questions = [];
    survey.sections.push(section);
    this.surveyWrapper.survey = survey;
  }


  private initializeQuestionMap() {
    this.interviewService.getSurveyQuestionList(this.category).subscribe(data => {
      const surveyQuestionList = data.sections[0].questions;
      surveyQuestionList.forEach((question, index) => {
        this.map.set(question.id, question);
      });
      if (this.category === 'MUTUI_IPOTECARI_CASA') {
        this.buildTree();
      } else if (this.category === 'ALTRI_MUTUI_IPOTECARI') {
        this.buildALTRItree();
      } else if(this.category === 'MUTUI_CHIROGRAFARI_DIPENDENTI'){
        this.buildChiroDipendentiTree();
      } else if (this.category === 'ALTRI_MUTUI_CHIROGRAFARI' || this.category === 'MUTUI_CHIROGRAFARI_CASA'){
        this.buildChirografariTree();
      }
    });
  }

  private buildChirografariTree(){
    const nestedTree: SurveyQuestion[] = [];
    nestedTree.push(this.map.get('D1'));
    nestedTree.push(this.map.get('D2'));
    nestedTree.push(this.map.get('D11_HID_NO'));
    nestedTree.push(this.map.get('D12'));
    nestedTree.push(this.map.get('D13'));
    nestedTree.push(this.map.get('D14'));
    this.surveyWrapper.survey.sections[0].questions = nestedTree;
    this.json = JSON.stringify(this.surveyWrapper);
    this.json = this.json.replace(/\'/g, "''"); // replace singlo quote with two single quotes to allow proper saving on DB
  }

  private buildChiroDipendentiTree() {
    const nestedTree: SurveyQuestion[] = [];
    nestedTree.push(this.map.get('D1_DIP'));
    this.surveyWrapper.survey.sections[0].questions = nestedTree;
    this.json = JSON.stringify(this.surveyWrapper);
    this.json = this.json.replace(/\'/g, "''");//replacesingloquotewithtwosinglequotestoallowpropersavingonDB
  }

  private buildALTRItree() {
    const nestedTree: SurveyQuestion[] = [];
    nestedTree.push(this.map.get('D1'));
    const D2: SurveyQuestion = this.getQuestionClone('D2');
    this.temp = D2;
    D2.choices.forEach((choice) => {
      if (choice.label === 'Acquisto + Ristrutturazione + Liquidità' ||
          choice.label === 'Acquisto + Liquidità' ||
          choice.label === 'Ristrutturazione + Liquidità') {
        choice.nextQuestions = this.buildAltriBranch1();
      } else if (choice.label === 'Liquidità') {
        choice.nextQuestions = this.buildAltriBranch3();
      } else {
        choice.nextQuestions = this.buildAltriBranch2();
      }
    });
    nestedTree.push(D2);
    this.surveyWrapper.survey.sections[0].questions = nestedTree;
    this.json = JSON.stringify(this.surveyWrapper);
    this.json = this.json.replace(/\'/g, "''"); // replace singlo quote with two single quotes to allow proper saving on DB
  }

  private buildAltriBranch1(): SurveyQuestion[] {
    const branch: SurveyQuestion[] = [];
    branch.push(this.getQuestionClone('D4'));
    branch.push(this.getQuestionClone('D5'));
    branch.push(this.getQuestionClone('D6'));
    branch.push(this.getQuestionClone('D9'));
    const D11 = this.getQuestionClone('D11');
    D11.onChange = 'showBperEmployeePopup';
    branch.push(D11);
    branch.push(this.getQuestionClone('D12'));
    branch.push(this.getQuestionClone('D13'));
    branch.push(this.getQuestionClone('D14'));
    console.log('branch 1 ALTRI -----> ', branch);
    return branch;
  }

  private buildAltriBranch2(): SurveyQuestion[] {
    const branch: SurveyQuestion[] = [];
    branch.push(this.getQuestionClone('D4'));
    return this.buildAltriBranch23(branch, 2);
  }

  private buildAltriBranch3(): SurveyQuestion[] {
    return this.buildAltriBranch23([], 3);
  }

  private buildAltriBranch23(branch: SurveyQuestion[], branchNumber: number): SurveyQuestion[] {
    branch.push(this.getQuestionClone('D5'));
    branch.push(this.getQuestionClone('D6'));
    branch.push(this.getQuestionClone('D9'));
    const siBranch: SurveyQuestion[] = [];
    this.addAll(siBranch, this.buildBranchD11bcd());
    this.addAll(siBranch, this.buildBranchD12D13D14());
    const D11 = this.getQuestionWithNextBranches('D11', siBranch, this.buildBranchD12D13D14());
    branch.push(D11);
    console.log('branch ' + branchNumber + ' ALTRI -----> ', branch);
    return branch;
  }

  private buildTree() {
    const nestedTree: SurveyQuestion[] = [];
    nestedTree.push(this.map.get('D1'));
    const D2: SurveyQuestion = this.getQuestionClone('D2');
    this.temp = D2;
    D2.choices.forEach((choice) => {
      if (choice.label === 'Acquisto + Ristrutturazione + Liquidità' || choice.label === 'Acquisto + Liquidità') {
        choice.nextQuestions = this.buildBranch1();
      } else if (choice.label === 'Acquisto') {
        choice.nextQuestions = this.buildBranch2(true);
      } else if (choice.label === 'Sostituzione' || choice.label === 'Surroga') {
        choice.nextQuestions = this.buildBranch3();
      } else if (choice.label === 'Costruzione' || choice.label === 'Ristrutturazione') {
        choice.nextQuestions = this.buildBranch4();
      } else if (choice.label === 'Ristrutturazione + Liquidità') {
        choice.nextQuestions = this.buildBranch5();
      } else if (choice.label === 'Acquisto + Ristrutturazione') {
        choice.nextQuestions = this.buildBranch2(false);
      }
    });
    nestedTree.push(D2);
    this.surveyWrapper.survey.sections[0].questions = nestedTree;
    this.json = JSON.stringify(this.surveyWrapper);
    this.json = this.json.replace(/\'/g, "''"); // replace single quote with two single quotes to allow proper saving on DB
  }

  private buildBranch1(): SurveyQuestion[] {
    const branch: SurveyQuestion[] = [];
    const D3: SurveyQuestion = this.getQuestionClone('D3');
    const D5D6 = this.buildBranchD5D6();
    D3.choices.forEach((choice) => {
      choice.nextQuestions = [];
      if (choice.label === 'Si') {
        this.addAll(choice.nextQuestions, D5D6);
        choice.nextQuestions.push(this.getQuestionClone('D8'));
      } else {
        choice.nextQuestions.push(this.getQuestionClone('D4'));
        this.addAll(choice.nextQuestions, D5D6);
      }
      this.addAll(choice.nextQuestions, this.buildR2());
    });
    branch.push(D3);
    console.log('branch 1 -----> ', branch);
    return branch;
  }

  private buildBranch2(isAcquisto: boolean): SurveyQuestion[] {
    const branch: SurveyQuestion[] = [];
    const D3: SurveyQuestion = this.getQuestionClone('D3');
    const D5D6 = this.buildBranchD5D6();
    D3.choices.forEach((choice) => {
      choice.nextQuestions = [];
      if (choice.label === 'Si') {
        this.addAll(choice.nextQuestions, D5D6);
        const D9 = this.getQuestionWithNextBranches('D9', this.buildR3(), this.buildR1());
        const D8 = this.getQuestionWithNextBranches('D8', this.buildR2(), [D9]);
        if (isAcquisto) {
          const D7 = this.getQuestionWithNextBranches('D7', this.buildR2(), [D8]);
          choice.nextQuestions.push(D7);
        } else {
          choice.nextQuestions.push(D8);
        }
      } else {
        choice.nextQuestions.push(this.getQuestionClone('D4'));
        this.addAll(choice.nextQuestions, D5D6);
        choice.nextQuestions.push(this.getQuestionClone('D9'));
        this.addAll(choice.nextQuestions, this.buildR1());
      }
    });
    branch.push(D3);
    console.log('branch 2 -----> ', branch);
    return branch;
  }

  private buildBranch3(): SurveyQuestion[] {
    const branch: SurveyQuestion[] = [];
    const D5D6 = this.buildBranchD5D6();
    const siBranch: SurveyQuestion[] = [];
    this.addAll(siBranch, D5D6);
    siBranch.push(this.getQuestionClone('D9'));
    this.addAll(siBranch, this.buildR1());
    const noBranch: SurveyQuestion[] = [];
    noBranch.push(this.getQuestionClone('D4'));
    this.addAll(noBranch, siBranch);
    const D3 = this.getQuestionWithNextBranches('D3', siBranch, noBranch);
    branch.push(D3);
    console.log('branch 3 -----> ', branch);
    return branch;
  }

  private buildBranch4(): SurveyQuestion[] {
    const branch: SurveyQuestion[] = [];
    const D5D6 = this.buildBranchD5D6();
    // si
    const siBranch: SurveyQuestion[] = [];
    this.addAll(siBranch, D5D6);
    const D9 = this.getQuestionWithNextBranches('D9', this.buildR3(), this.buildR1());
    siBranch.push(D9);
    // no
    const noBranch: SurveyQuestion[] = [];
    noBranch.push(this.getQuestionClone('D4'));
    this.addAll(noBranch, D5D6);
    noBranch.push(this.getQuestionClone('D9'));
    this.addAll(noBranch, this.buildR1());
    const D3 = this.getQuestionWithNextBranches('D3', siBranch, noBranch);
    branch.push(D3);
    console.log('branch 4 -----> ', branch);
    return branch;
  }

  private buildBranch5(): SurveyQuestion[] {
    const branch: SurveyQuestion[] = [];
    const D5D6 = this.buildBranchD5D6();
    // si
    const siBranch: SurveyQuestion[] = [];
    this.addAll(siBranch, D5D6);
    this.addAll(siBranch, this.buildR2());
    // no
    const noBranch: SurveyQuestion[] = [];
    noBranch.push(this.getQuestionClone('D4'));
    this.addAll(noBranch, siBranch);

    const D3 = this.getQuestionWithNextBranches('D3', siBranch, noBranch);
    branch.push(D3);
    console.log('branch 5 -----> ', branch);
    return branch;
  }

  private buildR1(): SurveyQuestion[] {
    const branch: SurveyQuestion[] = [];
    branch.push(this.getQuestionClone('D10'));
    const siBranch: SurveyQuestion[] = [];
    this.addAll(siBranch, this.buildBranchD11bcd());
    this.addAll(siBranch, this.buildBranchD12D13D14());
    const D11 = this.getQuestionWithNextBranches('D11', siBranch, this.buildBranchD12D13D14());
    branch.push(D11);
    console.log('R1 -----> ', branch);
    return branch;
  }

  private buildR2(): SurveyQuestion[] {
    const branch: SurveyQuestion[] = [];
    branch.push(this.getQuestionClone('D9'));
    branch.push(this.getQuestionClone('D10'));
    const D11 = this.getQuestionClone('D11');
    D11.onChange = 'showBperEmployeePopup';
    branch.push(D11);
    branch.push(this.getQuestionClone('D12'));
    branch.push(this.getQuestionClone('D13'));
    branch.push(this.getQuestionClone('D14'));
    console.log('R2 -----> ', branch);
    return branch;
  }

  private buildR3(): SurveyQuestion[] {
    const branch: SurveyQuestion[] = [];
    branch.push(this.getQuestionClone('D10'));
    const siBranch: SurveyQuestion[] = [];
    // 11.b no
    const noBranch: SurveyQuestion[] = [];
    noBranch.push(this.getQuestionClone('D11.c'));
    noBranch.push(this.getQuestionClone('D11.d'));
    this.addAll(noBranch, this.buildBranchD12D13D14());
    // 11.b si
    siBranch.push(this.getQuestionClone('D11.c'));
    siBranch.push(this.getQuestionClone('D11.d'));
    siBranch.push(this.getQuestionClone('D11.e'));
    this.addAll(siBranch, this.buildBranchD12D13D14());

    const D11b = this.getQuestionWithNextBranches('D11.b', siBranch, noBranch);

    const D11 = this.getQuestionWithNextBranches('D11', [D11b], this.buildBranchD12D13D14());
    branch.push(D11);
    console.log('R3 -----> ', branch);
    return branch;
  }

  private buildBranchD5D6(): SurveyQuestion[] {
    const branch: SurveyQuestion[] = [];
    branch.push(this.map.get('D5'));
    branch.push(this.map.get('D6'));
    return branch;
  }

  // R1 = D9, D10
  private buildBranchR2(): SurveyQuestion[] {
    const branch: SurveyQuestion[] = [];
    branch.push(this.map.get('D9'));
    branch.push(this.map.get('D10'));
    return branch;
  }

  private buildBranchD12D13D14(): SurveyQuestion[] {
    const branch: SurveyQuestion[] = [];
    branch.push(this.map.get('D12'));
    branch.push(this.map.get('D13'));
    branch.push(this.map.get('D14'));
    return branch;
  }

  private buildBranchD11bcd(): SurveyQuestion[] {
    const branch: SurveyQuestion[] = [];
    branch.push(this.map.get('D11.b'));
    branch.push(this.map.get('D11.c'));
    branch.push(this.map.get('D11.d'));
    return branch;
  }

  // buildBranchR1R2(): SurveyQuestion[]{
  //   let branch : SurveyQuestion[] = [];
  //   var R1 : SurveyQuestion[] = this.buildBranchR1();
  //   var R2 : SurveyQuestion[] = this.buildBranchR2();
  //   R2[1].choices.forEach((choice) => {
  //     if(choice.label == "Si"){
  //       choice.nextQuestions = R1;
  //     }
  //   });
  //   branch = R2;
  //   return branch;
  // }

  // buildBranchAcquisto(): SurveyQuestion[]{
  //   let branch : SurveyQuestion[] = [];
  //   let D3 : SurveyQuestion = this.getQuestionClone("D3");
  //   let R3 = this.buildBranchR3()
  //   let R2 = this.buildBranchR2();
  //   D3.choices.forEach((choice) => {
  //     choice.nextQuestions = [];
  //     if(choice.label == "Si"){
  //       this.addAll(choice.nextQuestions, R3);
  //       let D7 = this.getQuestionClone("D7");
  //       D7.choices.forEach((c) => {
  //         c.nextQuestions = [];
  //         if(c.label == "No"){
  //           c.nextQuestions.push(this.getQuestionClone("D8"));
  //         }
  //         this.addAll(c.nextQuestions, this.buildBranchR1R2());
  //       });
  //       choice.nextQuestions.push(D7);
  //     } else {
  //       choice.nextQuestions.push(this.getQuestionClone("D4"));
  //       this.addAll(choice.nextQuestions, R3);
  //       this.addAll(choice.nextQuestions, R2);
  //     }
  //   });
  //   branch.push(D3);
  //   return branch;
  // }


  // buildOthers(): SurveyQuestion[]{
  //   let branch : SurveyQuestion[] = [];
  //   let R3 = this.buildBranchR3()
  //   let R2 = this.buildBranchR2();
  //   let D3 : SurveyQuestion = this.getQuestionClone("D3");
  //   D3.choices.forEach((choice) => {
  //     choice.nextQuestions = [];
  //     if(choice.label == "No"){
  //       choice.nextQuestions.push(this.getQuestionClone("D4"));
  //     }
  //     this.addAll(choice.nextQuestions, R3);
  //     this.addAll(choice.nextQuestions, R2);
  //   });
  //   branch.push(D3);
  //   return branch;
  // }

  private addAll(source: SurveyQuestion[], additional: SurveyQuestion[]) {
    additional.forEach((question) => {
      source.push(question);
    });
  }

  private getQuestionClone(id: string): SurveyQuestion {
    const D = this.map.get(id);
    return (JSON.parse(JSON.stringify(D)));
    // return Object.assign(new SurveyQuestion(), D);
  }

  private getQuestionWithNextBranches(questionId: string, nextBranchSi: SurveyQuestion[], nextBranchNo: SurveyQuestion[]): SurveyQuestion {
    const D: SurveyQuestion = this.getQuestionClone(questionId);
    D.choices.forEach((choice) => {
      choice.nextQuestions = [];
      if (choice.label === 'Si') {
        this.addAll(choice.nextQuestions, nextBranchSi);
      } else if (choice.label === 'No') {
        this.addAll(choice.nextQuestions, nextBranchNo);
      }
    });
    return D;
  }


}
