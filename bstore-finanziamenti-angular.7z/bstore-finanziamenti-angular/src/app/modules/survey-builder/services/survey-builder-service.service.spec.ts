import { TestBed } from '@angular/core/testing';

import { SurveyBuilderServiceService } from './survey-builder-service.service';

describe('SurveyBuilderServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SurveyBuilderServiceService = TestBed.get(SurveyBuilderServiceService);
    expect(service).toBeTruthy();
  });
});
