import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Survey } from '../../interview/models/survey';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SurveyBuilderServiceService {

  constructor(private httpClient: HttpClient) { }

  public getSurveyQuestionList(category:string): Observable<Survey> {
    if(category == "MUTUI_IPOTECARI_CASA"){
      return this.httpClient.get<Survey>('assets/mock_data/survey-builder/MUTUI_IPOTECARI_CASA_QUESTION_LIST.json');
    } else if(category == "ALTRI_MUTUI_IPOTECARI"){    
      return this.httpClient.get<Survey>('assets/mock_data/survey-builder/ALTRI_MUTUI_IPOTECARI_QUESTION_LIST.json');
    } else if(category == "MUTUI_CHIROGRAFARI_DIPENDENTI"){    
      return this.httpClient.get<Survey>('assets/mock_data/survey-builder/MUTUI_CHIROGRAFARI_DIPENDENTI_LIST.json');
    } else if (category === 'MUTUI_CHIROGRAFARI_CASA') {
      return this.httpClient.get<Survey>('assets/mock_data/survey-builder/MUTUI_CHIROGRAFARI_CASA_QUESTION_LIST.json');
    } else if (category == "ALTRI_MUTUI_CHIROGRAFARI") {
      return this.httpClient.get<Survey>('assets/mock_data/survey-builder/ALTRI_MUTUI_CHIROGRAFARI_QUESTION_LIST.json');
    }else {
      throw new Error("No question List found for category: " + category);
    }
  }
}
