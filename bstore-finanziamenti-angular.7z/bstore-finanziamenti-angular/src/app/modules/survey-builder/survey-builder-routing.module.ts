import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SurveyBuilderPageComponent } from './pages/survey-builder-page/survey-builder-page.component';

const routes: Routes = [
  { path: '', component: SurveyBuilderPageComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SurveyBuilderRoutingModule { }
