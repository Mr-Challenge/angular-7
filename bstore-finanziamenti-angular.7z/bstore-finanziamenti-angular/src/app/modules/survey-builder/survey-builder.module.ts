import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SurveyBuilderRoutingModule } from './survey-builder-routing.module';
import { SurveyBuilderPageComponent } from './pages/survey-builder-page/survey-builder-page.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    SurveyBuilderPageComponent
  ],
  imports: [
    CommonModule,
    SurveyBuilderRoutingModule,
    FormsModule
  ]
})
export class SurveyBuilderModule { }
