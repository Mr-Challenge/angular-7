import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PartiCorrelate } from 'src/app/models/PartiCorrelate';
import { EndpointsService } from '../../../services/endpoints.service';
import { LoanPurposeModel } from '../../product-configuration/models/LoanPurposeModel';
import { AnomaliaForborneModel } from 'src/app/models/anomaliaForborne.model';
import { FetchAnomalies } from 'src/app/models/fetchAnomalies.model';

@Injectable({
  providedIn: 'root'
})
export class RilevazioneForborneService {

  constructor(private httpClient: HttpClient, private endpointsService: EndpointsService) { }

  public getPartiCorrelate(idProposal: string) {
    const parameters = new HttpParams().append('idProposta', idProposal);
    return this.httpClient.get<PartiCorrelate>(this.endpointsService.getPartiCorrelate, { params: parameters });
  }

  public getAnomaliaList(fetchAnomalie: FetchAnomalies): Observable<any> {
    return this.httpClient.post<any>(this.endpointsService.fetchAnomaliaList, fetchAnomalie);
  }
}
