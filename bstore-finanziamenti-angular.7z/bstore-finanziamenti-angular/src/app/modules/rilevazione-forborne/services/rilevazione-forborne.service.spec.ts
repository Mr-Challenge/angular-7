import { TestBed } from '@angular/core/testing';

import { RilevazioneForborneService } from './rilevazione-forborne.service';

describe('RilevazioneForborneService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RilevazioneForborneService = TestBed.get(RilevazioneForborneService);
    expect(service).toBeTruthy();
  });
});
