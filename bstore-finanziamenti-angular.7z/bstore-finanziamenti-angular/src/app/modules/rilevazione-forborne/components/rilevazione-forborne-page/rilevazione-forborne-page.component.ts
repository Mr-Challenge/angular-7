import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BreadcrumbModel, DialogService } from 'bstore-angular-library';
import { EventsModel } from 'bstore-angular-library/lib/models/event-model';
import { MortgageStepWizard } from 'src/app/constant/mortgageStepWizard';
import { AnomaliaForborneModel } from 'src/app/models/anomaliaForborne.model';
import { ClientRole } from 'src/app/models/clientRole.enum';
import { FetchAnomalies } from 'src/app/models/fetchAnomalies.model';
import { PartiCorrelate } from 'src/app/models/PartiCorrelate';
import { ModificaPropostaPopupComponent } from 'src/app/modules/modifica-proposta/components/modifica-proposta-popup/modifica-proposta-popup.component';
import { ForborneQuestionList } from 'src/app/modules/product-configuration/models/ForborneQuestionList';
import { MutuiDetailsModel } from 'src/app/modules/product-configuration/models/MutuiDetailsModel';
import { ProductConfiguartionService } from 'src/app/modules/product-configuration/services/product-configuartion.service';
import { RestituisciBpiPopupSectionComponent } from 'src/app/modules/restituisci-bpi-popup-section/restituisci-bpi-popup-section.component';
import { ForborneService } from 'src/app/modules/vendita/services/forborne.service';
import { CommonService } from 'src/app/services/common.service';
import { RilevazioneForborneService } from '../../services/rilevazione-forborne.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'bst-fin-rilevazione-forborne-page',
  templateUrl: './rilevazione-forborne-page.component.html',
  styleUrls: ['./rilevazione-forborne-page.component.scss']
})
export class RilevazioneForbornePageComponent implements OnInit {
  domainName = environment.devUrlJSON['npv.service.callback.url'];
  proposalId: any;
  public breadcrumbs: BreadcrumbModel[];
  allClients: any[];
  updateProposalStepEvents: EventsModel[] = [];
  dropDownList: any[];
  openBPIPopup: EventsModel[] = [];
  myList: any[];
  fetchedMutuiDetails: MutuiDetailsModel;
  msgLineaForborne = 'La proposta di misure di forbearance non è supportata tramite BStore. Procedere tramite PEF.';
  ndgList: string[] = [];
  ndgListForborneCall: string[] = [];
  anomaliaList: AnomaliaForborneModel[];
  casoConflittoDifficoltaFinanziaria = false;
  notaForborneInvalid: boolean;

  constructor(
    private router: Router,
    private commonService: CommonService,
    private rilevazioneForborneService: RilevazioneForborneService,
    private forborneService: ForborneService,
    private route: ActivatedRoute,
    private dialogservice: DialogService,
    private productConfiguartionService: ProductConfiguartionService,
  ) {
    this.route.params.subscribe(params => this.proposalId = params['proposalId']);
  }

  ngOnInit() {
    const filterCointestazioneNdg = client => client.cointestazione;
    const filterNonCointestazioneNdg = client => !client.cointestazione;
    const filterNdgWithClientRoleIntestari = client => client.role === ClientRole.INTESTARI.toString();
    this.commonService.retrieveAllClient(this.proposalId).subscribe(response => {
      this.allClients = response;
      if (this.allClients) {
        this.ndgList = this.allClients.filter(filterNonCointestazioneNdg).map(clientVal => clientVal.ndg);
        this.ndgListForborneCall = (this.allClients.find(filterCointestazioneNdg) ?
        this.allClients.filter(filterCointestazioneNdg)
        : this.allClients.filter(filterNdgWithClientRoleIntestari)
        ).map(clientVal => clientVal.ndg);
      }
    }, null, () => {
      this.callFetchAnomalies();
    });

    // if I pass no category all result are fetched
    this.forborneService.selectFinancingPurposeForCategory('').subscribe(
      result => {
        const finanziamentoList: any[] = [];
        this.myList = result;
        this.myList.map(data =>
          finanziamentoList.push(
            {
              value: data.codice,
              description: data.descrizione

            }
          )
        );
        this.dropDownList = finanziamentoList;
      });

    this.updateProposalStepEvents = [
      { eventName: 'click', eventCallBack: this.updateProposalStep.bind(this) }
    ];

    this.openBPIPopup = [
      { eventName: 'click', eventCallBack: this.openRestituisciBPIPopup.bind(this) }
    ];


    this.rilevazioneForborneService.getPartiCorrelate(this.proposalId).subscribe((resp) => {
      const partiDetails = resp;
      if (this.canISkipPartiCorrelate(partiDetails)) {
        this.breadcrumbs = [{
          label: 'Indietro',
          url: `/politiche/${this.proposalId}`,
          enabled: true,
          externalLink: false
        }];

      } else {
        this.breadcrumbs = [{
          label: 'Indietro',
          url: `/partiCorrelate/${this.proposalId}`,
          enabled: true,
          externalLink: false
        }];

      }
    });
  }

  callFetchAnomalies() {

    this.commonService.fetchMutuoDetails(this.proposalId).subscribe(data => {
      this.fetchedMutuiDetails = data;
    }, null, () => {
      const fetchAnomaliesVm = new FetchAnomalies();
      fetchAnomaliesVm.proposalId = this.proposalId;
      fetchAnomaliesVm.pefProposalId = this.fetchedMutuiDetails.idPef.toString();
      fetchAnomaliesVm.ndgList = this.ndgListForborneCall;
      fetchAnomaliesVm.istruttoriaAvviata = this.fetchedMutuiDetails.istruttoriaAvviata;
      const isRimodulazione = this.dropDownList.find(data => data.value == this.fetchedMutuiDetails.finalita);
      fetchAnomaliesVm.rimodulazione = isRimodulazione ? isRimodulazione.remodulation : false;
      this.forborneService.getAnomaliaListAndDataToForce(fetchAnomaliesVm).subscribe(response => {
        console.log(response);
        this.anomaliaList = response.anomaliaList;
        this.allClients.forEach(client => {
          const anomliesforNdg = this.anomaliaList.filter(anomaly => anomaly.ndg === client.ndg);
          client.rossoFlag = anomliesforNdg.some(anomalia => anomalia.colorAnomalia === 'ROSSO');
          if (!client.rossoFlag) {
            client.arancioneFlag = anomliesforNdg.some(value => value.colorAnomalia === 'ARANCIONE');
            if (!client.arancioneFlag) {
              client.neroFlag = anomliesforNdg.some(anomaliaVal => anomaliaVal.colorAnomalia === 'NERO');
              if (!client.neroFlag) {
                client.verdeFlag = true;
              } else {
                client.verdeFlag = false;
              }
            }
          }
        });
        if (!this.fetchedMutuiDetails.diff && response.toForceDifficoltaFinanziaria) {
          this.casoConflittoDifficoltaFinanziaria = true;
        }
        if (response.toForceDifficoltaFinanziaria) {
          this.fetchedMutuiDetails.diff = response.toForceDifficoltaFinanziaria;
        }
      });
    });
  }

  openRestituisciBPIPopup() {
    const forborneQuestionListObj = new ForborneQuestionList();
    forborneQuestionListObj.concessionConcession = this.fetchedMutuiDetails.concess;
    if (this.fetchedMutuiDetails.dataevento) {
      var date = new Date(Number(this.fetchedMutuiDetails.dataevento));
      forborneQuestionListObj.dateEvent = date.getFullYear() + '/' + (date.getMonth() + 1) + '/' + date.getDate();
    }
    forborneQuestionListObj.difficoltàFinanziaria = this.fetchedMutuiDetails.diff;
    forborneQuestionListObj.finalitàFinanziamento = this.fetchedMutuiDetails.finalita;
    forborneQuestionListObj.lineaForborne = this.fetchedMutuiDetails.lineaforbone;
    forborneQuestionListObj.loanEvent = this.fetchedMutuiDetails.evento;
    forborneQuestionListObj.notaForborne = this.fetchedMutuiDetails.notaforbone;
    forborneQuestionListObj.pefProposalId = this.fetchedMutuiDetails.idPef;
    forborneQuestionListObj.praticaId = this.proposalId;
    forborneQuestionListObj.ndgList = this.ndgList;
    forborneQuestionListObj.istruttoriaAvviata = this.fetchedMutuiDetails.istruttoriaAvviata;
    const checkRimodulazione = this.dropDownList.find(data => data.value == this.fetchedMutuiDetails.finalita);
    forborneQuestionListObj.rimodulazione = checkRimodulazione.remodulation;
    forborneQuestionListObj.suffisoFido = this.fetchedMutuiDetails.preFinaziamento;

    this.productConfiguartionService.saveForborne(forborneQuestionListObj).subscribe(data => {
      console.log(data);
    }, null, () => {
      this.dialogservice.open(RestituisciBpiPopupSectionComponent, {
        data: { idProposal: this.proposalId, idPef: this.fetchedMutuiDetails.idPef.toString() },
        size: 'large',
        title: 'PROPOSTA ' + this.proposalId + ' RESTITUITA CON MODIFICA',
      });
    });
  }

  updateProposalStep() {
    this.commonService.updateProposalStep(this.proposalId, MortgageStepWizard.EIGHT).subscribe();
    this.router.navigate(['/sceltaProponente', this.proposalId]);
  }

  abbandonaPropostaPopup() {
    localStorage.setItem('previousPage', 'rilevazioneForborne');
    this.router.navigate(['/abbandona/' + this.proposalId]);
  }

  canISkipPartiCorrelate(partiCorrelate: PartiCorrelate) {
    if (partiCorrelate.listaSoggettoRilevante === null && partiCorrelate.notaCorrelazione === '' && partiCorrelate.numeroElementiTotali === 0 && partiCorrelate.outputDaisy === '') {
      return true;
    } else {
      return false;
    }
  }

  modificaPopup() {
    this.dialogservice.open(ModificaPropostaPopupComponent, {
      data: { idProposal: this.proposalId },
      noCloseButton: true,
      size: 'large'
    });
  }

  notaInvalid(data) {
    this.notaForborneInvalid = data;
  }
}
