import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RilevazioneForbornePageComponent } from './rilevazione-forborne-page.component';

describe('RilevazioneForbornePageComponent', () => {
  let component: RilevazioneForbornePageComponent;
  let fixture: ComponentFixture<RilevazioneForbornePageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RilevazioneForbornePageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RilevazioneForbornePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
