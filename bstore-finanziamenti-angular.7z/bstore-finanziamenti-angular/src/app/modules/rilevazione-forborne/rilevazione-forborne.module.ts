import { RilevazioneForborneRoutingModule } from './rilevazione-forborne-routing';
import { RilevazioneForbornePageComponent } from './components/rilevazione-forborne-page/rilevazione-forborne-page.component';
import { BstoreCommonModule } from '../bstore-common/bstore-common.module';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared.module';

@NgModule({
  declarations: [
    RilevazioneForbornePageComponent
  ],
  imports: [
    CommonModule,
    BstoreCommonModule,
    RilevazioneForborneRoutingModule,
    SharedModule
  ]
})
export class RilevazioneForborneModule {

}