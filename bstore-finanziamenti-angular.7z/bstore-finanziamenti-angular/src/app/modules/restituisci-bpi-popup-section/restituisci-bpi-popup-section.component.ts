import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { DialogModel, DialogRef } from 'bstore-angular-library';
import { SintesiPraticaService } from 'src/app/modules/sintesi-practica/services/sintesi-pratica.service';
import { UpdateProposalStatusAndStepModel } from '../sintesi-practica/models/UpdateProposalStatusAndStepModel';
@Component({
  selector: 'bst-fin-restituisci-bpi-popup-section',
  templateUrl: './restituisci-bpi-popup-section.component.html',
  styleUrls: ['./restituisci-bpi-popup-section.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class RestituisciBpiPopupSectionComponent implements OnInit {

  idProposal: string;
  idPef: string;
  testoNota = '';
  updateProposalStatusAndStepModel: UpdateProposalStatusAndStepModel;

  saveButtonClickEvents = [
    { eventName: 'click', eventCallBack: this.process.bind(this) }
  ];

  constructor(private config: DialogModel, private dialogRef: DialogRef,
    private sintesiPraticaService: SintesiPraticaService, private router: Router) { }

  ngOnInit() {
    this.idProposal = this.config.data.idProposal;
    this.idPef = this.config.data.idPef;
  }

  process() {
    if (this.idProposal) {
      this.sintesiPraticaService.restituisciToPef(this.idProposal,
        this.idPef, this.testoNota).subscribe(response => {
          if (response) {
            this.router.navigate(['/product', this.idProposal]);
            this.dialogRef.close();
          }
        }
        );
    }
  }

}

