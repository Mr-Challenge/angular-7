import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestituisciBpiPopupSectionComponent } from './restituisci-bpi-popup-section.component';

describe('RestituisciBpiPopupSectionComponent', () => {
  let component: RestituisciBpiPopupSectionComponent;
  let fixture: ComponentFixture<RestituisciBpiPopupSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestituisciBpiPopupSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestituisciBpiPopupSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
