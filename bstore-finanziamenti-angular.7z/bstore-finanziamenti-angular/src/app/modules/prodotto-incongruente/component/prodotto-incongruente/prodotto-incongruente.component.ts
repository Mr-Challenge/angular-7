import { Component, OnInit } from '@angular/core';
import { DialogModel, RedirectService } from 'bstore-angular-library';
import { NotificationVm } from 'src/app/models/notificationVm.model';
import { CommonService } from 'src/app/services/common.service';
import { EndpointsService } from '../../../../services/endpoints.service';

@Component({
  selector: 'bst-fin-prodotto-incongruente',
  templateUrl: './prodotto-incongruente.component.html',
  styleUrls: ['./prodotto-incongruente.component.scss']
})
export class ProdottoIncongruentePopupComponent implements OnInit {

  idProposal: string;
  notificaVm: NotificationVm;
  notifica: string;

  constructor(private commonService: CommonService,
    public config: DialogModel, private endpointsService: EndpointsService,
    private redirectService: RedirectService) { }

  ngOnInit() {
    this.idProposal = this.config.data.idProposal;
    this.notificaVm = this.config.data.notificaVm;
    this.notificaVm.idPraticaBstore = this.idProposal;
    this.notifica = this.notificaVm.notifica;
  }

  onDocumento() {
    this.commonService.updateProposalStepStatusAfterNotification(this.notificaVm).subscribe(res => {
      this.redirectService.redirectWithSpinner(this.endpointsService.openCart + '?modifyProposal=false&ndg=' + this.config.data.ndg);
    });
  }

}
