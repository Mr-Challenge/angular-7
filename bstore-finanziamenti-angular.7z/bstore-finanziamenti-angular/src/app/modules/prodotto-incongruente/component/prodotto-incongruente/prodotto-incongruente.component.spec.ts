import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProdottoIncongruentePopupComponent } from './prodotto-incongruente.component';

describe('ProdottoIncongruentePopupComponent', () => {
  let component: ProdottoIncongruentePopupComponent;
  let fixture: ComponentFixture<ProdottoIncongruentePopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProdottoIncongruentePopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProdottoIncongruentePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
