import { APP_BASE_HREF } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ApplicationRef, APP_ID, ComponentRef, NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ModificaIntervistaPopupComponent } from 'src/app/modules/interview/components/modifica-intervista-popup/modifica-intervista-popup.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './components/app.component';
import { CommonMessagePopupComponent } from './components/common-message-popup/common-message-popup.component';
import { EmailModalPopupComponent } from './components/email-modal-popup/email-modal-popup.component';
import { LinksComponent } from './components/links/links.component';
import { MessagePopupComponent } from './components/message-popup/message-popup.component';
import { AntifrodeKOPopupComponent } from './modules/antifrode-ko-popup/antifrode-ko-popup.component';
import { CompleteIstrPopupComponent } from './modules/complete-istr-popup/complete-istr-popup.component';
import { DeliberaEmailComponent } from './modules/delibera/component/deliberapage/delibera-email/delibera-email.component';
import { CheckDocumentComponent } from './modules/immobili/components/check-document/check-document.component';
import { EsitoPeriziaComponent } from './modules/immobili/components/esito-perizia/esito-perizia.component';
import { EsitoRichiestaPeriziaComponent } from './modules/immobili/components/esito-richiesta-perizia/esito-richiesta-perizia.component';
import { InviaPeriziaComponent } from './modules/immobili/components/invia-perizia/invia-perizia.component';
import { PeriziaPopupComponent } from './modules/immobili/components/perizia-popup/perizia-popup.component';
import { UploadDocumentComponent } from './modules/immobili/components/upload-document/upload-document.component';
import { ConfirmMessagePopupComponent } from './modules/interview/components/confirm-message-popup/confirm-message-popup.component';
import { InterviewMutuiDipendentiPopupComponent } from './modules/interview/components/interview-mutui-dipendenti-popup/interview-mutui-dipendenti-popup.component';
import { InterviewMessagePopupComponent } from './modules/interview/components/interview-popup/interviewmessage-popup.component';
import { ModificaPropostaPopupComponent } from './modules/modifica-proposta/components/modifica-proposta-popup/modifica-proposta-popup.component';
import { ProdottoIncongruentePopupComponent } from './modules/prodotto-incongruente/component/prodotto-incongruente/prodotto-incongruente.component';
import { CreditLinePopupComponent } from './modules/product-configuration/components/credit-line-popup/credit-line-popup.component';
import { GuranteesListPopupComponent } from './modules/product-configuration/components/gurantees-list-popup/gurantees-list-popup.component';
import { PreliminaryCheckPopupComponent } from './modules/product-configuration/components/preliminary-check-popup/preliminary-check-popup.component';
import { ProposalRejectionPopupComponent } from './modules/product-configuration/components/proposal-rejection-popup/proposal-rejection-popup.component';
import { TrafficLightComponent } from './modules/product-configuration/components/traffic-light/traffic-light.component';
import { RestituisciBpiPopupSectionComponent } from './modules/restituisci-bpi-popup-section/restituisci-bpi-popup-section.component';
import { RichiestaPeriziaPopUpComponent } from './modules/richiesta-perizia-pop-up/richiesta-perizia-pop-up.component';
import { AmountSectionPopupComponent } from './modules/simulations/components/amount-section/amount-section-popup/amount-section-popup.component';
import { ConsistanyCheckPopupComponent } from './modules/simulations/components/consistany-check-popup/consistany-check-popup.component';
import { DocumentAttachComponent } from './modules/simulations/components/document-attach/document-attach.component';
import { InviaRichiestaPopupComponent } from './modules/simulations/components/invia-richiesta-popup/invia-richiesta-popup.component';
import { MortgageProtectionPolicyPopupComponent } from './modules/simulations/components/mortgage-protection-policy-popup/mortgage-protection-policy-popup.component';
import { DocumentiPopUpComponent } from './modules/vendita/component/documenti-da-caricare/documenti-pop-up/documenti-pop-up.component';
import { GeneraModuloRichiestaPopUpComponent } from './modules/vendita/component/genera-modulo-richiesta-pop-up/genera-modulo-richiesta-pop-up.component';
import { PageBehaviourPopUpComponent } from './modules/vendita/component/page-behaviour-pop-up/page-behaviour-pop-up.component';
import { SezioneImmobiliChiroPopUpComponent } from './modules/immobili/components/sezione-immobili-chiro-pop-up/sezione-immobili-chiro-pop-up.component';
import { NotificationCommonPopupComponent } from './components/notification-common-popup/notification-common-popup.component';
import { HttpInterceptorService } from './services/http-interceptor.service';
import { SharedModule } from './shared.module';
import { PopupMutuoPrimaCasaComponent } from './components/popup-mutuo-prima-casa/popup-mutuo-prima-casa.component';
import { AnnulloPropostaPopupComponent } from './modules/interview/components/annullo-proposta-popup/annullo-proposta-popup.component';


@NgModule({
  declarations: [
    AppComponent,
    MessagePopupComponent,
    ConsistanyCheckPopupComponent,
    EmailModalPopupComponent,
    CreditLinePopupComponent,
    ModificaIntervistaPopupComponent,
    PeriziaPopupComponent,
    EsitoPeriziaComponent,
    EsitoRichiestaPeriziaComponent,
    UploadDocumentComponent,
    CheckDocumentComponent,
    InviaPeriziaComponent,
    RestituisciBpiPopupSectionComponent,
    LinksComponent,
    AmountSectionPopupComponent,
    PreliminaryCheckPopupComponent,
    CommonMessagePopupComponent,
    ConfirmMessagePopupComponent,
    InterviewMessagePopupComponent,
    ProposalRejectionPopupComponent,
    TrafficLightComponent,
    DocumentAttachComponent,
    InviaRichiestaPopupComponent,
    PageBehaviourPopUpComponent,
    AntifrodeKOPopupComponent,
    ProdottoIncongruentePopupComponent,
    ModificaPropostaPopupComponent,
    MortgageProtectionPolicyPopupComponent,
    DocumentiPopUpComponent,
    RichiestaPeriziaPopUpComponent,
    GeneraModuloRichiestaPopUpComponent,
    GuranteesListPopupComponent,
    DeliberaEmailComponent,
    CompleteIstrPopupComponent,
    InterviewMutuiDipendentiPopupComponent,
    PopupMutuoPrimaCasaComponent,
    AnnulloPropostaPopupComponent,
    SezioneImmobiliChiroPopUpComponent,
    NotificationCommonPopupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgbModule,
    BrowserAnimationsModule,
    SharedModule
  ],

  providers: [
    NgbActiveModal,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpInterceptorService,
      multi: true
    },
    { provide: APP_ID, useValue: 'sch-priv' },
    {
      provide: APP_BASE_HREF,
      useFactory: () => window['bstoreAppPath'] || null
    }
  ],
  entryComponents: [
    AppComponent,
    AntifrodeKOPopupComponent,
    MessagePopupComponent,
    ConsistanyCheckPopupComponent,
    EmailModalPopupComponent,
    CreditLinePopupComponent,
    ModificaIntervistaPopupComponent,
    PeriziaPopupComponent,
    EsitoPeriziaComponent,
    EsitoRichiestaPeriziaComponent,
    UploadDocumentComponent,
    CheckDocumentComponent,
    InviaPeriziaComponent,
    RestituisciBpiPopupSectionComponent,
    AmountSectionPopupComponent,
    PreliminaryCheckPopupComponent,
    CommonMessagePopupComponent,
    ConfirmMessagePopupComponent,
    InterviewMessagePopupComponent,
    ProposalRejectionPopupComponent,
    TrafficLightComponent,
    InviaRichiestaPopupComponent,
    PageBehaviourPopUpComponent,
    ModificaPropostaPopupComponent,
    ProdottoIncongruentePopupComponent,
    MortgageProtectionPolicyPopupComponent,
    DocumentiPopUpComponent,
    RichiestaPeriziaPopUpComponent,
    GeneraModuloRichiestaPopUpComponent,
    GuranteesListPopupComponent,
    DeliberaEmailComponent,
    InterviewMutuiDipendentiPopupComponent,
    CompleteIstrPopupComponent,
    PopupMutuoPrimaCasaComponent,
    AnnulloPropostaPopupComponent,
    SezioneImmobiliChiroPopUpComponent,
    NotificationCommonPopupComponent
  ]
})
export class AppModule {
  ngDoBootstrap(app: ApplicationRef) {
    let rootRef: ComponentRef<AppComponent>;
    window['startApplication'] = () => {
      rootRef = app.bootstrap(AppComponent);
      // this.userService.loadProfile();
    };
    window['killApplication'] = () => {
      if (rootRef) {
        rootRef.destroy();
        rootRef = null;
      }
    };
    window[`startApplication`]();
  }

}
