
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ErrorPageComponent } from 'bstore-angular-library';
import { LinksComponent } from './components/links/links.component';
import { RootGuard } from './components/root.guard';

const routes: Routes = [
  { path: '', component: LinksComponent, canActivate: [RootGuard] },
  { path: 'simulazione', loadChildren: './modules/simulations/simulations.module#SimulationsModule' },
  { path: 'interview', loadChildren: './modules/interview/interview.module#InterviewModule' },
  { path: 'notifications', loadChildren: './modules/notifications/notifications.module#NotificationsModule' },
  { path: 'vendita', loadChildren: './modules/vendita/vendita.module#VenditaModule' },
  { path: 'vendita/:idProposal', loadChildren: './modules/vendita/vendita.module#VenditaModule' },
  { path: 'vendita/:idProposal/:flagCentraleRischi', loadChildren: './modules/vendita/vendita.module#VenditaModule' },
  { path: 'product', loadChildren: './modules/product-configuration/product-configuration.module#ProductConfigurationModule' },
  { path: 'politiche/:proposalId', loadChildren: './modules/politiche/politiche.module#PoliticheModule' },
  { path: 'immobili', loadChildren: './modules/immobili/immobili.module#ImmobiliModule' },
  { path: 'nuovaPerizia', loadChildren: './modules/richiedi-perizia/richiedi-perizia.module#RichiediPeriziaModule' },
  { path: 'sintesi/:proposalId', loadChildren: './modules/sintesi-practica/sintesi-practica.module#SintesiPracticaModule' },
  { path: 'delibera/:proposalId', loadChildren: './modules/delibera/delibera.module#DeliberaModule' },
  { path: 'postDelibera/:proposalId', loadChildren: './modules/post-delibera/post-delibera.module#PostDeliberaModule' },
  { path: 'finalpage/:proposalId', loadChildren: './modules/final-page/final-page.module#FinalPageModule' },
  { path: 'iterechiusure/:proposalId', loadChildren: './modules/iter-e-chiusure/iter-e-chiusure.module#IterEChiusureModule' },
  { path: 'partiCorrelate/:proposalId', loadChildren: './modules/parti-correlate/parti-correlate.module#PartiCorrelateModule' },
  { path: 'surveyBuilder', loadChildren: './modules/survey-builder/survey-builder.module#SurveyBuilderModule' },
  { path: 'rilevazioneForborne', loadChildren: './modules/rilevazione-forborne/rilevazione-forborne.module#RilevazioneForborneModule' },
  // tslint:disable-next-line: max-line-length
  { path: 'rilevazioneForborne/:proposalId', loadChildren: './modules/rilevazione-forborne/rilevazione-forborne.module#RilevazioneForborneModule' },
  { path: 'sceltaProponente/:proposalId', loadChildren: './modules/scelta-proponente/scelta-proponente.module#SceltaProponenteModule' },
  { path: 'simulazione/:proposalId/modifica/:modifica', loadChildren: './modules/simulations/simulations.module#SimulationsModule' },
  { path: 'abbandona/:proposalId', loadChildren: './modules/abbandona-proposta/abbandona.module#AbbandonaModule' },
  { path: 'errorPage', component: ErrorPageComponent }
];


@NgModule({
  imports: [RouterModule.forRoot(routes, { scrollPositionRestoration: 'top' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
